from __future__ import unicode_literals

from django.db import models

DimZou_article_BaseFields = 'art_id,title,summary,content,author,columns,taxonomy,art_image,taxonomy,publish_time,created,cel_profile_art.updated,is_audit, '

Users_BaseFields = 'user_id,username,handle,personal_image,personal_image_id '