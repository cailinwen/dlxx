//(function($) {
//	$.fn.Trigger = function(option) {
//		var options = $.extend({}, $.fn.Trigger.defaults, option);
//		options.self = $(this);
//		$(this).on('click', function() {
//			var site = $(this).attr('data-site');
//			var Jewel = $(this).parents('.' + site);
//			if (Jewel.hasClass('openToggle')) {
//				Jewel.removeClass('openToggle');
//			} else {
//				$('.openToggle').removeClass('openToggle');
//				Jewel.addClass('openToggle');
//
//				if (typeof options.callback === 'function') {
//					options.callback.call(this, $(this).next());
//				}
//			}
//		});
//		$(window).mouseup(function(evn) {
//			var self = $(evn.target).hasClass('Trigger');
//			var parent = $(evn.target).parents('.Trigger');
//			var frame = $(evn.target).parents(".jewelFlyout");
//			if (!self && parent.length == 0 && frame.length == 0) {
//				setTimeout(function() {
//					$('.openToggle').removeClass('openToggle');
//				}, 0);
//			}
//		});
//	};
//
//	$.fn.Trigger.defaults = {
//		intervalTime : false
//	// 点击jewelFlyout内部是否关闭
//	};
//	
//})(jQuery);