
define('Dimzou', [], function(){
	
	$('.jsArticleNavLink').click(function(){
		var i = $(this).index();
		var main = $(this).parent().next();
		$(this).addClass('selected').siblings('.selected').removeClass('selected');
		main.children().animate({left: -1*i*100+'%'}, 280);
	});
	
	$('#jsdianSlides').children().each(function(i){
		var l = $(this).parent().children().length;
		if (i==0) return ;
		$(this).hide().css({marginLeft: -1*100/l+'%'});
	});
	
	
	var time = setInterval(function(){
		var elem = $('.dianSlideNavItem.selected').next().length ? $('.dianSlideNavItem.selected').next() : $('.dianSlideNavItem').eq(0);
		elem.children().trigger('click', false);
	}, 10000);
	
	$('.jsdianSlideNavLink').click(function(e, bool){
		if (bool) clearInterval(time);
		
		var item = $(this).closest('li');
		var i = item.index();
		if ($('#jsdianSlides').children('.selected').index()==0){
			$('#jsdianSlides').children('.selected').stop().animate({opacity: 0}, 280, function(){$(this).removeClass('selected');});
		}else{
			$('#jsdianSlides').children('.selected').fadeOut(function(){$(this).removeClass('selected');});
		}
		if (i==0){
			$('#jsdianSlides').children().eq(i).stop().animate({opacity: 1}, 280, function(){$(this).addClass('selected');});
		}else{
			$('#jsdianSlides').children().eq(i).fadeIn(function(){$(this).addClass('selected');});
		}
		item.addClass('selected').siblings('.selected').removeClass('selected');
	});
	
	
	$('.jsShowAuditPage').click(function(){
		var full = $(this).attr('name');
		var idAry = full.split('_');
		var current_id = idAry[2];
		var wrap = $('.diWrap'), wrapStyle = wrap.attr('style') || '';
		wrap.data({style: wrapStyle}).css({position: 'fixed',top: -1*$('body').scrollTop()});
		$.get('/dimzou/audit/ajaxGetArtById',{ 'art_id': current_id,'pre':idAry[1],'next':idAry[3] },function (data){
			var dataObj=jQuery.parseJSON(data);
			if(dataObj['status']==1){
				var html = $($.parseJSON(dataObj['data']));
				$('.auditArticleFrame').remove();
				$('body').append(html);
				
				$(html).find('.jsAuditClose').click(function(){
					var top = parseInt($('.diWrap').css('top'))*-1;
					$('.diWrap').attr({style: $('.diWrap').data('style')});
					$(this).closest('.auditArticleFrame').hide();
					$('body').scrollTop(top);
				});
				
				$(window).scroll(auditSwitch);
				$(window).resize(auditSwitch);
				auditSwitch();
				function auditSwitch(){
					if (!$('a.auditPrevButton').length || !$('a.auditNextButton').length) return false;
					$('.jsAuditSwitch').css({position: 'relative',top: $(window).height()/2 + $('body').scrollTop()});
				}
				
				$(html).find('.jsAuditSwitch').click(function(){
				
				});
				
				$('#auditVeto').click(function(){
					$(this).parent().html('<a class="dib auditArticelButton" id="" style="background-color: #44ACE8;" href="javascript:void(0);">确定</a>');
					$('#auditContent').children().mouseenter(function(){
						if ($(this).closest('.auditVetoComments').length) return false;
						$(this).wrap('<div class="auditVetoComments"></div>');
						$(this).after('<div class="auditVetoCommentBox"><textarea class="auditVetoCommentTextarea" placeholder="否决原因？"></textarea></div>');
						$(this).next().find('textarea').focus().autosize();
						
						$(this).parent().mouseleave(removeCommentBox);
					});
					function removeCommentBox(){
						if ($(this).find('textarea').val()!=='') return false;
						$(this).children('p').replaceAll(this);
					}
				});
			}
		});
		
	});
	
});