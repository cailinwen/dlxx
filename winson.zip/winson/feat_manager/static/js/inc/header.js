//(function($){
//	$.fn.Trigger =  function(option){
//		var options = $.extend({}, $.fn.Trigger.defaults, option);
//		options.self = $(this);
//		$(this).on('click', function(){
//			var site = $(this).attr('data-site');
//			var Jewel = $(this).parents('.'+ site);
//			if( Jewel.hasClass('openToggle') ){
//				Jewel.removeClass('openToggle');
//			}else{
//				$('.openToggle').removeClass('openToggle');
//				Jewel.addClass('openToggle');
//				
//				if (typeof options.callback === 'function') {
//					options.callback.call(this, $(this).next());
//				}
//			}
//		});
//		$(window).mouseup(function(evn){
//			var self = $(evn.target).hasClass('Trigger');
//			var parent = $(evn.target).parents('.Trigger');
//			var frame = $(evn.target).parents(".jewelFlyout");
//			var translate = ($(evn.target).is('.translateInput') || $(evn.target).is('.translateSpan')) && $(evn.target).parents('.openToggle').length;
//			if( !self && parent.length == 0 && frame.length == 0 && !translate){
//				setTimeout(function(){$('.openToggle').removeClass('openToggle');}, 0);
//			}
//		});
//	};
//	
//	$.fn.Trigger.defaults = {
//		intervalTime	: 	false	//点击jewelFlyout内部是否关闭
//	};
//	
//})(jQuery);

define('Header', ['/static/js/vendor/jquery.js'], function(){
	function Header(){};
	
	
	$.fn.Trigger =  function(option){
		var options = $.extend({}, $.fn.Trigger.defaults, option);
		options.self = $(this);
		$(this).on('click', function(){
			var site = $(this).attr('data-site');
			var Jewel = $(this).parents('.'+ site);
			if( Jewel.hasClass('openToggle') ){
				Jewel.removeClass('openToggle');
			}else{
				$('.openToggle').removeClass('openToggle');
				Jewel.addClass('openToggle');
				
				if (typeof options.callback === 'function') {
					options.callback.call(this, $(this).next());
				}
			}
		});
		$(window).mouseup(function(evn){
			var self = $(evn.target).hasClass('Trigger');
			var parent = $(evn.target).parents('.Trigger');
			var frame = $(evn.target).parents(".jewelFlyout");
			var translate = ($(evn.target).is('.translateInput') || $(evn.target).is('.translateSpan')) && $(evn.target).parents('.openToggle').length;
			if( !self && parent.length == 0 && frame.length == 0 && !translate){
				setTimeout(function(){$('.openToggle').removeClass('openToggle');}, 0);
			}
		});
	};
	
	$.fn.Trigger.defaults = {
		intervalTime	: 	false	//点击jewelFlyout内部是否关闭
	};
	
	
	Header.prototype.init = function(){
		$('.Trigger').Trigger();
		
		this.hasNextlevel();
	};
	
	Header.prototype.hasNextlevel = function(){
		$('#diClassMenu,.hasNextlevel').mouseenter(function(){
			$(this).addClass('selectedClass');
			if ($(this).hasClass('jsCheckLanguageArea')){
				var diClassMain = $(this).next('.diClassMain');
				var diClassList = diClassMain.children();
				var count = diClassList.children('li').length;
				var cellSpace = $(window).height() - ($(this).offset().top - $(document).scrollTop());
				var cellHeight = diClassList.children().innerHeight();
				var colNum = Math.floor(cellSpace/cellHeight) < 10 ? 10 : Math.floor(cellSpace/cellHeight);
				var rowNum = Math.ceil(count/colNum);
				
				diClassList.addClass('checkHeaderLanguage').css({width: (rowNum*100)+'%'});
				diClassList.children().css({width: (100/rowNum)+'%',float: 'left'});
			}
		});
		
		$('#diClassMenu').mouseleave(function(){
			$(this).removeClass('selectedClass');
		});
		
		$('.hasNextlevel').parent().mouseleave(function(){
			$(this).children('.hasNextlevel').removeClass('selectedClass');
		});
	};
	
	
//	$(document).ready(function () {
//		$("#checkLanguage").click(function () {
//			$.facebox({div: '#f22'});
//			clickLanguage($('#facebox'));
//		});
//	});
	
//	function clickLanguage(elem){
//		$('a.languageLink').not('.unclickStyle').on('click', elem, function(){
//			console.log('languageDisabled');
//			if ($(this).parent().hasClass('languageDisabled')) {
//				return false;
//			}
//			var browseUri = window.location.href;
//			if(browseUri.indexOf('?') > 0){
//				if(browseUri.indexOf('&l=') > 0){
//					browseUri = browseUri.split('&l=')[0];
//				}else if(browseUri.indexOf('?l=') > 0){
//					browseUri = browseUri.split('?l=')[0];
//					window.top.location.href = browseUri+'?l='+$(this).attr('title');
//					return false;
//				}
//				window.top.location.href = browseUri+'&l='+$(this).attr('title');
//			}else{
//				window.top.location.href = browseUri+'?l='+$(this).attr('title');
//			}
//		});
//	}
	
//	$('.dianSearchButton').click(function(){
//		if ($(this).parent().hasClass('showSearch')){
//			$(this).parent().removeClass('showSearch');
//		}else{
//			$(this).parent().addClass('showSearch');
//		}
//	});
	
//	$(document).click(function(e){
//		if (!$(e.target).closest('.dianSearchArea').length && !$('.dianSearchArea').is(e.target)){
//			$('.dianSearchArea').removeClass('showSearch');
//		}
//	});
	
//	$(window).resize(tinyViewport);
//	$(window).ready(tinyViewport);
//	function tinyViewport(){
//		if ($(window).width()<1752){
//			$('html').addClass('tinyViewport');
//		}else{
//			$('html').removeClass('tinyViewport');
//		}
//	}
	
	return new Header;
});

require(['Header'], function(Header){
	Header.init();
});