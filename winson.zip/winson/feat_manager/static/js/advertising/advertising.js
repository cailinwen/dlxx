define('Advertising', ['jquery'], function(){
	
	function Advertising(){
		this.baseUrl = Project.settings.baseUrl;
		this.verify = this.baseUrl+'/ads/audit/verify-operate';
	}
	
	Advertising.prototype.init = function(){
		var _this = this;
		//审核通过
		$('.adsCheckAgree').click(function(){
			var $this = $(this),
				data = { ads_id: $this.closest('.adsItem').attr('data-item'), status : 1 },
				success = function(result){
					if(result.status==1) $this.closest('.adsItem').remove(); 
				};
			_this.ajaxCommit(_this.verify, data,function(){}, success);
		});
		
		//审核否决
		$('.vetoConfirm').click(function(){
			var reason = $('input[name="vetoReason"]').val();
			if(reason == '')  return false;
			var $this = $(this),
				data = { ads_id: $this.closest('.adsItem').attr('data-item'), status : 0, reason: reason },
				success = function(result){
					if(result.status==1) $this.closest('.adsItem').remove(); 
				};
			_this.ajaxCommit(_this.verify,data,function(){},success);
		});
		
		//触发否决缘由面板
		$('.adsCheckVeto').click(function(){
			$(this).toggleClass('Veto');
		});
		//取消否决缘由面板
		$('.vetoCancel').click(function(){
			$(this).parent().parent().prev().trigger('click.frame');
		});
		
		_this.slideAds();
	};
	
	Advertising.prototype.slideAds = function(){
		$('.slideLR').children().click(function(){
			var ul = $(this).parent().prev(),
				index = ul.find('.iconItem.selected').index();
				turn = $(this).hasClass('slideLeft') ? 'left' : 'right';
			if(turn == 'left'){
				if(index == 0) return false;
				index = index - 1;
			}else{
				if(index == ul.children().length - 1)	return false;
				index = index + 1;
			}
			ul.stop().animate({ left: -(index)*100+'%' }, 500, function(){ 
				ul.children().eq(index).addClass('selected').siblings().removeClass('selected');
			});
		});
	};
	
	Advertising.prototype.ajaxCommit = function(url,data,beforeSubmit,submitSuccess){
		$.ajax({
			url : url,
			type : 'POST',
			dataType : 'json',
			beforeSend : beforeSubmit,
			success : submitSuccess,
			data : data
		});
	};
	
	return new Advertising;
});

require(['Advertising'], function(adver){
	adver.init();
});
