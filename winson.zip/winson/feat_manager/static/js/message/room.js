define('Room', ['Mustache', 'User', 'Template', 'Util'], 
		function(Mustache, User, Template, Util) {
	
	function RoomModule() {
		this._currentRoom = {};
		
		this._cacheRoomItem = {
			index: [],
			archive: [],
			other: [],
			unread: []
		};
		
		this._rooms = {};
		this.threadLoaded;
	}
    
    function _createDayFormat(time) {
        var arrayDate = [];
        arrayDate.year = Util.dateFormat('Y', time);
        arrayDate.month = Util.dateFormat('m', time);
        arrayDate.day = Util.dateFormat('d', time);
        arrayDate.houer = Util.dateFormat('H:i a', time);
        arrayDate.week_number = Util.dateFormat('W', time);
        arrayDate.week = Util.dateFormat('D', time);
        arrayDate.month_day = Util.dateFormat('m月d日', time);
        arrayDate.year_month_day = Util.dateFormat('Y-n-j', time);
        return arrayDate;
    }

    function _sendContent(room) {
        var participantList = room.participants,
            currentUser = Project.settings.profile_id;
        
        var message = {};
        if (room.snippet_sender == currentUser) {
        		message.author_name = '你';
        		message.currentUser = true;
        } else {
        		message.currentUser = false;
            for (var j in participantList) {
                if (participantList.hasOwnProperty(j)) {
                    if (room.snippet_sender == participantList[j].id) {
                    		message.author_name = participantList[j].name;
                    }
                }
            }
        }
        
        if (room.snippet === '') {
        		message.hasContent = false;
            if (room.snippet_has_attachments !== undefined &&
                room.snippet_has_attachments) {
            		message.showPhoto = function () {
            			return room.snippet_attachments.type === 'photo';
            		};
            		message.showFile = function () {
            			return room.snippet_attachments.type === 'file';
            		};
            		
            		message.showMessagePhoto = function () {
        				return room.share_type == 'message';
        			};
        			message.showLogPhoto = function () {
        				return room.share_type == 'log';
        			};
            		
                if (room.snippet_attachments.type === 'photo') {
                		message.count = Util.objectLength(room.snippet_attachments.photo);
                } else if (room.snippet_attachments.type === 'file') {
                    message.files = room.snippet_attachments.file;
                }
            }
        } else {
            message.body = Util.escapeHtml(room.snippet);
            message.hasContent = true;
        }

        return Mustache.to_html(Template.Message.Snippet, message);
    }
    
    RoomModule.prototype.init = function() {
    		var self = this; 
    };
    
    RoomModule.prototype.fetchRemoteData = function(uri, data, callback) {
    		var self = this; 
        if (uri === undefined) return false;

        var ajaxCallback = function(result) {
            var parsed = false;
            if (result !== false) {
                parsed = typeof(result) != 'object' ? $.parseJSON(result) : result;
            }
            callback.call(self, parsed);
        };

        return $.ajax({
            url: uri,
            type: 'POST',
            data: data,
            success: ajaxCallback,
            error: function(jqXHR, textStatus, errorThrown) {
                ajaxCallback(false);
            },
            dataType: 'json',
            timeout: 20000
        });
    };

    /** Function: getRooms
     *  获取所有的房间列表
     *
     */
    RoomModule.prototype.getRooms = function() {
        return this._rooms;
    };
    
    /** Function: getRoom
     *  根据房间jid获取房间信息
     *
     * Parameters:
     *   (string) roomJid - 房间jid
     */
    RoomModule.prototype.getRoom = function(roomJid) {
        if (this._rooms[roomJid]) {
            return this._rooms[roomJid];
        }
        return null;
    };
    
    /** Function: getRoomByThreadid
     *  通过房间id获取房间信息
     *
     * Parameters:
     *   (String) thread_id - 房间id
     */
    RoomModule.prototype.getRoomByThreadid = function(thread_id) {
        var rooms = this.getRooms();
        if ($.isEmptyObject(rooms)) return false;

        for (var i in rooms) {
            if (rooms.hasOwnProperty(i) && rooms[i].thread_id == thread_id) {
                return rooms[i];
            }
        }

        return false;
    };

    /** Function: roomSnipperContent
     *  根据房间jid获取房间信息
     *
     * Parameters:
     *   (Object) room - 房间信息
     */
    RoomModule.prototype.roomSnippetContent = function(room) {
        return _sendContent(room);
    };
    
    /** Function: setRoomToLsit
     *  往房间列表中添加内容
     *
     * Parameters:
     *   (Object) room - 房间信息
     */
    RoomModule.prototype.setRoomToList = function(room) {
        if (Util.isEmptyObject(this.getRoom(room.jid))) {
            this._rooms[room.jid] = room;
        }
    };

    RoomModule.prototype.setCurrentRoom = function (room) {
    		this._currentRoom = room;
    };
    
    RoomModule.prototype.getCurrentRoom = function() {
        return this._currentRoom;
    };

    /** Function: getCurrentRoomJid
     *  获取当前房间的jid
     *
     */
    RoomModule.prototype.getCurrentRoomJid = function() {
        return this._currentRoom.jid;
    };

    return new RoomModule;
});