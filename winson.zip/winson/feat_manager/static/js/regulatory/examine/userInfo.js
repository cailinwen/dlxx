	define('UserInfo', [], function () {
		'user strict';
	function UserRelatedInfo(){
		this.navigationObj = $('.navigation_li');
		this.user_id = $('input[name=cur_user]').val();
		this.loadTabUrl = Project.settings.baseUrl+'/uinfo';
		this.container = $('.navigation_showArea');
		this.initTab = false;
	};
	
	/**
	 * 监听事件
	 * @param obj
	 * @param evt
	 * @param method
	 */
	UserRelatedInfo.prototype.addListener = function( obj, evt, method ) {
		var _this = this,
		fn = function(e) {
			method.call(_this, e, this);
		};
		obj.unbind(evt).bind(evt, fn);
	};
	
	/**
	 * ajax提交
	 */
	UserRelatedInfo.prototype.ajaxCommit = function( url, data, submitSuccess, beforeSubmit ) {
		$.ajax({
			url : url,
			type : 'POST',
			dataType : 'json',
			beforeSend : beforeSubmit,
			success : submitSuccess,
			data : data
		});
	};
	
	UserRelatedInfo.prototype.init = function(){
		this.addListener( this.navigationObj, 'click.loadTab', this.loadTab );
		$('.navigation_ul').find('.tabin').trigger('click.loadTab');
		this.viewlog();
		this.opFilterWordStatus();
		this.addFilterWord();
	};
	
	/**
	 * Tab型切换页面
	 */
	UserRelatedInfo.prototype.loadTab = function(e, obj){
		e.preventDefault();
		if ($(obj).hasClass('active') && this.initTab) return false;
		this.initTab = true;
		var _this = this,
			tab = $(obj).attr('data-tab'),
			data = {tab : tab,'id':_this.user_id},
			beforeSubmit = function () {
				$('.navigation_ul li.active').removeClass('active');
				$(obj).addClass('active');
			},
			submitSuccess = function ( result ) {
				if (result.status === 1) {
					_this.container.html(result.data.view);
					window.history.pushState({},0,_this.loadTabUrl+'?id='+_this.user_id+'&tab='+tab);
					_this.viewlog();
					if (tab == 'messages') {
						require(['MessageBundle'], function (Messaging) {
							Messaging.init();
						});
					}else if(tab=='activityLogs' || tab=='friendRequest' || tab=='friends' || tab=='removedFriends'
						|| tab=='loginHistory' || tab=='dimzou'){
						_this.scrollMsc();
					}else if(tab=='experiences'){
						_this.scrollMsc();
						_this.moreExperiShow();
					}else if(tab=='aboutMe'){
						//_this.viewlog();
					}else if(tab=='filterWord'){
						_this.opFilterWordStatus();
					}
					
				}
			};
		_this.ajaxCommit(_this.loadTabUrl, data, submitSuccess, beforeSubmit);	
	};
	
	UserRelatedInfo.prototype.scrollMsc = function(){
		var area = $('.showAreaScroll');
		if(area.children().height()>area.height()){
			area.mCustomScrollbar({
				scrollInertia: 200,
				autoHideScrollbar: true
			});
		}
	};
	
	UserRelatedInfo.prototype.moreExperiShow = function(){
		$('.itemDetailItem').unbind('click.ex').bind('click.ex',function(){
			var experi = $(this).find('.experiDetailShow');
			if(experi.css('display')=='block'){
				experi.slideUp();
				$('.showAreaScroll').mCustomScrollbar('update');
				return false;
			}
			$('.experiDetailShow').not(experi).slideUp();
			experi.slideDown('slow',function(){
				$('.showAreaScroll').mCustomScrollbar('update');
			});
		});
	};
	
	
	UserRelatedInfo.prototype.opFilterWordStatus = function(){
		var _this = this;
		$('.opAction').click(function(){
			var $this = $(this), data = {};
			var	id = $this.attr('data-id'), status = $this.attr('data-status'),
				beforeSubmit = function(){},
				submitSuccess = function(result){
					if(result.status){
						if(result.data == 1){
							$this.text('OFF');
						}else if(result.data == 2){
							$this.text('ON');
						}else if(result.data == 0 || result.data == ''){
							var countObj = $this.closest('.panel').find('.panel-heading span span');
							countObj.text(countObj.text()-1);
							$this.closest('tr').remove();
						}
					}
				};
			if(typeof status!='undefined'){
				data.status = status;
			}
			_this.ajaxCommit('/fword/'+id, data, submitSuccess, beforeSubmit);	
		});
		
	};
	
	var tpl = '<tr class="addfw success"><td>1369</td>'
				+'<td><input type="text" class="form-control" name="fkeyword"></td>'
				+'<td><select class="form-control" name="actionType"><option value="0">禁止</option><option value="1">替换</option><option value="2">审核</option></select></td>'
				+'<td></td>'
				+'<td><button type="button" data-id="" data-status="1" class="saveFword btn btn-primary btn-xs">Save</button></td></tr>';
	
	UserRelatedInfo.prototype.addFilterWord = function(){
		var _this = this, addnum = 0;//统计点击次数
		$('.addFilterWord').click(function(){
			if( !addnum ){
				$(this).closest('.panel').find('tbody').prepend(tpl);
				++addnum;
				$('.saveFword').click(function(){
					var $this = $(this);
					var keyword = $(this).closest('tr').find('input[name=fkeyword]').val(),
						action = $(this).closest('tr').find('select[name=actionType] option:selected').val(),
						url = '/fword/add', data = {};
					if( !keyword ){
						return false;
					}
					data.keyword = keyword;
					var beforeSubmit = function(){ addnum=0; },
						submitSuccess = function(result){
							if(result.status){
								//$this.closest('tr').remove();
							}else{
								alert(result.info);
							}
							$this.closest('tr').remove();
						};
					_this.ajaxCommit(url, data, submitSuccess, beforeSubmit);	
					
					
					
					
					
				});
			}
		});
	};
	
	
	UserRelatedInfo.prototype.viewlog = function(){
		var _this = this, tabAry = [];
		$('.view-log').click(function(){
			var $this = $(this);
			if( typeof tab =='undefined'){
				var tab = $this.attr('data-tab');
				var baseOnObj = $this.closest('.panel').find('table');
			}else{
				var tab = $this.closest('.list-group-item').attr('data-tab');
				var baseOnObj = $this.closest('.list-group-item');
			}
			
			var tabDom = $('.'+tab+'-log');
			if( $.inArray(tab, tabAry)==-1){
				var url = '/ulog/'+Project.settings.profile_id,
				data = {tab:tab},
				beforeSubmit = function(){},
				submitSuccess = function(result){
					if(result.status){
						var arrData =result.data;
						var tpls = $(arrData.html);
						baseOnObj.after(tpls);
						tpls.slideDown();
						$this.text('hide log');
						baseOnObj.css('background-color','#f5f5f5');
						tabAry.push(tab);
					}
				};
				_this.ajaxCommit(url, data, submitSuccess, beforeSubmit);	
			}else{
				if(tabDom.is(':hidden')){
					tabDom.slideDown();
					$this.text('hide log');
					baseOnObj.css('background-color','#f5f5f5');
				}else{
					$this.text('view log');
					baseOnObj.css('background-color','');
					tabDom.slideUp()
				}
			}
		})
	};
	
	
	
	
	
	
	
	
	return new UserRelatedInfo();
	
});