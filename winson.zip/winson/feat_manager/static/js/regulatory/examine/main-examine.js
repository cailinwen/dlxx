/**
 * 
 */

requirejs([ '../config' ], function(config) {
	if(Project.settings.content.page==='search'){
		 require([ 'UserSearch' ], function(UserSearch) {
			UserSearch.init();
		});
	}else{
		require([ 'UserInfo' ], function(UserInfo) {
			UserInfo.init();
		});
	}
	
	
	if(Project.settings.content.curNav=='messages'){
		require(['MessageBundle'], function (Messaging) {
		    Messaging.init();
	   });
	}
	
});
