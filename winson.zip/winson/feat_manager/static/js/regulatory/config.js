/**
 * 
 */
var staticServiceUrl = Project.settings.staticServer+'js/regulatory';
requirejs.config({
	baseUrl : staticServiceUrl,
	paths : {
		Jquery : '../vendor/jquery-2.1.3.min',
		Account : 'account-admin/account',
		Login : 'account-admin/account',
		Mousewheel : '../vendor/jquery.mousewheel',
		CustomScrollbar : '../vendor/jquery.mCustomScrollbar',
		JqueryDatetimepicker : '../vendor/jquery.datetimepicker',
		Mustache : '../vendor/mustache',

		// Message
		Core : '../message/core',
		Room : '../message/room',
		Util : '../message/message.util',
		User : '../message/message.user',
		Template : '../message/message.template',
		MessageController : '../message/message.message',
		MessageRoom : '../message/message.room',
		JqueryHighlight : '../message/jquery.highlight',
		Cluetip : '../message/jquery.cluetip',

		// message view
		Preview : '../message/message.preview',
		MessageBundle : '../message/message.bundle',
		UserSearch : 'examine/userSearch',
		UserInfo : 'examine/userInfo',

	},
	shim : {
		Mousewheel : {
			deps : [ 'Jquery' ],
			exports : 'Mousewheel'

		},
		CustomScrollbar : {
			deps : [ 'Jquery' ],
			exports : 'CustomScrollbar'
		},
		Mustache : {
			deps : [ 'Jquery' ],
			exports : 'Mustache'
		},
		JqueryDatetimepicker : {
			deps : [ 'Jquery' ],
			exports : 'JqueryDatetimepicker'
		}

	}
});
define([ 'Jquery' ], function() {
	return jQuery;
});
