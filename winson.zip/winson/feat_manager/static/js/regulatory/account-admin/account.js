
function ajaxCommit(url,type, data, submitSuccess, beforeSubmit,error){
	$.ajax({
		url : url,
		type : type,
		dataType : 'json',
		beforeSend : beforeSubmit,
		success : submitSuccess,
		data : data,
		error:error
	});
}

define('Login', [''], function(){
	function AccountLogin(){}
	AccountLogin.prototype.init=function(){
		this.login();
	};
	AccountLogin.prototype.login=function(){
		var name, pwd, error = $('.loginError');
		$('.loginButton').unbind('click.login').bind('click.login',function(){
			name = $('input[name="username"]').val();
			pwd = $('input[name="pwd"]').val();
			if (name == '' || pwd == '') {
				error.html('请把信息填写完整.');
				return false;
			}
			ajaxCommit(
				'/login/executeLogin', 'POST',
				{ username : name, password : pwd },
				function(data){
					if(data.status){
						window.location.replace(data.data);
					}else{
						error.html('信息填写不正确.');
					}
				},
				function(){ error.html('&nbsp;'); },
				function(){ error.html('信息填写不正确.'); }
			);
		});
	};
	return new AccountLogin;
});



define('Account', ['Mousewheel','CustomScrollbar'], function(){
	function AccountManage() {
		this.navNeedRequestArray = ['rUsers','rUserLoginRecord','addRuser'];
	}
	
	AccountManage.prototype.init = function(){
		this.transTab();
		this.addUserFun();
		this.userToggleFun();
		this.resetFormFun();
	};
	
	AccountManage.prototype.addUserFun = function(){
		var addUserForm =  $('.addUserForm'), 
			newUserName = addUserForm.find('input[name="username"]'),
			newPwd = addUserForm.find('input[name="pwd"]'),
			reNewPwd = addUserForm.find('input[name="re-pwd"]'),
			newPhone = addUserForm.find('input[name="phone"]'),
			newEmail = addUserForm.find('input[name="email"]'),
			varialLoad = $('.varialLoad'),
			varial = $('.confirmVarial'),
			errorMesg = $('.addError');
			confirmVarial = true;
		
		//检测用户名是否存在
		newUserName.blur(function(){
			var $this = $(this);
			if($(this).val()==''){return false};
			var type= "POST", 
				url= '/register/existUsername',
				data= {username:$(this).val()},
				beforeSend= function(){
					errorMesg.removeClass('hide');
					errorMesg.html('');
		        },
		        success= function(data){
		        		if(data.status==1){
		        			$this.parent().removeClass('has-error').addClass('has-success');
		        			errorMesg.css({'color':'#3c763d'}).html(data.info);
		        		}else{
		        			$this.parent().addClass('has-error');
		        			errorMesg.html(data.info);
		        		}
		        },
		       	error= function(){
		        		errorMesg.html('检测用户名是否存在失败.');
		        };
	        ajaxCommit(url, type, data, success, beforeSend, error)
		});
		
		$('.addButton').unbind('click').bind('click',function(){
			errorMesg.css({'color':'red'})
			if(newUserName.val() == '' || newPwd.val() == ''){
				errorMesg.html('必填项必须填写完整');
				return false;
			}
			
			if(newPwd.val() != reNewPwd.val()){
				errorMesg.html('两次密码不一致');
				return false;
			}
			if(newPhone.val()=='' || !checkPhone(newPhone.val())){
				errorMesg.html('手机号码不正确');
				return false;
			}
			if(newEmail.val()=='' || !checkMail(newEmail.val())){
				errorMesg.html('邮箱格式不正确');
				return false;
			}
			var $this = $(this);
			$.ajax({
		        type: "POST",
		        url: '/register/executeReg',
		        data: addUserForm.serialize(),
		        beforeSend: function(){
		        		errorMesg.html('');
		        },
		        success: function(data){
		        		if(data.status==1){
		        			addUserForm.find('input').val('');
		        			errorMesg.html('');
		        			window.location.assign('/account-manage');
		        		}
		        },
		        error: function(){
		        		errorMesg.html('创建用户失败.');
		        }
		    });
		});
		function checkPhone(phone){
			var reg = /^[0-9]{11}$/;
			return reg.test(phone);
		}
		function checkMail(mail){
			var reg = /^([a-zA-Z0-9]+[_|-|.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|-|.]?)*[a-zA-Z0-9]+.[a-zA-Z]{2,3}$/;
			return reg.test(mail);
		}
	};
	
	AccountManage.prototype.userToggleFun = function(){
		$('.disUser').click(function(){
			var _this = $(this);
			$.post('/account-manage/saveUserStatus',{},function(data){
				_this.addClass('disabled');
				_this.unbind('click');
				_this.closest('tr').html('<td colspan="5" class="text-center h2">NO DATA</td>');
			},'json');
		});
	};
	
	AccountManage.prototype.resetFormFun = function(){
		$(document).on('click.reset','.buttonReset',function(){
			var formStyle = $(this).closest('.addUserForm');
			formStyle.find('input').val('');
			$('.addError').html('');
			if(formStyle.is('form')){
				formStyle.find('select').each(function(){ $(this).get(0).selectedIndex = 0; });
			}else{
				$('.confirmVarial').html('');
				$('.addError').html('');
			}
		});
	};
	
	/**
	 * Ajax提交
	 */
	AccountManage.prototype.ajaxCommit = function(url,type, data, submitSuccess, beforeSubmit) {
		$.ajax({
			url : url,
			type : type,
			dataType : 'json',
			beforeSend : beforeSubmit,
			success : submitSuccess,
			data : data
		});
	};
	
	AccountManage.prototype.recordsFun = function(){
		var _this = this,
			recordForm = $('.userRecordsFrom'),
			recordsList = $('.recordsTableList');
		$('.recordsSubmit').unbind('click.record').bind('click.record',function(){
			var $this = $(this),
				dateRight = _this.checkDate(recordForm);
			if(dateRight){
				$.ajax({
			        type: "POST",
			        url: '',
			        data: recordForm.serialize(),
			        beforeSend: function(){
			        		$this.prev().html('');
			        		$('.listsLoading').removeClass('hide');
			        },
			        success: function(data){
			        		$('.listsLoading').addClass('hide');
			        		recordsList.find('table').html(recordTemple());
			    			recordsList.mCustomScrollbar('update');
			        },
			        error: function(){
			        		$this.prev().html('查询用户失败.');
			        }
			    });
			}else{
				$this.prev().html('查询条件不正确');
			}
		});
	};
	
	AccountManage.prototype.transTab = function(){
		var _this = this;
		var manageItem = $('.manageItem'),
			manageRight = $('.manageRight');
		
		//$('.usersTableList').mCustomScrollbar({});
		$('.recordsTableList').mCustomScrollbar({});
		
		
		//Tab切换
		manageItem.unbind('click.tab').bind('click.tab',function(){
			if($(this).hasClass('active')) return false;
			var $this = $(this),
				index = $this.index(),
				tab = $this.attr('data-tab');
			$this.addClass('active').siblings().removeClass('active');
			if($.inArray(tab, _this.navNeedRequestArray) >-1){
				var url = '/account-manage', type = 'GET', data = {tab:tab}, 
					submitSuccess = function(data){
						data = $.parseJSON(data.data);
						$('.mCustomScrollbar').mCustomScrollbar('destroy');
						manageRight.html(data.viewHtml);
						(index == 0) && _this.userToggleFun(); //$('.usersTableList').mCustomScrollbar({});
						(index == 1) && _this.addUserFun();
						(index == 2) && $('.recordsTableList').mCustomScrollbar({});
						window.history.replaceState({},0,Project.settings.baseUrl+'/account-manage?tab='+tab);
					};
				_this.ajaxCommit(url, type, data, submitSuccess, function(){});
			}
		});
		
		//下属用户状态开启
		//_this.userToggleFun();
		//重置表单
		//_this.resetFormFun();
		//用户查询记录
		//_this.recordsFun();
		
	};
	
	var recordTemple = function(){
		var table;
		for(var $i=0;$i<20;$i++){
			table += '<tr><td>Chritai</td><td>10.0.10.110:880</td><td>2015.02.01</td><td>钟村</td><td>web登录</td></tr>';
		}
	    return table;
	};
	
	AccountManage.prototype.checkDate = function(form){
		var dataRight = true;
		var name = form.find('input[name="loginUserName"]').val(),
			beginY = form.find('select[name="loginBeginYear"]').val(),
			beginM = form.find('select[name="loginBeginMonth"]').val(),
			beginD = form.find('select[name="loginBeginDay"]').val(),
			endY = form.find('select[name="loginEndYear"]').val(),
			endM = form.find('select[name="loginEndMonth"]').val(),
			endD = form.find('select[name="loginEndDay"]').val();
//		console.log(name,beginY,beginM,beginD,endY,endM,endD);
//		console.log(name=='' && beginY==0 && endY==0);
		if(name=='' && beginY==0 && endY==0){
			dataRight = false;
			return dataRight;
		}
//		console.log((beginY==0 && (beginM!=0 || beginD!=0)),(endY==0 && (endM!=0 || endD!=0)));
		if((beginY==0 && (beginM!=0 || beginD!=0)) || (endY==0 && (endM!=0 || endD!=0))){
			dataRight = false;
			return dataRight;
		}
//		console.log((beginM==0 && beginD!=0),(endM==0 && endD!=0));
		if((beginM==0 && beginD!=0) || (endM==0 && endD!=0)){
			dataRight = false;
			return dataRight;
		}
		if(beginY>endY && endY!=0){
			dataRight = false;
		}else if(beginY==endY){
			if(beginM>endM && endM!=0){
				dataRight = false;
			}else if(beginM==endM){
				if(beginD>endD && endD!=0){
					dataRight = false;
				}else if(beginD<endD && beginD==0){
					dataRight = false;
				}
			}else if(beginM<endM && beginM==0){
				dataRight = false;
			}
		}else if(beginY<endY && beginY==0){
			dataRight = false;
		}
		return dataRight;
	};
	
	return new AccountManage;
});