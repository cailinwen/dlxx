(function($) {
	function gh() {
		var navHeight = $('.menu').height();
		var mainHeight = $('.contentInfo').height();
		if (navHeight > mainHeight) {
			$('.contentInfo').height(navHeight);
		} else {
			$('.menu').height(mainHeight);
		}
	}
	
	/**
	 * 点击菜单事件
	 */
	$('.menuItem').click(function() {
		var i = $(this).index(), chTab = $(this).attr('data-tab');
		var record = new recordInfomation(chTab);
		record.init();
		$(this).addClass('selected').siblings('.selected').removeClass(
				'selected');
		$('.featPolicyTab').addClass('hide').eq(i).removeClass('hide');
		gh();
	});
	
	
	
	
	var  recordInfomation = function(item) {
		this.glayout;
		this.item = item;
	};
	
	recordInfomation.prototype.init = function(){
		this.glayout = new dhtmlXLayoutObject({
		        parent: "gridbox",
		        pattern: "1C"
		    });
		this.glayout.cells('a').progressOn();// 等待加载状态
		switch(this.item){
			case 'online_users':
				this.glayout.cells('a').setText("当前在线的用户");
				this.setOnlineUsersGrid();
				break;
			case 'all_user_access_record':
				this.glayout.cells('a').setText("访问记录");
				this.accessRecord();
				break;
			case '':
				break;
			
		}
		
	};
	
	/**
	 * 在线用户Grid
	 */
	recordInfomation.prototype.setOnlineUsersGrid = function() {
		var mygrid = this.glayout.cells('a').attachGrid();
		mygrid.setImagePath("./imgs/"); // the path to images required by grid
		mygrid.setHeader('编号,ID,头像,用户名,登录时间,IP,地点,操作系统,浏览器,分辨率,SESSION');// the headers ofcolumns
		mygrid.setInitWidthsP("4,8,7,10,9,7,10,8,10,7,20"); // the widths of columns  百分比
		mygrid.setColAlign("center,left,center,left,left,left,left,left,left,left,left"); // the alignment of columns
		mygrid.setColTypes("ro,ed,img,ro,ro,ro,ro,ro,ro,ro,ro"); // the types of columns
		mygrid.setColSorting("int,str,str,str,str,str,str,str,str,str,str"); // the sorting types
		mygrid.init(); // finishes initialization and renders the grid on the page
		mygrid.load(Project.settings.baseUrl + '/record/user/loginUser','json');
		this.glayout.cells('a').progressOff();// 关闭等待加载状态
	}
	
	/**
	 * 访问记录Record
	 */
	recordInfomation.prototype.accessRecord = function() {
		var mygrid =this.glayout.cells('a').attachGrid();
		mygrid.setImagePath("./imgs/"); // the path to images required by grid
		mygrid.setHeader('编号,IP,Page,使用语言,地点,访问时间,停留时间,操作系统,浏览器,分辨率');// the headers ofcolumns
		mygrid.setInitWidthsP("6,8,13,10,12,11,8,12,12,8"); // the widths of columns  百分比
		mygrid.setColAlign("center,left,left,left,left,left,center,left,left,left"); // the alignment of columns
		mygrid.setColTypes("ro,ro,ro,ro,ro,ro,ro,ro,ro,ro"); // the types of columns
		mygrid.setColSorting("int,str,str,str,str,str,str,str,str,str"); // the sorting types
		mygrid.init(); // finishes initialization and renders the grid on the page
		mygrid.enableSmartRendering(true,50);
//		mygrid.enablePaging(true,30,null,"pagingArea",true,"recinfoArea");
		mygrid.load(Project.settings.baseUrl + '/record/user/accessRecord','json');
		this.glayout.cells('a').progressOff();// 关闭等待加载状态
	}
	
	
})(jQuery);


