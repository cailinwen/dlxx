define('UserSearch', ['JqueryDatetimepicker','Mustache', 'MCustomScrollbar'], function () {
	'user strict';
	
	function UserSearch() {
		this.loadSearch;
		this.userInforLists = $('.userInforLists');
		this.form = $("#userSearchForm");
		this.searchContainer = $('.userInforListWrap');
	}
	
	function isValidDate(d) {
		if ( Object.prototype.toString.call(d) !== "[object Date]" )
		    return false;
		return !isNaN(d.getTime());
	}
	
	UserSearch.prototype.init = function () {
		//this.dateTimePicker();
		this.tabulationForm($('.tabulationSearch a'));
	};
	
	UserSearch.prototype.loadMoreUser = function() {
		var self = this;
		self.loadSearch = $.ajax({
			url: self.form.get(0).action,
			data: self.form.serialize(),
			dataType: 'json',
			type: 'post',
			success: function (result) {
				if (result.status == '1') {
					$(self.form.start).val(result.data.last);
					self.searchContainer.append(result.data.html);
					if (self.searchContainer.height() <= self.userInforLists.height()) {
						self.loadMoreUser();
					}
				}else{
					console.log("滚动加载出错了。。。");
				}
			}
		});
	};
	
//	UserSearch.prototype.dateTimePicker = function(){
//		 $('#datetimepickerStart').datetimepicker();
//		 $('#datetimepickerEnd').datetimepicker();
//	};
	
	UserSearch.prototype.tabulationForm = function(searchButton){
		var self = this;
		
		searchButton.click(function(e){
			e.preventDefault();
//			var checkStart = new Date(self.form.get(0).timer_start.value),
//				checkEnd = new Date(self.form.get(0).timer_end.value);
//			
//			if ($.trim(self.form.get(0).timer_start.value) != '' && !isValidDate(checkStart) || 
//				checkStart.getFullYear() < 2014 || checkStart.getFullYear() > new Date().getFullYear()) {
//				alert('起始时间不正确');
//				return false;
//			}
//			if ($.trim(self.form.get(0).timer_end.value) != '' && !isValidDate(checkEnd) || 
//					checkEnd.getFullYear() < checkStart.getFullYear() || checkEnd.getFullYear() > new Date().getFullYear()) {
//				alert('结束时间不正确');
//				return false;
//			}
			console.log(self.form.get(0).action);
			self.loadSearch = $.ajax({
				url: self.form.get(0).action,
				data: self.form.serialize(),
				dataType: 'json',
				type: 'post',
				success: function (result) {
					self.searchContainer.empty().append(result.data.html);
					if (result.status == '1') {
						$(self.form.start).val(result.data.last);
//						if (self.searchContainer.height() <= self.userInforLists.height()) {
//							self.loadMoreUser();
//						}
					}
				}
			});
		});
	};

	return new UserSearch;
});

require(['UserSearch'], function(UserSearch){
	UserSearch.init();
});