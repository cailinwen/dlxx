#-*- coding:UTF-8 -*-
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.contrib.auth import logout, authenticate, login
from django.shortcuts import render

def login_check(view_func):
    def _wrapped_view(request,*args,**kwargs):
        if request.user.is_authenticated():
            pass
        else:
            return HttpResponseRedirect("/login")
        return view_func(request, *args, **kwargs)
    return _wrapped_view
    

def login_view(request):
    '''For some testings'''
    print "viewer's IP Address", request.META.get('REMOTE_ADDR')
    
    if request.user.is_authenticated():
        return HttpResponseRedirect("/dimzou")
    
    if request.method == 'POST':
        request.session.flush()
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(email=username,password=password)
        if user is not None:
            if user.is_active:
                login(request,user)
                return HttpResponseRedirect("/dimzou")
            else:
                return HttpResponse("It is a disabled account.")
        else:
            return HttpResponse("There was an error with your Account/Password combination. Please try again.")
    else:
        return render(request, 'login/login.html')

def logout_view(request):
    if request.user.is_authenticated():
        logout(request)
        return HttpResponseRedirect("/dimzou")
    else:
        return HttpResponseRedirect("/login")
    
def auth_check(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username,password=password)
        print user
        if user is not None:
            if user.is_active:
                print "user is active"
                login(request,user)
                return HttpResponse("success")
            else:
                return HttpResponse("error")
        return HttpResponse("error")
    else:
        return HttpResponseRedirect("/login")