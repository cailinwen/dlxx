#-*- coding:UTF-8 -*-
from __future__ import unicode_literals
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser
from django.db import models
from django.utils import timezone

class FeatUserManager(BaseUserManager):
    def create_user(self,username,password=None,level=3,country_code="CN",country_name="China",status=1):
        if not username:
            raise ValueError('Users must have an username')

        now = timezone.now()
        user = self.model(
            username=username,
            created_date=now, updated_date=now,
            level=level,
            country_code=country_code,
            country_name=country_name,
            status=1,
        )
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    def create_superuser(self,username,password):
        user = self.create_user(username,
            password = password,
            level = 1,
        )
        user.is_admin = True
        user.save(using=self._db)
        return user

class FeatUser(AbstractBaseUser):
    username = models.CharField(max_length=50, unique=True)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    country_code = models.CharField(max_length=5,default="CN")
    country_name = models.CharField(max_length=50,default="China") #optional
    status = models.IntegerField(max_length=1,default=1)
    level = models.IntegerField(max_length=1)
    created_date = models.DateTimeField(default=timezone.now)
    updated_date = models.DateTimeField(default=timezone.now)
    created =  models.IntegerField(max_length=11,default=0)
    updated =  models.IntegerField(max_length=11,default=0)
    
    objects = FeatUserManager()
    
    USERNAME_FIELD = 'username'
    #REQUIRED_FIELDS = ['firstname','lastname']
    
    def get_full_name(self):
        full_name =  self.username
        return full_name.strip()

    def get_short_name(self):
        "Returns the short name for the user."
        return self.username
    

    def has_perm(self, perm, obj=None):
        if self.is_active and self.is_admin:   
            return True
    
    def has_module_perms(self, app_label):
        return True
    
    @property
    def is_staff(self):
        return self.is_admin
