#-*- coding:UTF-8 -*-
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.shortcuts import render

def index(request):
    if request.user.is_authenticated():
        return HttpResponseRedirect("/dimzou")
    else:
        return HttpResponseRedirect("/login")