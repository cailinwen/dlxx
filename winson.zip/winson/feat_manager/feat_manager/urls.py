"""feat_manager URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, patterns, include
from django.contrib import admin
from feat_manager import views as main_views
from users import views as users_views

'''Admin pages'''
urlpatterns = [
    url(r'^admin/', admin.site.urls),
]

'''Main pages'''
urlpatterns += [
    url(r'^$', main_views.index, name='Index'),
]

'''dimzou pages'''
urlpatterns += [
    url(r'^dimzou/',include('dimzou.urls')),
]

'''Users pages'''
urlpatterns += [
    url(r'^login/$', users_views.login_view, name='Login'),
    url(r'^logout/$', users_views.logout_view, name='Logout'),
    url(r'^auth/$', users_views.auth_check, name='auth')
]

