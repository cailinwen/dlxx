Ext.onReady(function(){
    Ext.QuickTips.init();
    var globalFromeValue = undefined;
    function formatDate(value){
        return value ? Ext.Date.dateFormat(value, 'M d, Y') : '';
    }

    Ext.define('Plant', {
        extend: 'Ext.data.Model',
        fields: [
            {name:'LE_ID',mapping:'LE_ID'},
            {name: 'LE_NAME',mapping:'LE_NAME'},
            {name:'LE_MAIN_PIC_URL',mapping:'LE_MAIN_PIC_URL'},
            {name:'LE_CODE',mapping:'LE_CODE'},
            {name: 'LE_BARCODE',mapping:'LE_BARCODE'},
            {name: 'LE_QTY',mapping:'LE_QTY'},
            {name:'LE_SPRICE1',mapping:'LE_SPRICE1'},
            {name:'LE_SPRICE',mapping:'LE_SPRICE'},
            {name:'LE_COST',mapping:'LE_COST'},
            {name:'LE_STAT',mapping:'LE_STAT'}
        ]
    });

    var store = Ext.create('Ext.data.Store', {
        autoDestroy: true,
        autoLoad : true,
        model: 'Plant',
        proxy: {
            type: 'ajax',
            url: '/product/commodity/commodityJson',
            reader: {
                type: 'json',
                root:'rows',
                total : 'total'
            }
        }/*,this is remote url store event
        sorters: [{
            property: 'common',
            direction:'ASC'
        }]*/
    });

    //第一品名的下拉数据
    var storeAll =  new Ext.data.Store({
         singleton: true,
         proxy: {
             type: 'ajax',
             url: '/product/commodity/categoryOne',
             reader: {
                 type: 'json',
                 root: 'root'
             }
         },
         fields: ['let_id','let_name'], //不管有没有model，这个fields都必须写，而且只能写在这里，
         autoLoad: true
     });
    storeAll.load();
    //第二品名的下拉数据
    var storeThree = new Ext.data.Store({
         singleton: true,
         proxy: {
             type: 'ajax',
             url: '/product/commodity/categoryTwo',
             reader: {
                 type: 'json',
                 root: 'root'
             }
         },
         fields: ['let_id','let_name'], //不管有没有model，这个fields都必须写，而且只能写在这里，
         autoLoad: false
     });
    storeThree.load();

    var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
        clicksToEdit: 1
    });

    var stateStore = Ext.create('Ext.data.Store', {
        fields : ['code', 'name'],
        data : [{
            name : "上架",
            code : "1"
        }, {
            name : "下架",
            code : "2"
        }]
    });

    var storeDetail = Ext.create('Ext.data.Store', {
        autoDestroy: true,
        autoLoad : true,
        model: 'Plant',
        proxy: {
            type: 'ajax',
            url: '/product/commodity/categoryDetail',
            reader: {
                type: 'json',
                root:'rows',
                total : 'total'
            }
        }
    });

    Ext.define('Plant2',{
        extend:'Ext.data.Model',
        fields:['LE_NAME','LE_CODE','LE_BARCODE','LE_QTY','LE_SECOND_NAME','LE_SHORT_NAME','COUNTRY_NAME','BRAND_NAME_CN','BRAND_NAME','ALIAS',
        'MADE_IN','MFRS_CN','MFRS_EN','PRODUCT_NAME_CN','CARTON','INGREDIENT','BATCH','BUYING_PRICE','BUYING_PRICE_CIF','EMPLOYEE_PRICE','COST_RV',
        'GROSS_RATE_YC','GROSS_AMT_YC','GROSS_RATE_DEALER','GROSS_AMT_DEALER','GROSS_AMT_ALL','GROSS_RATE_ALL','SP_COST','SP_GROSS_RATE_YC','SP_GROSS_AMT_YC',
        'SP_GROSS_RATE_DEALER','SP_GROSS_AMT_DEALER','YT_RRP','YT_PROFIT_AMT_RD_100K','YT_PROFIT_RATE_RD_100K','YT_PROFIT_AMT_RD_CIF','YT_PROFIT_RATE_RD_CIF_MIX',
        'YT_RD_COST','YT_RD_COST_30K','YT_RD_COST_100K','YT_RD_PROFIT_RATE_CUSTOM','YT_CIF_HK_PRICE_MIX_NO_MOQ','YT_CIF_HK_PRICE_MIX_30K','YT_CIF_HK_PRICE_60K',
        'GOODS_STATUS','SUPPLIER_1','SUPPLIER_2','SUPPLIER_3','SUPPLIER_4','SUPPLIER_5','LE_SPRICE3','LE_CROSS_TAX','LE_SPRICE2','LE_TAX','LE_TAX_NO','LE_RATE']
    })

    var gridAll = Ext.create('Ext.form.Panel', {
        frame: false,
        bodyBorder:0,
        autoScroll : true,
        render : Ext.create('Ext.data.JsonReader',{
            root:'rows',
            model:'Plant2'
        }),
        layout: "form", // 整个大的表单是form布局
        labelWidth: 120,
        labelAlign: "right",
        items: [
            {
                xtype: 'container',
                columnWidth: .33,
                style: 'margin:5px',
                layout: 'fit',
                items: [
                    {
                        xtype: 'textfield',
                        name: 'LE_NAME',
                        fieldLabel: "商品名称",
                        style:{'text-align':'right'},
                        readOnly: true
                    }
                ]
            },
            {
                xtype: 'container',
                layout: 'column',
                items: [
                //col第一列
                    {
                        xtype: 'container',
                        columnWidth: .33,
                        style: 'margin:5px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'LE_CODE',
                                fieldLabel: "商品货号",
                                style:{'text-align':'right'},
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_BARCODE',
                                fieldLabel: "商品条形码",
                                style:{'text-align':'right'},
                                readOnly: true,
                                margin: '0 10 10 0'
                            } ,{
                                xtype: 'textfield',
                                name: 'LE_QTY',
                                fieldLabel: "库存",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            } ,{
                                xtype: 'textfield',
                                name: 'MADE_IN',
                                fieldLabel: "原产地",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'PRODUCT_NAME_CN',
                                fieldLabel: "商品名(中文)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'BATCH',
                                fieldLabel: "批次",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'EMPLOYEE_PRICE',
                                fieldLabel: "现货员工价",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'GROSS_AMT_YC',
                                fieldLabel: "毛利额(我司)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'GROSS_AMT_ALL',
                                fieldLabel: "整体毛利额",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SP_GROSS_RATE_YC',
                                fieldLabel: "促销毛利率(我司)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SP_GROSS_AMT_DEALER',
                                fieldLabel: "促销毛利额(经销)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'YT_PROFIT_RATE_RD_100K',
                                fieldLabel: "洋桃代发利润率",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'YT_RD_COST',
                                fieldLabel: "代发供货价(包邮)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'YT_RD_PROFIT_RATE_CUSTOM',
                                fieldLabel: "代发客户利润率",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SUPPLIER_3',
                                fieldLabel: "供应商3",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_SPRICE3',
                                fieldLabel: "BC价",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_TAX',
                                fieldLabel: "CC税率",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            }]
                    },
                     //col第二列
                    {
                        xtype: 'container',
                        columnWidth: .33,
                        //flex: 1,
                        style: 'margin:5px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'LE_SECOND_NAME',
                                fieldLabel: "报关品名",
                                style:{'text-align':'right'},
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_SHORT_NAME',
                                fieldLabel: "面单品名",
                                style:{'text-align':'right'},
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'COUNTRY_NAME',
                                fieldLabel: "国家",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'MFRS_CN',
                                fieldLabel: "厂家名字(中文)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'CARTON',
                                fieldLabel: "箱规",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'BUYING_PRICE',
                                fieldLabel: "进货价",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'COST_RV',
                                fieldLabel: "经销商供货成本",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'GROSS_RATE_DEALER',
                                fieldLabel: "毛利率(经销)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'GROSS_RATE_ALL',
                                fieldLabel: "整体毛利率",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SP_GROSS_AMT_YC',
                                fieldLabel: "促销毛利额(我司)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'YT_RRP',
                                fieldLabel: "洋桃客户建议售价",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'YT_PROFIT_AMT_RD_CIF',
                                fieldLabel: "洋桃CIF利润额",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'YT_CIF_HK_PRICE_60K',
                                fieldLabel: "CIF期货(6万起)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SUPPLIER_1',
                                fieldLabel: "供应商1",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SUPPLIER_4',
                                fieldLabel: "供应商4",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_CROSS_TAX',
                                fieldLabel: "BC税率",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_TAX_NO',
                                fieldLabel: "行邮编码",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            }]
                    },
                     //col第三列
                    {
                        xtype: 'container',
                        columnWidth: .33,
                        //flex: 1,
                        style: 'margin:5px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'BRAND_NAME_CN',
                                fieldLabel: "品牌(中文)",
                                style:{'text-align':'right'},
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'BRAND_NAME',
                                fieldLabel: "品牌(英文)",
                                style:{'text-align':'right'},
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            } ,{
                                xtype: 'textfield',
                                name: 'ALIAS',
                                fieldLabel: "规格",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'MFRS_EN',
                                fieldLabel: "厂家名字(英文)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'INGREDIENT',
                                fieldLabel: "成份",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'BUYING_PRICE_CIF',
                                fieldLabel: "进货到仓价",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'GROSS_RATE_YC',
                                fieldLabel: "毛利率（我司）",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'GROSS_AMT_DEALER',
                                fieldLabel: "毛利额（经销）",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SP_COST',
                                fieldLabel: "促销供货成本",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SP_GROSS_RATE_DEALER',
                                fieldLabel: "促销毛利率(经销)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'YT_PROFIT_AMT_RD_100K',
                                fieldLabel: "洋桃代发利润额",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'YT_PROFIT_RATE_RD_CIF_MIX',
                                fieldLabel: "洋桃CIF利润率",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'GOODS_STATUS',
                                fieldLabel: "商品状态",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SUPPLIER_2',
                                fieldLabel: "供应商2",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SUPPLIER_5',
                                fieldLabel: "供应商5",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_SPRICE2',
                                fieldLabel: "CC价",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_RATE',
                                fieldLabel: "促销利润倍数",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            }]
                    }
                ]
            },{
                xtype: 'container',
                layout: 'column',
                items: [
                //col文本框的字较多久单独写第一列
                    {
                        xtype: 'container',
                        style: 'margin:-10px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'YT_RD_COST_30K',
                                fieldLabel: "代发供货价3万一个月(包邮)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                labelWidth: 155 ,
                                width:390,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 15'
                            },{
                                xtype: 'textfield',
                                labelWidth: 200 ,
                                width:390,
                                name: 'YT_CIF_HK_PRICE_MIX_NO_MOQ',
                                fieldLabel: "CIF-HK现货价(不包邮)混批，无MOQ",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 15'
                            }]
                    },
                     //col文本框的字较多久单独写第二列
                    {
                        xtype: 'container',
                        layout: 'fit',
                        style: 'margin:-10px',
                        items: [{
                                xtype: 'textfield',
                                name: 'YT_RD_COST_100K',
                                fieldLabel: "代发供货价10万一个月(包邮)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                labelWidth: 175 ,
                                width:390,
                                enableKeyEvents: true,
                                margin: '0 10 10 30'
                            },{
                                xtype: 'textfield',
                                name: 'YT_CIF_HK_PRICE_MIX_30K',
                                fieldLabel: "CIF-HK现货价(不包邮)混批,3万",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                labelWidth: 175 ,
                                width:390,
                                enableKeyEvents: true,
                                margin: '0 10 10 30'
                            }]

                    }
                ]
            }
        ]
    });
    var grid = Ext.create('Ext.grid.Panel', {
        store: store,
        layout:"fit",
        listeners:{
            itemdblclick : function(gird,row){
                var leId = row.data.LE_ID
                 Ext.create('widget.window', {
                    title: '总库明细信息',
                    closable : true,
                    closeAction : 'hide',
                    height: 700,
                    width: 1250,
                    layout: 'fit',
                    items: gridAll,
                    listeners : {
                        show:function(win){
                            //你在这里写一个ajax请求
                            Ext.Ajax.request({
                                url: '/product/commodity/categoryDetail?leId='+leId,
                                success: function (response, options) {
                                    var json = Ext.decode(response.responseText);
                                    win.down('form').getForm().setValues(json.rows[0]);
                                },
                                failure: function (response, options) {
                                    Ext.MessageBox.alert('失败', '请求超时或网络故障,错误编号：' + response.status);
                                }
                            });
                        }
                    }
                }).show();
            }
        },
        columns: [
            {
            header: 'LE_ID',
                hidden:true,
            dataIndex: 'LE_ID',
            flex:1
        },{
            header: '商品名称',
            dataIndex: 'LE_NAME',
            flex:1,
            renderer:function(LE_NAME,metadata){
                metadata.tdAttr = "data-qtip='"+LE_NAME+"'";
                return LE_NAME;
            }
        },{
            header: '白底图',
            dataIndex: 'LE_MAIN_PIC_URL',
            renderer:function(value) {
                return '<img src="'+value+'" width=50 height=50/>';
            }
        },{
            header: '商品货号',
            dataIndex: 'LE_CODE',
            flex:1
        },  {
            header: '商品条形码',
            dataIndex: 'LE_BARCODE',
            flex:1
        }, {
            header: '库存',
            dataIndex: 'LE_QTY',
            flex:1
        },{
            header: '洋葱售价',
            dataIndex: 'LE_SPRICE',
            flex:1
        },{
            header: '市场价',
            dataIndex: 'LE_SPRICE1',
            flex:1
        },{
            header: '供货成本',
            dataIndex: 'LE_COST',
            flex:1
        },{
            header: '商品状态',
            dataIndex: 'LE_STAT',
            renderer:function(value) {
                if(value == 1){
                    return '上架';
                }else if(value == 2){
                    return '下架';
                }else{
                    return '--';
                }
            },
            flex:1

        }],
        selModel: {
            selType: 'cellmodel'
        },
        frame: false,
        tbar: [
            {xtype:'label',text:'货号:'},
            {xtype:'textfield',name:'seacheLeCode'},

            {xtype:'label',text:'品名:'},
            {xtype:'textfield',name:'seacheLeName'},

            {xtype:'label',text:'条码:'},
            {xtype:'textfield',name:'seacheBarcode'},

            {xtype:'label',text:'第一品类:'},
            {
             xtype : 'combo',
             queryMode : 'remote',
                name:'first',
             readOnly : false,
             loadingText: '正在加载数据......',
             triggerAction : 'all',
             emptyText : '请选择...',
             store:storeAll,
             hiddenName : 'genus',
             listeners : {
                //控制下一个下拉框值的改变
                change : function(combo){
                    //获取上级toolbar
                    var toolbar_sencond_combo = this.up('toolbar').down('combo[name=second]');
                    var secondComboStore = toolbar_sencond_combo.getStore();
                    var firstComboValue = combo.getValue();
                    toolbar_sencond_combo.clearValue();
                    secondComboStore.load({params:{'letParentId':firstComboValue}});
                }
             },
             valueField : 'let_id',
             displayField : 'let_name',
            },
            {xtype:'label',text:'第二品类:'},
            {
             xtype : 'combo',
             mode : 'local',
			 name:'second', //控件名称
             readOnly : false,
             triggerAction : 'all',
             emptyText : '请选择...',
             store:storeThree,
             hiddenName : 'genus',
                /*listeners : {
					//控制下一个下拉框值的改变
                    change : function(combo){
						//获取上级toolbar
						var toolbar_sencond_combo = this.up('toolbar').down('combo[name=secondAll]');
						var secondComboStore = toolbar_sencond_combo.getStore();
						var firstComboValue = combo.getValue();
						toolbar_sencond_combo.clearValue();
						secondComboStore.load({params:{'letParentIdAll':firstComboValue}});
                    }
                },**/
             valueField : 'let_id',
             displayField : 'let_name'
            },/*{xtype:'label',text:'第三品类:'},
            {
             xtype : 'combo',
             name:'secondAll', //控件名称
             mode : 'local',
             readOnly : false,
             triggerAction : 'all',
             emptyText : '请选择...',
             store: new Ext.data.Store({
                 singleton: true,
                 proxy: {
                     type: 'ajax',
                     url: '/product/commodity/categoryThree',
                     reader: {
                         type: 'json',
                         root: 'root'
                     }
                 },
                 fields: ['let_id','let_name'], //不管有没有model，这个fields都必须写，而且只能写在这里，
                 autoLoad: false
             }),
             hiddenName : 'genus',
             valueField : 'let_id',
             displayField : 'let_name'
            },**/
            {xtype:'label',text:'商品状态:'},
            {
             xtype : 'combo',
             store:stateStore,
             name:'state',
             width : 60,
             labelWidth : 60,
             readOnly : false,
             triggerAction : 'all',
             emptyText : '请选择...',
             displayField : 'name',
             valueField : 'code'
            },
            {xtype:'button',padding:'10px',text:'查询',handler:function(btn){
                var submitProjectType = undefined;
                //第一品名
                var firstValue = btn.up('toolbar').down('combo[name=first]').getValue();
                //第二品名
                var secondVaue = btn.up('toolbar').down('combo[name=second]').getValue();
                if(firstValue){
                    if(secondVaue){
                        submitProjectType = secondVaue;
                    }else{
                        submitProjectType = firstValue;
                    }
                }
                //console.log(btn.up('toolbar').down('textfield[name=seacheName]').getValue(),111);
                var  params = {'seacheLeCode':btn.up('toolbar').down('textfield[name=seacheLeCode]').getValue(),
                               'seacheBarcode':btn.up('toolbar').down('textfield[name=seacheBarcode]').getValue(),
                               'seacheLeName':btn.up('toolbar').down('textfield[name=seacheLeName]').getValue(),
                               'categoryOne':submitProjectType,
                               'state':btn.up('toolbar').down('combo[name=state]').getValue()};
                store.proxy.extraParams = params;
                store.reload();
            }}
            /**,{xtype:'button',padding:'10px',text:"导出"
            }*/
        ],
        dockedItems : [
            {
                xtype:'pagingtoolbar',
                store:store,
                dock : 'bottom',
                displayInof:true,
                emptyMsg:'no records',
                displayMsg:'begin{0} - {1} total{2}',
                pageSize:10

            }
        ],
        plugins: [cellEditing]
    });

    new Ext.Viewport({
        layout:'fit',
        items : [grid]
    });
});
