    //加载功能按钮
    function loadButton(){
        var cId = $("#id").val();
        var userID = $("#userID").val();
        $.ajax({
            url:'/pyonion/loadButtonByResourceId?type='+cId+'&userID='+userID+"&popup="+3,
            type:"json",
            success: function(result) {
                for(var i = 0; i < result.length; i++){
                    $("#dymbButton").append('<button type="button" onclick="'+result[i].url+'" class="jebtn jebtn-blue tool_sobtn rdu4" style="background-image:url('+result[i].imgPath+')">'+result[i].name+'</button>');
                }
            }
        });
    }

      //加载弹出框的按钮
    function loadPopup(btnValue){
        var cId = $("#idAll").val();
        var userID = $("#userIDAll").val();
        $.ajax({
            url:'/pyonion/loadButtonByResourceId?type='+cId+'&userID='+userID+"&popup="+4,
            type:"json",
            success: function(result) {
				var buttonHtml = "";
                for(var i = 0; i < result.length; i++){
                    //$("#popupButton").html('<button type="button" id="confirmId" onclick='+result[i].url+' peon class="jebtn jebtn-blue rdu4"></button>');
                    if(result[i].name == btnValue){
                        buttonHtml += '<button type="button" onclick="'+result[i].url+'" class="jebtn jebtn-blue tool_sobtn rdu4" style="background-image:url('+result[i].imgPath+')">'+result[i].name+'</button>';
                    }
                }
				$("#popupButton").html(buttonHtml);
            }
        });
    }

     //加载弹出框的下拉框按钮控制
    function loadTextBox(btnValue){
        var cId = $("#idAll").val();
        var userID = $("#userIDAll").val();
        $.ajax({
            url:'/pyonion/loadButtonByResourceId?type='+cId+'&userID='+userID+"&popup="+4,
            type:"json",
            success: function(result) {
                var selectHtml = '';
                if(btnValue == '确认商品状态'){
                    selectHtml = '<select class="input"  style="width:120px" id="setchoose"><option value="" selected="selected">请选择类型</option><option value="5">已到港</option><option value="6">已提货</option><option value="7">已入仓</option></select>';
                }
                var buttonHtml = "";
                for(var i = 0; i < result.length; i++){
                    //buttonHtml += '<button type="button" onclick="'+result[i].url+'" class="jebtn jebtn-blue tool_sobtn rdu4" style="background-image:url('+result[i].imgPath+')">'+result[i].name+'</button>';
                    if(result[i].name == '确认商品状态' && btnValue == '确认商品状态'){
                        buttonHtml += '<button type="button" id="purId2" onclick="'+result[i].url+'" peon class="jebtn jebtn-blue rdu4">'+result[i].name+'</button>';
                    }else if(result[i].name == '确认上架' && btnValue == '确认上架'){
                        buttonHtml += '<button type="button" id="shelvesId" onclick="'+result[i].url+'" peon class="jebtn jebtn-blue rdu4">'+result[i].name+'</button>';
                    }
                }
                if(buttonHtml != ""){
                    buttonHtml = selectHtml + buttonHtml;
                }
				$("#productButton").html(buttonHtml);
            }
        });
    }
