// JavaScript Document
$(function(){
	function centinfoHeight(){
		var mainH = $(".ovetouch").height(),
			toolsH = $(".tools").outerHeight(true);
		$(".centinfo").css({height:mainH - toolsH - 20});
    }
	centinfoHeight();
	$(window).resize(function(){
		centinfoHeight()
	})
});
