Ext.onReady(function(){
    Ext.QuickTips.init();
    var globalFromeValue = undefined;
    function formatDate(value){
        return value ? Ext.Date.dateFormat(value, 'M d, Y') : '';
    }

    Ext.define('Plant', {
        extend: 'Ext.data.Model',
        fields: [
            {name:'LE_ID',mapping:'LE_ID'},
            {name: 'LE_NAME',mapping:'LE_NAME'},
            {name:'LE_MAIN_PIC_URL',mapping:'LE_MAIN_PIC_URL'},
            {name:'LE_CODE',mapping:'LE_CODE'},
            {name: 'LE_BARCODE',mapping:'LE_BARCODE'},
            {name: 'LE_QTY',mapping:'LE_QTY'},
            {name:'LE_SPRICE1',mapping:'LE_SPRICE1'},
            {name:'LE_SPRICE',mapping:'LE_SPRICE'},
            {name:'LE_COST',mapping:'LE_COST'},
            {name:'LE_STAT',mapping:'LE_STAT'},
            {name:'SALES_QTY_DAY',mapping:'SALES_QTY_DAY'},
            {name:'SALES_DAYS',mapping:'SALES_DAYS'},
            {name:'STOCK_SALES_RATIO_DAY',mapping:'STOCK_SALES_RATIO_DAY'},
            {name:'STOCK_SALES_RATIO_WEEK',mapping:'STOCK_SALES_RATIO_WEEK'},
            {name:'STOCK_SALES_RATIO_MONTH',mapping:'STOCK_SALES_RATIO_MONTH'},
            {name:'TRANSIT_QTY',mapping:'TRANSIT_QTY'},
            {name:'ARRIVE_DAYS',mapping:'ARRIVE_DAYS'},
            {name:'VIRTUAL_QTY',mapping:'VIRTUAL_QTY'},
            {name:'WARNING1',mapping:'WARNING1'},
            {name:'WARNING2',mapping:'WARNING2'},
            {name:'EST_SALES_DAYS',mapping:'EST_SALES_DAYS'},
            {name:'NORMAL_DAYS',mapping:'NORMAL_DAYS'},
            {name:'COMMON_DAYS',mapping:'COMMON_DAYS'},
            {name:'TOTAL_DAYS',mapping:'TOTAL_DAYS'}
        ]
    });

    var store = Ext.create('Ext.data.Store', {
        autoDestroy: true,
        autoLoad : true,
        model: 'Plant',
        proxy: {
            type: 'ajax',
            url: '/product/orderanalysis/orderanalysisJson',
            reader: {
                type: 'json',
                root:'rows',
                total : 'total'
            }
        }/*,this is remote url store event
        sorters: [{
            property: 'common',
            direction:'ASC'
        }]*/
    });

    //第一品名的下拉数据
    var storeAll =  new Ext.data.Store({
         singleton: true,
         proxy: {
             type: 'ajax',
             url: '/product/commodity/categoryOne',
             reader: {
                 type: 'json',
                 root: 'root'
             }
         },
         fields: ['let_id','let_name'], //不管有没有model，这个fields都必须写，而且只能写在这里，
         autoLoad: true
     });
    storeAll.load();
    //第二品名的下拉数据
    var storeThree = new Ext.data.Store({
         singleton: true,
         proxy: {
             type: 'ajax',
             url: '/product/commodity/categoryTwo',
             reader: {
                 type: 'json',
                 root: 'root'
             }
         },
         fields: ['let_id','let_name'], //不管有没有model，这个fields都必须写，而且只能写在这里，
         autoLoad: false
     });
    storeThree.load();

    var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
        clicksToEdit: 1
    });

    var stateStore = Ext.create('Ext.data.Store', {
        fields : ['code', 'name'],
        data : [{
            name : "上架",
            code : "1"
        }, {
            name : "下架",
            code : "2"
        }]
    });

    var storeDetail = Ext.create('Ext.data.Store', {
        autoDestroy: true,
        autoLoad : true,
        model: 'Plant',
        proxy: {
            type: 'ajax',
            url: '/product/orderanalysis/orderanalysisDetail',
            reader: {
                type: 'json',
                root:'rows',
                total : 'total'
            }
        }
    });
    var gridAll = Ext.create('Ext.form.Panel', {
        frame: false,
        bodyBorder:0,
        autoScroll : true,
        layout: "form", // 整个大的表单是form布局
        labelWidth: 120,
        labelAlign: "right",
        items: [
            {
                xtype: 'container',
                columnWidth: .20,
                style: 'margin:5px',
                layout: 'fit',
                items: [
                    {
                        xtype: 'textfield',
                        name: 'LE_NAME',
                        fieldLabel: "商品名称",
                        style:{'text-align':'right'},
                        readOnly: true
                    }
                ]
            },
            {
                xtype: 'container',
                layout: 'column',
                items: [
                //col第一列
                    {
                        xtype: 'container',
                        columnWidth: .33,
                        style: 'margin:5px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'LE_CODE',
                                fieldLabel: "商品货号",
                                style:{'text-align':'right'},
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_BARCODE',
                                fieldLabel: "商品条形码",
                                style:{'text-align':'right'},
                                readOnly: true,
                                margin: '0 10 10 0'
                            } ,{
                                xtype: 'textfield',
                                name: 'LE_QTY',
                                fieldLabel: "库存",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            } ,{
                                xtype: 'textfield',
                                name: 'SALES_QTY_DAY',
                                fieldLabel: "日销售",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'STOCK_SALES_RATIO_WEEK',
                                fieldLabel: "周库销比",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'ARRIVE_DAYS',
                                fieldLabel: "到货日",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'WARNING2',
                                fieldLabel: "预警2",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'COMMON_DAYS',
                                fieldLabel: "常规提货",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                margin: '0 10 10 0'
                            }]
                    },
                     //col第二列
                    {
                        xtype: 'container',
                        columnWidth: .33,
                        //flex: 1,
                        style: 'margin:5px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'LE_SECOND_NAME',
                                fieldLabel: "报关品名",
                                style:{'text-align':'right'},
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'LE_SHORT_NAME',
                                fieldLabel: "面单品名",
                                style:{'text-align':'right'},
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'COUNTRY_NAME',
                                fieldLabel: "国家",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SALES_DAYS',
                                fieldLabel: "可售天数",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'STOCK_SALES_RATIO_MONTH',
                                fieldLabel: "月库销比",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'VIRTUAL_QTY',
                                fieldLabel: "虚拟库存",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'EST_SALES_DAYS',
                                fieldLabel: "预估销售天数",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'TOTAL_DAYS',
                                fieldLabel: "合共货期",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            }]
                    },
                     //col第三列
                    {
                        xtype: 'container',
                        columnWidth: .33,
                        //flex: 1,
                        style: 'margin:5px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'BRAND_NAME_CN',
                                fieldLabel: "品牌(中文)",
                                style:{'text-align':'right'},
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'BRAND_NAME',
                                fieldLabel: "品牌(英文)",
                                style:{'text-align':'right'},
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            } ,{
                                xtype: 'textfield',
                                name: 'ALIAS',
                                fieldLabel: "规格",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'STOCK_SALES_RATIO_DAY',
                                fieldLabel: "日库销比",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'TRANSIT_QTY',
                                fieldLabel: "在途",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'WARNING1',
                                fieldLabel: "预警",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'NORMAL_DAYS',
                                fieldLabel: "正常货期",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 0'
                            }]
                    }
                ]
            }
            /**,{
                xtype: 'container',
                layout: 'column',
                items: [
                //col文本框的字较多久单独写第一列
                    {
                        xtype: 'container',
                        style: 'margin:-10px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'YT_RD_COST_30K',
                                fieldLabel: "代发供货价3万一个月(包邮)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                labelWidth: 155 ,
                                width:390,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 15'
                            },{
                                xtype: 'textfield',
                                labelWidth: 200 ,
                                width:390,
                                name: 'YT_CIF_HK_PRICE_MIX_NO_MOQ',
                                fieldLabel: "CIF-HK现货价(不包邮)混批，无MOQ",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                enableKeyEvents: true,
                                margin: '0 10 10 15'
                            }]
                    },
                     //col文本框的字较多久单独写第二列
                    {
                        xtype: 'container',
                        layout: 'fit',
                        style: 'margin:-10px',
                        items: [{
                                xtype: 'textfield',
                                name: 'YT_RD_COST_100K',
                                fieldLabel: "代发供货价10万一个月(包邮)",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                labelWidth: 175 ,
                                width:390,
                                enableKeyEvents: true,
                                margin: '0 10 10 30'
                            },{
                                xtype: 'textfield',
                                name: 'YT_CIF_HK_PRICE_MIX_30K',
                                fieldLabel: "CIF-HK现货价(不包邮)混批,3万",
                                style:{'text-align':'right'},
                                allowBlank: false,
                                readOnly: true,
                                labelWidth: 175 ,
                                width:390,
                                enableKeyEvents: true,
                                margin: '0 10 10 30'
                            }]

                    }
                ]
            }*/
        ]
    });
    var grid = Ext.create('Ext.grid.Panel', {
        store: store,
        layout:"fit",
        forceFit: true,
        listeners:{
            itemdblclick : function(gird,row){
                var leId = row.data.LE_ID
                 Ext.create('widget.window', {
                    title: '订货分析明细信息',
                    closable : true,
                    closeAction : 'hide',
                    height: 500,
                    width: 1250,
                    layout: 'fit',
                    items: gridAll,
                    listeners : {
                        show:function(win){
                            //在这里写一个ajax请求
                            Ext.Ajax.request({
                                url: '/product/orderanalysis/orderanalysisDetail?leId='+leId,
                                success: function (response, options) {
                                    var json = Ext.decode(response.responseText);
                                    win.down('form').getForm().setValues(json.rows[0]);
                                }
                            });
                        }
                    }
                }).show();
            }
        },
        columns: [
            {
            header: 'LE_ID',
            hidden:true,
            dataIndex: 'LE_ID',
            flex:1
        },{
            header: '商品名称',
            dataIndex: 'LE_NAME',
            flex:1,
            renderer:function(LE_NAME,metadata){
                metadata.tdAttr = "data-qtip='"+LE_NAME+"'";
                return LE_NAME;
            }
        },{
            header: '白底图',
            dataIndex: 'LE_MAIN_PIC_URL',
            renderer:function(value) {
                return '<img src="'+value+'" width=50 height=50/>';
            }
        },{
            header: '商品货号',
            dataIndex: 'LE_CODE',
            flex:1
        },  {
            header: '商品条形码',
            dataIndex: 'LE_BARCODE',
            flex:1
        },{
            header: '库存',
            dataIndex: 'LE_QTY',
            flex:1
        }, {
            header: '洋葱售价',
            dataIndex: 'LE_SPRICE',
            flex:1
        },{
            header: '市场价',
            dataIndex: 'LE_SPRICE1',
            flex:1
        },{
            header: '供货成本',
            dataIndex: 'LE_COST',
            flex:1
        },{
            header: '商品状态',
            dataIndex: 'LE_STAT',
            renderer:function(value) {
                if(value == 1){
                    return '上架';
                }else if(value == 2){
                    return '下架';
                }else{
                    return '--';
                }
            },
            flex:1

        },{
            header: '日销售',
            dataIndex: 'SALES_QTY_DAY',
            hidden: true,
            flex:1
        },{
            header: '可售天数',
            dataIndex: 'SALES_DAYS',
            hidden: true,
            flex:1
        },{
            header: '日库销比',
            dataIndex: 'STOCK_SALES_RATIO_DAY',
            hidden: true,
            flex:1
        },{
            header: '周库销比',
            dataIndex: 'STOCK_SALES_RATIO_WEEK',
            hidden: true,
            flex:1
        },{
            header: '库销比',
            dataIndex: 'STOCK_SALES_RATIO_MONTH',
            hidden: true,
            flex:1
        },{
            header: '在途',
            dataIndex: 'TRANSIT_QTY',
            hidden: true,
            flex:1
        },{
            header: '到货日',
            dataIndex: 'ARRIVE_DAYS',
            hidden: true,
            flex:1
        },{
            header: '虚拟库存',
            dataIndex: 'VIRTUAL_QTY',
            hidden: true,
            flex:1
        },{
            header: '预警1',
            dataIndex: 'WARNING1',
            hidden: true,
            flex:1
        },{
            header: '预警2',
            dataIndex: 'WARNING2',
            hidden: true,
            flex:1
        },{
            header: '预估销售天数',
            dataIndex: 'EST_SALES_DAYS',
            hidden: true,
            flex:1
        },{
            header: '正常货期',
            dataIndex: 'NORMAL_DAYS',
            hidden: true,
            flex:1
        },{
            header: '常规提货',
            dataIndex: 'COMMON_DAYS',
            hidden: true,
            flex:1
        },{
            header: '合共货期',
            dataIndex: 'TOTAL_DAYS',
            hidden: true,
            flex:1
        }],
        selModel: {
            selType: 'cellmodel'
        },
        frame: false,
        tbar: [
            {xtype:'label',text:'货号:'},
            {xtype:'textfield',name:'seacheLeCode'},

            {xtype:'label',text:'品名:'},
            {xtype:'textfield',name:'seacheLeName'},

            {xtype:'label',text:'条码:'},
            {xtype:'textfield',name:'seacheBarcode'},

            {xtype:'label',text:'第一品类:'},
            {
             xtype : 'combo',
             queryMode : 'remote',
                name:'first',
             readOnly : false,
             loadingText: '正在加载数据......',
             triggerAction : 'all',
             emptyText : '请选择...',
             store:storeAll,
             hiddenName : 'genus',
             listeners : {
                //控制下一个下拉框值的改变
                change : function(combo){
                    //获取上级toolbar
                    var toolbar_sencond_combo = this.up('toolbar').down('combo[name=second]');
                    var secondComboStore = toolbar_sencond_combo.getStore();
                    var firstComboValue = combo.getValue();
                    toolbar_sencond_combo.clearValue();
                    secondComboStore.load({params:{'letParentId':firstComboValue}});
                }
             },
             valueField : 'let_id',
             displayField : 'let_name',
            },
            {xtype:'label',text:'第二品类:'},
            {
             xtype : 'combo',
             mode : 'local',
			 name:'second', //控件名称
             readOnly : false,
             triggerAction : 'all',
             emptyText : '请选择...',
             store:storeThree,
             hiddenName : 'genus',
                /*listeners : {
					//控制下一个下拉框值的改变
                    change : function(combo){
						//获取上级toolbar
						var toolbar_sencond_combo = this.up('toolbar').down('combo[name=secondAll]');
						var secondComboStore = toolbar_sencond_combo.getStore();
						var firstComboValue = combo.getValue();
						toolbar_sencond_combo.clearValue();
						secondComboStore.load({params:{'letParentIdAll':firstComboValue}});
                    }
                },**/
             valueField : 'let_id',
             displayField : 'let_name'
            },/*{xtype:'label',text:'第三品类:'},
            {
             xtype : 'combo',
             name:'secondAll', //控件名称
             mode : 'local',
             readOnly : false,
             triggerAction : 'all',
             emptyText : '请选择...',
             store: new Ext.data.Store({
                 singleton: true,
                 proxy: {
                     type: 'ajax',
                     url: '/product/commodity/categoryThree',
                     reader: {
                         type: 'json',
                         root: 'root'
                     }
                 },
                 fields: ['let_id','let_name'], //不管有没有model，这个fields都必须写，而且只能写在这里，
                 autoLoad: false
             }),
             hiddenName : 'genus',
             valueField : 'let_id',
             displayField : 'let_name'
            },**/
            {xtype:'label',text:'商品状态:'},
            {
             xtype : 'combo',
             store:stateStore,
             name:'state',
             width : 60,
             labelWidth : 60,
             readOnly : false,
             triggerAction : 'all',
             emptyText : '请选择...',
             displayField : 'name',
             valueField : 'code'
            },
            {xtype:'button',padding:'10px',text:'查询',handler:function(btn){
                var submitProjectType = undefined;
                //第一品名
                var firstValue = btn.up('toolbar').down('combo[name=first]').getValue();
                //第二品名
                var secondVaue = btn.up('toolbar').down('combo[name=second]').getValue();
                if(firstValue){
                    if(secondVaue){
                        submitProjectType = secondVaue;
                    }else{
                        submitProjectType = firstValue;
                    }
                }
                //console.log(btn.up('toolbar').down('textfield[name=seacheName]').getValue(),111);
                var  params = {'seacheLeCode':btn.up('toolbar').down('textfield[name=seacheLeCode]').getValue(),
                               'seacheBarcode':btn.up('toolbar').down('textfield[name=seacheBarcode]').getValue(),
                               'seacheLeName':btn.up('toolbar').down('textfield[name=seacheLeName]').getValue(),
                               'categoryOne':submitProjectType,
                               'state':btn.up('toolbar').down('combo[name=state]').getValue()};
                store.proxy.extraParams = params;
                store.reload();
            }}
            /**,{xtype:'button',padding:'10px',text:"导出"
            }*/
        ],
        dockedItems : [
            {
                xtype:'pagingtoolbar',
                store:store,
                dock : 'bottom',
                displayInof:true,
                emptyMsg:'no records',
                displayMsg:'begin{0} - {1} total{2}',
                pageSize:10

            }
        ],
        plugins: [cellEditing]
    });

    new Ext.Viewport({
        layout:'fit',
        items : [grid]
    });
});
