Ext.onReady(function(){
    Ext.QuickTips.init();
    var globalFromeValue = undefined;
    function formatDate(value){
        return value ? Ext.Date.dateFormat(value, 'M d, Y') : '';
    }

    Ext.define('Plant', {
        extend: 'Ext.data.Model',
        fields: [
            {name:'ID',mapping:'ID'},
            {name: 'NAME',mapping:'NAME'},
            {name: 'NAME_EN',mapping:'NAME_EN'},
            {name:'CODE',mapping:'CODE'},
            {name:'COUNTRY_CODE',mapping:'COUNTRY_CODE'},
            {name: 'CATALOG',mapping:'CATALOG'},
            {name: 'ADDRESS',mapping:'ADDRESS'},
            {name:'ZIP',mapping:'ZIP'},
            {name:'CONTACTER',mapping:'CONTACTER'},
            {name:'EMAIL',mapping:'EMAIL'},
            {name:'TEL',mapping:'TEL'},
            {name:'WEIXIN',mapping:'WEIXIN'},
            {name:'QQ',mapping:'QQ'},
            {name:'OTHER_CONTACT',mapping:'OTHER_CONTACT'},
            {name:'CONTACTER2',mapping:'CONTACTER2'},
            {name:'EMAIL2',mapping:'EMAIL2'},
            {name:'TEL2',mapping:'TEL2'},
            {name:'WEIXIN2',mapping:'WEIXIN2'},
            {name:'QQ2',mapping:'QQ2'},
            {name:'OTHER_CONTACT2',mapping:'OTHER_CONTACT2'},
            {name:'CURRENCY',mapping:'CURRENCY'},
            {name:'BANK',mapping:'BANK'},
            {name:'ACCOUNT',mapping:'ACCOUNT'},
            {name:'REMARK',mapping:'REMARK'},
            {name:'PRINCIPAL',mapping:'PRINCIPAL'},
            {name:'SWIFT_CODE',mapping:'SWIFT_CODE'},
            {name:'STATE',mapping:'STATE'}
        ]
    });

     var stateStore = Ext.create('Ext.data.Store', {
        fields : ['code', 'name'],
        data : [{
            name : "合作中",
            code : 1
        }, {
            name : "未合作",
            code : 2
        }]
    });

    var store = Ext.create('Ext.data.Store', {
        autoDestroy: true,
        autoLoad : true,
        model: 'Plant',
        proxy: {
            type: 'ajax',
            url: '/product/supplier/supplierJson',
            reader: {
                type: 'json',
                root:'rows',
                total : 'total'
            }
        }
    });

    var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
        clicksToEdit: 1
    });

    var gridAll = Ext.create('Ext.form.Panel', {
        frame: false,
        bodyBorder:0,
        autoScroll : true,
        layout: "form", // 整个大的表单是form布局
        labelWidth: 120,
        labelAlign: "right",
        items: [
            {
                xtype: 'container',
                columnWidth: .20,
                style: 'margin:5px',
                layout: 'fit',
                items: [
                    {
                        xtype: 'textfield',
                        name: 'NAME',
                        fieldLabel: "供应商中文名称",
                        style:{'text-align':'right'},
                        margin: '0 20 10 0'
                    },{
                        xtype: 'textfield',
                        name: 'ID',
                        hidden: true
                    },{
                        xtype: 'textfield',
                        name: 'NAME_EN',
                        fieldLabel: "供应商英文名称",
                        style:{'text-align':'right'},
                        margin: '0 20 10 0'
                    },
                ]
            },
            {
                xtype: 'container',
                layout: 'column',
                items: [
                //col第一列
                    {
                        xtype: 'container',
                        columnWidth: .33,
                        style: 'margin:5px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'CODE',
                                fieldLabel: "供应商编码",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'COUNTRY_CODE',
                                fieldLabel: "国家代码",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            } ,{
                                xtype: 'textfield',
                                name: 'CATALOG',
                                fieldLabel: "主供商品类别",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            } ,{
                                xtype: 'textfield',
                                name: 'ADDRESS',
                                fieldLabel: "地址",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'ZIP',
                                fieldLabel: "地区编码",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'CONTACTER',
                                fieldLabel: "联系人",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'EMAIL',
                                fieldLabel: "电子邮箱",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'TEL',
                                fieldLabel: "电话",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'SWIFT_CODE',
                                fieldLabel: "SWIFT_CODE",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            }]
                    },
                     //col第二列
                    {
                        xtype: 'container',
                        columnWidth: .33,
                        //flex: 1,
                        style: 'margin:5px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'WEIXIN',
                                fieldLabel: "微信",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'QQ',
                                fieldLabel: "QQ",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'OTHER_CONTACT',
                                fieldLabel: "其他联系方式",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'CONTACTER2',
                                fieldLabel: "第二联系人",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'EMAIL2',
                                fieldLabel: "第二联系人邮箱",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'TEL2',
                                fieldLabel: "第二联系人电话",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'WEIXIN2',
                                fieldLabel: "第二联系人微信",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'QQ2',
                                fieldLabel: "第二联系人QQ",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                fieldLabel : '商品状态',
                                style:{'text-align':'right'},
                                xtype: 'combo',
                                store:stateStore,
                                name: 'STATE',
                                hiddenName:'STATE',
                                editable : false,
                                value : 1,
                                displayField : 'name',
                                valueField : 'code',
                                margin: '0 10 10 0'
                            }]
                    },
                     //col第三列
                    {
                        xtype: 'container',
                        columnWidth: .33,
                        //flex: 1,
                        style: 'margin:5px',
                        layout: 'fit',
                        items: [{
                                xtype: 'textfield',
                                name: 'OTHER_CONTACT2',
                                fieldLabel: "第二联系人其他联系方式",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'CURRENCY',
                                fieldLabel: "使用货币",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            } ,{
                                xtype: 'textfield',
                                name: 'BANK',
                                fieldLabel: "开户银行",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'ACCOUNT',
                                fieldLabel: "银行账号",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'REMARK',
                                fieldLabel: "备注",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            },{
                                xtype: 'textfield',
                                name: 'PRINCIPAL',
                                fieldLabel: "采购责任人",
                                style:{'text-align':'right'},
                                margin: '0 10 10 0'
                            }]
                    }
                ]
            }
        ],
        buttonAlign : "center",
        buttons : [{
            text : "提交",
            handler:function(){
                var form=gridAll.getForm()
                form.submit({
                    url:"/product/supplier/supplierUpdate",
                    method : 'POST',
                    waitMsg:"数据正在提交中......",
                    success:function(response){
                        Ext.Msg.alert("提示","提交成功")
                    },failure : function() {
                        Ext.Msg.alert("提示", "提交失败");
                    }
                })
            }
         }, {
          text : "重置",handler:function(){
            gridAll.getForm().reset();
        }
         }]
    });
    var grid = Ext.create('Ext.grid.Panel', {
        store: store,
        layout:"fit",
        viewConfig:{enableTextSelection:true},
        forceFit: true,
        listeners:{
            itemdblclick : function(gird,row){
                 var orId = row.data.ID
                 Ext.create('widget.window', {
                    title: '供应商信息修改',
                    closable : true,
                    closeAction : 'hide',
                    height: 500,
                    width: 1250,
                    layout: 'fit',
                    items: gridAll,
                    listeners : {
                        close:function(win){
                            win.down('form').getForm().reset();
                        },
                        show:function(win){
                            //在这里写一个ajax请求
                            Ext.Ajax.request({
                                url: '/product/supplier/supplierDetail?orId='+orId,
                                success: function (response, options) {
                                    var json = Ext.decode(response.responseText);
                                    win.down('form').getForm().setValues(json.rows[0]);
                                }
                            });
                        }
                    }
                }).show();
            }
        },
        columns: [
            {
            header: 'ID',
            hidden:true,
            dataIndex: 'ID',
            flex:1
        },{
            header: '供应商中文名称',
            dataIndex: 'NAME',
            flex:1,
            renderer:function(NAME,metadata){
                metadata.tdAttr = "data-qtip='"+NAME+"'";
                return NAME;
            }
        },{
            header: '供应商英文名称',
            dataIndex: 'NAME_EN',
            hidden:true,
            flex:1,
            renderer:function(NAME_EN,metadata){
                metadata.tdAttr = "data-qtip='"+NAME_EN+"'";
                return NAME_EN;
            }
        },  {
            header: '供应商编码',
            dataIndex: 'CODE',
            flex:1
        },{
            header: '国家代码',
            dataIndex: 'COUNTRY_CODE',
            hidden:true,
            flex:1,
            renderer:function(COUNTRY_CODE,metadata){
                metadata.tdAttr = "data-qtip='"+COUNTRY_CODE+"'";
                return COUNTRY_CODE;
            }
        }, {
            header: '主供商品类别',
            dataIndex: 'CATALOG',
            flex:1,
            renderer:function(CATALOG,metadata){
                metadata.tdAttr = "data-qtip='"+CATALOG+"'";
                return CATALOG;
            }
        },{
            header: '地址',
            dataIndex: 'ADDRESS',
            hidden:true,
            flex:1,
            renderer:function(ADDRESS,metadata){
                metadata.tdAttr = "data-qtip='"+ADDRESS+"'";
                return ADDRESS;
            }
        },{
            header: '地区编码(邮政编码)',
            dataIndex: 'ZIP',
            hidden:true,
            flex:1
        },{
            header: '联系人',
            dataIndex: 'CONTACTER',
            flex:1
        },{
            header: '电子邮箱',
            dataIndex: 'EMAIL',
            hidden:true,
            flex:1
        },{
            header: '电话',
            dataIndex: 'TEL',
            hidden:true,
            flex:1
        },{
            header: '微信',
            dataIndex: 'WEIXIN',
            hidden:true,
            flex:1
        },{
            header: 'QQ',
            dataIndex: 'QQ',
            hidden:true,
            flex:1
        },{
            header: '其他联系方式',
            dataIndex: 'OTHER_CONTACT',
            hidden:true,
            hidden: true,
            flex:1
        },{
            header: '第二联系人',
            dataIndex: 'CONTACTER2',
            hidden:true,
            hidden: true,
            flex:1
        },{
            header: '第二联系人电子邮箱',
            dataIndex: 'EMAIL2',
            hidden: true,
            flex:1
        },{
            header: '第二联系人电话',
            dataIndex: 'TEL2',
            hidden: true,
            flex:1
        },{
            header: '第二联系人微信',
            dataIndex: 'WEIXIN2',
            hidden: true,
            flex:1
        },{
            header: '第二联系人QQ',
            dataIndex: 'QQ2',
            hidden: true,
            flex:1
        },{
            header: '第二联系人其他联系方式',
            dataIndex: 'OTHER_CONTACT2',
            hidden: true,
            flex:1
        },{
            header: '使用货币',
            dataIndex: 'CURRENCY',
            hidden:true,
            flex:1
        },{
            header: '开户银行',
            dataIndex: 'BANK',
            hidden:true,
            flex:1
        },{
            header: '银行账号',
            dataIndex: 'ACCOUNT',
            hidden:true,
            flex:1
        },{
            header: '备注',
            dataIndex: 'REMARK',
            hidden:true,
            hidden: true,
            flex:1
        },{
            header: '采购责任人',
            dataIndex: 'PRINCIPAL',
            hidden:true,
            flex:1
        },{
            header: 'SWIFT_CODE',
            dataIndex: 'SWIFT_CODE',
            hidden:true,
            flex:1
        },{
            header: '合作状态',
            dataIndex: 'STATE',
            renderer:function(value) {
                if(value == 1){
                    return '合作中';
                }else if(value == 2){
                    return '未合作';
                }else{
                    return '--';
                }
            },
            flex:1
        }],
        selModel: {
            selType: 'cellmodel'
        },
        frame: false,
        tbar: [
            {xtype:'label',text:'供应商名称:'},
            {xtype:'textfield',name:'supplierName'},

            {xtype:'label',text:'供应商编码:'},
            {xtype:'textfield',name:'supplierCode'},

            {xtype:'button',padding:'10px',text:'查询',handler:function(btn){
                var  params = {'supplierName':btn.up('toolbar').down('textfield[name=supplierName]').getValue(),
                               'supplierCode':btn.up('toolbar').down('textfield[name=supplierCode]').getValue()};
                store.proxy.extraParams = params;
                store.reload();
            }},
            {
                xtype:'button',padding:'10px',text:'新增',
                 handler:function(){
                         Ext.create('widget.window', {
                            title: '供应商信息新增',
                            closable : true,
                            closeAction : 'hide',
                            height: 500,
                            width: 1250,
                            layout: 'fit',
                            items: gridAll
                        }).show();
                }
            }
        ],
        dockedItems : [
            {
                xtype:'pagingtoolbar',
                store:store,
                dock : 'bottom',
                displayInof:true,
                emptyMsg:'no records',
                displayMsg:'begin{0} - {1} total{2}',
                pageSize:10
            }
        ],
        plugins: [cellEditing]
    });

    new Ext.Viewport({
        layout:'fit',
        items : [grid]
    });
});
