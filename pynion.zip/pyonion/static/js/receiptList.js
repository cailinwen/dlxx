Ext.onReady(function(){
    Ext.QuickTips.init();

    function formatDate(value){
        return value ? Ext.Date.dateFormat(value, 'M d, Y') : '';
    }

    Ext.define('Plant', {
        extend: 'Ext.data.Model',
        fields: [
            {name:'customs',mapping:'customs'},
            {name: 'transbillno',mapping:'transbillno'},
            {name: 'orderno',mapping:'orderno'},
            {name:'country',mapping:'country'},
            {name:'status',mapping:'status'},
            {name:'platform',mapping:'platform'},
            {name:'type',mapping:'type'},
            {name:'tax',mapping:'tax'},
            {name:'vat',mapping:'vat'},
            {name:'createTime',mapping:'createTime'}
        ]
    });

    var store = Ext.create('Ext.data.Store', {
        autoDestroy: true,
        autoLoad : true,
        model: 'Plant',
        proxy: {
            type: 'ajax',
            url: '/receipt/receiptJson',
            reader: {
                type: 'json',
                root:'retmsg',
                total : 'total'
            }
        }
    });

    var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
        clicksToEdit: 1
    });
    var grid = Ext.create('Ext.grid.Panel', {
        store: store,
        columns: [
            {xtype:'rownumberer',width:35,header:''}
            ,{
            header: '海关清单号',
            dataIndex: 'customs',
            flex:1,
            renderer:function(customs,metadata){
                metadata.tdAttr = "data-qtip='"+customs+"'";
                return customs;
            }
        },{
            header: '运单号',
            dataIndex: 'transbillno',
            flex:1
        },{
            header: '物流订单号',
            dataIndex: 'orderno',
            flex:1,
            renderer:function(orderno,metadata){
                metadata.tdAttr = "data-qtip='"+orderno+"'";
                return orderno;
            }
        },{
            header: '进境状态',
            dataIndex: 'country',
            flex:1
        },{
            header: '验放指令状态',
            dataIndex: 'status',
            flex:1
        },{
            header: '电商平台备案号',
            dataIndex: 'platform',
            flex:1,
            renderer:function(platform,metadata){
                metadata.tdAttr = "data-qtip='"+platform+"'";
                return platform;
            }
        },{
            header: '清单类型',
            dataIndex: 'type',
            flex:1
        },{
            header: '消费税',
            dataIndex: 'tax',
            flex:1
        },{
            header: '增值税',
            dataIndex: 'vat',
            flex:1
        },{
            header: '清单录入时间',
            dataIndex: 'createTime',
            flex:1,
            renderer:function(createTime,metadata){
                metadata.tdAttr = "data-qtip='"+createTime+"'";
                return createTime;
            }
        }],
        selModel: {
            selType: 'cellmodel'
        },
        frame: false,
        tbar: [

            {xtype:'label',text:'订单号:'},
            {xtype:'textfield',name:'orderSn'},

            {xtype:'button',padding:'10px',text:'查询',handler:function(btn){
                store.removeAll();
                var  params = {'orderSn':btn.up('toolbar').down('textfield[name=orderSn]').getValue()};
                store.proxy.extraParams = params;
                store.reload();
            }}
        ],
        dockedItems : [
            {
                xtype:'pagingtoolbar',
                store:store,
                dock : 'bottom',
                displayInof:true,
                emptyMsg:'no records',
                displayMsg:'begin{0} - {1} total{2}',
                pageSize:25

            }
        ],
        plugins: [cellEditing]
    });

    new Ext.Viewport({
        layout:'fit',
        items : [grid]
    });
});
