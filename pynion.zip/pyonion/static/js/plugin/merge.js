// JavaScript Document
//jQuery美化Select下拉菜单能
(function($){
	$.fn.dropSelect = function(options){				
		var config = {
			 dropCss:"",
			 dropCls:"seleopt",     //下拉列表class名
			 openBox:"dl",          //默认li (可以是标签名或者类名)
			 openCon:"dd",          //默认li (可以是标签名或者类名)
			 diff:2,
			 currCls:"action",      //选中的样式
			 hoveCls:"over",        //移动划过的样式
			 valCls:"seleinp",   //默认传值 (可以是标签名或者类名)
			 zindex:9999,           //层级顺序	
			 column:1,	            //一行几列数字越大列数越多
			 callback:null          //选中点击后的回调函数
		}

		var opts = $.extend(config, options);
		
		this.hide();
		return this.each(function(){
			var thisVal,thisdrop,cIndex=0,Maid=Math.floor(Math.random() * 9999999);
			var that=$(this),valHtml='',openHtml='',conHtml='';
			var opcon =opts.openCon;
            if(opts.dropCss != "" || opts.dropCss !=undefined || opts.dropCss !='undefined'){var dropstyle=opts.dropCss;}else{var dropstyle="";};
			that.after('<div class="'+opts.valCls+'" id="c'+Maid+'" style="'+dropstyle+'">'+that.find('option:selected').text()+'</div>');
			$("body").append('<div class="'+opts.dropCls+'" id="m'+Maid+'"><'+opts.openBox+'>');
		    //用dt替代optgroup，用dd替代option
			var cssCol="width:"+(100/opts.column)+'%';
		    if(that.find('optgroup').length>0){
			   $(this).find('optgroup').each(function(){
				   //html+='<dt>'+$(this).attr('label')+'</dt>';
				   $(this).find('option').each(function(){
						if($(this).is(':selected')){conHtml+='<'+opcon+' class="'+opts.currCls+'" title="'+$(this).text()+'" style="'+cssCol+'">'+$(this).text()+'</'+opcon+'>'; 
						}else{
							conHtml+='<'+opcon+' title="'+$(this).text()+'" optval="'+$(this).attr('value')+'" style="'+cssCol+'">'+$(this).text()+'</'+opcon+'>';
						}                    
				   });
			   });
		    }else{
				   $(this).find('option').each(function(){
					    if($(this).is(':selected')){conHtml+='<'+opcon+' class="'+opts.currCls+'" title="'+$(this).text()+'" style="'+cssCol+'">'+$(this).text()+'</'+opcon+'>'; 
						}else{
							conHtml+='<'+opcon+' title="'+$(this).text()+'" optval="'+$(this).attr('value')+'" style="'+cssCol+'">'+$(this).text()+'</'+opcon+'>';
						}
				   });
		    }
           thisVal=$('#c'+Maid);
		   thisdrop=$('#m'+Maid);
		   thisdrop.find(opts.openBox).append(conHtml);
		   thisdrop.hide();     
		   //弹出模拟下拉列表
		   if(that.is(":disabled")){
			   thisVal.css({"background-color":"#F5F5F5","cursor":"not-allowed"});
		   }else{
			   thisVal.on('click',function(){
				  if(thisdrop.is(":hidden")){
					  thisdrop.css({width:thisVal.outerWidth(),left:thisVal.offset().left,top:(thisVal.offset().top+thisVal.outerHeight(true)+opts.diff),"position":"absolute","z-index":opts.zindex});
					  thisdrop.slideDown(100);
				  }else{ 
					  thisdrop.slideUp(100);
				  }
			   });
		   }
		   $(window).resize(function(){thisdrop.hide();})
		   //模拟列表点击事件-赋值-改变y坐标位置-...
           thisdrop.find(opcon).on('click',function(){
               $(this).addClass(opts.currCls).siblings().removeClass(opts.currCls);
               cIndex=thisdrop.find(opcon).index(this);
               thisVal.text($(this).text());
			   that.val($(this).attr("optval"));
			   that.trigger("change");
			   that.find('option').removeAttr('selected').eq(cIndex).attr('selected','selected');
               thisdrop.slideUp(100); 
			   if(opts.callback!= undefined && typeof opts.callback==="function"){  opts.callback();  }

           }).on('mouseover mouseout',function(event){
			   if(event.type == 'mouseover'){
			       $(this).addClass(opts.hoveCls);
			   }else{
				   $(this).removeClass(opts.hoveCls);
			   }
		   });
		   
           $(document).on('click',function(event){
			   event.stopPropagation();
			   var e = event || window.event;
               var elem = e.srcElement || e.target;
			   if(elem.id=='c'+Maid || elem.id=='m'+Maid){return;}else{ thisdrop.slideUp(200); } 
		    });
		   //取消模块列表处取消默认事件
           thisdrop.on('click',function(ev){  ev.stopPropagation();  });
		})
	};
})(jQuery);

//jeGrid v1.0 表格生成控件
;(function($) {
    $.fn.jeGrid = function(options) {
        var config = {
            dataUrl: null, //用于AJAX内容的URL或对象
            jsonType: "GET", //AJAX请求方式 ("POST" 或 "GET")， 默认为 "GET"。
            jsondataType: "json", //用于AJAX内容的服务器返回的数据类型
            jsonAsync: true, //用于AJAX内容同步或异步加载
            dataRows: "rows", //数据格式类
            columns: null, //表头格式
            columnSort: [], //设定哪些表头可以排序
            colsHtml: [],  //为表格加入一些HTML元素          
            pageIndex: 1, //默认为第一页
			pageSize: 10, //默认每页显示10条
            pageField: ["pageNo", "size"], //用于AJAX分页的分页类型		
			pageCount:["totalPage","total"], //用于分页统计，totalPage为分页总数，total为每页显示多少个，可自定义字段
            pageCell: "#divPage", //分页容器
			pageWord: {
				first: '首页',
				last: '尾页',
				prev: '上一页',
				next: '下一页',
				gotext:'转到',
				oktext:'确定'
			},
			dblclickFun:function(n) {}, //双击行的回调,n为当前序列值
            pageFun: function(n) {}, //点击分页的回调
            success: null //内容加载成功后的回调
        };
        var opts = $.extend(config, options), tabnum = Math.floor(Math.random() * 9999999);
        return this.each(function() {
            var that = $(this);
            var initData = function(index) {
                that.append('<table class="tabledata" id="table' + tabnum + '"><thead><tr></tr></thead><tbody></tbody></table>');
                if (typeof opts.dataUrl == "string") {
					var newsUrl = opts.dataUrl + (opts.dataUrl.indexOf("?") != -1 ? "&" : "?");
                    function pages(n, field) {
                        return opts.pageField[n] == "" || opts.pageField[n] == null || opts.pageField == (null | undefined) ? "" : ((newsUrl.indexOf("?") != -1 && n == 0) ? "" : "&") + opts.pageField[n] + "=" + field;
                    }
                    var pagefield = pages(0, index), pagesize = pages(1, opts.pageSize);
                    $.ajax({
                        url: newsUrl + pagefield + pagesize,
                        type: opts.jsonType,
                        dataType: opts.jsondataType,
                        async: opts.jsonAsync,
						success:function(json) {
						   tdDataHtml(json, index);
						}
                    });
                } else if (typeof opts.dataUrl == "object") {
                    tdDataHtml(opts.dataUrl, index);
                }
            };
            initData(opts.pageIndex);

            function tdDataHtml(data, index) {
                var DataRows = (opts.dataRows == "" || opts.dataRows == null) ? "" : opts.dataRows, thStr = "";
                //生成表头
                $.each(opts.columns, function(i, d) {
                    thStr = "<th>" + d + "</th>";
                    $('#table' + tabnum).find("thead tr").append(thStr);
                });
                //核心部分
                function tdData(colsHtml) {
                    var tdStr = "", drs = DataRows + "[i].";
                    $.each(colsHtml, function(i, e) {
                        var colCell = colsHtml[i].cell == null || colsHtml[i].cell == "" || typeof colsHtml[i].cell == undefined ? "" : "class=" + colsHtml[i].cell + "",
						    colCss = colsHtml[i].css == null || colsHtml[i].css == "" || typeof colsHtml[i].css == undefined ? "" : "style=" + colsHtml[i].css + "",
                            htmlArr = colsHtml[i].html;
						tdStr += "<td " + colCell + " " + colCss + ">" + htmlArr.replace(/\{\@/g, "<=%").replace(/\#\s*/g, drs).replace(/\s*\@\}/g, "%>") + "</td>";
                    });
                    return tdStr;
                }
                //以模板引擎方式生成表格内容
                var tplhtml = "<% for(var i = 0; i < " + DataRows + ".length; i++){ %>" + "<tr>" + tdData(opts.colsHtml) + "</tr>" + "<% } %>";
                tppl(tplhtml, data, function(html) {
                    $('#table' + tabnum).find("tbody").append(html);
                });
                //初始化分页
                opts.pageField == (null | undefined) ? "" : jsPage(opts.pageCell, data[opts.pageCount[0]], data[opts.pageCount[1]], index);
                //点击分页数字跳转
                $(opts.pageCell).find("a").on("click", function() {
                    var thatpage = $(this).data("page");
                    pageDataFun(that, thatpage);
                });
                //输入数字点击确定跳转
                $(opts.pageCell + "-but").on("click", function() {
					var valnum = $(opts.pageCell + "-num").val();
					if(valnum != ''){ 
					    valnum > data[opts.pageCount[0]] ? alert('总页数：'+data[opts.pageCount[0]]+'，不能大于总页数！') : pageDataFun(that, valnum);
					}
                });
                if ($.isFunction(opts.success) || opts.success != ("" || null)) {
                    opts.success && opts.success();
                }

                TableSorter("#table" + tabnum, opts.columnSort); 
                evenAndodd("#table" + tabnum);
				$('#table' + tabnum).find("tbody tr").dblclick(function() {
					var tridx = $(this).index()+1;
					if ($.isFunction(opts.dblclickFun) || opts.dblclickFun != ("" || null)) {
						opts.dblclickFun && opts.dblclickFun(tridx);
					}
				});
            }
            //隔行变色
            function evenAndodd(that) {
                $("tbody tr:odd", that).removeClass("even").addClass("odd"); //隔行变色 奇数行
                $("tbody tr:even", that).removeClass("odd").addClass("even"); //隔行变色 偶数行
            }
            //点击分页的回调
            function pageDataFun(that, page) {
                that.html("");
                $(opts.pageCell).html("");
                initData(page);
                opts.pageField == (null | undefined) ? "" : jsPage(opts.pageCell, data[opts.pageCount[0]], data[opts.pageCount[1]], page);
                if ($.isFunction(opts.pageFun) || opts.pageFun != ("" || null)) {
                    opts.pageFun && opts.pageFun(page);
                }
            }
            //以模板方式调用生成表格数据
            function tppl(tpl, data, fun, fast) {
                var tool = {
                    startTag: "<%", endTag: "%>",
                    error: function(e, tplog) {
                        var error = "jeGrid Error：";
                        typeof console === "object" && console.error(error + e + "\n" + (tplog || ""));
                        return error + e;
                    }
                }
                var Parse = function(tpl, data, fast) {
                    var fn = function(d) {
						var i, k = [], v = [];
						for (i in d) {
							k.push(i);
							v.push(d[i]);
						};
						return (new Function(k, fn.tp)).apply(d, v);                       
                    };
                    if (!fn.tp) {
                        fn.tp = 'var $="";';
                        var tpls = tpl.replace(/[\r\t\n]/g, " ").split(tool.startTag), i = 0;
                        while (i < tpls.length) {
                            var p = tpls[i];
                            if (i) {
                                var x = p.indexOf(tool.endTag);
                                fn.tp += p.substr(0, x);
                                p = p.substr(x + 2)
                            }
                            fn.tp += "$+='" + p.replace(/\'/g, "\\'").replace(/\<\=\%(.*?)\%\>/g, "'+$1+'") + "';";
                            i++;
                        }
                        fn.tp += "return $";
                    }
                    try {
                        return data ? fn(data) : fn;
                    } catch (e) {
                        return tool.error(e, tpl);
                    }
                }
                var html = Parse(tpl, data, fast);
                if (typeof html !== "string") return tool.error("Template not found");
                if (fun === "function" || fun != null) {
                    return fun(html);
                };
            }
            //el:分页容器 count:分页总记录数 pageStep:每页显示多少个 pageNum:第几页 fnGo:分页跳转函数
            function jsPage(el, count, pageStep, pageNum) {
                this.getLink = function(index, pageNum, text) {
                    var text = text || index;
                    var str = (index == pageNum) ? '<span class="acurr">' + text + '</span>' : '<a href="javascript:;" data-page="' + index + '">' + text + '</a>';
                    return str;
                };
                //总页数
                var elCell = el.substr(1), pageNumAll = Math.ceil(count), itemNum = 4;
                //当前页左右两边显示个数
                pageNum = Math.max(pageNum, 1);
                pageNum = Math.min(pageNum, pageNumAll);
                var str = "";
                str += "<span class='pagecount'>" + pageNum + " / " + count + "</span>";
                if (pageNum > 1) {
                    str += this.getLink(pageNum - 1, pageNum, opts.pageWord.prev);
                } else {
                    str += "<span>"+opts.pageWord.prev+"</span> ";
                }
				//str += this.getLink(1, pageNum, opts.pageWord.first);
                var begin = 1;
                if (pageNum - itemNum > 1) {
                    str += this.getLink(1, pageNum) + "<i>… </i>";
                    begin = pageNum - itemNum;
                }
                var end = Math.min(pageNumAll, begin + itemNum * 2);
                if (end == pageNumAll - 1) {
                    end = pageNumAll;
                }
                for (var i = begin; i <= end; i++) {
                    str += this.getLink(i, pageNum);
                }
                if (end < pageNumAll) {
                    str += "<i>… </i>" + this.getLink(pageNumAll, pageNum);
                }
				//str += this.getLink(pageNumAll, pageNum, opts.pageWord.last);
                if (pageNum < pageNumAll) {
                    str += this.getLink(pageNum + 1, pageNum, opts.pageWord.next);
                } else {
                    str += "<span>"+opts.pageWord.next+"</span> ";
                }
                str += '<em>'+opts.pageWord.gotext+'<input class="pagenum" id="' + elCell + '-num" name="pagenum" type="text"/> <input class="pagebut" id="' + elCell + '-but" name="button" type="button" value="'+opts.pageWord.oktext+'"/></em>';
                $(el).html(str);
            }
            //表格排序
            function TableSorter(elem, colSort) {
                $.each(colSort, function(i, d) {
                    $("thead th", elem).eq(d).addClass("sortall").attr("sort", "asc");
                });
                var sortType = '', aTdCont = [], thi = 0; //点击列的索引值
				//判断是否为有效日期
				var isDate = function(str){
					for(var i=0;i<str.length;i++){
						if(str[i].match(/((^((1[8-9]\d{2})|([2-9]\d{3}))([-\/\._])(10|12|0?[13578])([-\/\._])(3[01]|[12][0-9]|0?[1-9])$)|(^((1[8-9]\d{2})|([2-9]\d{3}))([-\/\._])(11|0?[469])([-\/\._])(30|[12][0-9]|0?[1-9])$)|(^((1[8-9]\d{2})|([2-9]\d{3}))([-\/\._])(0?2)([-\/\._])(2[0-8]|1[0-9]|0?[1-9])$)|(^([2468][048]00)([-\/\._])(0?2)([-\/\._])(29)$)|(^([3579][26]00)([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][0][48])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2-9][0-9][0][48])([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][2468][048])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2-9][0-9][2468][048])([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][13579][26])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2-9][0-9][13579][26])([-\/\._])(0?2)([-\/\._])(29)$))/)==null){
						     return false;
						}
					    return true;
					}
				}
				//判断是否为字符串类型(String)
				var isString = function(str){
					for(var i=0;i<str.length;i++){
						return ((typeof str[i] == 'string') && str[i].constructor == String) ? true : false;
					}
				}
				//检查数据为哪种类型
				var variousType = function(aTdCont){
					if(isDate(aTdCont)){
						sortType = "date";
					}else if(isString(aTdCont)){
						for(var i=0;i<aTdCont.length;i++){
							sortType = (/^\d+$/.test(aTdCont[i])) ? "number" : "string";
						}
					}
				}
				//根据类型选择对数据进行排序
				var descAndasc = function(a, b, type, bool) {
					var a, b;
					switch (type) {
					  case "date":
						  var dateSort = function(d1, d2) {
							  if(!isNaN(d1) && !isNaN(d2)){
								  return parseInt(d1) - parseInt(d2);
							  }					  
							  return d1.localeCompare(d2);
						  };
						  return bool == true ? dateSort(a, b) :dateSort(b, a);
						  break;				
					  case "string":
						  if(bool == true){
							  var vsA = a[0] > b[0], vsB = a[0] < b[0];
						  }else{
							  var vsA = a[0] < b[0], vsB = a[0] > b[0];
						  }  
						  if(vsA) return -1;
						  else if (vsB) return 1;
						  else return 0;
						  break;				
					  case "number":
						  return bool == true ? b - a : a - b;
						  break;
					}
				};
                //比较函数的参数函数
                var compare_desc = function(a, b) {
					return descAndasc(a,b,sortType,true);
                };
                var compare_asc = function(a, b) {
					return descAndasc(a,b,sortType,false)
                };
                //重新对TR进行排序
                var reorderIndex = function(idx) {
                    for (i = 0; i < aTdCont.length; i++) {
                        $("tbody tr", elem).each(function() {
                            var thisText = $(this).children("td:eq(" + idx + ")").text();
                            if (thisText == aTdCont[i]) {
                                $("tbody").append($(this));
                            }
                        });
                    }
                    evenAndodd(elem);
                };

                //取出TD的值，并存入数组,取出前二个TD值；
                var setTdCont = function(idx) {
                    $(elem).find("tbody tr").each(function() {
                        var tdCont = $(this).children("td:eq(" + idx + ")").text();
                        aTdCont.push(tdCont);
                    });
                };
                //点击时需要执行的函数
                var clickFun = function(idx) {
                    aTdCont = [];
                    //获取点击当前列的索引值
                    var nThCount = idx;
                    //调用sortTh函数 取出要比较的数据
                    setTdCont(nThCount);
					variousType(aTdCont);

                };
                //点击事件绑定函数，desc表示按倒序排序(即：从大到小排序)，asc表示按正序排序(即：从小到大排序)
                $.each(colSort, function(i, d) {
                    $(elem).find("thead th").eq(d).on("click", function() {
						$(elem).find("thead th").removeClass('sort-desc').removeClass('sort-asc');
                        if ($(this).attr("sort") == "asc") { 
                            $(this).attr("sort", "desc");
                            thi = $(this).index();
                            $(this).addClass("sort-desc");
                            clickFun(thi);							
                            //调用比较函数,降序
							aTdCont.sort(compare_desc);
                            //重新排序行
                            reorderIndex(thi);
                        } else {
                            $(this).attr("sort", "asc");
                            thi = $(this).index();
                            $(this).addClass("sort-asc");
                            clickFun(thi);
                            //调用比较函数,升序
                            aTdCont.sort(compare_asc);
                            //重新排序行
                            reorderIndex(thi);
                        }
                    });
					
                });
            }
        });
    };
})(jQuery);
// jeCombox下拉菜单
;(function($) {
    $.fn.jeCombox = function(options) {
        var config = {
            dataUrl:null,  //用于AJAX内容的URL或对象
            jsonType:"GET",  //AJAX请求方式 ("POST" 或 "GET")， 默认为 "GET"。
            jsondataType:"json",  //用于AJAX内容的服务器返回的数据类型
            jsonAsync:true,  //用于AJAX内容同步或异步加载
			comIndex:[],
			comField:["id","text"],
            wrapCell:"combox",   //目标元素的样式
            openCell:"comopen",  //下拉框的样式
            currCell:"action",  //选中的样式
            hoverCell:"hover",  //移动划过的样式
            openHeight:0,  //限制下拉框的高度并产生滚动条
            isMulti:true,  //是否为多选或单选，默认true为多选
            zindex:150,  //层级顺序
			clickFun:function(index, val) {},
            success:null  //成功后的回调函数
        };
        var opts = $.extend(config, options);
        return this.each(function() {
            var that = $(this), comData = "", comField = opts.comField,
			comMath = Math.floor(Math.random() * 9999999), 
			isValtag = /textarea|input/.test(that.get(0).tagName.toLocaleLowerCase()), 
			initVal = isValtag ? that.val() :that.text(), 
			wraptag = $('<div class="' + opts.wrapCell + '" id="wrap' + comMath + '"></div>'), 
			opentag = $('<div class="' + opts.openCell + '" id="open' + comMath + '"></div>');
            //加载数据
            if (typeof opts.dataUrl == "string") {
                $.ajax({
                    url:opts.dataUrl,
                    type:opts.jsonType,
                    dataType:opts.jsondataType,
                    async:opts.jsonAsync,
                    success:function(json) {
                       comData = json;
					}
                });
            } else if (typeof opts.dataUrl == "object") {
                comData = opts.dataUrl;
            }
            //把目标元素包裹起来
            that.wrap(wraptag);
            //把数据列表出来
            var listHtml = "";
            $.each(comData, function(i, k) {
                listHtml += (comData[i][comField[0]] == undefined || comData[i][comField[0]] == "") ? "<li>" + comData[i][comField[1]] + "</li>" :'<li data-comval="' + comData[i][comField[0]] + '">' + comData[i][comField[1]] + "</li>";
            });
            $(document.body).append(opentag.append("<ul>" + listHtml + "</ul>").hide());
            var wrapdrop = $("#wrap" + comMath), comdrop = $("#open" + comMath);
            //方位辨别
            var dropOrien = function(wrapCell, openCell) {
                var lefts = "", tops = "", rect = wrapCell.offset(), 
				wrapH = wrapCell.outerHeight(), wrapW = wrapCell.outerWidth(), 
				openH = openCell.outerHeight(), openW = openCell.outerWidth();
                if (openH > rect.top && openW > rect.left) {
                    lefts = rect.left;
                    tops = rect.top + wrapH + 2;
                } else if (openH > rect.top && openW + rect.left + wrapW > $(document).innerWidth()) {
                    lefts = rect.left - 2 * wrapW;
                    tops = rect.top + wrapH + 2;
                } else if (openH + rect.top + wrapH > $(document).innerHeight() && openW > rect.left) {
                    lefts = rect.left;
                    tops = rect.top - openH - 2;
                } else if (openH + rect.top + wrapH > $(document).innerHeight() && openW + rect.left + wrapW > $(document).innerWidth()) {
                    lefts = rect.left - 2 * wrapW;
                    tops = rect.top - openH - 2;
                } else if (openH > rect.top || openW > rect.left) {
                    lefts = rect.left;
                    tops = rect.top + wrapH + 2;
                } else {
                    lefts = rect.left - 2 * wrapW;
                    tops = rect.top - openH - 2;
                }
                comdrop.css({
                    width:wrapCell.innerWidth(),
                    height:opts.openHeight == 0 || opts.openHeight == "auto" ? "auto" :opts.openHeight,
                    left:lefts,
                    top:tops,
                    overflow:"auto",
                    position:"absolute",
                    "z-index":opts.zindex
                });
            };
            //点击目标元素后弹出列表出来的数据
            wrapdrop.on("click", function() {
                if (comdrop.is(":hidden")) {
                    dropOrien(wrapdrop, comdrop);
                    comdrop.show();
                } else {
                    comdrop.hide();
                }
            });
            $(window).resize(function() {
                dropOrien(wrapdrop);
            });
            //初始化对目标元素进行赋值样式名
			if (opts.isMulti) {
				var idxSelected = [];  
				$.each(opts.comIndex, function(i, val) {		
					idxSelected.push(comdrop.find("li").eq(val).text())	
					comdrop.find("li").eq(val-1).addClass(opts.currCell);	
					isValtag ? that.val(idxSelected) : that.text(idxSelected);
				});
			}else{ 
				if(opts.comIndex.length == 0 && (isValtag ? that.val() : that.text()) != ""){
					$.each(initVal.split(","), function(i, val) {
						$.each(comdrop.find("li"), function() {
							if (val == $(this).text()) $(this).addClass(opts.currCell);
						});
					});				
				}
		    }
			//是否可以多选
			comdrop.on("click", "li", function() {
				if (opts.isMulti) {   //多选状态，选中后赋值
					var vals = [], idx = [];
					$(this).hasClass(opts.currCell) ? $(this).removeClass(opts.currCell) :$(this).addClass(opts.currCell);
					comdrop.find("." + opts.currCell).each(function() {
						vals.push($(this).text());
						idx.push($(this).index()+1);
					});
				} else {  //单选状态，选中后赋值
					var vals = $(this).text(), idx = $(this).index();
					comdrop.hide();                    
					$(this).addClass(opts.currCell).siblings().removeClass(opts.currCell);
				}
				isValtag ? that.val(vals) :that.text(vals);
				if ($.isFunction(opts.clickFun) || opts.clickFun != ("" || null)) {
					opts.clickFun && opts.clickFun(idx, vals);
				}
			}).on("mouseover mouseout", "li", function(event) {
                if (event.type == "mouseover") {
                    $(this).addClass(opts.hoverCell);
                } else {
                    $(this).removeClass(opts.hoverCell);
                }
            });
            //加载完成后的回调函数
            if ($.isFunction(opts.success) || opts.success != ("" || null)) {
                opts.success && opts.success();
            }
            //点击空白或其他部分收起展开的DIV
            $(document).bind("click", function(event) {
                var target = $(event.target);
                if (target.closest("#wrap" + comMath + ",#open" + comMath + "").length == 0) {
                    comdrop.hide();
                }
                event.stopPropagation();
            });
        });
    };
})(window.jQuery || window.$);
//三级联动
;(function($){
	$.fn.linkSelect=function(options){
		var config={
			listData:listData,
			mainCell:["#aPro","#aCity","#aArea"],
			openBox:["#ListPro","#ListCity","#ListArea"],
			openCls:'.seltopen',
			mainText:["请选省级","请选城市","请选县区"],
			overCell:["over","action"]
		};
		var opts=$.extend(config,options);
		return this.each(function(){
			var linkageData=opts.listData, maCls=opts.mainCell, opCls=opts.openBox, maTxt=opts.mainText, ovCls=opts.overCell, dataJson;
			var mac0 = maCls[0], mac1 = maCls[1], mac2 = maCls[2], opc0 = opCls[0], opc1 = opCls[1], opc2 = opCls[2], ovc0 = ovCls[0], ovc1 = ovCls[1];
			var linecon, oneVal=$(mac0).data("value"), twoVal=$(mac1).data("value"), threeVal=$(mac2).data("value");
			var lineHtml = function(i,t){return "<p openid='" + i + "' title='" + t + "'>" + t + "</p>"};
			if (typeof linkageData === 'string') {
				$.getJSON(linkageData, function(json){
					dataJson = json;
				});
			} else if (typeof linkageData === 'object') {
				dataJson = linkageData;
			};

			$.each(maCls,function (k, p) {
				$(p).html(maTxt[k]);
				var linecon = "<p openid='" + (k+1) + "' title='" + maTxt[k] + "'>" + maTxt[k] + "</p>";
				var LineBoxHtml=$("<div id='" + opCls[k].replace('#','') + "' class='"+(opts.openCls.replace('.',''))+"'>"+linecon+"</div>");
				LineBoxHtml.css({left:$(p).position().left,top:($(p).position().top+$(p).outerHeight(true)+2),"position":"absolute"}).hide();
				$(window).resize(function(){
					LineBoxHtml.css({left:$(p).position().left,top:($(p).position().top+$(p).outerHeight(true)+2),"position":"absolute"}).hide();
				});
				$(document.body).append(LineBoxHtml);
			});

			$.each(dataJson, function (k, p) {
				var that=$(this),twoData=p.s;
				if(oneVal!=null){
					$(mac0).text(oneVal);
					$(opc0).append(lineHtml("1"+k,p.n));
					if(oneVal==p.n){
						$(opc0).find("p[openid='1"+k+"']").addClass(ovc1);
						$.each(twoData,function(k,p){
							var threeData=p.s;
							if(twoVal!=null){
								$(mac1).text(twoVal);
								$(opc1).append(lineHtml("2"+k,p.n));
								if(twoVal==p.n){
									$(opc1).find("p[openid='2"+k+"']").addClass(ovc1);
									$.each(threeData,function(k,p){
										if(threeVal!=null){
											$(mac2).text(threeVal);
											$(opc2).append(lineHtml("3"+k,p.n));
											if(threeVal==p.n){
												$(opc2).find("p[openid='3"+k+"']").addClass(ovc1);
											}
										}
									})
								}
							}
						})
					}
				}else{
					$(opc0).append(lineHtml("1"+k,p.n));
				}
			});

			$(mac0).on("click", function (e) {
				e.stopPropagation();
				$(opc0).is(":hidden") ? $(opc0).show() : $(opc0).hide();
				$(opc1).hide();    $(opc2).hide();
			});
			$(opc0).on('click',"p",function () {
				$(mac0).text($(this).text());
				$(opc0).hide();
				$(opc1).find("p").remove();
				$(opc2).find("p").remove();
				$(opc1).html(lineHtml(2, maTxt[1]));
				$(opc2).html(lineHtml(3, maTxt[2]));
				$(mac1).text(maTxt[1]);
				$(mac2).text(maTxt[2]);
				var flag = true, that = $(this);
				$.each(dataJson,function(k,p){
					var twoData=p.s;
					if(flag){
						if(that.text()==p.n){
							flag = false;
							$.each(twoData,function(k,p){
								$(opc1).append(lineHtml("2"+k,p.n));
							})
						}
					}
				});
				$(this).addClass(ovc1).siblings().removeClass(ovc1);
			}).on('mouseover mouseout','p',function(event){
				if(event.type == 'mouseover'){
					$(this).addClass(ovc0);}else{$(this).removeClass(ovc0);}
				}
			);

			$(mac1).on("click", function (e) {
				e.stopPropagation();
				$(opc1).is(":hidden") ? $(opc1).show() : $(opc1).hide();
				$(opc0).hide();    $(opc2).hide();
			});
			$(opc1).on('click',"p",function () {
				$(mac1).text($(this).text());
				$(opc1).hide();
				$(opc2).find("p").remove();
				$(opc2).html(lineHtml(3, maTxt[2]));
				$(mac2).text(maTxt[2]);
				var flag = true, that = $(this);
				$.each(dataJson,function(k,p){
					var twoData=p.s;
					if(flag){
						if($(mac0).text()==p.n){
							flag = false;
							$.each(twoData,function(k,p){
								var threeData=p.s;
								if(that.text()==p.n && threeData){
									$.each(threeData,function(k,p){
										$(opc2).append(lineHtml("3"+k,p.n));
									})
								}
							})
						}
					}
				});
				$(this).addClass(ovc1).siblings().removeClass(ovc1);
			}).on('mouseover mouseout','p',function(event){
				if(event.type == 'mouseover'){
					$(this).addClass(ovc0);}else{$(this).removeClass(ovc0);}
				}
			);

			$(mac2).on("click", function (e) {
				e.stopPropagation();
				$(opc2).is(":hidden") ? $(opc2).show() : $(opc2).hide();
				$(opc0).hide();    $(opc1).hide();
			});
			$(opc2).on('click',"p",function () {
				$(mac2).text($(this).text());
				$(opc2).hide();
				$(this).addClass(ovc1).siblings().removeClass(ovc1);
			}).on('mouseover mouseout','p',function(event){
				if(event.type == 'mouseover'){
					$(this).addClass(ovc0);}else{$(this).removeClass(ovc0);}
				}
			);

			$(document).on("click",function(){
				$.each(maCls,function (i) {
					if($(opCls[i]).is(":visible")){
						$(opCls[i]).hide();
					}
				})
			});

		});
	};
})(jQuery);

//弹出类型的气泡提示
(function($) { 
	$.fn.showTips = function(options,elem){
		var config = {
			skin:"trips",
			content:$(this).attr("tips")||"弹出类型的气泡提示！",  //气泡提示内容里面可以是HTML，默认显示自定义的提示内容
			width:"auto",  //默认为auto，可以写具体尺寸如：200
			alignTo:["right","center"],  //箭头方向
			color:["rgb(247, 206, 57)","#FFFEF4"],  //这里是提示层的风格，第一个参数为提示边框颜色，第二个参数为提示背景颜色
			type:"html",   //显示内容类型
			trigger:"click",    //默认为点击显示，show为初始化就显示，hover为经过显示，focus焦点显示，mouse跟随鼠标显示隐藏
			spacing:10,  //默认为箭头距离对象的尺寸
			customid:"",  //自定义ID
			isclose:false,   //是否显示关闭按钮
			success : null    //成功后的回调函数
		};
		var opts = $.extend(config, options);
		return this.each(function(){
			var that = $(this),tipBox,tipId,selfH,selfW,conId,docW, spa = opts.spacing, skin=opts.skin;	
			var Mathrandom = Math.floor(Math.random() * 9999999);
            var pmr = (opts.customid=="") ? Mathrandom :opts.customid.replace(/[#.]/, "");
			var pointer=opts.alignTo.length===1 ? ''+opts.alignTo[0]+'' : ''+opts.alignTo[0]+'-'+opts.alignTo[1]+'';
			
			if(typeof elem == 'string') {
				if(elem =="show"){
					$('#tip'+pmr).show();  $("#con"+pmr).html(opts.content);
					calculate(pointer,$('#tip'+pmr));
					};
				if(elem =="hide"){$('#tip'+pmr).hide()};
			};
			if(typeof elem == '' || typeof elem == undefined){return true};
			if($('#tip'+pmr).length==1){return false;}
			tipBox=$('<div class="'+skin+' '+skin+'-'+pointer+'" id="tip'+pmr+'"><i></i><em></em><div class="'+skin+'con" id="con'+pmr+'"></div></div>').appendTo(document.body);
			tipId = $("#tip"+pmr);	
			conId = $("#con"+pmr);
			
			var edgecolor='border-'+opts.alignTo[0]+'-color';
			tipId.css({'position':'absolute',border:'1px solid','border-color':opts.color[0],'background-color':opts.color[1]});
			if(opts.alignTo[1]=='center'){ var offpos=50,percen="%"; }else{ var offpos=5,percen="px"; };
			tipId.find("i,em").css({width:0,height:0,content:'','position':'absolute'})
			tipId.find("i").css({border:'8px solid transparent','z-index':5});
			tipId.find("em").css({border:'7px solid transparent','z-index':10});
			if(pointer=='top-center' || pointer=='bottom-center' || pointer=='top-left' || pointer=='bottom-left'){
				var poi="left";
				if(pointer=='top-center' || pointer=='bottom-center'){
					tipId.find("i").css({"margin-left":"-8px"});
					tipId.find("em").css({"margin-left":"-7px"});
				}
			}else if(pointer=='left-center' || pointer=='right-center' ||  pointer=='left-top'|| pointer=='right-top'){
				var poi="top";
				if(pointer=='left-center' || pointer=='right-center'){
					tipId.find("i").css({"margin-top":"-8px"});
					tipId.find("em").css({"margin-top":"-7px"});
				}
			}else{
				var poi="right";
			};
			if(pointer=='follow'){
				tipId.find("i").css({'border-bottom-color':opts.color[0],left:''+offpos+percen+'',bottom:'100%'});
				tipId.find("em").css({'border-bottom-color':opts.color[1],left:''+(offpos+(opts.alignTo[1]=='center'?0:1))+percen+'',bottom:'100%'});
			}else{
				tipId.find("i").css(edgecolor,opts.color[0]).css(poi,''+offpos+percen+'');
				tipId.find("em").css(edgecolor,opts.color[1]).css(poi,''+(offpos+(opts.alignTo[1]=='center'?0:1))+percen+'');
				tipId.find("i,em").css(opts.alignTo[0],'100%');
			};
	
			switch (opts.type) {
				case 'html':conId.html(opts.content); break;
				case 'id'  :
				    var tempid=$(opts.content) ,wrap = document.createElement("div");
					if(tempid.css("display") == "none"){  tempid.css({display:"block"}); }
					conId.append(tempid);		
				    break;
			};
			if(opts.isclose){
				$('<span class="'+skin+'close" id="close'+pmr+'">&times;</span>').appendTo(tipId);
				tipId.find("#close"+pmr+"").on("click",function(){tipId.hide();});
			}
			
			if(typeof opts.width === 'string'){
				docW = parseInt(document.body.clientWidth*(opts.width.replace('%','')/100));
				(typeof opts.width == 'auto' || typeof opts.width == '') ? tipBox.css({width:'auto'}) : tipBox.css({width:docW});
				tipBox.height();
			}else{
				tipBox.width(opts.width).height();
			}		
            function calculate(pointer,cell){
				var selfH = that.outerHeight(true), selfW = that.outerWidth(true);
				var post=that.offset().top, posl=that.offset().left;
				var tipCell=(cell=="" || cell==undefined) ? tipId : cell;
			    var tipH=tipCell.outerHeight(true), tipW=tipCell.outerWidth(true); 

				switch (pointer) {
					case 'top-left': tipCell.css({top:post-tipH-spa,left:posl}); break;
					case 'top-center': tipCell.css({top:post-tipH-spa,left:posl-(tipW/2)+(selfW/2)}); break;	
					case 'top-right': tipCell.css({top:post-tipH-spa,left:posl-(tipW-selfW)}); break;
					case 'bottom-left': tipCell.css({top:post+selfH+spa,left:posl}); break;
					case 'bottom-center': tipCell.css({top:post+selfH+spa,left:posl-(tipW/2)+(selfW/2)}); break;	
					case 'bottom-right': tipCell.css({top:post+selfH+spa,left:posl-(tipW-selfW)}); break;	  
					case 'left-top': tipCell.css({top:post,left:posl-tipW-spa}); break;
					case 'left-center': tipCell.css({top:post-(tipH/2)+(selfH/2),left:posl-tipW-spa}); break;
					case 'right-top': tipCell.css({top:post,left:posl+selfW+spa}); break;	  
					case 'right-center': tipCell.css({top:post-(tipH/2)+(selfH/2),left:posl+selfW+spa}); break;		
					case 'follow': that.mousemove(function(e) { tipCell.css({top:e.pageY + 30,left:e.pageX - 6}); }); break;
				};
			}
			tipBox.hide();
			switch (opts.trigger){
				case 'show':calculate(pointer);tipBox.show();break; 
                case 'click':that.click(function(){calculate(pointer);tipBox.show();});break;
				case 'hover':that.hover(function(){calculate(pointer);tipBox.show(); tipBox.on("mouseover",function(){$(this).show()}).on("mouseout",function(){$(this).hide()})},function(){tipBox.hide();});break;
				case 'focus':that.focus(function(){calculate(pointer);tipBox.show();});  that.blur(function(){tipBox.hide();});break; 	  
				case 'mouse':that.hover(function(){calculate(pointer);tipBox.show();},function(){tipBox.hide();});break; 
			};
			setTimeout(function(){opts.success && opts.success();}, 1);
		});
	}
})(jQuery);

//表单验证
(function($){
	var validGroup={
		dataTypes: "",
		Notempty: /[^(^\s*)|(\s*$)]/,
		Email: /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/,
		Phone: /^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/,
		Mobile: /^(0|86|17951)?(13[0-9]|15[012356789]|17[0678]|18[0-9]|14[57])[0-9]{8}$/,
		Tel: /^(\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$/,
		Call: /^(^(0[0-9]{2,3}\-)?([2-9][0-9]{6,7})+(\-[0-9]{1,4})?$)|(^(1[358]\d{9})$)/,
		Url: /^http:\/\/[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*$/,
		Currency: /^\d+(\.\d+)?$/,
		Number: /^\d+$/,
		Pic:/^(.*)\.(jpg|bmp|gif|ico|jpeg|tif|png)$/,	//图片
	    Rar:/^(.*)\.(rar|zip|7zip|tgz)$/,	//压缩文件
		Zip: /^[1-9]\d{5}$/,
		QQ: /^[1-9]\d{4,10}$/,
		IP: /^[\d\.]{7,15}$/,
		Integer: /^[-\+]?\d+$/,
		ZInteger: /^[+]?\d+$/,
		Double: /^[-\+]?\d+(\.\d+)?$/,
		ZDouble: /^[+]?\d+(\.\d+)?$/,
		English: /^[A-Za-z]+$/,
		Chinese: /^[\u0391-\uFFE5]{2,6}$/,
		Username: /^[a-z]\w{3,}$/i,
		UnSafe: /^(([A-Z]*|[a-z]*|\d*|[-_\~!@#\$%\^&\*\.\(\)\[\]\{\}<>\?\\\/\'\"]*)|.{0,5})$|\s/,
		IdCard: "this.isIdCard(value)",
		IsSafe : function(str){return !this.UnSafe.test(str);},
	    SafeString : "this.IsSafe(value)",
	    Date : "this.isDate(element,value)",
	    Range : "this.checkRange(element,value)",
		Compare: "this.checkCompare(element,value)",
	    Group : "this.mustChecked(element)",
		Ajax: "this.doajax(errindex)",
		
		isIdCard: function(number) {
			var idcard, Y, JYM,S, M, idcard_array = new Array();
			idcard_array = number.split("");
			switch (number.length) {
			case 15:
				if ((parseInt(number.substr(6, 2)) + 1900) % 4 == 0 || ((parseInt(number.substr(6, 2)) + 1900) % 100 == 0 && (parseInt(number.substr(6, 2)) + 1900) % 4 == 0)) {
					ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/
				} else {
					ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/
				}
				if (ereg.test(number)) { return true } else { return false }
				break;
			case 18:
				if (parseInt(number.substr(6, 4)) % 4 == 0 || (parseInt(number.substr(6, 4)) % 100 == 0 && parseInt(number.substr(6, 4)) % 4 == 0)) {
					ereg = /^[1-9][0-9]{5}(19|20)[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}(\d|x|X)$/
				} else {
					ereg = /^[1-9][0-9]{5}(19|20)[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}(\d|x|X)$/
				}
				if (ereg.test(number)) {
					S = (parseInt(idcard_array[0]) + parseInt(idcard_array[10])) * 7 + (parseInt(idcard_array[1]) + parseInt(idcard_array[11])) * 9 + (parseInt(idcard_array[2]) + parseInt(idcard_array[12])) * 10 + (parseInt(idcard_array[3]) + parseInt(idcard_array[13])) * 5 + (parseInt(idcard_array[4]) + parseInt(idcard_array[14])) * 8 + (parseInt(idcard_array[5]) + parseInt(idcard_array[15])) * 4 + (parseInt(idcard_array[6]) + parseInt(idcard_array[16])) * 2 + parseInt(idcard_array[7]) * 1 + parseInt(idcard_array[8]) * 6 + parseInt(idcard_array[9]) * 3;
					Y = S % 11; M = "F"; JYM = "10X98765432"; M = JYM.substr(Y, 1);
					if (M == idcard_array[17]){ return true;}else{ return false;}
				} else{ return false};
				break;
			default: return false; break
			}
		},
		isDate: function(item,op) {
			var type = item.attr('datatype');
			var formatString = type || "ymd";
			var m, year, month, day;
			switch (formatString) {
			case "ymd":
				m = op.match(new RegExp("^((\\d{4})|(\\d{2}))([-./])(\\d{1,2})\\4(\\d{1,2})$"));
				if (m == null){ return false};
				day = m[6]; month = m[5] * 1; year = (m[2].length == 4) ? m[2] : GetFullYear(parseInt(m[3], 10));
				break;
			case "dmy":
				m = op.match(new RegExp("^(\\d{1,2})([-./])(\\d{1,2})\\2((\\d{4})|(\\d{2}))$"));
				if (m == null){ return false};
				day = m[1]; month = m[3] * 1; year = (m[5].length == 4) ? m[5] : GetFullYear(parseInt(m[6], 10));
				break;
			default: break
			}
			if (!parseInt(month)){ return false};
			month = month == 0 ? 12 : month;
			var date = new Date(year, month - 1, day);
			return (typeof(date) == "object" && year == date.getFullYear() && month == (date.getMonth() + 1) && day == date.getDate());
	
			function GetFullYear(y) { return ((y < 30 ? "20" : "19") + y) | 0 }
		},
		checkRange: function(item,value) {
			var value = value | 0;
			var minval = parseInt(item.attr('min')) || Number.MIN_VALUE;
			var maxval = parseInt(item.attr('max')) || Number.MAX_VALUE;
			return (minval <= value && value <= maxval)
		},
		checkCompare: function(item,value) {
			var compare = item.attr('datatype');
			if (isNaN(value)) return false;
			value = parseInt(value);
			return eval(value + compare);
		},
		mustChecked: function(item) {
			var tagName = item.attr('name'),mustMin,mustMax;
			$('input[name="' + tagName + '"]').each(function() {
				mustMin=$(this).attr('min');
				mustMax=$(this).attr('max');
			});
			var mustlen = $('input[name="' + tagName + '"]:checked').length;
			var count = $('input[name="' + tagName + '"]').length;
			var minval = parseInt(mustMin) || 1;
			var maxval = parseInt(mustMax) || count;
			return (minval <= mustlen && mustlen <= maxval);
		},
		doajax: function(item,value) {
			var name = item.attr('name');
            var ajaxmethod = item.attr('ajaxmethod');
			var url = item.attr('url');
			var ajaxreg = item.attr('datatype');
			var datatype = item.attr('datatype') || 'post';
			if (url == "" || url == undefined) {
				item.attr('errormsg',"请设定url的值");
				return false;
			}
			if (url.indexOf('?') > -1) {
				var dataurl = url + "&" + name + "=" + escape(value);
			} else {
				var dataurl = url + '?' + name + "=" + escape(value);
			}
			if(ajaxreg){
				var RegExpcon= new RegExp(ajaxreg,"gi").test(value);
				if(RegExpcon){
					var ajxs = $.ajax({
						type: datatype, url: dataurl, data: {}, cache: false, async: false,
						success: function(data) {
							data = data.replace(/(^\s*)|(\s*$)/g, "");
							if (data != 'success') {
								errmsg = errmsg == "" ? data : errmsg;
								return false;
							}
							if (data == 'success') { return true; }
						}
					}).responseText;
					ajxs = ajxs.replace(/(^\s*)|(\s*$)/g, "");
					return ajxs == 'success' ? true : false
				}else{
					return false;
				}
			}
		}//end doajaxs
	};
	/*检测校验类型*/
	validGroup.checkValidType = function(element,checktype){
		var value=$.trim(element.val());
		switch(checktype){
			 case "IdCard" :
			 case "Date" :
			 case "Range" :
			 case "Compare" :
			 case "Group" : 
			 case "SafeString" :
			 	return eval(this[checktype]);
			 break;
			 default:
			 	return this[checktype].test(value);
			 break;
		}
	};
	$.fn.jeValidator = function(options) {
		var config={
			eachValidate : false,
			emptytip : false,
			verifyReturn : false,
			onSubmit : true,
			focusError : true,
			focusBlurError : false,
			tipWidth:"auto",
			tipAlignTo:["right","center"],
			tipColor:["rgb(247, 206, 57)","#FFFEF4"],
			spacing:10,
			tipClose:false,
			noinvasive:false,
			invasConfig:[],
			zIndex:200,
			correctway : function(item){
				return verifyTips(item, true);
			},
			errorway : function(item){
				return verifyTips(item, false);
			},
			oncompleted : null
		};

		var opts= $.extend(config, options), _needFocus = false,  _isFocusOn = false;
		this.each(function(){
		    var that=$(this);
			var controls = $(':input');
            
			controls.each(function(){
				var item=$(this);
				var msgid = item.attr("msgid");
                var tipcls = eval("({"+$.trim(item.attr("tipcls"))+"})");
				if(msgid && item.attr("bubbles")=="false"){
					verifyContent(item, that);	
				};
				if($("#"+msgid).length > 0){return true};
				if(msgid){
				   poinSkinHtml(msgid); $("#"+msgid).hide();		   
				};

			});

			controls.on('blur keyup keyDown change',function(){
				var item = $(this);
				var msgid = item.attr("msgid");
				if(item.attr('type')=="checkbox" || item.attr('type')=="radio"){
					var itemName = item.attr('name'),bubble;
					$('input[name="' + itemName + '"]').each(function() {
						bubble=$(this).attr('bubbles');	
					});
				}else{
					bubble = item.attr("bubbles");
				}
				
				_needFocus = opts.focusBlurError;
				_isFocusOn = false;
				if(bubble=="" || bubble=="true" || bubble==undefined){
				    verifyContent(item, that);
				    poinSkinTip(item,msgid);
				}else{
					verifyContent(item, that);
				}
				if($("#"+msgid).length > 0)return false;				
			});

		})
		
		function verifyTips(item, isValid){
			var msgid,unfocuson,tipobj ,tipcls,errortip, suctip, nulltip,bubble,checkedlen;
            if(item.attr('type')=="checkbox" || item.attr('type')=="radio"){
				var itemName = item.attr('name');
				$('input[name="' + itemName + '"]').each(function() {
					msgid = $(this).attr('msgid');
			        unfocuson = $(this).attr('focuson');
					tipcls = eval("({"+$.trim($(this).attr("tipcls"))+"})");
					bubble = $(this).attr("bubbles");
					tipobj=$('#' +$(this).attr('msgid'));
					errortip = $(this).attr('errormsg');
			        suctip = $(this).attr('sucmsg');
					nulltip = $(this).attr('nullmsg');
					checkedlen = $(this+"[checked]").length;	
				});	
			}else{
				msgid = item.attr('msgid');
			    unfocuson = item.attr('focuson');
				tipcls = eval("({"+$.trim(item.attr("tipcls"))+"})");
				itemcheck=item.is(':checked');
				bubble = item.attr("bubbles");
				tipobj = $('#' + msgid);
				errortip = item.attr('errormsg');
			    suctip = item.attr('sucmsg');
			    nulltip = item.attr('nullmsg');
			};

			if(msgid && bubble=="false"){
				tipobj.addClass(tipcls.nullcls ? tipcls.nullcls : tipcls.errorcls);
				if(tipobj.find("#tipcon-"+msgid).length==0){
					$("<div class='verifytipcon' id='tipcon-"+msgid+"'></div>").appendTo(tipobj);
				}
				if(tipobj && checkedlen==0){
				    tipobj.find("#tipcon-"+msgid).html(nulltip ? nulltip : errortip);
				}
			};

			if((item.val()=="" || checkedlen==0)  && nulltip!="" && nulltip!=undefined){
				var tip = nulltip;
			}else{
				var tip =isValid ? suctip : $("<span style='color:#ff4136;'></span>").append(errortip);
			};
			unfocuson = (unfocuson && (unfocuson.toLowerCase() == 'false' || unfocuson == '0'));
			if(msgid || tipobj){
					var nullclass = tipcls.nullcls;
					var errorclass = tipcls.errorcls;
					var succlass = tipcls.succls;

					if(isValid){
						if(bubble=="" || bubble=="true" || bubble==undefined){
							tipobj.css("display","none");
						}else{
							if(nullclass && (item.val()=="" || checkedlen==0)){
								tipobj.removeClass(errorclass).addClass(nullclass);
							};
							if(succlass && (item.val()!="" || checkedlen>0)){
								tipobj.removeClass(nullclass);
								tipobj.removeClass(errorclass).addClass(succlass);
							};
						}
					}else{
						
						if(bubble=="" || bubble=="true" || bubble==undefined){
							tipobj.css("display","block");
						}else{
							
							if(nullclass && (item.val()==""  || checkedlen==0)){
								tipobj.removeClass(errorclass).addClass(nullclass);
							}else if(errorclass && (item.val()!="" || checkedlen>0)){
								tipobj.removeClass(succlass);
								tipobj.removeClass(nullclass).addClass(errorclass);
							};
						}
					}
					if(tip){
						tipobj.find("#tipcon-"+msgid).html(tip);
						//tipobj.append(tip);
					}  //else{tipobj.html(tipobj.attr('nullmsg'));}
			}else if(tip){alert(tip);}
			if(!unfocuson && _needFocus && !isValid && !_isFocusOn){ item.focus(); _isFocusOn = true; }
			return true;
		};
		
		function verifyContent(item, form){
			var rulestype = item.attr('rules');
			var regexptype = item.attr('regexp');
			var contrast = item.attr('contrast');
			var addmethod = item.attr('addmethod');
			var isrequired = item.attr('isrequired');
			
			if(!(rulestype || regexptype || contrast || addmethod)){return true};
			var fre = false, pre = false;
			var itemVal = item.val();
			
			if("false" != item.attr('trims')){
				if(!this.disabled && itemVal != undefined && itemVal.length > 0){
					if("TEXTAREA" == item[0].tagName || ("INPUT" == item[0].tagName && item.attr('type') == 'text')){
						var trimVal = itemVal.replace(/^\s+|\s+$/g,"");
						if(trimVal.length != itemVal.length){
							itemVal = trimVal;
							item.val(trimVal);
						}
					}
				}
			}
			if(isrequired && (isrequired.toLowerCase() == 'false' || isrequired == '0')){
				if(itemVal == '')fre = true;
			}else if(this.disabled || !itemVal /*== undefined*/){
				pre = true; fre = false;
			}
			
			if(!pre && !fre){
				
				fre = true;
				if(rulestype){
					if(rulestype.substr(0,1)=="@"){
						var Regpatt=eval('(' + rulestype.replace(/(^\s*)|(\s*$)/g, "").substring(1) + ')');
						var RegCon = new RegExp(Regpatt,"gi").test(itemVal);	
					}else{
						var RegCon = validGroup.checkValidType(item,rulestype);
					}

					if(!RegCon){fre = false;}
				}
				if(regexptype){
					var RegCon = new RegExp(regexptype.replace(/(^\/*)|(\/*$)/g, ""),"gi").test(itemVal);
					if(!RegCon){fre = false;} 
				}
				if(contrast && fre){
					var co = $('#' + contrast);
					if(co.length > 0 && co.val() != itemVal)fre = false;
				}

				if(addmethod && fre){
					winfre = window[addmethod](item);
					if(typeof(winfre) == 'object' && winfre.message){
						item.attr('beforemsg',item.attr('aftermsg') ? item.attr('beforemsg') : item.attr('errormsg'));
						item.attr('aftermsg', winfre.message);
						item.attr('errormsg', winfre.message);
						fre = winfre.result;
					}
				}else{
					item.attr('errormsg',item.attr('beforemsg'));
				}
			}
			if(fre){
				if(itemVal != '' && itemVal != undefined){
					opts.correctway(item);
				}
			}else{
				opts.errorway(item);
			}
			return fre;
		};
		
		function stepvalidate(form){
			var success = true;
			_isFocusOn = false;
			_needFocus = opts.focusError;
			$(':input', form).each(function(){
				if(!verifyContent($(this))){
					success = false;
					if(!opts.eachValidate){return false};
				}
			});
			if(success && opts.oncompleted)success = opts.oncompleted();
			return success;
		};
		if(opts.onSubmit){
			this.submit(function(){
				return stepvalidate(this);
			});
		};

		if(!opts.verifyReturn){
			return this;
		}else{
			var fre = true;
			this.each(function(){
				if(!stepvalidate(this)){fre = false};
			});
			return fre;
		};
		function poinSkinHtml(sid){
			var pointer=opts.tipAlignTo.length===1 ? ''+opts.tipAlignTo[0]+'' : ''+opts.tipAlignTo[0]+'-'+opts.tipAlignTo[1]+'';
			$('<div class="verifytip verifytip-'+pointer+'" id="'+sid+'"><i></i><em></em><div class="verifytipcon" id="tipcon-'+sid+'"></div></div>').appendTo(document.body);
			var verTipid = $("#"+sid);
			
			var edgecolor='border-'+opts.tipAlignTo[0]+'-color';
			verTipid.css({'position':'absolute',border:'1px solid','border-color':opts.tipColor[0],'background-color':opts.tipColor[1],'z-index':opts.zIndex});
			if(opts.tipAlignTo[1]=='center'){ var offpos=50,percen="%"; }else{ var offpos=5,percen="px"; };
			verTipid.find("i,em").css({width:0,height:0,'line-height':0,'font-size':0,content:'','position':'absolute'})
			verTipid.find("i").css({border:'8px solid transparent','z-index':5});
			verTipid.find("em").css({border:'7px solid transparent','z-index':10});
			if(pointer=='top-center' || pointer=='bottom-center' || pointer=='top-left' || pointer=='bottom-left'){
				var poi="left";
				if(pointer=='top-center' || pointer=='bottom-center'){
					verTipid.find("i").css({"margin-left":"-8px"});
					verTipid.find("em").css({"margin-left":"-7px"});
				}
			}else if(pointer=='left-center' || pointer=='right-center' ||  pointer=='left-top'|| pointer=='right-top'){
				var poi="top";
				if(pointer=='left-center' || pointer=='right-center'){
					verTipid.find("i").css({"margin-top":"-8px"});
					verTipid.find("em").css({"margin-top":"-7px"});
				}
			}else{
				var poi="right";
			};
			verTipid.find("i").css(edgecolor,opts.tipColor[0]).css(poi,''+offpos+percen+'');
			verTipid.find("em").css(edgecolor,opts.tipColor[1]).css(poi,''+(offpos+(opts.tipAlignTo[1]=='center'?0:1))+percen+'');
			verTipid.find("i,em").css(opts.tipAlignTo[0],'100%');
			if(opts.tipClose){
				$('<span class="verifytipclose" id="close'+sid+'">&times;</span>').appendTo(verTipid);
				verTipid.find("#close"+sid+"").on("click",function(){verTipid.hide();});
			}
			if(typeof opts.tipWidth === 'string'){
				var tipdocW = parseInt(document.body.clientWidth*(opts.tipWidth.replace('%','')/100));
				(typeof opts.tipWidth == 'auto' || typeof opts.tipWidth == '') ? verTipid.css({width:'auto'}) : verTipid.css({width:tipdocW});
				verTipid.height();
			}else{
				verTipid.width(opts.tipWidth).height();
			}
		};
		function poinSkinTip(item,sid){
			function swalign(){
				var CheckName = item.attr('name'),Checkmsg,Checkid;
				$('input[name="' + CheckName + '"]').each(function() {
					Checkid=$(this).attr('msgid');
					Checkmsg=$('input[msgid="' + Checkid + '"]');
				});
				var spa = opts.spacing;
				var align=opts.tipAlignTo.length===1 ? ''+opts.tipAlignTo[0]+'' : ''+opts.tipAlignTo[0]+'-'+opts.tipAlignTo[1]+'';
				
				if(item.attr("type")=='checkbox' || item.attr("type")=="radio"){
					var tipCell=$('#'+Checkid);
					var selfH = Checkmsg.outerHeight(true), selfW = Checkmsg.outerWidth(true);
					var post= Checkmsg.offset().top, posl = Checkmsg.offset().left;
				}else{
					var tipCell=$('#'+sid);
					var selfH = item.outerHeight(true), selfW = item.outerWidth(true);
					var post=item.offset().top, posl=item.offset().left;
				}
				var tipH=tipCell.outerHeight(true), tipW=tipCell.outerWidth(true);  
				
				switch (align) {
					case 'top-left': tipCell.css({top:post-tipH-spa,left:posl}); break;
					case 'top-center': tipCell.css({top:post-tipH-spa,left:posl-(tipW/2)+(selfW/2)}); break;	
					case 'top-right': tipCell.css({top:post-tipH-spa,left:posl-(tipW-selfW)}); break;
					case 'bottom-left': tipCell.css({top:post+selfH+spa,left:posl}); break;
					case 'bottom-center': tipCell.css({top:post+selfH+spa,left:posl-(tipW/2)+(selfW/2)}); break;	
					case 'bottom-right': tipCell.css({top:post+selfH+spa,left:posl-(tipW-selfW)}); break;	  
					case 'left-top': tipCell.css({top:post,left:posl-tipW-spa}); break;
					case 'left-center': tipCell.css({top:post-(tipH/2)+(selfH/2),left:posl-tipW-spa}); break;
					case 'right-top': tipCell.css({top:post,left:posl+selfW+spa}); break;	  
					case 'right-center': tipCell.css({top:post-(tipH/2)+(selfH/2),left:posl+selfW+spa}); break;		
				};
		    };  swalign();
			$(window).resize(function() {swalign();});
		};
				
	};
})(jQuery);

//jQuery placeholder  input,textarea占位插件
(function($) {
	$.fn.placeholder = function(options) {
		var defaults = {
			labelStyle: {},
			isEmpty: false,
			focusCls:"finps",  
		    blurCls:"oinps"   
		};
		var params = $.extend({}, defaults, options || {});
		var funPlaceholder = function(ele) {
			// 为了向下兼容$ 1.4
			if (document.querySelector) {
				return $(ele).attr("placeholder");	
			} else {
				// IE6, 7
				var ret;
				ret = ele.getAttributeNode("placeholder");
				// Return undefined if nodeValue is empty string
				return ret && ret.nodeValue !== "" ? ret.nodeValue : undefined;	
			}
		};
		
		return this.each(function() {
			var that = $(this), thatplace = funPlaceholder(this);
			that.data("placeholder", thatplace);
			var idEle = that.attr("id"), eleLabel = null;
				if (!idEle) {
					idEle = "place" +Math.floor(Math.random().toString().substr(2,8));	//如果没有id,生成一个附带8位随机数的id
					//idEle = "place" +Math.floor( Math.random()*950000);	
					that.attr("id", idEle);
				};
               that.wrapAll('<div class="labelwraps" style="position:relative;z-index:1;display:inline-block;"></div>');
		       eleLabel = $('<label for="'+ idEle +'"></label>').css($.extend({
					lineHeight: "",
					position: "absolute",
					cursor: "text",
					'z-index':5,
					'text-indent':'3px',
					top:0,left:0,
					marginLeft: that.css("marginLeft"),
					marginTop: that.css("marginTop"),
					paddingLeft: that.css("paddingLeft"),
					paddingTop: that.css("paddingTop")
				}, params.labelStyle)).css({color:"#999"}).insertBefore(that);		
				
				that.removeAttr("placeholder");		
				eleLabel.html(thatplace);	
				
				if(that.val()==""){eleLabel.show();}else{eleLabel.hide();}
				if(params.isEmpty){
					
					that.bind({
						"input cut focus keydown keyup paste":function(){
							if(that.val()==""){
								eleLabel.show().css({color:"#ddd"});
								$(this).removeClass(params.blurCls).addClass(params.focusCls); 
							}else{
								eleLabel.hide();
								$(this).removeClass(params.blurCls).addClass(params.focusCls); 
							}
						},
						"blur":function(){
							if(that.val()==""){
								eleLabel.show().css({color:"#999"});
								$(this).removeClass(params.focusCls).addClass(params.blurCls); 
							}else{
								eleLabel.hide();
								$(this).removeClass(params.focusCls).addClass(params.blurCls); 
							}
						}
					});
				}else{
				   	that.bind({
						"focus":function(){
							if(that.val()==""){
								eleLabel.hide();
								$(this).removeClass(params.blurCls).addClass(params.focusCls); 
							}else{
								eleLabel.hide();
								$(this).removeClass(params.blurCls).addClass(params.focusCls); 
							}
						},
						"blur":function(){
							if(that.val()==""){
								eleLabel.show();
								$(this).removeClass(params.focusCls).addClass(params.blurCls); 
							}else{
								eleLabel.hide();
								$(this).removeClass(params.focusCls).addClass(params.blurCls); 
							}
						}
					}); 
				}		
		});
	}
})(jQuery);

//tab切换
(function($){
	
	$.fn.rTabs = function(options){
		
		//默认值
		var defaultVal = {
			btnClass:'.j-tab-nav',	/*按钮的父级Class*/
			conClass:'.j-tab-con',	/*内容的父级Class*/
			bind:'hover',	/*事件参数 click,hover*/
			action:'current',
			animation:'0',	/*动画方向 left,up,fadein,0 为无动画*/
			speed:300, 	/*动画运动速度*/
			delay:200,	/*Tab延迟速度*/
			auto:true,	/*是否开启自动运行 true,false*/
			autoSpeed:3000	/*自动运行速度*/
		};
		
		//全局变量
		var obj = $.extend(defaultVal, options),
			evt = obj.bind,
			btn = $(this).find(obj.btnClass),
			con = $(this).find(obj.conClass),
			anim = obj.animation,
			conWidth = con.width(),
			conHeight = con.height(),
			len = con.children().length,
			sw = len * conWidth,
			sh = len * conHeight,
			i = 0,
			len,t,timer;

		return this.each(function(){
			
			//判断动画方向
			function judgeAnim(){
				var w = i * conWidth,
					h = i * conHeight;
				btn.children().removeClass(obj.action).eq(i).addClass(obj.action);
				switch(anim){
					case '0':
					con.children().hide().eq(i).show();
					break;
					case 'left':
					con.css({position:'absolute',width:sw}).children().css({float:'left',display:'block'}).end().stop().animate({left:-w},obj.speed);
					break;
					case 'up':
					con.css({position:'absolute',height:sh}).children().css({display:'block'}).end().stop().animate({top:-h},obj.speed);
					break;
					case 'fadein':
					con.children().hide().eq(i).fadeIn();
					break;
				}
			}
			
			//判断事件类型
			if(evt == "hover"){
				btn.children().hover(function(){
					var j = $(this).index();
					function s(){
						i = j;
						judgeAnim();
					}
					timer=setTimeout(s,obj.delay);
				}, function(){
					clearTimeout(timer);
				})
			}else{
				btn.children().bind(evt,function(){
					i = $(this).index();
					judgeAnim();
				})
			}
			
			//自动运行
			function startRun(){
				t = setInterval(function(){
					i++;
					if(i>=len){
						switch(anim){
							case 'left':
							con.stop().css({left:conWidth});
							break;
							case 'up':
							con.stop().css({top:conHeight});
						}	
						i=0;
					}
					judgeAnim();
				},obj.autoSpeed)
			}
			
			//如果自动运行开启，调用自动运行函数
			if(obj.auto){
				$(this).hover(function(){
					clearInterval(t);
				},function(){
					startRun();
				})
				startRun();
			}
			
		})
		
	}
	
})(jQuery);

/*! iCheck v1.0.2 by Damir Sultanov, http://git.io/arlzeA, MIT Licensed */
(function(f){function A(a,b,d){var c=a[0],g=/er/.test(d)?_indeterminate:/bl/.test(d)?n:k,e=d==_update?{checked:c[k],disabled:c[n],indeterminate:"true"==a.attr(_indeterminate)||"false"==a.attr(_determinate)}:c[g];if(/^(ch|di|in)/.test(d)&&!e)x(a,g);else if(/^(un|en|de)/.test(d)&&e)q(a,g);else if(d==_update)for(var f in e)e[f]?x(a,f,!0):q(a,f,!0);else if(!b||"toggle"==d){if(!b)a[_callback]("ifClicked");e?c[_type]!==r&&q(a,g):x(a,g)}}function x(a,b,d){var c=a[0],g=a.parent(),e=b==k,u=b==_indeterminate,
v=b==n,s=u?_determinate:e?y:"enabled",F=l(a,s+t(c[_type])),B=l(a,b+t(c[_type]));if(!0!==c[b]){if(!d&&b==k&&c[_type]==r&&c.name){var w=a.closest("form"),p='input[name="'+c.name+'"]',p=w.length?w.find(p):f(p);p.each(function(){this!==c&&f(this).data(m)&&q(f(this),b)})}u?(c[b]=!0,c[k]&&q(a,k,"force")):(d||(c[b]=!0),e&&c[_indeterminate]&&q(a,_indeterminate,!1));D(a,e,b,d)}c[n]&&l(a,_cursor,!0)&&g.find("."+C).css(_cursor,"default");g[_add](B||l(a,b)||"");g.attr("role")&&!u&&g.attr("aria-"+(v?n:k),"true");
g[_remove](F||l(a,s)||"")}function q(a,b,d){var c=a[0],g=a.parent(),e=b==k,f=b==_indeterminate,m=b==n,s=f?_determinate:e?y:"enabled",q=l(a,s+t(c[_type])),r=l(a,b+t(c[_type]));if(!1!==c[b]){if(f||!d||"force"==d)c[b]=!1;D(a,e,s,d)}!c[n]&&l(a,_cursor,!0)&&g.find("."+C).css(_cursor,"pointer");g[_remove](r||l(a,b)||"");g.attr("role")&&!f&&g.attr("aria-"+(m?n:k),"false");g[_add](q||l(a,s)||"")}function E(a,b){if(a.data(m)){a.parent().html(a.attr("style",a.data(m).s||""));if(b)a[_callback](b);a.off(".i").unwrap();
f(_label+'[for="'+a[0].id+'"]').add(a.closest(_label)).off(".i")}}function l(a,b,f){if(a.data(m))return a.data(m).o[b+(f?"":"Class")]}function t(a){return a.charAt(0).toUpperCase()+a.slice(1)}function D(a,b,f,c){if(!c){if(b)a[_callback]("ifToggled");a[_callback]("ifChanged")[_callback]("if"+t(f))}}var m="iCheck",C=m+"-helper",r="radio",k="checked",y="un"+k,n="disabled";_determinate="determinate";_indeterminate="in"+_determinate;_update="update";_type="type";_click="click";_touch="touchbegin.i touchend.i";
_add="addClass";_remove="removeClass";_callback="trigger";_label="label";_cursor="cursor";_mobile=/ipad|iphone|ipod|android|blackberry|windows phone|opera mini|silk/i.test(navigator.userAgent);f.fn[m]=function(a,b){var d='input[type="checkbox"], input[type="'+r+'"]',c=f(),g=function(a){a.each(function(){var a=f(this);c=a.is(d)?c.add(a):c.add(a.find(d))})};if(/^(check|uncheck|toggle|indeterminate|determinate|disable|enable|update|destroy)$/i.test(a))return a=a.toLowerCase(),g(this),c.each(function(){var c=
f(this);"destroy"==a?E(c,"ifDestroyed"):A(c,!0,a);f.isFunction(b)&&b()});if("object"!=typeof a&&a)return this;var e=f.extend({checkedClass:k,disabledClass:n,indeterminateClass:_indeterminate,labelHover:!0},a),l=e.handle,v=e.hoverClass||"hover",s=e.focusClass||"focus",t=e.activeClass||"active",B=!!e.labelHover,w=e.labelHoverClass||"hover",p=(""+e.increaseArea).replace("%","")|0;if("checkbox"==l||l==r)d='input[type="'+l+'"]';-50>p&&(p=-50);g(this);return c.each(function(){var a=f(this);E(a);var c=this,
b=c.id,g=-p+"%",d=100+2*p+"%",d={position:"absolute",top:g,left:g,display:"block",width:d,height:d,margin:0,padding:0,background:"#fff",border:0,opacity:0},g=_mobile?{position:"absolute",visibility:"hidden"}:p?d:{position:"absolute",opacity:0},l="checkbox"==c[_type]?e.checkboxClass||"icheckbox":e.radioClass||"i"+r,z=f(_label+'[for="'+b+'"]').add(a.closest(_label)),u=!!e.aria,y=m+"-"+Math.random().toString(36).substr(2,6),h='<div class="'+l+'" '+(u?'role="'+c[_type]+'" ':"");u&&z.each(function(){h+=
'aria-labelledby="';this.id?h+=this.id:(this.id=y,h+=y);h+='"'});h=a.wrap(h+"/>")[_callback]("ifCreated").parent().append(e.insert);d=f('<ins class="'+C+'"/>').css(d).appendTo(h);a.data(m,{o:e,s:a.attr("style")}).css(g);e.inheritClass&&h[_add](c.className||"");e.inheritID&&b&&h.attr("id",m+"-"+b);"static"==h.css("position")&&h.css("position","relative");A(a,!0,_update);if(z.length)z.on(_click+".i mouseover.i mouseout.i "+_touch,function(b){var d=b[_type],e=f(this);if(!c[n]){if(d==_click){if(f(b.target).is("a"))return;
A(a,!1,!0)}else B&&(/ut|nd/.test(d)?(h[_remove](v),e[_remove](w)):(h[_add](v),e[_add](w)));if(_mobile)b.stopPropagation();else return!1}});a.on(_click+".i focus.i blur.i keyup.i keydown.i keypress.i",function(b){var d=b[_type];b=b.keyCode;if(d==_click)return!1;if("keydown"==d&&32==b)return c[_type]==r&&c[k]||(c[k]?q(a,k):x(a,k)),!1;if("keyup"==d&&c[_type]==r)!c[k]&&x(a,k);else if(/us|ur/.test(d))h["blur"==d?_remove:_add](s)});d.on(_click+" mousedown mouseup mouseover mouseout "+_touch,function(b){var d=
b[_type],e=/wn|up/.test(d)?t:v;if(!c[n]){if(d==_click)A(a,!1,!0);else{if(/wn|er|in/.test(d))h[_add](e);else h[_remove](e+" "+t);if(z.length&&B&&e==v)z[/ut|nd/.test(d)?_remove:_add](w)}if(_mobile)b.stopPropagation();else return!1}})})}})(window.jQuery||window.Zepto);