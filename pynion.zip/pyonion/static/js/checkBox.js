function checkBox(){
        //��ѡ��ȫѡ
        var Checkitem=$('.tabledata input[name="valitems"]');
        $(Checkitem).iCheck({
          checkboxClass: 'icheckbox_futurico',
          radioClass: 'iradio_futurico',
          increaseArea: '0%' // optional
        });
        $(Checkitem).on('ifClicked', function(event){
                if($(this).is(':checked')){
                    $(this).parent().parent().parent().removeClass("select");
                }else{
                    $(this).parent().parent().parent().addClass("select");
                }
        });

        $('#jqchk').on('ifChecked', function(event){
            $(Checkitem).iCheck('check');
            $.each(Checkitem,function(){
                if($(this).is(':checked')){
                    $(this).parent().parent().parent().addClass("select");
                }
            })
        });
        $('#jqchk').on('ifUnchecked', function(event){
            $(Checkitem).iCheck('uncheck');
            $.each(Checkitem,function(){
                if(!$(this).is(':checked')){
                    $(this).parent().parent().parent().removeClass("select");
                }
            })
        });
        $.each(Checkitem,function(){
            if($(this).is(':checked')){
                $(this).parent().parent().parent().addClass("select");
            }else{
                $(this).parent().parent().parent().removeClass("select");
            }
        });
    }