# -*- coding: utf-8 -*-
#import codecs

from pyonion.auth.views import need_login
import json

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from pyonion.models import Purchase,PurchaseDetail,Le,inBound,Supplier,purchaseLog

from django.db import connections
from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import transaction
from django.core.exceptions import ObjectDoesNotExist

import xlrd
import decimal
import os
import datetime

#商品采购列表页
@need_login
def purchaseList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("purchase/purchaseList.html",dic)

#商品采购查询列表页
@csrf_exempt
@need_login
def purchaseJson(request):
    sodNo = request.GET.get('sodNo')
    nameAll = request.GET.get('nameAll')
    paymentType = request.GET.get('paymentType')
    goodsState = request.GET.get('goodsState')
    queryset = Purchase.objects.filter(is_deleted=0).order_by('-create_time')
    if sodNo:
        queryset = queryset.filter(purchase_no__icontains=sodNo)
    if nameAll:
        queryset = queryset.filter(supplier__name__icontains=nameAll)
    if paymentType:
        queryset = queryset.filter(pay_mode__icontains=paymentType)
    if goodsState:
        queryset = queryset.filter(state__icontains=goodsState)

    purchases = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (purchases.paginator.count, purchases.paginator.num_pages)]
    for purchase in purchases:
        estTime = purchase.est_arrival_time
        #当前时间(数据库中的类型是tetime.datetime，而不是datetime.date)
        todatay = datetime.datetime.today()
        #如果state=6的时候表示此采购单已经终止了就不计算剩余天数
        if purchase.state >= 5:
            dateTimeAll = "terminationOf"
        else:
            #到货剩余天数 = 预计到货时间-当前时间
            #0时0分0秒时 时间差 无需加1
            if todatay.strftime('%H:%M:%S') == '00:00:00':
               dateTimeAll = (estTime - todatay).days
            else:
               dateTimeAll = (estTime - todatay).days + 1

        total = purchase.first_amount+purchase.rest_amount+purchase.freight
        names = purchase.supplier
        if names != None:
            items.append(
                '{"id":"%s","state":"%s","purchase_no":"%s","name":"%s","shipping_time":"%s","est_arrival_time":"%s","first_amount":"%s","rest_amount":"%s","freight":"%s","total_amount":"%s","date_time_all":"%s","shipping_mode":"%s","pay_mode":"%s"},' % (
                    purchase.id,purchase.state,purchase.purchase_no,purchase.supplier.name, purchase.shipping_time, purchase.est_arrival_time, purchase.first_amount,purchase.rest_amount,purchase.freight,total,dateTimeAll,purchase.shipping_mode,purchase.pay_mode))
        else:
            items.append(
                '{"id":"%s","state":"%s","purchase_no":"%s","shipping_time":"%s","est_arrival_time":"%s","first_amount":"%s","rest_amount":"%s","freight":"%s","total_amount":"%s","date_time_all":"%s","shipping_mode":"%s","pay_mode":"%s"},' % (
                    purchase.id,purchase.state,purchase.purchase_no,purchase.shipping_time, purchase.est_arrival_time, purchase.first_amount,purchase.rest_amount,purchase.freight,total,dateTimeAll,purchase.shipping_mode,purchase.pay_mode))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if purchases.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#记录操作过的日志
@csrf_exempt
def operationLog(request,operation,business_name):
    try:
        #获取当前用户名
        userauth = request.COOKIES.get('username', '')
        userNo = request.COOKIES.get('userId', '')
        purchaseLog.objects.create(create_user_name = userauth,modify_user_id = userNo,content=operation,business_name = business_name)
    except Exception, e:
        pass

#删除采购主表信息
@csrf_exempt
@need_login
def deleteZhu(request):
    #删除采购信息
    if request.method == 'POST':
        ids = request.POST['orId']
        try:
            business_name = "商品采购" #操作模块
            Purchase.objects.filter(pk=ids).update(is_deleted=1)
            content = "删除商品采购主表信息！"   #操作内容
            operationLog(request,content,business_name)
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #删除成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json")#删除失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json")#删除失败

#商品采购导入跳转页面
@csrf_exempt
@need_login
def purchaseImportList(request):
    return render_to_response("purchase/purchaseImportList.html")

def parseDatetime(strdatetime):
    time = datetime.datetime.strptime(strdatetime,"%Y-%m-%d")
    return time

#自动生成订单号
def get_purchase_no(par_id):
    aa = datetime.date
    date_year = aa.today().year
    #id = str(id)
    #if len(id) == 0:
        #no = "-1"
    #if len(id) < 5:
        #no ="YC"+ str(date_year) + "%s%s"%('0'*(5-len(id)),id)
    #else:
        #no ="YC"+ str(date_year) + id[len(id)-5:len(id)]
    no = "YC%s%08d" % (date_year, par_id)
    return no

#从Excel中取数据插入到相关表中
@transaction.atomic
def processTable(filepath,username,userId):
    data = xlrd.open_workbook(filepath)
    table1 = data.sheets()[0]
    x = table1.row_values(1)
    #根据Excel中的订单号查询主表中是否存在，存在就不能导入
    #purchaseNo = Purchase.objects.filter(purchase_no=x[0],is_deleted = 0)
    par = None
    #根据Excel中的商品编码查询对应的id
    supplierId = Supplier.objects.filter(code=x[3])
    supplierIds = supplierId[0]
    suppCodeId = supplierIds
    #if not purchaseNo:
    par = Purchase.objects.create(pay_rate=x[0],pay_type=x[1],currency =x[2],supplier_code = x[3],first_amount=decimal.Decimal(str(x[4])),
                                  bank = x[5],payee = x[6],swift_code = x[7], pay_account = x[8],rest_amount = decimal.Decimal(str(x[9])),shipping_mode=x[10],
                                  shipping_time =parseDatetime(x[11]),freight=decimal.Decimal(str(x[12])), est_arrival_time =parseDatetime(x[13]),remark=x[14],pay_mode=x[15] ,
                                  create_user_id = userId,confirm_user_id=username, modify_user_id = userId,state=1,is_deleted=0,supplier = suppCodeId)
    purchaseNo = get_purchase_no(par.id)
    par.purchase_no = purchaseNo
    par.save()
    #else:
        #os.remove(filepath)
        #return HttpResponse("数据有重复！")#导入失败
    #par.save()
    table2 = data.sheets()[1]
    len2 = table2.nrows
    for j in range(1,len2):
        y = table2.row_values(j)
        barcode = str(y[1])
        try:
            #外币总价=采购单价（外币）*采购量
            foreignAmt = float(y[3]) * float(y[4])
            #人民币总价=采购单价（人民币）*采购量
            rmbAmt = float(y[3]) * float(y[5])

            lebarcode = Le.objects.get(le_barcode=str(barcode))
            PurchaseDetail.objects.create(purchase = par,le = lebarcode,le_code = str(y[0]),le_barcode = str(y[1]), package_spe = y[2], package_qty = y[3],foreign_price = decimal.Decimal(str(y[4])),
                                    rmb_price = decimal.Decimal(str(y[5])),validity_date = parseDatetime(y[6]),remark =y[7],modify_user_id = userId,confirm_qty = userId,state = 0,is_new=0,foreign_amt=foreignAmt,rmb_amt = rmbAmt)
        except Exception, e:
            PurchaseDetail.objects.create(purchase = par,le_code = str(y[0]),le_barcode = str(y[1]), package_spe = y[2], package_qty = y[3],foreign_price = decimal.Decimal(str(y[4])),
                                    rmb_price = decimal.Decimal(str(y[5])),validity_date = parseDatetime(y[6]),remark =y[7],modify_user_id = userId,confirm_qty = userId,state = 0,is_new=0,foreign_amt=foreignAmt,rmb_amt = rmbAmt)
            pass
    os.remove(filepath)
    return HttpResponse("导入成功！") #导入成功

#上传Excel文件
def handle_uploaded_file(file, filename):
    if not os.path.exists('upload/'):
        os.mkdir('upload/')
    with open('upload/' + filename, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
    return 'upload/' + filename

@csrf_exempt
@need_login
def purchaseImport(request):
    business_name = "商品采购" #操作模块
    #获取当前用户名
    username = request.COOKIES.get('username', '')
    userId = request.COOKIES.get('userId', '')
    result = {}
    #获取Excel文件
    if request.method == 'POST':
        filepath = handle_uploaded_file(request.FILES['file'], str(request.FILES['file']))
        content = "导入商品采购信息！"   #操作内容
        operationLog(request,content,business_name)
        return processTable(filepath,username,userId)


#采购信息修改跳转页面
@csrf_exempt
@need_login
def purchaseUpdate(request):
    dic = {'id': request.GET.get('showId'),'idAll': request.GET.get('idAll'),'userIDAll': request.GET.get('userIDAll')}
    return render_to_response("purchase/purchaseUpdate.html" , dic)

#商品采购查询列表页
#def updateJson(request):
    #orId = request.GET.get('id')
    #根据id查询主表的采购信息
    #sysPurchase = Purchase.objects.get(id = orId)
    #根据主表的id询子表的信息
    #zis = getPaginator(sysPurchase.purchasedetail_set.all(),request)
    #itemPurchase = ['{"total":%d,"totalPage":%d,"rows":[' % (zis.paginator.count, zis.paginator.num_pages)]
    #for zi in zis:
        #itemPurchase.append('{"id":"%s","purchase_no":"%s","pay_type":"%s","currency":"%s","pay_account":"%s","first_amount":"%s","rest_amount":"%s","shipping_mode":"%s","purchase":"%s","le_barcode":"%s","package_spe":"%s","package_qty":"%s","foreign_amt":"%s","rmb_amt":"%s","sell_price":"%s"},' % (
            #sysPurchase.id, sysPurchase.purchase_no,sysPurchase.pay_type,sysPurchase.currency,sysPurchase.pay_account,sysPurchase.first_amount,
            #sysPurchase.rest_amount,sysPurchase.shipping_mode,zi.purchase,zi.le_barcode,zi.package_spe,zi.package_qty,zi.foreign_amt,zi.rmb_amt,zi.sell_price))
    #itemPurchase.append(']}')
    #jsonstr = ''.join(itemPurchase)
    #jsonlen = len(jsonstr)
    #jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    #return HttpResponse(jsonstr, content_type="application/json")

#查询主表信息
@csrf_exempt
@need_login
def updateZhu(request):
    orId = request.GET.get('id')
    #根据id查询主表的采购信息
    sysPurchase = getPaginator(Purchase.objects.filter(id = orId),request)
    itemPurchase = ['{"total":%d,"totalPage":%d,"rows":[' % (sysPurchase.paginator.count, sysPurchase.paginator.num_pages)]
    for sysPurchases in sysPurchase:
        estTime = sysPurchases.est_arrival_time
        #当前时间(数据库中的类型是tetime.datetime，而不是datetime.date)
        todatay = datetime.datetime.today()
        #如果state=6的时候表示此采购单已经终止了就不计算剩余天数
        if sysPurchases.state >= 5:
            dateTimeAll = "terminationOf"
        else:
            #到货剩余天数 = 预计到货时间-当前时间
            #0时0分0秒时 时间差 无需加1
            if todatay.strftime('%H:%M:%S') == '00:00:00':
               dateTimeAll = (estTime - todatay).days
            else:
               dateTimeAll = (estTime - todatay).days + 1

        total = sysPurchases.first_amount+sysPurchases.rest_amount+sysPurchases.freight
        names = sysPurchases.supplier
        if names != None:
            itemPurchase.append(
                '{"id":"%s","purchase_no":"%s","state":"%s","name":"%s","shipping_time":"%s","est_arrival_time":"%s","first_amount":"%s","rest_amount":"%s","freight":"%s","total_amount":"%s","bank":"%s","payee":"%s","swift_code":"%s","pay_account":"%s","date_time_all":"%s","shipping_mode":"%s","remark":"%s","pay_mode":"%s","currency":"%s"},' % (
                    sysPurchases.id,sysPurchases.purchase_no,sysPurchases.state,sysPurchases.supplier.name, sysPurchases.shipping_time, sysPurchases.est_arrival_time, sysPurchases.first_amount,sysPurchases.rest_amount,sysPurchases.freight,total,sysPurchases.bank,sysPurchases.payee,sysPurchases.swift_code,sysPurchases.pay_account,dateTimeAll,sysPurchases.shipping_mode,sysPurchases.remark,sysPurchases.pay_mode,sysPurchases.currency))
        else:
            itemPurchase.append(
                '{"id":"%s","purchase_no":"%s","state":"%s","shipping_time":"%s","est_arrival_time":"%s","first_amount":"%s","rest_amount":"%s","freight":"%s","total_amount":"%s","bank":"%s","payee":"%s","swift_code":"%s","pay_account":"%s","date_time_all":"%s","shipping_mode":"%s","remark":"%s","pay_mode":"%s","currency":"%s"},' % (
                    sysPurchases.id,sysPurchases.purchase_no,sysPurchases.state,sysPurchases.shipping_time, sysPurchases.est_arrival_time, sysPurchases.first_amount,sysPurchases.rest_amount,sysPurchases.freight,total,sysPurchases.bank,sysPurchases.payee,sysPurchases.swift_code,sysPurchases.pay_account,dateTimeAll,sysPurchases.shipping_mode,sysPurchases.remark,sysPurchases.pay_mode,sysPurchases.currency))
    itemPurchase.append(']}')
    jsonstr = ''.join(itemPurchase)
    jsonlen = len(jsonstr)
    if sysPurchase.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 修改采购主信息
@csrf_exempt
@need_login
def purchaseZhu(request):
    dic = {'id': request.GET.get('id'), 'purchase_no': request.GET.get('purchase_no'),
           'first_amount': request.GET.get('first_amount'),'rest_amount':request.GET.get('rest_amount'),
           'freight':request.GET.get('freight'),'startTimeAll':request.GET.get('startTimeAll'),'enTimeAll':request.GET.get('enTimeAll'),'remark':request.GET.get('remark'),
           'stateAll':request.GET.get('stateAll')}
    return render_to_response("purchase/purchaseZhu.html", dic)

# 修改采购主表数据
@csrf_exempt
@need_login
def updateZhuSave(request):
    # c={}
    # 修改采购主表信息
    if request.method == 'POST':
        business_name = "商品采购" #操作模块
        orId = request.POST['orId']
        sysRe = Purchase.objects.get(pk=int(orId))
        #订单号
        sysRe.purchase_no = request.POST['purchaseNo']
        #初次贷款
        sysRe.first_amount = request.POST['firstAmount']
        #尾款
        sysRe.rest_amount = request.POST['restAmount']
        #运费
        sysRe.freight = request.POST['freight']
        #发运时间
        sysRe.shipping_time = request.POST['shippingTime']
        #预计到货时间
        sysRe.est_arrival_time = request.POST['estArrivalTime']
        sysRe.remark = request.POST['remark']
        try:
           sysRe.save()
           content = "修改商品采购信息！"   #操作内容
           operationLog(request,content,business_name)
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#查询商品规格
def propval(leId):
    mySql = "select b.LE_PROPVAL_ALIAS from le_rec a LEFT JOIN le_propval_rec b on a.LE_ID=b.LE_PROPVAL_LE_ID and b.LE_PROPVAL_PROP_ID=48 where LE_ID='"+ leId +"'; "
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    jsonItme = cursor.fetchall()
    cursor.close()
    for item in jsonItme:
        val=item[0]
    return val

#查询子表信息
@csrf_exempt
@need_login
def updateZi(request):
    orId = request.GET.get('id')
    sysPurchase = Purchase.objects.get(pk = orId)
    #根据主表的id询子表的信息
    zis = getPaginator(sysPurchase.purchasedetail_set.all(),request)
    itemPurchase = ['{"total":%d,"totalPage":%d,"rows":[' % (zis.paginator.count, zis.paginator.num_pages)]
    totalAll = 0
    totalAllWb = 0
    difTotalAll = 0
    for zi in zis:
        #实际到货总价(RMB) = 采购单价(RMB)rmb_price * 实际到货到货量arrival_qty
        if zi.rmb_price and zi.arrival_qty:
            actualTotal = zi.rmb_price * zi.arrival_qty
        else:
            actualTotal = 0

        #差异总价differencesTotal = 实际到货总价(RMB) — 采购总价(RMB)
        if actualTotal and zi.rmb_price:
             differencesTotal = actualTotal - zi.rmb_amt
        else:
            differencesTotal = 0

        #求差异总价的总和(RMB)
        totalAll = totalAll + differencesTotal

        #差异数量=实际到货量-采购量
        if zi.arrival_qty and zi.package_qty:
            difTotal = zi.arrival_qty - zi.package_qty
        else:
            difTotal = 0

        #求差异数量的总和
        difTotalAll = difTotalAll + difTotal

        #总价(RMB) = 采购单价（人民币）*采购量
        rmbAmts = zi.rmb_price * zi.package_qty

        #总价(外币)=采购量*单价(外币)
        wbAmts = zi.foreign_price * zi.package_qty
        #实际到货总价(外币)=实际到货量*单价(外币)
        if zi.foreign_price and zi.arrival_qty:
            wbActualTotal = zi.foreign_price * zi.arrival_qty
        else:
            wbActualTotal = 0
        #差异总价(外币)=实际到货总价(外币)-总价(外币)
        if wbActualTotal and zi.foreign_amt:
             wbDifferencesTotal = actualTotal - zi.foreign_amt
        else:
            wbDifferencesTotal = 0

        #求差异总价的总和(外币)
        totalAllWb = totalAllWb + wbDifferencesTotal
        ziName = zi.le
        if ziName != None:
            leId = zi.le.le_id
            propvalAll = propval(str(leId))
            #获取商品图片
            imgUrl = "http://msyc-img.oss-cn-shenzhen.aliyuncs.com/"+zi.le.le_main_pic_url
            itemPurchase.append('{"id":"%s","purchase":"%s","le_code":"%s","le_barcode":"%s","le_name":"%s","package_spe":"%s","package_qty":"%s","arrival_qty":"%s","foreign_price":"%s","rmb_price":"%s","foreign_amt":"%s","rmb_amt":"%s","actual_total":"%s","differences_total":"%s","dif_total":"%s","is_new":"%s","totalAll":"%s","difTotalAll":"%s","remark":"%s","validity_date":"%s","wbAmts":"%s","wbActualTotal":"%s","wbDifferencesTotal":"%s","img_url":"%s","totalAllWb":"%s","propvalAll":"%s"},' % (
                 zi.id,zi.purchase.id,zi.le_code,zi.le_barcode,zi.le.le_name,zi.package_spe,zi.package_qty,zi.arrival_qty,zi.foreign_price,zi.rmb_price,zi.foreign_amt,rmbAmts,actualTotal,differencesTotal,difTotal,zi.is_new,totalAll,difTotalAll,zi.remark,zi.validity_date,wbAmts,wbActualTotal,wbDifferencesTotal,imgUrl,totalAllWb,propvalAll))
        else:
            itemPurchase.append('{"id":"%s","purchase":"%s","le_code":"%s","le_barcode":"%s","package_spe":"%s","package_qty":"%s","arrival_qty":"%s","foreign_price":"%s","rmb_price":"%s","foreign_amt":"%s","rmb_amt":"%s","actual_total":"%s","differences_total":"%s","dif_total":"%s","is_new":"%s","totalAll":"%s","difTotalAll":"%s","remark":"%s","validity_date":"%s","wbAmts":"%s","wbActualTotal":"%s","wbDifferencesTotal":"%s","totalAllWb":"%s"},' % (
                 zi.id,zi.purchase.id,zi.le_code,zi.le_barcode,zi.package_spe,zi.package_qty,zi.arrival_qty,zi.foreign_price,zi.rmb_price,zi.foreign_amt,rmbAmts,actualTotal,differencesTotal,difTotal,zi.is_new,totalAll,difTotalAll,zi.remark,zi.validity_date,wbAmts,wbActualTotal,wbDifferencesTotal,totalAllWb))
    itemPurchase.append(']}')
    jsonstr = ''.join(itemPurchase)
    #df = '"totalAll":%s,' % totalAll
    #jsonstr = jsonstr[0] + df + jsonstr[1:]
    jsonlen = len(jsonstr)
    if zis.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 修改采购子信息
@csrf_exempt
@need_login
def purchaseZi(request):
    dic = {'id': request.GET.get('id'), 'le_barcode': request.GET.get('le_barcode'),
           'package_qty':request.GET.get('package_qty'),
           'foreign_price':request.GET.get('foreign_price'),'rmb_price':request.GET.get('rmb_price'),'remark':request.GET.get('remark'),'validityDate':request.GET.get('validityDate'),'foreignTotal':request.GET.get('foreignTotal'),
           'rmb_amt':request.GET.get('rmb_amt'),'actual_total':request.GET.get('actual_total'),'differences_total':request.GET.get('differences_total'),'stateTypes':request.GET.get('stateTypes')}
    return render_to_response("purchase/purchaseZi.html", dic)

# 修改采购子表数据
@csrf_exempt
@need_login
def updateZiSave(request):
    # c={}
    # 修改采购主表信息
    if request.method == 'POST':
        business_name = "商品采购" #操作模块
        orId = request.POST['id']
        sysPu = PurchaseDetail.objects.get(pk=int(orId))
        sysPu.le_barcode = request.POST['leBarcode']
        #sysPu.package_spe = request.POST['packageSpe']
        sysPu.package_qty = request.POST['packageQty']
        sysPu.foreign_price = request.POST['foreignPrice']
        sysPu.rmb_price = request.POST['rmbPrice']
        sysPu.validity_date = request.POST['validityDate']
        sysPu.remark = request.POST['remark']
        try:
           sysPu.save()
           content = "修改商品采购明细信息！"   #操作内容
           operationLog(request,content,business_name)
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#删除采购明细表信息
@csrf_exempt
@need_login
def deleteZi(request):
    if request.method == 'POST':
        ids = request.POST['orId']
        #先删除角色管理表RoleResource
        try:
            business_name = "商品采购" #操作模块
            PurchaseDetail.objects.filter(pk=ids).delete()
            content = "删除商品采购明细信息！"   #操作内容
            operationLog(request,content,business_name)
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #删除成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #删除失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #删除出现异常

# 入库信息信息
@csrf_exempt
@need_login
def storageList(request):
    dic = {'id': request.GET.get('id'), 'package_qty': request.GET.get('package_qty'),'purchase':request.GET.get('purchase')}
    return render_to_response("purchase/storageList.html", dic)

#查询入库信息
@csrf_exempt
@need_login
def storageJson(request):
    orId = request.GET.get('id')
    #根据id查询主表的采购信息
    sysInBound = getPaginator(inBound.objects.filter(purchaseDetailid = orId),request)
    itemInBound = ['{"total":%d,"totalPage":%d,"rows":[' % (sysInBound.paginator.count, sysInBound.paginator.num_pages)]
    for sysInBounds in sysInBound:
        itemInBound.append('{"id":"%s","qty":"%s","create_user_name":"%s","create_time":"%s","code":"%s","barcode":"%s"},' % (
            sysInBounds.id, sysInBounds.qty,sysInBounds.create_user_name,sysInBounds.create_time,sysInBounds.code,sysInBounds.barcode))
    itemInBound.append(']}')
    jsonstr = ''.join(itemInBound)
    jsonlen = len(jsonstr)
    if sysInBound.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 保存入库信息数据
@csrf_exempt
@need_login
def storageSave(request):
    if request.method == 'POST':
        purchaseId = request.POST['id']
        username = request.COOKIES.get('username', '')
        package_qty = request.POST['qtyCount']
        inBound.objects.create(qty=package_qty, purchaseDetailid=purchaseId, create_user_name=username)

        #保存明细表的已到货数量
        sysPu = PurchaseDetail.objects.get(id=purchaseId)
        sysPu.arrival_qty = package_qty
        try:
            sysPu.save()
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#删除入库表信息
@csrf_exempt
@need_login
def deleteStorage(request):
    if request.method == 'POST':
        ids = request.POST['orId']
        #获取当前的采购量用于减去明细表的已经到货数量(ARRIVAL_QTY)
        bo = inBound.objects.get(pk=ids)
        p_id = bo.purchaseDetailid

        #根据入库表删除的采购量，减去对应的明细表的已经到货数量(ARRIVAL_QTY)
        pu = PurchaseDetail.objects.get(pk=p_id)
        pu.arrival_qty =pu.arrival_qty - bo.qty
        pu.save()
        try:
            bo.delete()
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #删除成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#商品入库导入跳转页面
@csrf_exempt
@need_login
def storageImportList(request):
    return render_to_response("purchase/storageImportList.html")

#从Excel中取数据插入到相关表中
@transaction.atomic
def storageTable(filepath,userauth,userNo):
    data = xlrd.open_workbook(filepath)
    table1 = data.sheets()[0]
    x = table1.row_values(1)
    #获取Excel第一页的主表的订单号
    purchase_no = x[0]

    pur = Purchase.objects.get(purchase_no = purchase_no)
    #逆向查询和反查询
    #purDetials = pur.purchasedetail_set.all().order_by('id')

    #读取Excel第二页的数据
    table2 = data.sheets()[1]
    len2 = table2.nrows
    for j in range(1,len2):
        row = table2.row_values(j)
        #根据Excel第一页的数据获取到的订单号去查询明细表的id（将获取到的明细表id传到定价表中）
        #将获取到的明细id赋值给定价表的关联明细表的id
        #puD = purDetials[j-1]
        puDs = PurchaseDetail.objects.filter(le_code=row[0])
        #puDetailId = inBound.objects.filter(purchaseDetailid=row[0])
        if puDs:
            puD = puDs[0]
            ziId = puD.id
            try:
                #isFlag = inBound.objects.filter(purchaseDetailid = ziId)
                inBound.objects.create(purchaseDetailid = ziId,qty = row[2],code = row[0],barcode = row[1],create_user_id=userNo,create_user_name=userauth)
                pudel = PurchaseDetail.objects.filter(le_code=row[0],le_barcode = row[1])
                if pudel:
                    #更改明细表的已到货数量
                    puD.arrival_qty = row[2]
                    puD.save()

                #如果入库单excel中有新的变化就将旧的对应的数据 赋值到新的数据中
                pulocd = PurchaseDetail.objects.filter(le_code=row[0],le_barcode = row[1])
                if not pulocd:
                    puNo = puDs[0]
                    #Excel新增的数据保存到明细表
                    puDetail =  PurchaseDetail()
                    puDetail.purchase_id = pur.id
                    puDetail.le_code = puNo.le_code
                    puDetail.le_barcode = row[1]
                    puDetail.arrival_qty = row[2]
                    puDetail.package_spe = puNo.package_spe
                    puDetail.package_qty = puNo.package_qty
                    puDetail.foreign_price = puNo.foreign_price
                    puDetail.foreign_amt = puNo.foreign_amt
                    puDetail.rmb_price = puNo.rmb_price
                    puDetail.rmb_amt = puNo.rmb_amt
                    puDetail.create_user_id = userNo
                    puDetail.create_user_name = userauth
                    puDetail.is_new = 1
                    puDetail.save()
            except Exception, e:
                pass
        else:
            #Excel新增的数据保存到明细表
            puDetail =  PurchaseDetail()
            puDetail.purchase_id = pur.id
            puDetail.le_barcode = row[1]
            puDetail.arrival_qty = row[2]
            puDetail.create_user_id = userNo
            puDetail.create_user_name = userauth
            puDetail.is_new = 1
            puDetail.save()

#上传Excel文件
def storage_uploaded_file(file, filename):
    if not os.path.exists('upload/'):
        os.mkdir('upload/')
    with open('upload/' + filename, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
    return 'upload/' + filename

@csrf_exempt
@need_login
def storageImportss(request):
    #获取当前用户名
    userauth = request.COOKIES.get('username', '')
    userNo = request.COOKIES.get('userId', '')
    #获取Excel文件
    if request.method == 'POST':
        filepath = storage_uploaded_file(request.FILES['file'], str(request.FILES['file']))
        try:
            storageTable(filepath,userauth,userNo)
        except Exception, e:
            os.remove(filepath)
            return HttpResponse("导入失败！")#导入失败
        else:
            os.remove(filepath)
            return HttpResponse("导入成功！") #导入成功
    else:
        return HttpResponse("导入失败!")#导入失败

#批量更新平均进货成本（PURCHASE_COST）
@csrf_exempt
@need_login
def updateCost(request):
     #平均进货成本(PURCHASE_COST) = SUM(单价[RMB RMB_PRICE] * 已经到货数量[ARRIVAL_QTY]) / SUM(已经到货数量[ARRIVAL_QTY])
     total = PurchaseDetail.objects.all()
     try:
         for pur in total:
             #根据货号查询明细数据
             huo = PurchaseDetail.objects.filter(le_code=pur.le_code)
             total_price = sum(map(lambda x:x.rmb_price*x.arrival_qty, huo))
             total_arrival_qty = sum(map(lambda x:x.arrival_qty, huo))
             pur.purchase_cost = total_price / total_arrival_qty
             pur.save()
         result = {"result":True}
         return HttpResponse(json.dumps(result), content_type="application/json") #审核成功
     except Exception, e:
         result = {"result":False}
         return HttpResponse(json.dumps(result), content_type="application/json") #审核失败

#新增采购明细跳转页面
@csrf_exempt
@need_login
def detailAdd(request):
    dic = {'purchaseId': request.GET.get('purchaseId')}
    return render_to_response("purchase/purchaseDetailAdd.html",dic)

# 保存采购明细信息数据
@csrf_exempt
@need_login
def detailSave(request):
    if request.method == 'POST':
        business_name = "商品采购" #操作模块
        purchaseId = request.POST['purchaseId']#主表id
        purchaseIds = Purchase.objects.get(id = purchaseId)
        leCode = request.POST['leCode']#货号
        barcode = request.POST['leBarcode']#国际条码
        packageSpe = request.POST['packageSpe']#包装规格
        packageQty = request.POST['packageQty']#采购量
        foreignPrice = request.POST['foreignPrice']#单价（外币）
        rmbPrice = request.POST['rmbPrice']#单价（RMB）
        startdata = request.POST['startdata']#商品有效期
        remark = request.POST['remark']#采购备注
        userNo = request.COOKIES.get('userId', '')
        userauth = request.COOKIES.get('username', '')
        try:
            lebarcode = Le.objects.get(le_barcode=str(barcode))
            #人民币总价=采购单价（人民币）*采购量
            rmbAmt = float(rmbPrice) * float(packageQty)
            #保存到采购明细表中
            detailId = PurchaseDetail.objects.create(purchase = purchaseIds,le = lebarcode,le_code = leCode,le_barcode = barcode, package_spe = packageSpe,
                                      package_qty = packageQty,foreign_price = decimal.Decimal(foreignPrice),
                                      rmb_price = decimal.Decimal(rmbPrice),validity_date = parseDatetime(startdata),
                                      remark =remark,modify_user_id = userNo,confirm_qty = userNo,rmb_amt = rmbAmt,state = 0,is_new=2)
            #保存到入库单表中
            inBound.objects.create(purchaseDetailid = detailId.id,qty = 0,code = leCode,barcode = barcode,create_user_id = userNo,create_user_name = userauth)
            content = "新增商品采购明细信息！"   #操作内容
            operationLog(request,content,business_name)
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except ObjectDoesNotExist:
            #人民币总价=采购单价（人民币）*采购量
            rmbAmt = float(rmbPrice) * float(packageQty)
            detailId = PurchaseDetail.objects.create(purchase = purchaseIds,le_code = leCode,le_barcode = barcode, package_spe = packageSpe,
                                      package_qty = packageQty,foreign_price = decimal.Decimal(foreignPrice),
                                      rmb_price = decimal.Decimal(rmbPrice),validity_date = parseDatetime(startdata),
                                      remark =remark,modify_user_id = userNo,confirm_qty = userNo,rmb_amt = rmbAmt,state = 0,is_new=2)
            #保存到入库单表中
            inBound.objects.create(purchaseDetailid = detailId.id,qty = 0,code = leCode,barcode = barcode,create_user_id = userNo,create_user_name = userauth)
            content = "新增商品采购明细信息！"   #操作内容
            operationLog(request,content,business_name)
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
    else:
        result = {"result":False}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存成功

#查询货号是否存在
@csrf_exempt
@need_login
def seachLeCode(request):
    leCode = request.POST['leCode']
    try:
        roleResource = PurchaseDetail.objects.get(le_code=leCode)
        if roleResource:
            result = 0   #商品货号已经存在的就提示
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        else:
            result = 1   #商品货号不存在就不提示
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
    except ObjectDoesNotExist:
        result = 1  #商品货号不存在就不提示
        return HttpResponse(json.dumps(result), content_type="application/json") #保存成功

#确认采购单
@csrf_exempt
@need_login
def confirmPurchase(request):
     if request.method == 'POST':
        try:
            purchaseId = request.POST['purchaseId']
            #更改state的状态
            sysPu = Purchase.objects.get(id=purchaseId)
            str_pay = "货前付款".decode('utf8')
            if sysPu.pay_mode == str_pay:
                if sysPu.state == 1:
                    sysPu.state = 2 #财务部看到李总已签署的采购单，就发起付款将state更改为2(确认付款)
                elif sysPu.state == 2:
                    sysPu.state = 3 #商品部向供应商确认是否已发货,将state更改为3（确认下单）
                elif sysPu.state == 3:
                    sysPu.state = 4 #商品部向供应商确认是否已发货,将state更改为3（确认发货）
                elif sysPu.state == 5:
                    sysPu.state = 6 #将state更改为6（已入仓）
                elif sysPu.state == 6:
                    sysPu.state = 7 #将state更改为7（已上架）
                elif sysPu.state == 7:
                    sysPu.state = 8 #将state更改为8（已完成）
                elif sysPu.state == 8:
                    sysPu.state = 9 #将state更改为8（已完成） 整个流程走完
            else:
                 if sysPu.state == 1:
                    sysPu.state = 2 #确认采购-财务部看到李总已签署的采购单，就发起付款将state更改为2(确认付款)
                 elif sysPu.state == 2:
                    sysPu.state = 4 #商品部向供应商确认是否已发货,将state更改为3（确认发货）
                 elif sysPu.state == 5:
                    sysPu.state = 6 #将state更改为6（已入仓）
                 elif sysPu.state == 6:
                    sysPu.state = 7 #将state更改为7（已上架）
                 elif sysPu.state == 7:
                    sysPu.state = 3 #确认收款-对方已经收到货物
                 elif sysPu.state == 3:
                    sysPu.state = 8 #将state更改为8（已完成）
                 elif sysPu.state == 8:
                    sysPu.state = 9 #将state更改为8（已完成） 整个流程走完

            sysPu.save()
            #记录日志信息
            if sysPu.state >=1 and sysPu.state <=5 or sysPu.state==9:
                business_name = "商品采购" #操作模块
            if sysPu.state >=6 and sysPu.state <=8:
                business_name = "商品入库" #操作模块
            content = "修改商品状态为 %d"%int(sysPu.state)   #操作内容
            operationLog(request,content,business_name)
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
     else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#确认商品状态
@csrf_exempt
@need_login
def confirmGoods(request):
     if request.method == 'POST':
        try:
            business_name = "商品入库" #操作模块
            purchaseId = request.POST['purchaseId']
            selectId = request.POST['selectId']
            #更改state的状态
            sysPu = Purchase.objects.get(id=purchaseId)
            sysPu.state = selectId
            sysPu.save()
            content = "修改商品状态为 %d"%int(sysPu.state)   #操作内容
            operationLog(request,content,business_name)
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
     else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#新增采购明细跳转页面
@csrf_exempt
@need_login
def updateZhuCi(request):
    dic = {'id': request.GET.get('id'),'bank': request.GET.get('bank'),'payee': request.GET.get('payee'),
           'swift_code': request.GET.get('swift_code'),'pay_account': request.GET.get('pay_account'),'currency': request.GET.get('currency')}
    return render_to_response("purchase/purchaseZhuCiUpdate.html",dic)

# 修改采购主表数据
@csrf_exempt
@need_login
def zhuCiSave(request):
    # c={}
    # 修改采购主表信息
    if request.method == 'POST':
        business_name = "商品采购" #操作模块
        orId = request.POST['orId']
        sysPu = Purchase.objects.get(pk=int(orId))
        sysPu.bank = request.POST['bank']
        sysPu.payee = request.POST['payee']
        sysPu.swift_code = request.POST['swift_code']
        sysPu.pay_account = request.POST['pay_account']
        sysPu.currency = request.POST['currency']
        try:
           sysPu.save()
           content = "修改商品采购主表信息！"   #操作内容
           operationLog(request,content,business_name)
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#分页控件
def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result