# -*- coding: utf-8 -*-
# import codecs

from django.shortcuts import render_to_response
from django.http import HttpResponse, HttpResponseRedirect

import xlwt

from pyonion.models import User,UserAgent
from pyonion.auth.views import need_login
import json
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext
from django import forms
from django.db import connections
from decimal import *
import md5
import datetime
import simplejson


# 表单
class LoginForm(forms.Form):
    username = forms.CharField(label=u"用户名",widget=forms.TextInput, error_messages={"required": u"用户名不能为空！"})
    password = forms.CharField(label=u"密码",widget=forms.PasswordInput, error_messages={"required": u"密码不能为空！"})

# 登陆
@csrf_exempt
def login(request):
    is_redirect = request.GET.get("redirect", False)
    if request.method == 'POST':
        uf = LoginForm(request.POST)
        if uf.is_valid():
            # 获取表单用户密码
            username = uf.cleaned_data['username']
            password = uf.cleaned_data['password']
            p = md5.new()
            p.update(password)
            password = p.hexdigest()
            # 获取的表单数据与数据库进行比较
            user = None
            try:
                user = User.objects.get(
                    user_code=username, user_password=password)
            except Exception, e:
                pass
            if user:
                if user.user_type != 5:
                    # 比较成功，跳转index
                    response = HttpResponseRedirect('/index/')
                    dt = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
                    # 将username写入浏览器cookie,失效时间为3600
                    response.set_cookie('username', username, expires=dt)
                    response.set_cookie('userId', user.user_id, expires=dt)
                    # request.session.set_expiry(60)
                    return response
                else:
                    agent = None
                    try:
                        agent = UserAgent.objects.get(user_code=username)
                        if agent is not None:
                            agentId = agent.agent_id
                            # if hasattr(request, 'session'):
                            #request.session['agentId_language'] = agentId
                            dt = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
                            response = HttpResponseRedirect('/index/')
                            response.set_cookie('username', username, expires=dt)
                            response.set_cookie('userId', user.user_id, expires=dt)
                            response.set_cookie( 'agentId_language', agentId, expires=dt)
                            return response
                    except Exception, e:
                        pass
            else:
                # 比较失败，还在login
                return HttpResponseRedirect('/login/')
        else:
            return HttpResponseRedirect('/login/')
    else:
        uf = LoginForm()
        return render_to_response('login/login.html', {'uf': uf, 'is_redirect': is_redirect}, context_instance=RequestContext(request))


# 登陆成功
@csrf_exempt
@need_login
def index(req):
    username = req.COOKIES.get('username', '')
    userId = req.COOKIES.get('userId', '')
    return render_to_response("index.html",{"username":username,"userId":userId})

def auth(request, template_name):
    print(request.body)
    is_login = False
    try:
        username = request.COOKIES.get('username', '')
        if username == None or username == '':
            is_login = False
            template_name = '/login/'
        else:
            is_login = True
    except:
            is_login = False
            template_name = '/login/'
    return is_login, template_name

# 退出
def logout(req):
    response = HttpResponse('logout !!')
    # 清理cookie里保存usernam e
    response.delete_cookie('username')
    return HttpResponseRedirect('/pyonion/')

# 首页页面跳转 New
@need_login
def indexList(request):
    return render_to_response("login/indexList.html")

@csrf_exempt
def indexListJson(request):
    start = request.GET.get('start')
    end = request.GET.get('end')
    mySql = "SELECT sum(sales_amt) as total,  sum(agent_amt) as agent_amt, CONCAT(round(sum(agent_amt)/sum(sales_amt)*100,2),'%') as profit_rate, (SELECT count(1) from member_rec c where c.MEMBER_TYPE = 3)  AS storeCount , sum(member_count) as member_count, sum(member_sod_count) as member_sod_count, CONCAT(round(sum(member_sod_count)/sum(member_count)*100,2),'%') as member_active_rate, sum(sod_item_count) as sod_item_count, sum(sod_count) as sod_count, round(sum(sales_amt)/sum(sod_count),2) as sodAvgPrice, round(sum(sales_amt)/sum(sod_item_count),2) as sod_item_avg_price , round(sum(sod_count)/sum(member_sod_count),2) as  member_sod_avg_count , sum(register_amt) as register_amt, sum(tmn_amt) as tmn_amt, sum(profit_amt) as profit_amt, round(sum(profit_amt)/(SELECT count(1) from member_rec c WHERE  c.MEMBER_TYPE = 3) ,2) as avgProfit,CONCAT(round(sum(profit_amt)/sum(sales_amt)*100,2),'%') as profit_rate1,round(sum(agent_amt)/(SELECT count(1) from member_rec c WHERE  c.MEMBER_TYPE = 3) ,2) as avgAgent,sum(refund_amt) as refund_amt,sum(refund_sod_item_count) as refund_sod_item_count,CONCAT(round(sum(refund_sod_item_count)/sum(sod_item_count)*100,2),'%') as refund_rate FROM dim_store_reports "
    whereSql = " WHERE "
    totalGroupSql = "  ORDER BY total desc "
    if start == None:
        whereSql = whereSql + " report_date <= '%s' " % (end)
    else:
        whereSql = whereSql + "report_date >= '%s' AND report_date <= '%s'" % (start, end)
    totalSql = mySql + whereSql + totalGroupSql
    cursor = connections['slave'].cursor()
    cursor.execute(totalSql)
    jsonItme = cursor.fetchall()
    desc = cursor.description
    cursor.close()

    items = ['{"rows":']
    li = []
    for item in jsonItme:
        repoerItem = {}
        i = 0
        for de in desc:
            if isinstance(item[i], Decimal):
                repoerItem[de[0]] = str(item[i])
            else:
                repoerItem[de[0]] = item[i]
            i = i + 1
        li.append(repoerItem)
    items.append(json.dumps(list(li)))
    items.append('}')
    return HttpResponse(items, content_type="application/json")

#导出代理商明细
def indexExport(request):
    start = request.GET.get('start')
    end = request.GET.get('end')
    mySql = "SELECT sum(sales_amt) as total,  sum(agent_amt) as agent_amt, CONCAT(round(sum(agent_amt)/sum(sales_amt)*100,2),'%') as profit_rate, (SELECT count(1) from member_rec c where c.MEMBER_TYPE = 3)  AS storeCount , sum(member_count) as member_count, sum(member_sod_count) as member_sod_count, CONCAT(round(sum(member_sod_count)/sum(member_count)*100,2),'%') as member_active_rate, sum(sod_item_count) as sod_item_count, sum(sod_count) as sod_count, round(sum(sales_amt)/sum(sod_count),2) as sodAvgPrice, round(sum(sales_amt)/sum(sod_item_count),2) as sod_item_avg_price , round(sum(sod_count)/sum(member_sod_count),2) as  member_sod_avg_count , sum(register_amt) as register_amt, sum(tmn_amt) as tmn_amt, sum(profit_amt) as profit_amt, round(sum(profit_amt)/(SELECT count(1) from member_rec c WHERE  c.MEMBER_TYPE = 3) ,2) as avgProfit,CONCAT(round(sum(profit_amt)/sum(sales_amt)*100,2),'%') as profit_rate1,round(sum(agent_amt)/(SELECT count(1) from member_rec c WHERE  c.MEMBER_TYPE = 3) ,2) as avgAgent,sum(refund_amt) as refund_amt,sum(refund_sod_item_count) as refund_sod_item_count,CONCAT(round(sum(refund_sod_item_count)/sum(sod_item_count)*100,2),'%') as refund_rate FROM dim_store_reports "
    whereSql = " WHERE "
    totalGroupSql = "  ORDER BY total desc "
    if start == None:
        whereSql = whereSql + " report_date <= '%s' " % (end)
    else:
        whereSql = whereSql + "report_date >= '%s' AND report_date <= '%s'" % (start, end)
    totalSql = mySql + whereSql + totalGroupSql
    cursor = connections['slave'].cursor()
    cursor.execute(totalSql)
    row_all = cursor.fetchall()
    cursor.close()

    _lst = []
    _lst.extend(row_all[:])
    _lst.insert(0, ['零售总额','代理收入','利润率','经纪人总数','新注册客户数','下单客户','活跃率','销售件数','销售单数','客单价','件单价','客单量','拓客收入','销售收入','总利润','平均利润','利润率','平均贡献','退款金额','退款件数','退款率'])

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for row, rowdata in enumerate(_lst):
        for col, val in enumerate(rowdata):
            sheet.write(row, col, val, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=统计导出.xls'
    book.save(response)
    return response

def indexSeachJson(request):
    jsoncalback = request.GET.get('jsoncalback')
    mySql = "select report_date,total,sod_item_count,sod_count,sod_item_avg_price,member_sod_avg_count,A,count,B,C,D,E,dt from (SELECT DATE_FORMAT(report_date,'%Y-%m-%d') report_date,sum(sales_amt) as total,  sum(sod_item_count) as sod_item_count, sum(sod_count) as sod_count, round(sum(sales_amt) / sum(sod_item_count), 2) as sod_item_avg_price, round(sum(sales_amt) / sum(member_sod_count), 2) as member_sod_avg_count FROM dim_store_reports  where DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= date(report_date) group by DATE_FORMAT(report_date,'%Y-%m-%d'))  as at left join (SELECT '' A,count(STORE_ID) as count,'' B,'' C,'' D,'' E, DATE_FORMAT(CONVERT(STORE_CHECK_TIME,DATE),'%Y-%m-%d') as dt FROM store_rec WHERE STORE_FLG = 3  group by DATE_FORMAT(CONVERT(STORE_CHECK_TIME,DATE),'%Y-%m-%d')) as bt on at.report_date = bt.dt  ORDER BY report_date desc "
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    jsonItme = cursor.fetchall()
    desc = cursor.description
    cursor.close()

    keys = ['report_date','total', 'sod_item_count', 'sod_count', 'sod_item_avg_price',
            'member_sod_avg_count', 'A', 'count', 'B', 'C', 'D', 'E','dt']
    jsonItem_lst = []
    for i in jsonItme:
        temp = []
        for j in i:
            s = str(j)
            temp.append(s)
        jsonItem_lst.append(dict(zip(keys, temp)))
    json_final = {}
    json_final["rows"] = jsonItem_lst
    items = json.dumps(json_final)

    if jsoncalback:
        jsonplist = "%s(%s)" % (jsoncalback, str(items))
    return HttpResponse(jsonplist, content_type="application/json")


def indexSeachJsons(request,jsoncalback):
    mySql = "select * from (SELECT DATE_FORMAT(report_date,'%Y-%m-%d') report_date,sum(sales_amt) as total,  sum(sod_item_count) as sod_item_count, sum(sod_count) as sod_count, round(sum(sales_amt) / sum(sod_item_count), 2) as sod_item_avg_price, round(sum(sod_count) / sum(member_sod_count), 2) as member_sod_avg_count FROM dim_store_reports  where DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= date(report_date) group by DATE_FORMAT(report_date,'%Y-%m-%d'))  as at left join (SELECT '' A,count(STORE_ID) as count,'' B,'' C,'' D,'' E, DATE_FORMAT(CONVERT(STORE_CHECK_TIME,DATE),'%Y-%m-%d') as dt FROM store_rec WHERE STORE_FLG = 3  group by DATE_FORMAT(CONVERT(STORE_CHECK_TIME,DATE),'%Y-%m-%d')) as bt on at.report_date = bt.dt  ORDER BY report_date desc "
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    jsonItme = cursor.fetchall()
    desc = cursor.description
    cursor.close()
    items = ['{"rows":']
    li = []
    for item in jsonItme:
        repoerItem = {}
        i = 0
        for de in desc:
            if isinstance(item[i], Decimal):
                repoerItem[de[0]] = str(item[i])
            else:
                repoerItem[de[0]] = item[i]
            i = i + 1
        li.append(repoerItem)
    items.append(json.dumps(list(li)))
    items.append('}')
    return HttpResponse(simplejson.dumps({"jsonp": items,"function": jsoncalback }))
