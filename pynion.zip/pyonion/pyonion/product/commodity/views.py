# -*- coding: utf-8 -*-
#import codecs

import json
from pyonion.auth.views import need_login

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render_to_response
from django.core.serializers.json import DjangoJSONEncoder

from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import connections
from pyonion.models import Let

@need_login
@csrf_exempt
#代理商统计跳转页面
def commoditylist(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("product/commodity/commodityList.html",dic)

#总库查询页面
@csrf_exempt
@need_login
def commodityJson(request):
    seacheLeCode = request.GET.get('seacheLeCode')
    seacheBarcode = request.GET.get('seacheBarcode')
    seacheLeName = request.GET.get('seacheLeName')
    categoryOne = request.GET.get('categoryOne')
    state = request.GET.get('state')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheLeCode:
        likeSql = likeSql + (" AND c.LE_CODE like '%%%s%%' " % seacheLeCode)

    if seacheBarcode:
        likeSql = likeSql + (" AND c.LE_BARCODE like '%%%s%%' " % seacheBarcode)

    if seacheLeName:
        likeSql = likeSql + (" AND c.LE_NAME like '%%%s%%' " % seacheLeName)

    if categoryOne:
        #第一品名
        #likeSql = likeSql + (" AND b.let_id1 = %s" % categoryOne)
        likeSql = likeSql +"AND b.let_id1=%s or b.let_id=%s"%(categoryOne,categoryOne);

    if state:
        #商品状态
        likeSql = likeSql + (" AND c.LE_STAT = %s" % state)

    whereSql = " WHERE 1 = 1 "
    whereSql = whereSql + likeSql
    mySql = '''
              select
                c.LE_ID,
                c.LE_NAME,
                c.LE_CODE,
                c.LE_BARCODE,
                c.LE_QTY,
                c.LE_HSCODE,
                CONCAT("http://msyc-img.oss-cn-shenzhen.aliyuncs.com/",c.LE_MAIN_PIC_URL) LE_MAIN_PIC_URL,
                c.LE_NW,
                c.LE_SECOND_NAME,
                c.LE_SHORT_NAME,
                c.LE_SPRICE3,
                c.LE_STAT,
                c.LE_CROSS_TAX,
                c.LE_SPRICE2,
                c.LE_TAX,
                c.LE_TAX_NO,
                c.LE_SPRICE1,
                c.LE_SPRICE,
                c.LE_COST,
                c.LE_RATE,
                a.*
                from ms_stock a
                left join le_rec c on a.LE_ID=c.LE_ID
                inner join let_rec b on c.LE_LET_ID=b.LET_ID  %s
            ''' % (whereSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#总库明细查询页面
@csrf_exempt
@need_login
def commodityDetailJson(request):
    leId = request.GET.get('leId')
    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if leId:
        likeSql = " AND c.LE_ID = %s" % leId

    whereSql = " WHERE 1 = 1 "
    whereSql = whereSql + likeSql
    mySql = '''
              select
                c.LE_NAME,
                c.LE_CODE,
                c.LE_BARCODE,
                c.LE_QTY,
                c.LE_HSCODE,
                CONCAT("http://msyc-img.oss-cn-shenzhen.aliyuncs.com/",c.LE_MAIN_PIC_URL) LE_MAIN_PIC_URL,
                c.LE_NW,
                c.LE_SECOND_NAME,
                c.LE_SHORT_NAME,
                c.LE_SPRICE3,
                c.LE_CROSS_TAX,
                c.LE_SPRICE2,
                c.LE_TAX,
                c.LE_TAX_NO,
                c.LE_SPRICE1,
                c.LE_SPRICE,
                c.LE_COST,
                c.LE_RATE,
                d.BRAND_NAME,
                d.BRAND_NAME_CN,
                e.COUNTRY_NAME,
                f.UNIT_NAME,
                g.LE_PROPVAL_ALIAS as ALIAS ,
                h.LE_PROPVAL_ALIAS as self_life ,
                a.*
                from ms_stock a
                left join le_rec c on a.LE_ID=c.LE_ID
                inner join let_rec b on c.LE_LET_ID=b.LET_ID
                LEFT JOIN brand_rec d on c.LE_BRAND_ID=d.BRAND_ID
                LEFT JOIN country_rec e on c.LE_COUNTRY_ID=e.COUNTRY_ID
                LEFT JOIN unit_rec f on c.LE_UNIT_ID=f.UNIT_ID
                LEFT JOIN le_propval_rec g
                on c.LE_ID=g.LE_PROPVAL_LE_ID and g.LE_PROPVAL_PROP_ID=48
                LEFT JOIN le_propval_rec h
                on c.LE_ID=g.LE_PROPVAL_LE_ID and g.LE_PROPVAL_PROP_ID=35  %s
            ''' % (whereSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

# 查询商品类型(第一品类)
def categoryOne(request):
	letType = Let.objects.filter(let_id__isnull=False,let_parent_id=0).order_by('let_id')
        itemType = ['{root:[']
        for letTypes in letType:
            itemType.append('{"let_id":"%s","let_name":"%s"},' % (letTypes.let_id, letTypes.let_name))
        itemType.append(']}')
        jsonstr = ''.join(itemType)
        jsonlen = len(jsonstr)
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
        return HttpResponse(jsonstr, content_type="application/json")

# 查询商品类型(第二品类)
def categoryTwo(request):
    letParentId = request.GET.get('letParentId')
    letTypeTwo = Let.objects.filter(let_parent_id=letParentId)
    itemType = ['{root:[']
    for letTypeTwos in letTypeTwo:
        itemType.append('{"let_id":"%s","let_name":"%s"},' % (letTypeTwos.let_id, letTypeTwos.let_name))
    itemType.append(']}')
    jsonstr = ''.join(itemType)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 查询商品类型(第三品类)
def categoryThree(request):
    letParentIdAll = request.GET.get('letParentIdAll')
    letTypeThree = Let.objects.filter(let_parent_id=letParentIdAll)
    itemType = ['{root:[']
    for letTypeThrees in letTypeThree:
        itemType.append('{"let_id":"%s","let_name":"%s"},' % (letTypeThrees.let_id, letTypeThrees.let_name))
    itemType.append(']}')
    jsonstr = ''.join(itemType)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

def getPaginator(objs, request):
    size = request.GET.get('limit')
    pageNo = request.GET.get('page')
    if size is None:
        size = 1
    if pageNo is None:
        pageNo = 1
    paginator = Paginator(objs, size)
    try:
        result = paginator.page(pageNo)
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result
