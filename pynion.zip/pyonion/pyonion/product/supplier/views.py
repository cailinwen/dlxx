# -*- coding: utf-8 -*-
#import codecs

import json
from pyonion.auth.views import need_login
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render_to_response
from django.core.serializers.json import DjangoJSONEncoder
from pyonion.models import Supplier

from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import connections

#供应商列表页
@csrf_exempt
@need_login
def supplierList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("product/supplier/supplierList.html",dic)

#供应商查询页面
@csrf_exempt
@need_login
def supplierJson(request):
    supplierName = request.GET.get('supplierName')
    supplierCode = request.GET.get('supplierCode')
    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if supplierName:
        likeSql = " AND t.name like '%%%s%%' " % supplierName

    if supplierCode:
        likeSql = " AND t.code like '%%%s%%' " % supplierCode

    whereSql = " WHERE 1 = 1 "
    whereSql = whereSql + likeSql
    mySql = '''
              select * from ms_supplier t %s
            ''' % (whereSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#供应商修改查询页面
@csrf_exempt
@need_login
def supplierDetail(request):
    orId = request.GET.get('orId')
    if orId:
        likeSql = " AND t.ID = %s" % orId

    whereSql = " WHERE 1 = 1 "
    whereSql = whereSql + likeSql
    mySql = '''
              select * from ms_supplier t %s
            ''' % (whereSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#供应商信息修改
@csrf_exempt
def supplierUpdate(request):
    # c={}
    # 修改采购主表信息
    if request.method == 'POST':
        try:
            orId = request.POST['ID']
            if orId:
                supplier = Supplier.objects.get(pk=int(orId))
                supplier.code = request.POST['CODE']
                supplier.name = request.POST['NAME']
                supplier.name_en = request.POST['NAME_EN']
                supplier.country_code = request.POST['COUNTRY_CODE']
                supplier.catalog = request.POST['CATALOG']
                supplier.address = request.POST['ADDRESS']
                supplier.zip = request.POST['ZIP']
                supplier.contacter = request.POST['CONTACTER']
                supplier.email = request.POST['EMAIL']
                supplier.tel = request.POST['TEL']
                supplier.weixin = request.POST['WEIXIN']
                supplier.qq = request.POST['QQ']
                supplier.other_contact = request.POST['OTHER_CONTACT']
                supplier.contacter2 = request.POST['CONTACTER2']
                supplier.email2 = request.POST['EMAIL2']
                supplier.tel2 = request.POST['TEL2']
                supplier.weixin2 = request.POST['WEIXIN2']
                supplier.qq2 = request.POST['QQ2']
                supplier.other_contact2 = request.POST['OTHER_CONTACT2']
                supplier.currency = request.POST['CURRENCY']
                supplier.bank = request.POST['BANK']
                supplier.account = request.POST['ACCOUNT']
                supplier.remark = request.POST['REMARK']
                supplier.principal = request.POST['PRINCIPAL']
                supplier.swift_code = request.POST['SWIFT_CODE']
                supplier.state = request.POST['STATE']
                supplier.save()
            else:
                Supplier.objects.create(code = request.POST['CODE'],name = request.POST['NAME'],name_en=request.POST['NAME_EN'],country_code=request.POST['COUNTRY_CODE'],
                                                   catalog=request.POST['CATALOG'],address=request.POST['ADDRESS'],zip=request.POST['ZIP'],contacter=request.POST['CONTACTER'],
                                                   email=request.POST['EMAIL'],tel = request.POST['TEL'],weixin = request.POST['WEIXIN'],qq = request.POST['QQ'],
                                                   other_contact = request.POST['OTHER_CONTACT'],contacter2 = request.POST['CONTACTER2'],email2 = request.POST['EMAIL2'],
                                                   tel2 = request.POST['TEL2'],weixin2 = request.POST['WEIXIN2'],qq2 = request.POST['QQ2'],other_contact2 = request.POST['OTHER_CONTACT2'],
                                                   currency = request.POST['CURRENCY'],bank = request.POST['BANK'],account = request.POST['ACCOUNT'],state = request.POST['STATE'],
                                                   remark = request.POST['REMARK'],principal = request.POST['PRINCIPAL'],swift_code = request.POST['SWIFT_CODE'])
            result = {"success":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
             result = {"success":False}
             return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
         result = {"success":False}
         return HttpResponse(json.dumps(result), content_type="application/json") #保存失败

def getPaginator(objs, request):
    size = request.GET.get('limit')
    pageNo = request.GET.get('page')
    if size is None:
        size = 1
    if pageNo is None:
        pageNo = 1
    paginator = Paginator(objs, size)
    try:
        result = paginator.page(pageNo)
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result