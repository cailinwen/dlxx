# -*- coding: utf-8 -*-
#import codecs

import json
import xlwt
from pyonion.auth.views import need_login

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from pyonion.models import Purchase

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage

#商品采购列表页
@need_login
def productList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("product/productList.html",dic)

#商品采购查询列表页
def productJson(request):
    sodNameParam = request.GET.get('supplier')
    queryset = Purchase.objects.all().order_by('id')
    if sodNameParam:
        queryset = queryset.filter(store__store_name__icontains=sodNameParam)

    purchases = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (purchases.paginator.count, purchases.paginator.num_pages)]
    for purchase in purchases:
        items.append(
            '{"id":"%s","supplier":"%s","first_amount":"%s","pay_account":"%s","rest_amount":"%s","shipping_mode":"%s"},' % (
                purchase.id,purchase.supplier, purchase.first_amount, purchase.pay_account, purchase.rest_amount,purchase.shipping_mode))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if purchases.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#商品采购新增跳转页面
@need_login
def productAdd(request):
    return render_to_response("product/productAdd.html")


#分页控件
def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result