# -*- coding: utf-8 -*-
#import codecs
import time
from django.shortcuts import render_to_response
from pyonion.auth.views import need_login
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.http import HttpResponse, HttpResponseRedirect
from django.template import RequestContext

from pyonion.models import Resource


#包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt

#资源页面跳转
@need_login
def resourceSeachList(request):
      dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
      return render_to_response("resource/resourceList.html",dic)

#资源信息信息列表展示
@csrf_exempt
@need_login
def resourceList(request):
    nameParam = request.GET.get('nameParam')
    if nameParam != None:
	   resource = getPaginator(Resource.objects.filter(name__icontains=nameParam).order_by('-id'),request)
    else:
	   resource = getPaginator(Resource.objects.filter().order_by('-id'),request)
    items = ['{"total":%d,"totalPage":%d,"rows":['%(resource.paginator.count,resource.paginator.num_pages)]
    for resources in resource:
     items.append('{"id":"%s","name":"%s","url":"%s","type":"%s","create_time":"%s","parentId":"%s"},'%(resources.id,resources.name,resources.url,resources.type,resources.create_time,resources.parentId))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if resource.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr,content_type="application/json")

# 资源新增信息跳转页面
@need_login
def resourceAdd(request):
    return render_to_response("resource/resourceAdd.html")

# 新增角色
@csrf_exempt
def resourceSave(request):
    # c={ }
    # 新增角色表信息
    name = request.POST.get('name')
    url = request.POST.get('url')
    type = request.POST.get('mySelect')
    parentId = request.POST.get('setchoose')
    create_time= time.strftime('%Y-%m-%d %H:%M:%S')
    if int(type) != 1:
         resourceItems = Resource(name=name,url=url,type=type,parentId=parentId,create_time=create_time)
    else:
        resourceItems = Resource(name=name,url=url,type=type,parentId=int('0'),create_time=create_time)
    resourceItems.save()
    return render_to_response("resource/resourceList.html")

# 资源修改信息跳转页面
@csrf_exempt
@need_login
def updateResourceInfo(request):
    dic = {'Id': request.GET.get('Id'), 'name': request.GET.get('name'),
           'url': request.GET.get('url'), 'type': request.GET.get('type'),'parentId': request.GET.get('parentId')}
    return render_to_response("resource/rsourceUpdate.html",dic)

# 修改资源信息
@csrf_exempt
def resourceInsert(request):
    # c={}
    # 根据资源名查询资源信息对该资源信息进行修改()
    name = request.GET.get('name')
    url = request.GET.get('url')
    type = request.GET.get('mySelect')
    Id  = request.GET.get('Id')
    parentId = request.GET.get('setchoose')
    resourceRe = Resource.objects.get(id=int(Id))
    # 修改资源表信息
    resourceRe.name = name
    resourceRe.url = url
    resourceRe.type = type
    resourceRe.parentId=parentId
    resourceRe.save()
    return render_to_response("resource/resourceList.html")

# 根据资源类型查询
def seachType(request):
    typeParam = request.GET.get('type')
    if typeParam != None:
	   tyepResource = Resource.objects.filter(type=typeParam).order_by('-id')
    else:
	   tyepResource = Resource.objects.filter().order_by('-id')
    itemType = ['[']
    for tyepResources in tyepResource:
        itemType.append('{"id":"%s","name":"%s"},' % (tyepResources.id, tyepResources.name))
    itemType.append(']')
    jsonstr = ''.join(itemType)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

#删除资源信息
@csrf_exempt
@need_login
def resourceDelete(request):
    ids = request.GET["resourceId"]
    Resource.objects.filter(id=ids).delete()
    return render_to_response('resource/resourceList.html',context_instance=RequestContext(request))

def getPaginator(objs, request):
	paginator = Paginator(objs,request.GET.get('size'))
	try:
		result = paginator.page(request.GET.get('pageNo'))
	except (EmptyPage, InvalidPage):
		result = paginator.page(paginator.num_pages)
	return result