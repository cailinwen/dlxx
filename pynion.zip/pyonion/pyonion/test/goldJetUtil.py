# -*- coding:UTF-8 -*-
__author__ = 'Administrator'
import base64
import md5
import json
import requests


seller = '洋葱小姐'
api_key = 'yc123456'
mark = 'check'

sodNo = "11"
idcard = "411321198705253625"
tel_phone = "13724038226"
address = "建中路20号首层"
order ={"order_sn":sodNo,"idcard":idcard,"tel_phone":tel_phone,"address":address}

md5 = md5.new()
md5.update(api_key)
api_key = md5.hexdigest()

#如果你将 verify 设置为False，Requests也能忽略对SSL证书的验证。
res = requests.post(
    "http://oms.cargo100.com/api/index.php?act=abnormal_bc&op=order",
    data={
        "seller": base64.b64encode(seller,None),
        "api_key": base64.b64encode(api_key, None),
        "mark": base64.b64encode(mark,None),
        "order": base64.b64encode((json.dumps(order)), None)
    }
)
#print res.content
print res.json()['idcard_amount']
