# -*- coding: utf-8 -*-
#import codecs
from __future__ import unicode_literals
__author__ = 'Administrator'

import httplib

def test1(request):
    url = "http://www.baidu.com"

    conn = httplib.HTTPConnection("www.baidu.com")
    conn.request(method="GET",url=url)

    response = conn.getresponse()
    res= response.read()

    print res