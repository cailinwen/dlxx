# -*- coding: utf-8 -*-
# import codecs
from __future__ import unicode_literals
# 包装csrf请求，避免django认为其实跨站攻击脚本
from decimal import *
import md5

#测试MD5加密
def testEncryption():
	password = 'yc123'
	p = md5.new()
	p.update(password)
	password = p.hexdigest()
	print(password)


testEncryption()


