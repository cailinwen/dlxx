__author__ = 'Administrator'
# -*- coding: utf-8 -*-

import httplib2

def get_request_header(self):
        return {
                 'Content-type': 'application/x-www-form-urlencoded',
                 "Cache-Control": "no-cache",
                 "Connection": "Keep-Alive",
        }
body = 'friendIdStr=1764930360&userWebId=3464602282&webType=sina'
http = httplib2.Http()
res = http.request("http://yourgift.sinaapp.com/system/messageAdd","POST", body=body)
#res = http.request("http://yourgift.sinaapp.com/system/messageSend","POST", body=body)

print res