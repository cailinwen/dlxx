# -*- coding: utf-8 -*-
#import codecs
import django
import json
import time

from django.shortcuts import render_to_response,render
from django.http import HttpResponse,HttpResponseRedirect
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from pyonion.models import Message,Replies
#包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django import forms
from django.template import RequestContext
from pyonion.login.views import LoginForm

def myIndex(request):
     uf = LoginForm()
     #cookie =  request.COOKIES['username']
     #if cookie != None:
     return render_to_response('login/login.html', {'uf': uf}, context_instance=RequestContext(request))
     #return render_to_response("index.html")

def myMessge(request):
	return render_to_response("message.html")

def messageList(request):
    title = request.GET.get('seacheTitleParam')
    if title != None:
	   msgs = getPaginator(Message.objects.filter(title__icontains=title).order_by('-id'),request)
    else:
	   msgs = getPaginator(Message.objects.filter().order_by('-id'),request)
    items = ['{"total":%d,"totalPage":%d,"rows":['%(msgs.paginator.count,msgs.paginator.num_pages)]
    for msg in msgs:
     items.append('{"id":"%s","name":"%s","title":"%s","content":"%s","postingTime":"%s"},'%(msg.id,msg.name,msg.title,msg.content,msg.postingTime))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen-3]+jsonstr[jsonlen-2:]
    return HttpResponse(jsonstr,content_type="application/json")

def messageAdd(request):
	return render_to_response("/pyonion/templates/addMessage.html",{'mId':request.GET['mId'],'title':request.GET['title'],'content':request.GET['content']})

#保存数据
@csrf_exempt
def messageSave(request):
   # c={}
   mId=request.POST['mId']
   repliesContent=request.POST['repliesContent']
   thisTime=time.strftime('%Y-%m-%d %H:%M:%S')
   st=Replies()
   st.mId=mId
   st.repliesContent=repliesContent
   st.thisTime=thisTime
   st.save()
   return HttpResponseRedirect("/returnMessage")

def returnMessage(request):
    return render(request,'message.html')

def repliesList(request):
    rep = getPaginator(Replies.objects.filter(mId__exact=request.GET.get('mId')).order_by('-thisTime').filter(),request)
    items = ['{"total":%d,"totalPage":%d,"rows":['%(rep.paginator.count,rep.paginator.num_pages)]
    for reps in rep:
        items.append('{"id":"%s","repliesContent":"%s","thisTime":"%s"},'%(reps.id,reps.repliesContent,reps.thisTime))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen-3]+jsonstr[jsonlen-2:]
    return HttpResponse(jsonstr,content_type="application/json")

def seach404(request):
    return render_to_response("error.html")

def getPaginator(objs, request):
	paginator = Paginator(objs,request.GET.get('size'))
	try:
		result = paginator.page(request.GET.get('pageNo'))
	except (EmptyPage, InvalidPage):
		result = paginator.page(paginator.num_pages)
	return result