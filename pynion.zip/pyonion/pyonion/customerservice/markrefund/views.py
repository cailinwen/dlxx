# -*- coding: utf-8 -*-
#import codecs
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )
import json
from pyonion.auth.views import need_login
from pyonion.paginatorutils.views import row_sql_pagination
from django.core.paginator import Paginator, InvalidPage, EmptyPage

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from pyonion.models import Sod

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.serializers.json import DjangoJSONEncoder
import datetime
import csv,codecs
from django.db import connections

#客服新审退款单跳转页面
@csrf_exempt
@need_login
def markrefundList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("customerservice/markrefund/markrefundList.html",dic)

#客服新审退款单统计查询页面
@csrf_exempt
@need_login
def markrefundJson(request):
    startdata = request.GET.get('startdata')
    enddata = request.GET.get('enddata')
    sodNo = request.GET.get('sodNo')
    ssod = request.GET.get('ssod')
    payName = request.GET.get('payName')
    payNo = request.GET.get('payNo')
    totalamt = request.GET.get('totalamt')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    start_sql=end_sql=""
    if startdata:
        start_sql = " and CONVERT(SOD_CREATE_TIME,DATE) >= '%s'" % datetime.datetime.strptime(startdata,'%Y-%m-%d')

    if enddata:
        end = enddata + " 23:59:59"
        end_sql = " and CONVERT(SOD_CREATE_TIME,DATE) <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    if sodNo:
        likeSql = likeSql + (" AND sod_no like '%%%s%%' " % sodNo)

    if ssod:
        likeSql = likeSql + (" AND (SELECT SOD_NO FROM sod_rec s WHERE s.SOD_ID = SOD_ITEM_FROM_ID) like '%%%s%%' " % ssod)

    if payName:
        likeSql = likeSql + (" AND SOD_ITEM_PAY_NAME like '%%%s%%' " % payName)

    if payNo:
        likeSql = likeSql + (" AND SOD_ITEM_PAY_NO like '%%%s%%' " % payNo)

    if totalamt:
        likeSql = likeSql + (" AND SOD_ITEM_PAY_NO like '%%%s%%' " % totalamt)
    whereSql = " WHERE SOD_TYPE = 2  AND SOD_STAT = 4 AND SOD_CLOSE_FLG = 0 "
    groupSql = " GROUP BY SOD_NO  Order by  SOD_DATE   "
    whereSql = whereSql + likeSql + start_sql + end_sql
    page_size = int(request.GET['size'])
    if 'pageNo' in request.GET:
        page_no = int(request.GET['pageNo'])
    else:
        page_no = 1
    sql = '''
            SELECT  sod_id,sod_no,(SELECT SOD_NO from sod_rec s WHERE s.SOD_ID = SOD_ITEM_FROM_ID) as ssod,
            sod_create_time,sod_item_pay_name,sod_item_pay_no,
            (CASE WHEN LENGTH(SOD_ITEM_PAY_BRANK) > 1 THEN SOD_ITEM_PAY_BRANK ELSE '支付宝' END) as bank,
            sod_amt, sod_uex,sod_ccf,(SOD_AMT + SOD_UEX + SOD_CCF) as toatalAmt
             FROM  sod_rec LEFT JOIN sod_item_rec ON SOD_ID = SOD_ITEM_SOD_ID  %s %s
        '''% (whereSql, groupSql)
    sql_all="""
            SELECT count(DISTINCT(SOD_ID)),ceil(count(DISTINCT(SOD_ID))/%d)   FROM  sod_rec LEFT JOIN sod_item_rec ON SOD_ID = SOD_ITEM_SOD_ID  WHERE  SOD_TYPE = 2  AND SOD_STAT = 4 AND SOD_CLOSE_FLG = 0 %s
            """% (page_size,likeSql)
    result=row_sql_pagination(page_no,sql_all,sql,page_size)
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#财务已选退款单
@csrf_exempt
@need_login
def markrefundTag(request):
    if request.method == 'POST':
        sodId = request.POST['sodId']
        list=sodId.split(',')
        inlist=[int(i.replace('\'','')) for i in list]
        try:
            Sod.objects.filter(sod_id__in=inlist).update(sod_stat = 2)
            Sod.objects.filter(sod_id__in=inlist)
            #for a in res:
                #print '%s-%s'%(a.sod_id,a.sod_stat)
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

# 确认退款失败修改备注
@csrf_exempt
@need_login
def updateRemark(request):
    dic = {'sodIdAll': request.GET.get('sodIdAll')}
    return render_to_response("customerservice/markrefund/updateRemark.html",dic)

#确认退款失败保存备注
@csrf_exempt
@need_login
def remarkSave(request):
    # c={}
    # 修改订单备注信息
    if request.method == 'POST':
        sodId = request.POST['sodId']
        sod_rec = Sod.objects.get(pk=int(sodId))
        sod_rec.sod_remark = request.POST['sodRemark']
        try:
           sod_rec.save()
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#确认退款失败导出
@need_login
@csrf_exempt
def exportSodNo(request):
    startdata = request.GET.get('startdata')
    enddata = request.GET.get('enddata')
    sodNo = request.GET.get('sodNo')
    ssod = request.GET.get('ssod')
    payName = request.GET.get('payName')
    payNo = request.GET.get('payNo')
    totalamt = request.GET.get('totalamt')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    start_sql=end_sql=""
    if startdata:
        start_sql = " and CONVERT(SOD_CREATE_TIME,DATE) >= '%s'" % datetime.datetime.strptime(startdata,'%Y-%m-%d')

    if enddata:
        end = enddata + " 23:59:59"
        end_sql = " and CONVERT(SOD_CREATE_TIME,DATE) <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    if sodNo:
        likeSql = likeSql + (" AND sod_no like '%%%s%%' " % sodNo)

    if ssod:
        likeSql = likeSql + (" AND (SELECT SOD_NO FROM sod_rec s WHERE s.SOD_ID = SOD_ITEM_FROM_ID) like '%%%s%%' " % ssod)

    if payName:
        likeSql = likeSql + (" AND SOD_ITEM_PAY_NAME like '%%%s%%' " % payName)

    if payNo:
        likeSql = likeSql + (" AND SOD_ITEM_PAY_NO like '%%%s%%' " % payNo)

    if totalamt:
        likeSql = likeSql + (" AND SOD_ITEM_PAY_NO like '%%%s%%' " % totalamt)
    whereSql = " where SOD_TYPE = 2  AND SOD_STAT = 4 AND SOD_CLOSE_FLG = 0 "
    groupSql = " GROUP BY SOD_NO  Order by  SOD_DATE   "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = '''
                SELECT SOD_ITEM_PAY_NAME,IFNULL(CID,'无'), SOD_ITEM_PAY_NO, CASE WHEN LENGTH(SOD_ITEM_PAY_BRANK) > 1 THEN SOD_ITEM_PAY_BRANK ELSE '支付宝' END,IFNULL(SOD_ITEM_PAY_SUB_BANK,'无'),
                IFNULL((SELECT p.AREA_NAME from area_rec p WHERE p.AREA_ID = SOD_ITEM_PAY_PROVINCE),'无'),
                IFNULL((SELECT p.AREA_NAME from area_rec p WHERE p.AREA_ID = SOD_ITEM_PAY_CITY),'无'),
                SOD_AMT, SOD_UEX, SOD_CCF, (SOD_AMT + SOD_UEX + SOD_CCF),SOD_NO,
               (SELECT SOD_NO from sod_rec s WHERE s.SOD_ID = SOD_ITEM_FROM_ID) as SSOD,SOD_REMARK FROM sod_rec LEFT JOIN sod_item_rec ON SOD_ID = SOD_ITEM_SOD_ID   %s %s
            ''' % (whereSql, groupSql)
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    results = cursor.fetchall()
    cursor.close()
    response = HttpResponse(content_type='text/csv')
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = 'attachment; filename=全部退款账号.csv'
    data = []
    writer = csv.writer(response)
    writer.writerow(['账号名称','身份证号','银行账号','开户银行','开户支行','收款省','收款市','退款金额','运费','清关费','退款总额','退款单号','来源订单','备注'])
    for row in results:
        datas =(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13])
        data.append(datas)
    writer.writerows(data)
    return response

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result