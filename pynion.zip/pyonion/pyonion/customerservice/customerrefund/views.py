# -*- coding: utf-8 -*-
#import codecs
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )
import json
from pyonion.auth.views import need_login
from pyonion.paginatorutils.views import row_sql_pagination
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from pyonion.models import Sod

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.serializers.json import DjangoJSONEncoder
import datetime

#退货订单统计跳转页面
@csrf_exempt
@need_login
def refundList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("customerservice/customerrefund/customerrefundList.html",dic)

#退货订单统计查询页面
@csrf_exempt
@need_login
def refundJson(request):
    startdata = request.GET.get('startdata')
    enddata = request.GET.get('enddata')
    memberName = request.GET.get('memberName')
    sodNo = request.GET.get('sodNo')
    ssod = request.GET.get('ssod')
    payName = request.GET.get('payName')
    payNo = request.GET.get('payNo')
    totalamt = request.GET.get('totalamt')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    start_sql=end_sql=""
    if startdata:
        start_sql = " and CONVERT(SOD_CREATE_TIME,DATE) >= '%s'" % datetime.datetime.strptime(startdata,'%Y-%m-%d')

    if enddata:
        end = enddata + " 23:59:59"
        end_sql = " and CONVERT(SOD_CREATE_TIME,DATE) <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    if sodNo:
        likeSql = likeSql + (" AND sod_no like '%%%s%%' " % sodNo)

    if ssod:
        likeSql = likeSql + (" AND (SELECT SOD_NO FROM sod_rec s WHERE s.SOD_ID = SOD_ITEM_FROM_ID) like '%%%s%%' " % ssod)

    if payName:
        likeSql = likeSql + (" AND SOD_ITEM_PAY_NAME like '%%%s%%' " % payName)

    if payNo:
        likeSql = likeSql + (" AND SOD_ITEM_PAY_NO like '%%%s%%' " % payNo)

    if totalamt:
        likeSql = likeSql + (" AND SOD_ITEM_PAY_NO like '%%%s%%' " % totalamt)
    whereSql = " WHERE SOD_TYPE = 2  AND SOD_STAT = 5 AND SOD_CLOSE_FLG = 0 "
    groupSql = " GROUP BY SOD_NO  Order by  SOD_DATE  "
    whereSql = whereSql + likeSql + start_sql + end_sql
    page_size = int(request.GET['size'])
    if 'pageNo' in request.GET:
        page_no = int(request.GET['pageNo'])
    else:
        page_no = 1
    sql = '''
            SELECT  sod_id,sod_no,(SELECT SOD_NO from sod_rec s WHERE s.SOD_ID = SOD_ITEM_FROM_ID) as ssod,
            sod_create_time,sod_item_pay_name,sod_item_pay_no,(CASE WHEN LENGTH(SOD_ITEM_PAY_BRANK) > 1 THEN SOD_ITEM_PAY_BRANK ELSE '支付宝' END) as bank,
            sod_amt,sod_uex,sod_ccf,(SOD_AMT + SOD_UEX + SOD_CCF) as totalamt,sod_remark
            FROM  sod_rec LEFT JOIN sod_item_rec ON SOD_ID = SOD_ITEM_SOD_ID  %s %s
        '''% (whereSql, groupSql)
    sql_all="""
            select count(DISTINCT(SOD_ID)),ceil(count(DISTINCT(SOD_ID))/%d) FROM  sod_rec JOIN sod_item_rec ON SOD_ID = SOD_ITEM_SOD_ID WHERE SOD_TYPE = 2  AND SOD_STAT = 5 AND SOD_CLOSE_FLG = 0 %s
            """% (page_size,likeSql)
    result=row_sql_pagination(page_no,sql_all,sql,page_size)
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

# 订单详细页面跳转
@csrf_exempt
@need_login
def customerDetailList(request):
    dic = {'sodId': request.GET.get('sodId')}
    return render_to_response("customerservice/customerDetailList.html",dic)

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result



