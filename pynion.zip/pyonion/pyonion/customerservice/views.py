# -*- coding: utf-8 -*-
#import codecs
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )
import json
from django.db import connections
from pyonion.auth.views import need_login
from pyonion.paginatorutils.views import row_sql_pagination
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from pyonion.models import Sod,Area,SodAddress,MsSubOrder,MsService
from pyonion.utils.expressHttpUtils import queryExpressNo
from pyonion.utils.jsonEncoder import CJsonEncoder

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.serializers.json import DjangoJSONEncoder
import datetime
import time

#订单统计跳转页面
@csrf_exempt
@need_login
def customerList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("customerservice/customerList.html",dic)

#订单统计查询页面
@csrf_exempt
@need_login
def customerJson(request):
    startdata = request.GET.get('startdata')
    enddata = request.GET.get('enddata')
    memberName = request.GET.get('memberName')
    sodNo = request.GET.get('sodNo')
    sodStat = request.GET.get('sodStat')
    sodPayType = request.GET.get('sodPayType')
    tmnId = request.GET.get('tmnId')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    start_sql=end_sql=""
    if startdata:
        start_sql = " and t1.sod_date >= '%s'" % datetime.datetime.strptime(startdata,'%Y-%m-%d')

    if enddata:
        end = enddata + " 23:59:59"
        end_sql = " and t1.sod_date <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    if memberName:
        likeSql = likeSql + (" AND t2.MEMBER_NAME like '%%%s%%' " % memberName)

    if sodNo:
        likeSql = likeSql + (" AND t1.sod_no like '%%%s%%' " % sodNo)

    if sodStat:
        likeSql = likeSql + (" AND t1.sod_stat = %s" % sodStat)

    if sodPayType:
        likeSql = likeSql + (" AND t1.sod_pay_type = %s" % sodPayType)

    if tmnId:
        likeSql = likeSql + (" AND t1.SOD_TMN_ID = %s" % tmnId)

    whereSql = " WHERE 1 = 1 "
    groupSql = " ORDER BY t1.SOD_DATE DESC "
    whereSql = whereSql + likeSql + start_sql + end_sql
    page_size = int(request.GET['size'])
    if 'pageNo' in request.GET:
        page_no = int(request.GET['pageNo'])
    else:
        page_no = 1
    sql = '''
        select t1.sod_id,t1.sod_no,t1.sod_date,t1.sod_stat,t1.sod_pay_type,t1.sod_pay_flg,t1.sod_pay_no,t1.sod_pay_time,t2.member_name,t1.sod_modify_time,t1.sod_amt
        from sod_rec t1 LEFT JOIN member_rec t2 on t1.SOD_MEMBER_ID = t2.MEMBER_ID %s %s
        '''% (whereSql, groupSql)
    sql_all="""
          select count(*),ceil(count(*)/%d) from sod_rec t1 JOIN member_rec t2 on t1.SOD_MEMBER_ID = t2.MEMBER_ID %s %s %s
          """% (page_size,likeSql,start_sql,end_sql)
    result=row_sql_pagination(page_no,sql_all,sql,page_size)
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

# 订单查询列表页面跳转 New
@csrf_exempt
@need_login
def customerJsonNew(request):
    startdata = request.GET.get('startdata')
    enddata = request.GET.get('enddata')
    memberName = request.GET.get('memberName')
    sodNo = request.GET.get('sodNo')
    sodStat = request.GET.get('sodStat')
    sodPayType = request.GET.get('sodPayType')
    tmnId = request.GET.get('tmnId')
    queryset = Sod.objects.all().order_by('sod_no')

    if memberName:
        queryset = queryset.filter(sod_member__member_name__icontains=memberName)
    if sodNo:
        queryset = queryset.filter(sod_no__icontains=sodNo)
    if sodPayType:
        queryset = queryset.filter(sod_pay_type=sodPayType)
    if sodStat:
        queryset = queryset.filter(sod_stat=sodStat)
    if tmnId:
        queryset = queryset.filter(sod_tmn_id=tmnId)

    if startdata and enddata:
        start_time = datetime.datetime.strptime(startdata,'%Y-%m-%d')
        end = enddata + " 23:59:59"
        end_time = datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')
        queryset = queryset.filter(sod_create_time__gte=start_time, sod_create_time__lte=end_time)
    elif startdata and not enddata:
        start_time = datetime.datetime.strptime(startdata,'%Y-%m-%d')
        queryset = queryset.filter(sod_create_time__gte=start_time)
    elif not startdata and enddata:
        end = enddata + " 23:59:59"
        end_time = datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')
        queryset = queryset.filter(sod_create_time__lte=end_time)

    sods = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (sods.paginator.count, sods.paginator.num_pages)]
    for sod in sods:
        sodAll = sod.sod_member
        if sodAll != None:
            items.append(
                '{"sod_id":"%s","sod_no":"%s","sod_date":"%s","sod_stat":"%s","sod_pay_type":"%s","sod_pay_flg":"%s","sod_pay_no":"%s","sod_pay_time":"%s","member_name":"%s","sod_modify_time":"%s","sod_amt":"%s"},' % (
                    sod.sod_id,sod.sod_no,sod.sod_date,sod.sod_stat, sod.sod_pay_type,sod.sod_pay_flg,sod.sod_pay_no,sod.sod_pay_time,sod.sod_member.member_name,sod.sod_modify_time,sod.sod_amt))
        else:
            items.append(
                '{"sod_id":"%s","sod_no":"%s","sod_date":"%s","sod_stat":"%s","sod_pay_type":"%s","sod_pay_flg":"%s","sod_pay_no":"%s","sod_pay_time":"%s","sod_modify_time":"%s","sod_amt":"%s"},' % (
                    sod.sod_id,sod.sod_no,sod.sod_date,sod.sod_stat, sod.sod_pay_type,sod.sod_pay_flg,sod.sod_pay_no,sod.sod_pay_time,sod.sod_modify_time,sod.sod_amt))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if sods.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 订单详细页面跳转
@csrf_exempt
@need_login
def customerDetailList(request):
    dic = {'sodId': request.GET.get('sodId')}
    return render_to_response("customerservice/customerDetailList.html",dic)

#订单详细数据查询（会员信息，订单详细信息）
@csrf_exempt
@need_login
def customerDetailJson(request):
    sodId = request.GET.get('sodId')
    likeSql = ""
    like_sql_all = ""
    #-----开始判断前端传的参数是否为空--------
    if sodId:
        likeSql = likeSql + (" AND t1.sod_id = %s" % sodId)
    if sodId:
        like_sql_all = like_sql_all + (" AND si.SOD_ITEM_SOD_ID = %s" % sodId)

    whereSql_all = " WHERE 1 = 1 "
    whereSql = whereSql_all + likeSql
    where_sql_all = whereSql_all + like_sql_all
    cursor = connections['slave'].cursor()
    #查询会员信息
    mySql_members = """
            select t1.sod_id,t1.sod_no,t1.sod_date,t2.member_name,t1.sod_tariff,t1.sod_ccf,t1.sod_uex,t1.sod_remark,t2.member_phone,t2.member_code,t2.member_id
            from sod_rec t1 LEFT JOIN member_rec t2 on t1.SOD_MEMBER_ID = t2.MEMBER_ID %s
          """% (whereSql)
    cursor.execute(mySql_members)
    jsonMember = cursor.fetchall()
    desc = cursor.description

    #查询订单详细信息
    mySql_order = """
                SELECT s.sod_tmn_id,st.store_name,m.member_name,t.tmn_name,le.le_code,le.le_barcode,le.le_name,un.unit_name,si.sod_item_qty,si.sod_item_price,si.sod_item_amt,si.sod_item_express_no,s.sod_qty,s.sod_amt
                FROM  sod_item_rec si LEFT JOIN le_rec le on le.le_id = si.sod_item_le_id LEFT JOIN unit_rec un on le.LE_UNIT_ID = un.UNIT_ID
                LEFT JOIN sod_rec s ON s.SOD_ID = si.SOD_ITEM_SOD_ID LEFT JOIN store_rec st on st.STORE_ID = s.STORE_ID LEFT JOIN member_rec m ON m.MEMBER_ID = s.STORE_MEMBER_ID
                LEFT JOIN tmn_rec t ON t.TMN_ID = s.SOD_TMN_ID %s
               """% (where_sql_all)
    cursor.execute(mySql_order)
    jsonOrder = cursor.fetchall()
    desc_all = cursor.description
    cursor.close()
    member = []
    tag = [de[0] for de in desc]
    for i in jsonMember:
        obj = dict(zip(tag,i))
        member.append(obj)

    order = []
    tag_all = [de[0] for de in desc_all]
    for j in jsonOrder:
        obj_all = dict(zip(tag_all,j))
        order.append(obj_all)
    return HttpResponse(json.dumps({"memberAll":member,"orderAll":order},cls=CJsonEncoder))

#查询收货人相关信息
@csrf_exempt
@need_login
def queryAddress(request):
    sodId = request.GET.get('sodId')
    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if sodId:
        likeSql = likeSql + (" AND t1.SOD_ADDRESS_SOD_ID = %s" % sodId)

    whereSql_all = " WHERE 1 = 1 "
    whereSql = whereSql_all + likeSql
    cursor = connections['slave'].cursor()
    #查询收货人信息
    mySql_members = """
            select t1.sod_address_user,t1.sod_address_tel,t1.sod_address_user_cid,t2.area_name as province_name,t3.area_name as city_name,t4.area_name,t2.area_id,t1.sod_address_id,t1.sod_parea_id,t1.sod_carea_id,t1.sod_rarea_id,t1.sod_address_no  from sod_address t1
          left join area_rec t2 on t1.sod_parea_id = t2.area_id left join area_rec t3 on t1.sod_carea_id = t3.area_id
          left join area_rec t4 on t1.sod_rarea_id = t4.area_id %s
          """% (whereSql)
    cursor.execute(mySql_members)
    jsonAddress = cursor.fetchall()
    desc = cursor.description
    cursor.close()
    address_all = []
    tag = [de[0] for de in desc]
    for i in jsonAddress:
        obj = dict(zip(tag,i))
        address_all.append(obj)
    return HttpResponse(json.dumps({"addressAll":address_all},cls=CJsonEncoder))

#查询拆单信息
@csrf_exempt
@need_login
def querySplit(request):
    sodId = request.GET.get('sodId')
    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if sodId:
        likeSql = likeSql + (" AND t.SOD_ID = %s" % sodId)

    whereSql_all = " WHERE 1 = 1 "
    whereSql = whereSql_all + likeSql
    cursor = connections['slave'].cursor()
    #查询拆单信息
    mySql_members = """
            select t.id,t.sod_sub_no,t.express_no,t.store_no from ms_sub_order t %s
          """% (whereSql)
    cursor.execute(mySql_members)
    jsonSplit = cursor.fetchall()
    desc = cursor.description
    cursor.close()
    split_all = []
    tag = [de[0] for de in desc]
    for i in jsonSplit:
        obj = dict(zip(tag,i))
        split_all.append(obj)
    return HttpResponse(json.dumps({"splitAll":split_all},cls=CJsonEncoder))

#查询省市区
def getArea(request):
    parameter_id = request.GET.get('parameter_id')
    res =Area.objects.filter(area_parent_id=int(parameter_id))
    res =[[i.area_id,i.area_name ] for i in res]
    area_all = []
    tag=["area_id","area_name"]
    for i in res:
        area_all.append(dict(zip(tag,i)))
    return HttpResponse(json.dumps(area_all,cls=CJsonEncoder))

#保存订单备注信息
@csrf_exempt
@need_login
def addRemark(request):
    # c={}
    # 修改采购主表信息
    if request.method == 'POST':
        sodId = request.POST['sodId']
        sod_rec = Sod.objects.get(pk=int(sodId))
        sod_rec.sod_remark = request.POST['sodRemark']
        try:
           sod_rec.save()
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#保存收货地址信息
@csrf_exempt
@need_login
def addAddress(request):
    # c={}
    # 修改采购主表信息
    if request.method == 'POST':
        addressId = request.POST['addressId']
        sod_address = SodAddress.objects.get(sod_address_id=int(addressId))
        #获取收货人
        sod_address.sod_address_user = request.POST['addressName']
        #获取收货人联系方式
        sod_address.sod_address_tel = request.POST['addressTel']
        #获取收货人身份证号
        sod_address.sod_address_user_cid = request.POST['addressCid']
        #获取省的ID
        sod_address.sod_parea_id = int(request.POST['provinceId'])
        #获取市的ID
        sod_address.sod_carea_id = int(request.POST['cityId'])
        #获取区的ID
        sod_address.sod_rarea_id = int(request.POST['areaId'])
        #获取收货地址详细信息
        sod_address.sod_address_no = request.POST['addressDetl']
        try:
           sod_address.save()
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#获取当前的系统时间
def GetNowTime():
    return time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))
#保存拆单信息
@csrf_exempt
@need_login
def addLogistics(request):
    if request.method == 'POST':
        #获取对应的拆单号的ID
        idNo = request.POST['idNo']
        #获取对应的sod_rec表的ID
        sodIdAll = request.POST['sodIdAll']
        expressComNo = request.POST['expressComNo']
        #调用物流接口返回信息
        expressNo = queryExpressNo(expressComNo)
        autoNo = json.loads(expressNo)
        #根据物流接口返回的code匹配对应的物流公司名称
        exprNo = ext_com_no(autoNo[0]['comCode'])
        ms_sub_order = MsSubOrder.objects.get(pk=int(idNo))
        #快递单号
        ms_sub_order.express_no = expressComNo
        #获取对应的快递公司名称
        ms_sub_order.express_com= exprNo[1]
        #获取对应的快递公司编号
        ms_sub_order.express_com_no= exprNo[0]
        try:
           ms_sub_order.save()
           #当拆单表修改成功就更新sod_rec表的sod_stat的状态将2更改为3
           sod_rec_all = Sod.objects.get(pk=int(sodIdAll))
           sod_rec_all.sod_stat='3'
           if(sod_rec_all.sod_stat <= '3'):
               sod_rec_all.sod_modify_time = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))
           sod_rec_all.save()
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#快递公司的中文名称/编码
def ext_com_no(code):
    #EXP_COM_NO_LINK_MAP = (('qf', '全峰'), ('ht', '汇通'),('zto', '中通'), ('ems', 'EMS'),('tt', '天天'), ('yd', '韵达'),('yt', '圆通'), ('sto', '申通'), ('sf', '顺丰'))
    #EXP_COM_NO_MAP = {"qf":"全峰","ht":"汇通","zto":"中通","ems":"EMS","tt":"天天","yd":"韵达","yt":"圆通","sto":"申通","sf":"顺丰"}
    #EXP_COM_NO_LINK_MAP = {"quanfengkuaidi":"qf","huitongkuaidi":"ht","zhongtong":"zto","youzhengguonei":"ems","ems":"ems","tt":"tt","yunda":"yd","yuantong":"yt","shentong":"sto","shunfeng":"sf","jd":"ems"}
    EXP_COM_NO_MAP = {"quanfengkuaidi":['qf','全峰'],"huitongkuaidi":['ht','汇通'],"zhongtong":['zto','中通'],"ems":['ems','EMS'],
                      "tt":['tt','天天'],"yunda":['yd','韵达'],"yuantong":['yt','圆通'],"shentong":['sto','申通'],"shunfeng":['sf','顺丰'],
                      "youzhengguonei":['ems','EMS'],"jd":['ems','EMS']}
    return EXP_COM_NO_MAP[code]

#订单服务记录跳转页面
@csrf_exempt
@need_login
def shopOwnerList(request):
    dic = {'sodNo': request.GET.get('sodNo'),'memberIdAll':request.GET.get('memberIdAll')}
    return render_to_response("customerservice/shopOwnerList.html",dic)

#订单服务记录查询数据
@csrf_exempt
@need_login
def shopOwnerJson(request):
    memberIdAll = request.GET.get('memberIdAll')
    sodNo = request.GET.get('sodNo')
    customerName = request.GET.get('customerName')
    serviceContent = request.GET.get('serviceContent')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if sodNo:
        likeSql = likeSql + (" AND t.MEMBER_ID = %s" % memberIdAll)

    if sodNo:
        likeSql = likeSql + (" AND t.SOD_NO like '%%%s%%' " % sodNo)

    if customerName:
        likeSql = likeSql + (" AND t.SERVICE_NAME like like '%%%s%%' " % customerName)

    if serviceContent:
        likeSql = likeSql + (" AND t.SERVICE_CONTENT like like '%%%s%%' " % serviceContent)

    whereSql = " WHERE 1 = 1 "
    whereSql = whereSql + likeSql
    mySql = '''
            select t.member_id,t.service_name,t.service_content,t.sod_no,t.create_time from ms_service t %s
            ''' % (whereSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#订单服务记录新增跳转页面
@csrf_exempt
@need_login
def shopOwnerAdd(request):
    dic = {'sodNo': request.GET.get('sodNo'),'memberIdAll':request.GET.get('memberId')}
    return render_to_response("customerservice/shopOwnerAdd.html",dic)

# 保存客服服务记录信息数据
@csrf_exempt
@need_login
def shopOwnerSave(request):
    if request.method == 'POST':
        serviceName = request.POST['serviceName']
        serviceContent = request.POST['serviceContent']
        sodNo = request.POST['sodNo']
        memberIdAll = request.POST['memberIdAll']
        print(memberIdAll)
        try:
            MsService.objects.create(member_id=memberIdAll, service_name=serviceName, service_content=serviceContent,sod_no=sodNo)
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result



