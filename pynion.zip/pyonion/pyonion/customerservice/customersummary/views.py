# -*- coding: utf-8 -*-
#import codecs
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )
import json
from pyonion.auth.views import need_login
from pyonion.paginatorutils.views import row_sql_pagination
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import connections
from pyonion.models import Sod,SodItem

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.serializers.json import DjangoJSONEncoder
from pyonion.utils.jsonEncoder import CJsonEncoder
import datetime
import csv,codecs

#退货订单统计跳转页面
@csrf_exempt
@need_login
def summaryList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("customerservice/customersummary/summaryList.html",dic)

# 退货订单统计查询页面
@csrf_exempt
@need_login
def summaryJson(request):
    startdata = request.GET.get('startdata')
    enddata = request.GET.get('enddata')
    sodStat = request.GET.get('sodStat')
    thenTime = request.GET.get('thenTime')
    sodNo = request.GET.get('sodNo')
    if len(thenTime) >0:
       thenTime = int(thenTime)
    else:
       thenTime = 0

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    start_sql=end_sql=""
    if startdata:
        start_sql = " and b.sod_pay_time >= '%s'" % datetime.datetime.strptime(startdata,'%Y-%m-%d')

    if enddata:
        end = enddata + " 23:59:59"
        end_sql = " and b.sod_pay_time <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    if sodStat:
        likeSql = likeSql + (" AND d.sod_stat = %s" % sodStat)
    if thenTime == 1:
       andstr=""" and TIMESTAMPDIFF(SECOND,b.sod_pay_time,d.sod_create_time) <=21600"""
    elif thenTime == 2:
       andstr="""and TIMESTAMPDIFF(SECOND,b.sod_pay_time,d.sod_create_time) >21600"""
    else:
       andstr=""

    if sodNo:
        likeSql = likeSql + (" AND b.sod_no like '%%%s%%' " % sodNo)

    whereSql = " WHERE d.SOD_CLOSE_FLG = 0 AND b.SOD_TYPE = 1 AND d.SOD_TYPE =2 AND b.SOD_CLOSE_FLG = 0 AND a.SOD_ITEM_FROM_ID IS NOT NULL "
    groupSql = " GROUP BY d.SOD_ID  Order by a.SOD_ITEM_CREATE_TIME DESC  "
    whereSql = whereSql + likeSql + start_sql + end_sql
    page_size = int(request.GET['size'])
    if 'pageNo' in request.GET:
        page_no = int(request.GET['pageNo'])
    else:
        page_no = 1
    sql = u'''
            SELECT  b.sod_id,b.sod_no,d.SOD_NO as thSodNo,b.sod_date,d.sod_stat,b.sod_pay_time,c.member_name,d.sod_create_time,
            CASE WHEN TIMESTAMPDIFF(SECOND,b.sod_pay_time,d.sod_create_time) <=21600 THEN '在6个小时内' ELSE '大于6个小时' END AS theTime,b.sod_remark,b.sod_ccf,b.sod_uex
            FROM  sod_item_rec a LEFT JOIN sod_rec b on a.SOD_ITEM_FROM_ID=b.sod_id LEFT JOIN MEMBER_REC c on c.MEMBER_ID=b.SOD_CREATE_MEMBER_ID
            LEFT JOIN sod_rec d on a.SOD_ITEM_SOD_ID=d.SOD_ID  %s %s %s
        '''% (whereSql,andstr, groupSql)
    sql_all="""
            SELECT  count(DISTINCT(d.SOD_ID)),ceil(count(DISTINCT(d.sod_id))/%d) FROM sod_item_rec a LEFT JOIN sod_rec b on a.SOD_ITEM_FROM_ID=b.sod_id LEFT JOIN MEMBER_REC c on c.MEMBER_ID=b.SOD_CREATE_MEMBER_ID LEFT JOIN sod_rec d on a.SOD_ITEM_SOD_ID=d.SOD_ID WHERE d.SOD_CLOSE_FLG = 0 AND b.SOD_TYPE = 1 AND d.SOD_TYPE =2 AND b.SOD_CLOSE_FLG = 0 AND a.SOD_ITEM_FROM_ID IS NOT NULL %s %s %s %s
            """% (page_size,andstr,likeSql,start_sql,end_sql)
    result=row_sql_pagination(page_no,sql_all,sql,page_size)
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

# 订单详细页面跳转
@csrf_exempt
@need_login
def summaryDetailList(request):
    dic = {'sodId': request.GET.get('sodId'),'thSodNo': request.GET.get('thSodNo')}
    return render_to_response("customerservice/customersummary/summaryDetailList.html",dic)

#退款订单详细数据查询（会员信息，订单详细信息）
@csrf_exempt
@need_login
def summaryDetailJson(request):
    sodId = request.GET.get('sodId')
    likeSql = ""
    like_sql_all = ""
    #-----开始判断前端传的参数是否为空--------
    if sodId:
        likeSql = likeSql + (" AND t1.sod_id = %s" % sodId)
    if sodId:
        like_sql_all = like_sql_all + (" AND si.SOD_ITEM_SOD_ID = %s" % sodId)

    whereSql_all = " WHERE 1 = 1 "
    whereSql = whereSql_all + likeSql
    where_sql_all = whereSql_all + like_sql_all
    cursor = connections['slave'].cursor()
    #查询会员信息
    mySql_members = """
            select t1.sod_id,t1.sod_no,t1.sod_date,t2.member_name,t1.sod_tariff,t1.sod_ccf,t1.sod_uex,t1.sod_remark,t2.member_phone,t2.member_code
            from sod_rec t1 LEFT JOIN member_rec t2 on t1.SOD_MEMBER_ID = t2.MEMBER_ID %s
          """% (whereSql)
    cursor.execute(mySql_members)
    jsonMember = cursor.fetchall()
    desc = cursor.description

    #查询订单详细信息
    mySql_order = """
                SELECT s.sod_tmn_id,st.store_name,m.member_name,t.tmn_name,le.le_code,le.le_barcode,le.le_name,un.unit_name,si.sod_item_qty,si.sod_item_price,si.sod_item_amt,si.sod_item_express_no,s.sod_qty,s.sod_amt,
                si.sod_item_rc_amt,si.sod_item_pay_name,si.sod_item_pay_brank,si.sod_item_pay_no,si.sod_item_rc_type, si.sod_item_rc_no,si.sod_item_rc_qty
                FROM  sod_item_rec si LEFT JOIN le_rec le on le.le_id = si.sod_item_le_id LEFT JOIN unit_rec un on le.LE_UNIT_ID = un.UNIT_ID
                LEFT JOIN sod_rec s ON s.SOD_ID = si.SOD_ITEM_SOD_ID LEFT JOIN store_rec st on st.STORE_ID = s.STORE_ID LEFT JOIN member_rec m ON m.MEMBER_ID = s.STORE_MEMBER_ID
                LEFT JOIN tmn_rec t ON t.TMN_ID = s.SOD_TMN_ID %s
               """% (where_sql_all)
    cursor.execute(mySql_order)
    jsonOrder = cursor.fetchall()
    desc_all = cursor.description
    cursor.close()
    member = []
    tag = [de[0] for de in desc]
    for i in jsonMember:
        obj = dict(zip(tag,i))
        member.append(obj)

    order = []
    tag_all = [de[0] for de in desc_all]
    for j in jsonOrder:
        obj_all = dict(zip(tag_all,j))
        order.append(obj_all)
    return HttpResponse(json.dumps({"memberAll":member,"orderAll":order},cls=CJsonEncoder))

# 订单审核页面跳转
@csrf_exempt
@need_login
def auditList(request):
    dic = {'thSodNo': request.GET.get('thSodNo'),'sod_uex_all': request.GET.get('sod_uex_all'),'sod_ccf_all': request.GET.get('sod_ccf_all')}
    return render_to_response("customerservice/customersummary/auditList.html",dic)

#退款订单详细数据查询（会员信息，订单详细信息）
@csrf_exempt
@need_login
def auditJson(request):
    thSodNo = request.GET.get('thSodNo')
    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if thSodNo:
        likeSql = likeSql + (" AND s.SOD_NO = '%s' " % thSodNo)

    whereSql_all = " WHERE 1 = 1 "
    whereSql = whereSql_all + likeSql
    cursor = connections['slave'].cursor()
    #查询会员信息
    mySql = """
                SELECT s.sod_tmn_id,s.sod_amt,s.sod_ccf,s.sod_uex,s.sod_no,le.le_name,si.sod_item_qty,si.sod_item_price,si.sod_item_rc_type,si.sod_item_id,
                s.sod_qty,si.sod_item_rc_qty,m.member_name,si.sod_item_amt,si.sod_item_pay_no,si.sod_item_rc_amt,
                case when s.sod_rc_flg = '1' THEN '线上直退' WHEN s.sod_rc_flg = '2' THEN '退回网点' ELSE '--' END as sod_rc_flg,si.sod_item_pay_name,s.sod_amt,
                CASE WHEN si.sod_item_rc_no = '1' THEN '21天无理由退换货仅退商品费' WHEN si.sod_item_rc_no = '2' THEN '错发、漏发、包裹破损' ELSE '--' END as sod_item_rc_no,
                CASE WHEN si.sod_item_no_type = '1' THEN '银行卡' WHEN si.sod_item_no_type = '2' THEN '支付宝' ELSE '--' END as sod_item_no_type
                FROM  sod_item_rec si
                LEFT JOIN le_rec le on le.le_id = si.sod_item_le_id
                LEFT JOIN sod_rec s ON s.SOD_ID = si.SOD_ITEM_SOD_ID
                LEFT JOIN member_rec m ON m.MEMBER_ID = s.STORE_MEMBER_ID
                LEFT JOIN tmn_rec t ON t.TMN_ID = s.SOD_TMN_ID %s
          """% (whereSql)
    cursor.execute(mySql)
    jsonMember = cursor.fetchall()
    desc = cursor.description

    member = []
    tag = [de[0] for de in desc]
    for i in jsonMember:
        obj = dict(zip(tag,i))
        member.append(obj)
    return HttpResponse(json.dumps({"memberAll":member},cls=CJsonEncoder))

#保存订单备注信息
@csrf_exempt
@need_login
def addRemark(request):
    # c={}
    # 修改订单备注信息
    if request.method == 'POST':
        sodId = request.POST['sodId']
        sod_rec = Sod.objects.get(pk=int(sodId))
        sod_rec.sod_remark = request.POST['sodRemark']
        try:
           sod_rec.save()
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#客服、财务审核流程保存
@csrf_exempt
@need_login
def auditSave(request):
    if request.method == 'POST':
        thSodNoAll = request.POST['thSodNoAll']
        sod_no_all = Sod.objects.get(sod_no=thSodNoAll)
        #获取清关费
        sod_no_all.sod_ccf = request.POST['sod_ccf_all']
        #获取运费
        sod_no_all.sod_uex = request.POST['sod_uex_all']
        try:
           sod_no_all.sod_stat = 3
           sod_no_all.save()
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#批量确认退货数量
@csrf_exempt
@need_login
def returnsumberSave(request):
    if request.method == 'POST':
        #获取前端封装好的参数
        thSodNoAll = request.POST['thSodNoAll']
        #分割前端传过来的参数
        try:
            for i in thSodNoAll.split('\',\''):
                 i = i.replace('\'','')
                 order = json.loads(i)
                 Sod.objects.filter(sod_no=order['no']).update(sod_stat=3,sod_ccf=order['ccf'],sod_uex=order['uex'])
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#确认退货数量导出
@need_login
@csrf_exempt
def summaryExport(request):
    startdata = request.GET.get('startdata')
    enddata = request.GET.get('enddata')
    sodStat = request.GET.get('sodStat')
    thenTime = request.GET.get('thenTime')
    if len(thenTime) >0:
       thenTime = int(thenTime)
    else:
       thenTime = 0

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    start_sql=end_sql=""
    if startdata:
        start_sql = " and b.sod_pay_time >= '%s'" % datetime.datetime.strptime(startdata,'%Y-%m-%d')

    if enddata:
        end = enddata + " 23:59:59"
        end_sql = " and b.sod_pay_time <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    if sodStat:
        likeSql = " AND d.sod_stat = %s" % sodStat
    if thenTime == 1:
       andstr=""" and TIMESTAMPDIFF(SECOND,b.sod_pay_time,d.sod_create_time) <=21600"""
    elif thenTime == 2:
       andstr="""and TIMESTAMPDIFF(SECOND,b.sod_pay_time,d.sod_create_time) >21600"""
    else:
       andstr=""

    whereSql = " WHERE d.SOD_CLOSE_FLG = 0 AND b.SOD_TYPE = 1 AND d.SOD_TYPE =2 AND b.SOD_CLOSE_FLG = 0 AND a.SOD_ITEM_FROM_ID IS NOT NULL "
    groupSql = " GROUP BY d.SOD_ID  Order by a.SOD_ITEM_CREATE_TIME DESC  "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = u'''
            SELECT  b.sod_id,b.sod_no,d.SOD_NO as thSodNo,b.sod_date,d.sod_stat,b.sod_pay_time,c.member_name,d.sod_create_time,
            CASE WHEN TIMESTAMPDIFF(SECOND,b.sod_pay_time,d.sod_create_time) <=21600 THEN '在6个小时内' ELSE '大于6个小时' END AS theTime,
            d.sod_amt,d.sod_ccf,d.sod_uex,a.sod_item_no_type
            FROM  sod_item_rec a LEFT JOIN sod_rec b on a.SOD_ITEM_FROM_ID=b.sod_id LEFT JOIN MEMBER_REC c on c.MEMBER_ID=b.SOD_CREATE_MEMBER_ID
            LEFT JOIN sod_rec d on a.SOD_ITEM_SOD_ID=d.SOD_ID  %s %s %s
        '''% (whereSql,andstr, groupSql)
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    results = cursor.fetchall()
    cursor.close()
    response = HttpResponse(content_type='text/csv')
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = 'attachment; filename=退款汇总导出.csv'
    data = []
    writer = csv.writer(response)
    writer.writerow(['订单号','退货单号','下单时间','退款状态','支付时间','制单人','时间差','退款时间','退款商品金额','清关费','运费','退货状态'])
    p_dicts = {1: '未完成退款', 2: '已完成退款',3:'销售审核通过',4:'已标记',5:'退款失败'}
    s_dicts = {1: '未发货', 2: '退款不退货',3:'退款退货——广州',4:'退款退货——香港',5:'退款退货——海关',6:'退款退货——海豚',7:'退款退货——其他'}
    for row in results:
        stat = p_dicts.get(row[4], '--')
        sod_item_no_type = s_dicts.get(row[12], '--')
        datas =(row[1],row[2],row[3],stat,row[5],row[6],row[7],row[8],row[9],row[10],row[11],sod_item_no_type)
        data.append(datas)
    writer.writerows(data)
    return response

#退货类型保存
@need_login
@csrf_exempt
def selectTypeSave(request):
    if request.method == 'GET':
        #获取前端封装好的参数
        sodItemRcTypeAll = request.GET['sodItemRcType']
        #分割前端传过来的参数
        try:
            for i in sodItemRcTypeAll.split('\',\''):
                 i = i.replace('\'','')
                 order = json.loads(i)
                 SodItem.objects.filter(sod_item_id=order['sodItemId']).update(sod_item_rc_type=order['sodRcType'])
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result



