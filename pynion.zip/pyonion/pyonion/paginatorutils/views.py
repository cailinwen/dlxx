# -*- coding: utf-8 -*-
#import codecs
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )
from django.db import connections
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt

#后台自动分页共用方法
@csrf_exempt
def row_sql_pagination(current_page,sql_all,sql,size):
    result={}
    cursor = connections['slave'].cursor()
    #此段计算总行数以及页码
    cursor.execute(sql_all)
    total = cursor.fetchall() #total[0][0] 总行数,total[0][1] 总页数
    if len(total) == 0:
        result['total']=0
        result['totalPage']=0
        result['rows'] = {}
        return result
    ##按分页求结果
    sql = sql + " limit %s,%s"%((current_page-1)*size,size)
    cursor.execute(sql)
    desc = cursor.description
    desc = [ i[0] for i in desc]
    res = cursor.fetchall()
    cursor.close()
    TAG=[]
    for i in res:
       TAG.append(dict(zip(desc,i)))
    result['total']=total[0][0]
    result['totalPage']=total[0][1]
    result['rows'] = TAG
    return result
