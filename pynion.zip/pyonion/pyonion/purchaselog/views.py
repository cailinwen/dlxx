# -*- coding: utf-8 -*-
#import codecs

from pyonion.auth.views import need_login
import json

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from pyonion.models import purchaseLog

from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage

from django.shortcuts import render_to_response

#商品采购列表页
@need_login
def purchaseLogList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("purchaselog/purchaselogList.html",dic)

#查询采购日志表信息
@csrf_exempt
@need_login
def purchaseLogJson(request):
    businessName = request.GET.get('businessName')
    queryset = purchaseLog.objects.filter().order_by('-create_time')
    if businessName:
        queryset = queryset.filter(business_name__icontains=businessName)

    purchases = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (purchases.paginator.count, purchases.paginator.num_pages)]
    for purchase in purchases:
		items.append(
			'{"id":"%s","business_name":"%s","content":"%s","create_user_name":"%s","create_time":"%s"},' % (
				purchase.id,purchase.business_name,purchase.content,purchase.create_user_name,purchase.create_time))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if purchases.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#分页控件
def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result