# -*- coding: utf-8 -*-
#import codecs
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )

import json
from pyonion.auth.views import need_login
from pyonion.models import ReportStockDay
import xlwt

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django.core.serializers.json import DjangoJSONEncoder
from django.utils.timezone import now, timedelta

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import connections
import csv,codecs

@need_login
@csrf_exempt
#商品库存统计跳转页面
def invertoryList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("inventory/inventoryList.html",dic)

#商品库存统计
@need_login
@csrf_exempt
def invertoryListJson(request):
    leName = request.GET.get('seacheNameParam')
    start = request.GET.get('start')
    queryset = ReportStockDay.objects.all().order_by('-id')
    date_time_all= now().date() + timedelta(days=-1)
    if leName:
        queryset = queryset.filter(le__le_name__icontains=leName)

    if start:
        queryset = queryset.filter(stock_date = start)
    else:
        queryset = queryset.filter(stock_date = date_time_all)

    reportStockDays = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (reportStockDays.paginator.count, reportStockDays.paginator.num_pages)]
    for reportStockDay in reportStockDays:
        try:
            leName = reportStockDay.le.le_name
            leCode = reportStockDay.le.le_code
        except:
            leName =""
            leCode =""
        items.append(
            '{"id":"%s","le_name":"%s","le_code":"%s","stock_qty":"%s"},' % (
                reportStockDay.id,leName,leCode,reportStockDay.stock_qty))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if reportStockDays.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#商品天数统计
@need_login
@csrf_exempt
def daysJson(request):
    leName = request.GET.get('seacheName')
    start = request.GET.get('startAll')
    end = request.GET.get('end')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if leName:
        likeSql = " AND t2.le_name like '%%%s%%' " % leName

    start_sql=end_sql=""
    if start:
        start_sql = " and t1.STOCK_DATE >= '%s'" % start

    if end:
        end_sql = " and t1.STOCK_DATE <= '%s' " % end

    whereSql = " WHERE t1.stock_qty >0 "
    groupSql = " GROUP BY  t1.le_id,t2.le_name,t2.le_code  "
    orderBy = " ORDER BY id desc "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = '''
              select t1.id,t1.le_id,count(distinct t1.stock_date) as day_count, t2.le_name,t2.le_code
              from report_stock_day t1 left join le_rec t2 on t1.le_id= t2.le_id   %s %s %s
            ''' % (whereSql, groupSql,orderBy)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#商品销量统计暂时不用
@need_login
@csrf_exempt
def salesJson(request):
    seacheNameFull = request.GET.get('seacheNameFull')
    startFull = request.GET.get('startFull')
    endFull = request.GET.get('endFull')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameFull:
        likeSql = " AND t2.le_name like '%%%s%%' " % seacheNameFull

    start_sql=end_sql=""
    if startFull:
        start_sql = " and t1.sale_date >= '%s'" % startFull

    if endFull:
        end_sql = " and t1.sale_date <= '%s' " % endFull

    whereSql = " WHERE 1=1 "
    groupSql = " GROUP BY  t1.le_id,t2.le_name,t2.le_code  "
    orderBy = " ORDER BY id desc "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = '''
              select t1.id,t1.le_id,sum(t1.sale_qty) as saleQty,t2.le_sprice, t2.le_name,t2.le_code,sum(t1.sale_qty*t2.le_sprice) as totalprice
              from report_stock_day t1 left join le_rec t2 on t1.le_id= t2.le_id    %s %s %s
            ''' % (whereSql, groupSql,orderBy)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#商品天数导出
@need_login
@csrf_exempt
def daysExprort(request):
    leName = request.GET.get('seacheName')
    start = request.GET.get('startAll')
    end = request.GET.get('end')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if leName:
        likeSql = " AND x.le_name like '%%%s%%' " % leName

    start_sql=end_sql=""
    if start:
        start_sql = " and t1.STOCK_DATE >= '%s'" % start

    if end:
        end_sql = " and t1.STOCK_DATE <= '%s' " % end

    whereSql = " WHERE t1.stock_qty >0 "
    groupSql = " GROUP BY  t1.le_id,x.le_name,x.le_code  "
    orderBy = " ORDER BY id desc "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = u'''
              select x.le_name,x.le_code,count(distinct t1.stock_date) as day_count,y.`一级品类` as yi,y.`二级品类` as er,y.`三级品类` as san from le_rec x LEFT JOIN
                (select a1.let_id 一级ID,a1.LET_NAME 一级品类,a2.let_id 二级ID,a2.LET_NAME 二级品类 ,a3.let_id 三级ID,a3.LET_NAME 三级品类 from (
                select a.let_id,a.LET_NAME from let_rec a where a.LET_ID1 is null and a.let_id!=92) a1 LEFT JOIN
               (select a.let_id,a.LET_PARENT_ID,a.LET_NAME from let_rec a where a.LET_PARENT_ID in(
                select a.let_id from let_rec a where a.LET_ID1 is null and a.let_id!=92) ) a2 on a1.let_id=a2.LET_PARENT_ID
                LEFT JOIN(select a.let_id,a.LET_PARENT_ID,a.LET_NAME from let_rec a where a.LET_PARENT_ID in(
                select a.let_id from let_rec a where a.LET_PARENT_ID in(select a.let_id from let_rec a where a.LET_ID1 is null and a.let_id!=92))) a3
                on a2.let_id=a3.LET_PARENT_ID
                ) y on x.LE_LET_ID=y.三级ID LEFT JOIN report_stock_day t1 on x.LE_ID = t1.LE_ID   %s %s %s
            ''' % (whereSql, groupSql,orderBy)
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    results = cursor.fetchall()
    cursor.close()
    response = HttpResponse(content_type='text/csv')
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = 'attachment; filename=商品天数导出.csv'
    data = []
    writer = csv.writer(response)
    writer.writerow(['商品名称','商品编码','天数','一级类别','二级类别','三级类别'])
    for row in results:
        datas =(row[0],row[1],row[2],row[3],row[4],row[5])
        data.append(datas)
    writer.writerows(data)
    return response

#商品库存导出
@need_login
@csrf_exempt
def inventoryExprort(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    startdata = request.GET.get('startdata')
    date_time_all= now().date() + timedelta(days=-1)
    args = {}
    if seacheNameParam:
        args['le__le_name__contains'] = seacheNameParam

    if startdata:
        args['stock_date'] = startdata
    else:
        args['stock_date'] = date_time_all

    if args:
        reportStockDays = ReportStockDay.objects.filter(**args)
    else:
        reportStockDays = ReportStockDay.objects.all()

    title = ['商品名称', '商品编码', '库存数量']

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for col, val in enumerate(title):
        sheet.write(0, col, val, style=xlwt.Style.default_style)

    for row, reportStockDay in enumerate(reportStockDays):
        try:
            leName = reportStockDay.le.le_name
            leCode = reportStockDay.le.le_code
        except:
            leName =""
            leCode =""
        sheet.write(row + 1, 0, leName, style=xlwt.Style.default_style)
        sheet.write(row + 1, 1, leCode, style=xlwt.Style.default_style)
        sheet.write(row + 1, 2, reportStockDay.stock_qty, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=example.xls'
    book.save(response)
    return response

#商品销量导出
@need_login
@csrf_exempt
def salesExprort(request):
    seacheNameFull = request.GET.get('seacheNameFull')
    startFull = request.GET.get('startFull')
    endFull = request.GET.get('endFull')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameFull:
        likeSql = " AND x.le_name like '%%%s%%' " % seacheNameFull

    start_sql=end_sql=""
    if startFull:
        start_sql = " and t1.sale_date >= '%s'" % startFull

    if endFull:
        end_sql = " and t1.sale_date <= '%s' " % endFull

    whereSql = " WHERE 1=1 "
    groupSql = " GROUP BY  t1.le_id,x.le_name,x.le_code  "
    orderBy = " ORDER BY t1.id desc "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = u'''
                select x.le_name,x.le_code,sum(t1.sale_qty) as saleQty,x.le_sprice,sum(t1.sale_qty*x.le_sprice) as totalprice,y.`一级品类` as yi,y.`二级品类` as er,y.`三级品类` as san from le_rec x LEFT JOIN
                (select a1.let_id 一级ID,a1.LET_NAME 一级品类,a2.let_id 二级ID,a2.LET_NAME 二级品类 ,a3.let_id 三级ID,a3.LET_NAME 三级品类 from (
                select a.let_id,a.LET_NAME from let_rec a where a.LET_ID1 is null and a.let_id!=92) a1
                LEFT JOIN
                (select a.let_id,a.LET_PARENT_ID,a.LET_NAME from let_rec a where a.LET_PARENT_ID in
                (select a.let_id from let_rec a where a.LET_ID1 is null and a.let_id!=92) ) a2
                on a1.let_id=a2.LET_PARENT_ID LEFT JOIN (select a.let_id,a.LET_PARENT_ID,a.LET_NAME from let_rec a where a.LET_PARENT_ID in
                 (select a.let_id from let_rec a where a.LET_PARENT_ID in (select a.let_id from let_rec a where a.LET_ID1 is null and a.let_id!=92))) a3
                on a2.let_id=a3.LET_PARENT_ID ) y on x.LE_LET_ID=y.三级ID LEFT JOIN report_stock_day t1 on x.LE_ID = t1.LE_ID   %s %s %s
            ''' % (whereSql, groupSql,orderBy)
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    results = cursor.fetchall()
    cursor.close()
    response = HttpResponse(content_type='text/csv')
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = 'attachment; filename=商品销量导出.csv'
    data = []
    writer = csv.writer(response)
    writer.writerow(['商品名称','商品编码','商品销量','商品售价','销售额','一级类别','二级类别','三级类别'])
    writer.writerows([(row[0],row[1],row[2] if row[2] else 0,row[3] if row[3] else 0,row[4] if row[4] else 0,row[5],row[6],row[7]) for row in results])
    #writer.writerows([(row[2],row[3],row[4] if row[4] else 0,row[5] if row[5] else 0,row[6] if row[6] else 0) for row in results])
    return response

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result
