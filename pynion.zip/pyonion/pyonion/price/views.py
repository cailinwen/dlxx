__author__ = 'sjun'

from pyonion.models import Price
from pyonion.auth.views import need_login
from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage


@need_login
def priceList(request):
    dic = {'id': request.GET.get('id'), 'userID': request.GET.get('userID')}
    return render_to_response("price/priceList.html", dic)


def priceJson(request):
    sodNameParam = request.GET.get('supplier')
    queryset = Price.objects.all().order_by('id')
    if sodNameParam:
        queryset = queryset.filter(store__store_name__icontains=sodNameParam)

    prices = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (prices.paginator.count, prices.paginator.num_pages)]
    for price in prices:
        items.append(
            '{"id":"%s","supplier":"%s","first_amount":"%s","pay_account":"%s","rest_amount":"%s","shipping_mode":"%s"},' % (
                price.id, price.supplier, price.first_amount, price.pay_account, price.rest_amount,
                price.shipping_mode))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if prices.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")


def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result
