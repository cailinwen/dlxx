# encoding: UTF-8
__author__ = 'Administrator'

import datetime
from django.db import connection
from apscheduler.schedulers.background import BackgroundScheduler

def tick():
    sql = "INSERT INTO test_tb (NAME) VALUES('123456789')";
    cursor = connection.cursor()
    cursor.execute(sql)
    cursor.commit()
    print('Tick! The time is: %s' % datetime.now())

def crontab():
    print("11111111111111")
    scheduler = BackgroundScheduler()
    scheduler.add_job(tick, 'date', run_date='2016-1-12 17:29:00')
    scheduler.start()
    print("2222222")


