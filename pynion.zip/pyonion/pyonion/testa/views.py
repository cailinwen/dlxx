# -*- coding: utf-8 -*-
#import codecs
from __future__ import unicode_literals
import json
from decimal import *

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from pyonion.models import Member,Store,Sod,SodItem
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django.db import connection
from decimal import *
import datetime
import threading
import time
from apscheduler.schedulers.background import BackgroundScheduler

# 订单查询页面跳转 New
def sodManagementList(request):
    dic = {'id': request.GET.get('id')}
    return render_to_response("test/sod.html",dic)

# 订单查询列表页面跳转 New
def sodManagementJson(request):
    sodNameParam = request.GET.get('sodNameParam')
    sodNoParam = request.GET.get('sodNoParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    queryset = Sod.objects.all()
    if sodNameParam:
        queryset = queryset.filter(store__store_name__icontains=sodNameParam)

    if sodNoParam:
        queryset = queryset.filter(sod_no__icontains=sodNoParam)

    if start and end:
        start_time = datetime.datetime.strptime(start,'%Y-%m-%d')
        end_time = datetime.datetime.strptime(end,'%Y-%m-%d')
        queryset = queryset.filter(sod_create_time__range=(start_time, end_time))
    elif start and not end:
        start_time = datetime.datetime.strptime(start,'%Y-%m-%d')
        queryset = queryset.filter(sod_create_time__gte=start_time)
    elif not start and end:
        end_time = datetime.datetime.strptime(end,'%Y-%m-%d')
        queryset = queryset.filter(sod_create_time__lte=end_time)

    sods = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (sods.paginator.count, sods.paginator.num_pages)]
    for sod in sods:
        items.append(
            '{"sod_no":"%s","sod_type":"%s","sod_stat":"%s","sod_pay_type":"%s","sod_pay_flg":"%s","sod_pay_no":"%s","member_name":"%s","store_name":"%s"},' % (
                sod.sod_no, sod.sod_type, sod.sod_stat, sod.sod_pay_type,sod.sod_pay_flg,sod.sod_pay_no,sod.store_member.member_name,sod.store.store_name))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if sods.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")


def tick():
    sql = "INSERT INTO test_tb (NAME) VALUES('123456789')";
    cursor = connection.cursor()
    cursor.execute(sql)
    cursor.commit()
    print('Tick! The time is: %s' % datetime.now())

def crontab():
    print("11111111111111")
    scheduler = BackgroundScheduler()
    scheduler.add_job(tick, 'date', run_date='2016-1-12 17:29:00')
    scheduler.start()
    print("2222222")

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result