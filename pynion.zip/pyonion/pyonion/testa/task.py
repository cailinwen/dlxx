# encoding: UTF-8
__author__ = 'Administrator'

import threading
import time

#获取当前的系统时间
def GetNowTime():
    return time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))

#定时任务执行方法
def myActionTask():
    #任务代码块开始：举例打印当前系统时间
    print "hello world new time is "+ GetNowTime()
    #任务代码块开始结束
    global t   #Notice: use global variable!
    t = threading.Timer(5.0, myActionTask) #回调 myActionTask （当前任务方法），间隔5s（时间可自定义）
    t.start() #启动定时任务

t = threading.Timer(5.0, myActionTask) #创建定时任务对象
t.start() #启动定时任务