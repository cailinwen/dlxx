# -*- coding: utf-8 -*-
#import codecs

from pyonion.auth.views import need_login
import json

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from pyonion.models import Purchase,PurchaseDetail,inBound

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import models, transaction

import xlrd
import os
import datetime
from pyonion.purchase.views import operationLog

# 入库信息信息
@csrf_exempt
@need_login
def storageList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("storage/storageList.html", dic)

#商品采购查询列表页
@csrf_exempt
@need_login
def storageJson(request):
    sodNo = request.GET.get('sodMo')
    nameAll = request.GET.get('nameAll')
    paymentType = request.GET.get('paymentType')
    goodsState = request.GET.get('goodsState')
    queryset = Purchase.objects.filter(is_deleted=0).order_by('-create_time')
    if sodNo:
        queryset = queryset.filter(purchase_no__icontains=sodNo)
    if nameAll:
        queryset = queryset.filter(supplier__name__icontains=nameAll)
    if paymentType:
        queryset = queryset.filter(pay_mode__icontains=paymentType)
    if goodsState:
        queryset = queryset.filter(state__icontains=goodsState)

    purchases = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (purchases.paginator.count, purchases.paginator.num_pages)]
    for purchase in purchases:
        estTime = purchase.est_arrival_time
        #当前时间(数据库中的类型是tetime.datetime，而不是datetime.date)
        todatay = datetime.datetime.today()
        #如果state=6的时候表示此采购单已经终止了就不计算剩余天数
        if purchase.state >= 5:
            dateTimeAll = "terminationOf"
        else:
            #到货剩余天数 = 预计到货时间-当前时间
            #0时0分0秒时 时间差 无需加1
            if todatay.strftime('%H:%M:%S') == '00:00:00':
               dateTimeAll = (estTime - todatay).days
            else:
               dateTimeAll = (estTime - todatay).days + 1
        total = purchase.first_amount+purchase.rest_amount+purchase.freight
        names = purchase.supplier
        if names != None:
            items.append(
                '{"id":"%s","purchase_no":"%s","state":"%s","name":"%s","shipping_time":"%s","est_arrival_time":"%s","first_amount":"%s","rest_amount":"%s","freight":"%s","total_amount":"%s","date_time_all":"%s","shipping_mode":"%s","pay_mode":"%s"},' % (
                    purchase.id,purchase.purchase_no,purchase.state,purchase.supplier.name, purchase.shipping_time, purchase.est_arrival_time, purchase.first_amount,purchase.rest_amount,purchase.freight,total,dateTimeAll,purchase.shipping_mode,purchase.pay_mode))
        else:
            items.append(
                '{"id":"%s","purchase_no":"%s","state":"%s","shipping_time":"%s","est_arrival_time":"%s","first_amount":"%s","rest_amount":"%s","freight":"%s","total_amount":"%s","date_time_all":"%s","shipping_mode":"%s","pay_mode":"%s"},' % (
                    purchase.id,purchase.purchase_no,purchase.state,purchase.shipping_time, purchase.est_arrival_time, purchase.first_amount,purchase.rest_amount,purchase.freight,total,dateTimeAll,purchase.shipping_mode,purchase.pay_mode))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if purchases.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#采购信息修改跳转页面
@csrf_exempt
@need_login
def storageDetailList(request):
    dic = {'id': request.GET.get('showId'),'state': request.GET.get('state'),'idAll': request.GET.get('idAll'),'userIDAll': request.GET.get('userIDAll')}
    return render_to_response("storage/storageDetailList.html" , dic)

#查询子表信息
@csrf_exempt
@need_login
def storageDetailJson(request):
    orId = request.GET.get('id')
    sysPurchase = Purchase.objects.get(pk = orId)
    #根据主表的id询子表的信息
    zis = getPaginator(sysPurchase.purchasedetail_set.all(),request)
    itemStorage = ['{"total":%d,"totalPage":%d,"rows":[' % (zis.paginator.count, zis.paginator.num_pages)]
    for zi in zis:
        ziName = zi.le
        if ziName != None:
            itemStorage.append('{"id":"%s","le_code":"%s","le_barcode":"%s","le_name":"%s","package_qty":"%s","arrival_qty":"%s"},' % (
                 zi.id,zi.le_code,zi.le_barcode,zi.le.le_name,zi.package_qty,zi.arrival_qty))
        else:
            itemStorage.append('{"id":"%s","le_code":"%s","le_barcode":"%s","package_qty":"%s","arrival_qty":"%s"},' % (
                 zi.id,zi.le_code,zi.le_barcode,zi.package_qty,zi.arrival_qty))
    itemStorage.append(']}')
    jsonstr = ''.join(itemStorage)
    jsonlen = len(jsonstr)
    if zis.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#商品入库导入跳转页面
@csrf_exempt
@need_login
def storageImportList(request):
    return render_to_response("storage/storageImportList.html")

#从Excel中取数据插入到相关表中
@transaction.atomic
def storageTable(filepath,userauth,userNo):
    data = xlrd.open_workbook(filepath)
    table1 = data.sheets()[0]
    x = table1.row_values(1)
    #获取Excel第一页的主表的订单号
    purchase_no = x[0]
    pur = Purchase.objects.filter(purchase_no = purchase_no,is_deleted=0)
    if pur:
        purs = pur[0]
        #读取Excel第二页的数据
        table2 = data.sheets()[1]
        len2 = table2.nrows
        for j in range(1,len2):
            row = table2.row_values(j)
            #根据Excel第二页的数据获取到的货号去查询明细表的货号
            puDs = PurchaseDetail.objects.filter(le_code=row[0],purchase=purs)
            try:
                puD = puDs[0]
                ziId = puD.id
                inBound.objects.create(purchaseDetailid = ziId,code = row[0],barcode = row[1],qty = row[2],create_user_id=userNo,create_user_name=userauth)
                #更改明细表的已到货数量
                if puD.arrival_qty:
                    puD.is_new = 1
                puD.arrival_qty = puD.arrival_qty + row[2]
                puD.save()
            except Exception, e:
                os.remove(filepath)
                return HttpResponse("货号在采购明细表中不存在！请检查EXCEL相关数据！")#导入失败
        os.remove(filepath)
        return HttpResponse("导入成功！") #导入成功
    else:
        os.remove(filepath)
        return HttpResponse("采购单号与入库单号不一致！请检查EXCEL中的订单号！")#导入失败
#上传Excel文件
def storage_uploaded_file(file, filename):
    if not os.path.exists('upload/'):
        os.mkdir('upload/')
    with open('upload/' + filename, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
    return 'upload/' + filename

@csrf_exempt
@need_login
def storageImport(request):
    #获取当前用户名
    userauth = request.COOKIES.get('username', '')
    userNo = request.COOKIES.get('userId', '')
    #获取Excel文件
    if request.method == 'POST':
        business_name = "商品入库" #操作模块
        filepath = storage_uploaded_file(request.FILES['file'], str(request.FILES['file']))
        try:
            content = "导入商品入库单信息！"   #操作内容
            operationLog(request,content,business_name)
            return storageTable(filepath,userauth,userNo)
        except Exception, e:
            os.remove(filepath)
            return HttpResponse("导入失败！请检查EXCEL相关数据格式！")#导入失败
    else:
        return HttpResponse("导入失败!请检查EXCEL相关数据格式！")#导入失败

# 修改采购子信息
@csrf_exempt
@need_login
def storageUpdateList(request):
    dic = {'id': request.GET.get('id'), 'qty': request.GET.get('qty'),'purchaseDetailid': request.GET.get('purchaseDetailid')}
    return render_to_response("storage/storageUpdate.html", dic)

# 修改采购子表数据
@csrf_exempt
@need_login
def storageUpdateSave(request):
    # c={}
    # 修改采购主表信息
    if request.method == 'POST':
        try:
           business_name = "商品入库" #操作模块
           orId = request.POST['id']
           purchaseDetailid = request.POST['purchaseDetailid'] #获取明细的id
           sysPu = inBound.objects.get(pk=int(orId))
           sysPu.qty = request.POST['qty']
           sysPu.save()
           #根据明细表的id查询入库单中的数据
           purDId = inBound.objects.filter(purchaseDetailid = purchaseDetailid)
           nval = 0
           for puD in purDId:
               nval += puD.qty
               #根据修改过的实际到货量更新到对应的明细表中的实际到货量字段中
               purchaseDetail = PurchaseDetail.objects.get(id = purchaseDetailid)
               purchaseDetail.arrival_qty = nval
               purchaseDetail.save()
           content = "修改商品采购明细信息！"   #操作内容
           operationLog(request,content,business_name)
           result = {"result":True}
           return HttpResponse(json.dumps(result), content_type="application/json") #保存成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #保存失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #保存出现异常

#删除采购明细表信息
@csrf_exempt
@need_login
def storagedelete(request):
    if request.method == 'POST':
        ids = request.POST['orId']
        #删除采购明细信息
        try:
            business_name = "商品入库" #操作模块
            PurchaseDetail.objects.filter(pk=ids).delete()
            content = "删除商品采购明细信息！"   #操作内容
            operationLog(request,content,business_name)
            result = {"result":True}
            return HttpResponse(json.dumps(result), content_type="application/json") #删除成功
        except Exception, e:
            result = {"result":False}
            return HttpResponse(json.dumps(result), content_type="application/json") #删除失败
    else:
        result = {"result":"Bad request, you need send a POST request"}
        return HttpResponse(json.dumps(result), content_type="application/json") #删除出现异常

#商品入库单跳转页面
@csrf_exempt
@need_login
def storageDetail(request):
    dic = {'id': request.GET.get('id'), 'package_qty': request.GET.get('package_qty'),'purchase':request.GET.get('purchase')}
    return render_to_response("storage/storageDetail.html",dic)

#查询入库信息
@csrf_exempt
@need_login
def detailJson(request):
    orId = request.GET.get('id')
    #根据id查询主表的采购信息
    sysInBound = getPaginator(inBound.objects.filter(purchaseDetailid = orId),request)
    itemInBound = ['{"total":%d,"totalPage":%d,"rows":[' % (sysInBound.paginator.count, sysInBound.paginator.num_pages)]
    for sysInBounds in sysInBound:
        itemInBound.append('{"id":"%s","qty":"%s","create_user_name":"%s","create_time":"%s","code":"%s","barcode":"%s","purchaseDetailid":"%s"},' % (
            sysInBounds.id, sysInBounds.qty,sysInBounds.create_user_name,sysInBounds.create_time,sysInBounds.code,sysInBounds.barcode,sysInBounds.purchaseDetailid))
    itemInBound.append(']}')
    jsonstr = ''.join(itemInBound)
    jsonlen = len(jsonstr)
    if sysInBound.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#分页控件
def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result