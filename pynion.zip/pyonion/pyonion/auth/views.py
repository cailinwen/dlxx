# -*- coding: utf-8 -*-
# import codecs
from django.http import HttpResponse, HttpResponseRedirect
import datetime


#定义装饰器need_login
def need_login(func):
    #定义方法_deco，传request
    def _deco(request):
        username = request.COOKIES.get('username', '')
        if username:
            #如果已登陆直接调用相关模块的view方法
             response = func(request)
             dt = datetime.datetime.utcnow() + datetime.timedelta(minutes = 10)
             response.set_cookie('username', username, expires=dt)
             #response.set_cookie('userId', user[0].user_id, expires=dt)
             return response
        else:
            #如果未登陆，重定向到登陆页面login
            return  HttpResponseRedirect('/login/?redirect=1')
    return _deco


def need_loginceshi(func):
    #定义方法_deco，传request
    def _deco(request):
        username = request.COOKIES.get('username', '')
        if username:
            #如果已登陆直接调用相关模块的view方法
            return func(request)
        else:
            #如果未登陆，重定向到登陆页面login
            return  HttpResponseRedirect('/login/')
    return _deco


