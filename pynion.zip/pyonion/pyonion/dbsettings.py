# -*- coding: utf-8 -*-
from django.conf import settings

class ReplicaRouter(object):
    def db_for_read(self, model, **hints):
        """
        Reads go to a randomly-chosen replica.
        """
        return 'slave'

    def db_for_write(self, model, **hints):
        """
        Reads go to a randomly-chosen replica.
        """
        return 'default'