# -*- coding: utf-8 -*-
#import codecs
from __future__ import unicode_literals
import json
import xlwt
from decimal import *
from pyonion.auth.views import need_login

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from pyonion.models import Member,Store,Sod,SodItem
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django.db import connections
from decimal import *
import datetime


# 商家用户页面跳转
@need_login
def managementList(request):
    dic = {'id': request.GET.get('id')}
    return render_to_response("management/managementList.html",dic)

# 商家用户信息列表展示
def managementListSeach(request):
    memberName = request.GET.get('memberNameParam')
    if memberName != None:
        member = getPaginator(Member.objects.filter(member_name__icontains=memberName).order_by('-member_id'), request)
    else:
        member = getPaginator(Member.objects.filter().order_by('-member_id'), request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (member.paginator.count, member.paginator.num_pages)]
    for members in member:
        items.append(
            '{"member_id":"%s","member_code":"%s","member_name":"%s","member_address_no":"%s","member_phone":"%s"},' % (
            members.member_id, members.member_code, members.member_name, members.member_address_no, members.member_phone))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 商家用户详细页面跳转
def managementDetailList(request):
    dic = {'memberId': request.GET.get('memberId')}
    return render_to_response("management/managementDetailList.html",dic)

# 商家用户详细信息列表展示
def managementDetailListSeach(request):
    memberName = request.GET.get('memberNameParam')
    if memberName != None:
        member = getPaginator(Member.objects.filter(member_name__icontains=memberName).order_by('-member_id'), request)
    else:
        member = getPaginator(Member.objects.filter().order_by('-member_id'), request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (member.paginator.count, member.paginator.num_pages)]
    for members in member:
        items.append(
            '{"member_id":"%s","member_code":"%s","member_name":"%s","member_address_no":"%s","member_phone":"%s"},' % (
            members.member_id, members.member_code, members.member_name, members.member_address_no, members.member_phone))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#店主管理查询跳转页面
@need_login
def shopOwnerManagementList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("management/shopOwnerManagementList.html",dic)

#店主管理查询列表
@csrf_exempt
def shopOwnerJsonListss(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    pageSzie = request.GET.get('size')
    pageNo = request.GET.get('pageNo')
    cursorA = connections['slave'].cursor()
    totalSql = "SELECT MEMBER_ID FROM member_rec t1 left join store_rec t2 on t1.MEMBER_ID= t2.STORE_MEMBER_ID "
    whereSql = " WHERE "
    likeSql = ""
    totalGroupSql = " GROUP BY MEMBER_ID"
    if start == None:
        whereSql = whereSql + " USER_CREATE_TIME < '%s' " % (end)
    else:
        whereSql = whereSql + " USER_CREATE_TIME > '%s' AND USER_CREATE_TIME < '%s'" % (start, end)
    if seacheNameParam != None:
        likeSql = " AND t1.MEMBER_NAME like '%%%s%%' " % (seacheNameParam)
    whereSql = whereSql + " and t1.MEMBER_TYPE='3' and t2.STORE_IS_BROKER='0' ";
    totalSql = totalSql + whereSql + likeSql + totalGroupSql
    cursorA.execute(totalSql)
    jsonItme = cursorA.fetchall()
    dataTotal = str(len(jsonItme))
    cursorA.close()

    startLimitNum = int(pageSzie) * (int(pageNo) - 1)
    mySql = "select t1.member_id,t1.member_name,t1.member_address_no,t1.member_phone,t1.user_create_time, t2.store_name from member_rec t1 left join store_rec t2 on t1.MEMBER_ID= t2.STORE_MEMBER_ID "
    groupSql = "GROUP BY MEMBER_ID ORDER BY MEMBER_ID desc"
    whereSql = whereSql + " and t1.MEMBER_TYPE='3' and t2.STORE_IS_BROKER='0'"
    if seacheNameParam == None:
        mySql = mySql + whereSql + groupSql
    else:
        likeSql = " AND t1.member_name like '%%%s%%' " % (seacheNameParam)
        mySql = mySql + whereSql + likeSql + groupSql
    temp = " limit %d,%d" % (startLimitNum, int(pageSzie))
    cursor = connections['slave'].cursor()
    cursor.execute(mySql + temp)
    jsonItme = cursor.fetchall()
    desc = cursor.description
    cursor.close()

    totalPage = int(dataTotal) / int(pageSzie)
    if (int(dataTotal) % int(pageSzie)) > 0:
        totalPage = totalPage + 1
    items = ['{"total":%s,"totalPage":%s,"rows":' % (dataTotal, str(totalPage))]
    li = []
    for item in jsonItme:
        repoerItem = {}
        i = 0
        for de in desc:
            if isinstance(item[i], Decimal):
                repoerItem[de[0]] = str(item[i])
            else:
                if(i == 4):
                    repoerItem[de[0]] = str(item[i].year)+"-"+str(item[i].month)+"-"+str(item[i].day)
                else:
                    repoerItem[de[0]] = item[i]
            i = i + 1
        li.append(repoerItem)
    items.append(json.dumps(list(li)))
    items.append('}')
    return HttpResponse(items, content_type="application/json")

#店主管理查询列表
@need_login
def shopOwnerJsonList(request):
    setchoose = request.GET.get('setchoose')
    seacheName = request.GET.get('seacheNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    if seacheName != None:
        #lte是小雨等于  gte是大于等于
        if start == None:
            stores = getPaginator(Store.objects.filter(store_member__member_name__icontains=seacheName,store_member__member_type=3,store_is_broker=setchoose), request)
        else:
            stores = getPaginator(Store.objects.filter(store_member__member_name__icontains=seacheName,store_member__user_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,store_member__user_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d'),store_member__member_type=3,store_is_broker=setchoose), request)
    else:
        if start == None:
            stores = getPaginator(Store.objects.filter(store_member__member_type=3,store_is_broker=setchoose), request)
        else:
            stores = getPaginator(Store.objects.filter(store_member__user_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,store_member__user_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d'),store_member__member_type=3,store_is_broker=setchoose), request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (stores.paginator.count, stores.paginator.num_pages)]
    for store in stores:
        items.append(
            '{"store_id":"%s","member_name":"%s","member_address_no":"%s","member_phone":"%s","user_create_time":"%s","store_name":"%s"},' % (
                store.store_id, store.store_member.member_name, store.store_member.member_address_no, store.store_member.member_phone,store.store_member.user_create_time.strftime('%Y-%m-%d'),store.store_name))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if stores.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 店主会员页面跳转
def memberManagementList(request):
    dic = {'storeId': request.GET.get('storeId')}
    return render_to_response("management/memberManagementList.html",dic)

# 店主会员信息列表查询
def memberManagementJson(request):
    storeId = request.GET.get('storeId')
    memberName = request.GET.get('memberNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    if memberName != None:
        #lte是小雨等于  gte是大于等于
        if start == None:
            members = getPaginator(Member.objects.filter(member_tmn__tmn_store_id=storeId,member_name__icontains=memberName), request)
        else:
            members = getPaginator(Member.objects.filter(member_tmn__tmn_store_id=storeId,member_name__icontains=memberName,user_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,user_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
    else:
        if start == None:
            members = getPaginator(Member.objects.filter(member_tmn__tmn_store_id=storeId), request)
        else:
            members = getPaginator(Member.objects.filter(member_tmn__tmn_store_id=storeId,user_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,user_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (members.paginator.count, members.paginator.num_pages)]
    for member in members:
        items.append(
            '{"member_id":"%s","member_name":"%s","member_address_no":"%s","member_phone":"%s","user_create_time":"%s"},' % (
                member.member_id, member.member_name, member.member_address_no,member.member_phone,member.user_create_time))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if members.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 店主会员订单详细页面跳转
@need_login
def shopOwnerDetailList(request):
    dic = {'memberId': request.GET.get('memberId')}
    return render_to_response("management/shopOwnerDetailList.html",dic)

# 店主会员订单信息列表查询
def shopOwnerDetailJson(request):
    memberId = request.GET.get('memberId')
    sodNoParam = request.GET.get('sodNoParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    if sodNoParam != None:
        #lte是小雨等于  gte是大于等于
        if start == None:
            sods = getPaginator(Sod.objects.filter(sod_member__member_id=memberId,sod_no__icontains=sodNoParam), request)
        else:
            sods = getPaginator(Sod.objects.filter(sod_member__member_id=memberId,sod_no__icontains=sodNoParam,sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
    else:
        if start == None:
            sods = getPaginator(Sod.objects.filter(sod_member__member_id=int(memberId)), request)
        else:
            sods = getPaginator(Sod.objects.filter(sod_member__member_id=int(memberId),sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (sods.paginator.count, sods.paginator.num_pages)]
    for sod in sods:
        items.append(
            '{"sod_no":"%s","sod_type":"%s","sod_stat":"%s","sod_pay_type":"%s","sod_pay_flg":"%s","sod_pay_no":"%s","member_name":"%s"},' % (
                sod.sod_no, sod.sod_type, sod.sod_stat, sod.sod_pay_type,sod.sod_pay_flg,sod.sod_pay_no,sod.sod_member.member_name))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if sods.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 订单查询页面跳转 New
@need_login
def sodManagementList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("management/sodManagementList.html",dic)

# 订单查询列表页面跳转 New
def sodManagementJson(request):
    sodNameParam = request.GET.get('sodNameParam')
    sodNoParam = request.GET.get('sodNoParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    if sodNameParam != None:
        #lte是小雨等于  gte是大于等于
        if sodNoParam == None:
            if start == None:
                sods = getPaginator(Sod.objects.filter(store__store_name__icontains=sodNameParam), request)
                if end != None:
                    sods = getPaginator(Sod.objects.filter(store__store_name__icontains=sodNameParam,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
            else:
                sods = getPaginator(Sod.objects.filter(store__store_name__icontains=sodNameParam,sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d')), request)
                if end != None:
                    sods = getPaginator(Sod.objects.filter(store__store_name__icontains=sodNameParam,sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
        else:
            if start == None:
                 sods = getPaginator(Sod.objects.filter(store__store_name__icontains=sodNameParam,sod_no__icontains=sodNoParam), request)
                 if end != None:
                     sods = getPaginator(Sod.objects.filter(store__store_name__icontains=sodNameParam,sod_no__icontains=sodNoParam,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
            else:
                sods = getPaginator(Sod.objects.filter(store__store_name__icontains=sodNameParam,sod_no__icontains=sodNoParam,sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d')), request)
                if end != None:
                    sods = getPaginator(Sod.objects.filter(store__store_name__icontains=sodNameParam,sod_no__icontains=sodNoParam,sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
    else:
        if sodNoParam == None:
            if start == None:
                if end == None:
                    sods = getPaginator(Sod.objects.filter(), request)
                else:
                    sods = getPaginator(Sod.objects.filter(sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
            else:
                if end == None:
                    sods = getPaginator(Sod.objects.filter(sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d')), request)
                else:
                    sods = getPaginator(Sod.objects.filter(sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
                #sods = getPaginator(Sod.objects.filter(sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
        else:
            if start == None:
                if end == None:
                    sods = getPaginator(Sod.objects.filter(sod_no__icontains=sodNoParam), request)
                else:
                    sods = getPaginator(Sod.objects.filter(sod_no__icontains=sodNoParam,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
            else:
                if end == None:
                    sods = getPaginator(Sod.objects.filter(sod_no__icontains=sodNoParam,sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d')), request)
                else:
                    sods = getPaginator(Sod.objects.filter(sod_no__icontains=sodNoParam,sod_create_time__gte=datetime.datetime.strptime(start,'%Y-%m-%d') ,sod_create_time__lte=datetime.datetime.strptime(end,'%Y-%m-%d')), request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (sods.paginator.count, sods.paginator.num_pages)]
    for sod in sods:
        items.append(
            '{"sod_no":"%s","sod_type":"%s","sod_stat":"%s","sod_pay_type":"%s","sod_pay_flg":"%s","sod_pay_no":"%s","member_name":"%s","store_name":"%s"},' % (
                sod.sod_no, sod.sod_type, sod.sod_stat, sod.sod_pay_type,sod.sod_pay_flg,sod.sod_pay_no,sod.store_member.member_name,sod.store.store_name))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if sods.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 订单查询列表页面跳转 New
def sodManagementJsonNew(request):
    sodNameParam = request.GET.get('sodNameParam')
    sodNoParam = request.GET.get('sodNoParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    setchoose = request.GET.get('setchoose')
    sodStat = request.GET.get('sodStat')
    queryset = Sod.objects.all().order_by('sod_no')
    if sodNameParam:
        queryset = queryset.filter(store__store_name__icontains=sodNameParam)

    if sodNoParam:
        queryset = queryset.filter(sod_no__icontains=sodNoParam)

    if setchoose:
        queryset = queryset.filter(tmn__tmn_type__icontains=setchoose)

    if sodStat:
        queryset = queryset.filter(sod_stat=sodStat)

    if start and end:
        start_time = datetime.datetime.strptime(start,'%Y-%m-%d')
        end = end + " 23:59:59"
        end_time = datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')
        queryset = queryset.filter(sod_create_time__gte=start_time, sod_create_time__lte=end_time)
    elif start and not end:
        start_time = datetime.datetime.strptime(start,'%Y-%m-%d')
        queryset = queryset.filter(sod_create_time__gte=start_time)
    elif not start and end:
        end = end + " 23:59:59"
        end_time = datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')
        queryset = queryset.filter(sod_create_time__lte=end_time)


    sods = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (sods.paginator.count, sods.paginator.num_pages)]
    for sod in sods:
        try:
           memberName = sod.store_member.member_name
           storeName = sod.store.store_name
           memberPhone = sod.store_member.member_phone
           tmnType = sod.tmn.tmn_type
        except:
           memberName = ""
           storeName = ""
           memberPhone = ""
           tmnType = ""
        items.append(
            '{"sod_no":"%s","sod_type":"%s","sod_stat":"%s","sod_pay_type":"%s","sod_pay_flg":"%s","sod_pay_no":"%s","sod_amt":"%s","member_name":"%s","store_name":"%s","member_phone":"%s","tmn_type":"%s"},' % (
                sod.sod_no, sod.sod_type, sod.sod_stat, sod.sod_pay_type,sod.sod_pay_flg,sod.sod_pay_no,sod.sod_amt,memberName,storeName,memberPhone,tmnType))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if sods.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

@need_login
@csrf_exempt
def sodManagentExport(request):
    sodNameParam = request.GET.get('sodNameParam')
    sodNoParam = request.GET.get('sodNoParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    setchoose = request.GET.get('setchoose')
    sodStat = request.GET.get('sodStat')

    args = {}
    if sodNameParam:
        args['store__store_name__icontains'] = sodNameParam
    if sodNoParam:
        args['sod_no'] = sodNoParam

    if setchoose:
        args['tmn__tmn_type'] = setchoose

    if sodStat:
        args['sod_stat'] = sodStat

    if start and end:
        start_time = datetime.datetime.strptime(start,'%Y-%m-%d')
        end = end + " 23:59:59"
        end_time = datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')
        args['sod_create_time__gte'] = start_time
        args['sod_create_time__lte'] = end_time
    elif start and not end:
        start_time = datetime.datetime.strptime(start,'%Y-%m-%d')
        args['sod_create_time__gte'] = start_time
    elif not start and end:
        end = end + " 23:59:59"
        end_time = datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')
        args['sod_create_time__lte'] = end_time

    if args:
        sods = Sod.objects.filter(**args)
    else:
        sods = Sod.objects.all()
    title = ['店铺名称', '订单号', '订单类型','支付金额','店主名','店主手机','订单状态','支付方式','支付类型','支付流水号','订单来源']

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for col, val in enumerate(title):
        sheet.write(0, col, val, style=xlwt.Style.default_style)

    p_dict = {1: '支付宝', 2: '银联', 3: '微信钱包', 4: '线下转账',5:'财付通',6:'钱袋宝'}
    p_dict1 = {1: '触屏', 2: '微信'}
    p_dict2 = {1: '待付款', 2: '待发货',3:'待签收',4:'已签收',0:'超时'}
    p_dict3 = {1: '直付', 2: '代付'}
    p_dict4 = {1: '销售订单', 2: '退货订单'}

    # for row, sod in enumerate(sods):
    row = 0
    for sod in sods.iterator():
        sod_pay_flg = p_dict.get(sod.sod_pay_flg, '--')      #支付类型
        tmn_type = p_dict1.get(sod.tmn.tmn_type, '--') #订单来源
        sod_stat = p_dict2.get(sod.sod_stat, '--')     #支付状态
        sod_pay_type = p_dict3.get(sod.sod_pay_type, '--')     #支付方式
        sod_type = p_dict4.get(sod.sod_type, '--')     #支付类型
        if sod.store != None:
            sheet.write(row + 1, 0, sod.store.store_name, style=xlwt.Style.default_style)            #店铺名称
            sheet.write(row + 1, 1, sod.sod_no, style=xlwt.Style.default_style)                      #订单号
            sheet.write(row + 1, 2, sod_type, style=xlwt.Style.default_style)                       #支付类型
            sheet.write(row + 1, 3, sod.sod_amt, style=xlwt.Style.default_style)                     #支付金额
            sheet.write(row + 1, 4, sod.store_member.member_name, style=xlwt.Style.default_style)    #店主名称
            sheet.write(row + 1, 5, sod.store_member.member_phone, style=xlwt.Style.default_style)   #店主手机号
            sheet.write(row + 1, 6, sod_stat, style=xlwt.Style.default_style)       #支付状态
            sheet.write(row + 1, 7, sod_pay_type, style=xlwt.Style.default_style)   #支付方式
            sheet.write(row + 1, 8, sod_pay_flg, style=xlwt.Style.default_style)   #支付类型
            sheet.write(row + 1, 9, sod.sod_pay_no, style=xlwt.Style.default_style)   #支付流水号
            sheet.write(row + 1, 10, tmn_type, style=xlwt.Style.default_style)   #订单来源
        row += 1
    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=example.xls'
    book.save(response)
    return response

#订单销售导出
@csrf_exempt
@need_login
def salesOrderExport(request):
    #店铺名称
    seacheNameParam = request.GET.get('sodNameParam')
    #开始时间
    start = request.GET.get('start')
    #结束时间
    end = request.GET.get('end')
    cursorA = connections['slave'].cursor()
    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = " AND d.STORE_NAME like '%%%s%%' " % seacheNameParam

    start_sql=end_sql=""
    if start:
        start_sql = " and c.SOD_PAY_TIME >= '%s'" % datetime.datetime.strptime(start,'%Y-%m-%d')

    if end:
        end = end + " 23:59:59"
        end_sql = " and c.SOD_PAY_TIME <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    whereSql = " where (e.SOD_INCOME_TYPE=1 or e.SOD_INCOME_TYPE=3 ) and !(c.SOD_TYPE=2 and c.SOD_STAT!=2) "
    groupSql = " GROUP BY  z.STORE_NAME , z.SALE_TYPE ,z.SOD_NO,z.SOD_PAY_TIME, z.LE_NAME,z.SOD_ITEM_QTY,z.SOD_ITEM_AMT "
    orderBy = " order by z.SOD_PAY_TIME "
    whereSql = whereSql + likeSql + start_sql + end_sql
    totalSql = '''
                  select z.member_name,z.STORE_NAME,z.SALE_TYPE,z.SOD_NO,z.SOD_PAY_TIME,z.LE_NAME,z.SOD_ITEM_QTY, round(z.SOD_ITEM_AMT/z.SOD_ITEM_QTY,2) as PRICE,
                  z.SOD_ITEM_AMT, sum(z.SOD_INCOME_IAMT) as SOD_INCOME_IAMT_SUM ,
                  concat(cast(round(sum(z.SOD_INCOME_IAMT) /z.SOD_ITEM_AMT*100,2) as char),'%%') as INCOME_IAMT_RATE  from (
                  select g.member_name, d.STORE_NAME , case when c.SOD_TYPE=2 then '退货' else '销售' end as SALE_TYPE  ,c.SOD_NO,c.SOD_PAY_TIME,
                  b.LE_NAME,a.SOD_ITEM_QTY,a.SOD_ITEM_AMT  , e.SOD_INCOME_IAMT
                  from sod_item_rec a LEFT JOIN le_rec b on a.SOD_ITEM_LE_ID=b.LE_ID
                  LEFT JOIN sod_rec c on a.SOD_ITEM_SOD_ID=c.SOD_ID
                  LEFT JOIN store_rec d on a.SOD_ITEM_STORE_ID=d.store_id
                  LEFT JOIN sod_income_rec e on a.SOD_ITEM_ID=e.SOD_INCOME_SOD_ITEM_ID   and d.STORE_MEMBER_ID=e.SOD_INCOME_MEMBER_ID
                  LEFT JOIN member_rec f on f.member_id=d.store_member_id
                  LEFT JOIN member_rec g on g.member_id=f.member_parent_id %s
                  ) z %s %s
              ''' % (whereSql,groupSql,orderBy)
    cursorA.execute(totalSql)
    print(totalSql)
    row_all = cursorA.fetchall()
    cursorA.close()

    if len(row_all) > 65535:
        response = HttpResponse(content_type='text/html;charset=utf-8')
        response.write("<script>parent.alert('导出超出范围，请重新选择过滤条件！');window.location.href = document.referrer;</script>")
        return response
    else:
        _lst = []
        _lst.extend(row_all[:])
        _lst.insert(0, ['代理商名称','店铺名称','销售或退货','单号','支付时间','品名','销售数量','单价','销售总金额','利润总金额','利润率%'])

        book = xlwt.Workbook(encoding='utf8')
        sheet = book.add_sheet('untitled')

        for row, rowdata in enumerate(_lst):
            for col, val in enumerate(rowdata):
                sheet.write(row, col, val, style=xlwt.Style.default_style)

        response = HttpResponse(content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename=exp.xls'
        book.save(response)
        return response

def salesOrderExport_temp(request):
    #店铺名称
    seacheNameParam = request.GET.get('sodNameParam')
    #开始时间
    start = request.GET.get('start')
    #结束时间
    end = request.GET.get('end')
    cursorA = connections['slave'].cursor()
    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = " AND d.STORE_NAME like '%%%s%%' " % seacheNameParam

    start_sql=end_sql=""
    if start:
        start_sql = " and c.SOD_PAY_TIME >= '%s'" % datetime.datetime.strptime(start,'%Y-%m-%d')

    if end:
        end = end + " 23:59:59"
        end_sql = " and c.SOD_PAY_TIME <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    whereSql = " where (e.SOD_INCOME_TYPE=1 or e.SOD_INCOME_TYPE=3 ) and !(c.SOD_TYPE=2 and c.SOD_STAT!=2) "
    groupSql = " GROUP BY  z.STORE_NAME , z.SALE_TYPE ,z.SOD_NO,z.SOD_PAY_TIME, z.LE_NAME,z.SOD_ITEM_QTY,z.SOD_ITEM_AMT "
    orderBy = " order by z.SOD_PAY_TIME "
    whereSql = whereSql + likeSql + start_sql + end_sql
    totalSql = '''
                  select z.member_name,z.STORE_NAME,z.SALE_TYPE,z.SOD_NO,z.SOD_PAY_TIME,z.LE_NAME,z.SOD_ITEM_QTY, round(z.SOD_ITEM_AMT/z.SOD_ITEM_QTY,2) as PRICE,
                  z.SOD_ITEM_AMT, sum(z.SOD_INCOME_IAMT) as SOD_INCOME_IAMT_SUM ,
                  concat(cast(round(sum(z.SOD_INCOME_IAMT) /z.SOD_ITEM_AMT*100,2) as char),'%%') as INCOME_IAMT_RATE  from (
                  select g.member_name, d.STORE_NAME , case when c.SOD_TYPE=2 then '退货' else '销售' end as SALE_TYPE  ,c.SOD_NO,c.SOD_PAY_TIME,
                  b.LE_NAME,a.SOD_ITEM_QTY,a.SOD_ITEM_AMT  , e.SOD_INCOME_IAMT
                  from sod_item_rec a LEFT JOIN le_rec b on a.SOD_ITEM_LE_ID=b.LE_ID
                  LEFT JOIN sod_rec c on a.SOD_ITEM_SOD_ID=c.SOD_ID
                  LEFT JOIN store_rec d on a.SOD_ITEM_STORE_ID=d.store_id
                  LEFT JOIN sod_income_rec e on a.SOD_ITEM_ID=e.SOD_INCOME_SOD_ITEM_ID   and d.STORE_MEMBER_ID=e.SOD_INCOME_MEMBER_ID
                  LEFT JOIN member_rec f on f.member_id=d.store_member_id
                  LEFT JOIN member_rec g on g.member_id=f.member_parent_id %s
                  ) z %s %s
              ''' % (whereSql,groupSql,orderBy)
    cursorA.execute(totalSql)
    row_all = cursorA.fetchall()
    cursorA.close()

    _lst = []
    _lst.extend(row_all[:])
    _lst.insert(0, ['代理商名称','店铺名称','销售或退货','单号','支付时间','品名','销售数量','单价','销售总金额','利润总金额','利润率%'])

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for row, rowdata in enumerate(_lst):
        for col, val in enumerate(rowdata):
            sheet.write(row, col, val, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=exp.csv'
    book.save(response)
    return response

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result