# -*- coding: utf-8 -*-
# import codecs
import time

import json
from django.shortcuts import render_to_response, render
from django.http import HttpResponse, HttpResponseRedirect
from django.core.paginator import Paginator, InvalidPage, EmptyPage

from pyonion.models import User, SysRole, UserRole, Resource, RoleResource
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext
from django.db import connections
from decimal import *
import md5
from pyonion.auth.views import need_login

# 用户页面跳转
@need_login
def userList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("user/userList.html",dic)

# 用户信息列表展示
@need_login
def userListSeach(request):
    userCode =  request.GET.get('userNameParam')
    if userCode != None:
        user = getPaginator(User.objects.filter(user_code__icontains=userCode).order_by('-user_id'), request)
    else:
        user = getPaginator(User.objects.filter().order_by('-user_id'), request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (user.paginator.count, user.paginator.num_pages)]
    for users in user:
        items.append(
            '{"user_id":"%s","user_code":"%s","user_name":"%s","user_password":"%s","user_phone":"%s","user_email":"%s","user_remark":"%s","user_tel":"%s"},' % (
            users.user_id, users.user_code, users.user_name,users.user_password, users.user_phone, users.user_email, users.user_remark,
            users.user_tel))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#根据parentId查询对应的三级菜单
@csrf_exempt
def loadButtonByResourceId(request):
    typeParam = request.GET.get('type')
    userID = request.GET.get('userID')
    popup = request.GET.get('popup')
    if typeParam != None:
        tyepResource = Resource.objects.filter(parentId=typeParam)
    jsonItme = None
    desc = None
    if userID != None:
        mySql = "SELECT id,name,url,type,parentId FROM resource WHERE id IN(SELECT DISTINCT resource_id FROM sys_role_resource WHERE role_id in(SELECT USER_ROLE_SYS_ROLE_ID FROM user_role_rec WHERE USER_ROLE_USER_ID = " + userID +" )) "
        cursor = connections['slave'].cursor()
        cursor.execute(mySql)
        jsonItme = cursor.fetchall()
        desc = cursor.description
        cursor.close()
    itemType = ['[']
    if jsonItme == None:
        for tyepResources in tyepResource:
            itemType.append('{"id":"%s","name":"%s","url":"%s","imgPath":"%s"},' % (tyepResources.id, tyepResources.name,tyepResources.url,tyepResources.imgPath))
    else:
       for itemObj in jsonItme:
           i = 0
           for descObj in desc:
               if descObj[0] == 'type' and str(itemObj[i]) == popup:
                   for tyepResources in tyepResource:
                       if str(tyepResources.id) == str(itemObj[0]):
                           itemType.append('{"id":"%s","name":"%s","url":"%s","imgPath":"%s"},' % (tyepResources.id, tyepResources.name,tyepResources.url,tyepResources.imgPath))
                           break
               i = i+1
    itemType.append(']')
    jsonstr = ''.join(itemType)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

# 用户新增信息跳转页面
@need_login
def userAdd(request):
    return render_to_response("user/userAdd.html")


# 保存数据
@csrf_exempt
def userSave(request):
    # c={}
    # 新增用户表信息
    user_code = request.POST.get('userCode')
    user_name = request.POST.get('userName')
    user_password = request.POST.get('userPassWord')
    user_email = request.POST.get('userEmail')
    user_tel = request.POST.get('userTel')
    #user_phone = request.POST.get('userPhone')
    user_type = request.POST.get('userType')
    user_create_time = time.strftime('%Y-%m-%d %H:%M:%S')
    p= md5.new()
    p.update(user_password)
    user_password = p.hexdigest()
    st = User.objects.create(user_name=user_name, user_code=user_code, user_password=user_password,
                             user_email=user_email, user_tel=user_tel, user_type=user_type,
                             user_create_time=user_create_time)

    # 新增关联用户管理角色信息
    # 保存用户所被分配的角色，对应表：user_role_rec
    sts = User.objects.get(user_name=user_name)
    userids = sts.user_id
    roleIdArray = request.GET.get('roleId').split(',')
    user_role_create_time = time.strftime('%Y-%m-%d %H:%M:%S')
    for roleVal in roleIdArray:
        UserRole.objects.create(user_role_user=int(userids), user_role_sys_role=roleVal)
    return HttpResponseRedirect("/returnUserList")


# 新增用户成功后跳转页面
def returnUserList(request):
    return render(request, 'user/userList.html')

# 修改用户信息
@csrf_exempt
def userUpdate(request):
    dic = {'userId': request.GET.get('userId'), 'userCode': request.GET.get('userCode'),
           'userName': request.GET.get('userName'),'userPassWord':request.GET.get('userPassWord'), 'userTel': request.GET.get('userTel'),
           'userType': request.GET.get('userType'), 'userEmail': request.GET.get('userEmail')}
    return render_to_response("user/userUpdate.html", dic)

# 根据用户ID查询对应的权限
def userSeachId(request):
    userId = request.GET.get('userId')
    userRoler = UserRole.objects.filter(user_role_user=userId)
    itemRoleId = ['[']
    for userRolers in userRoler:
        itemRoleId.append('%s,' % (userRolers.user_role_sys_role))
    itemRoleId.append(']')
    jsonstr = ''.join(itemRoleId)
    jsonlen = len(jsonstr)
    if jsonlen > 2:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

@csrf_exempt
def testUrl(request):
    # c={}
    # 根据用户名查询用户信息对该用户信息进行修改(用户名必须唯一)
    user_name = request.GET.get('userName')
    user_id = request.GET.get("userId")
    sts = User.objects.get(user_id=int(user_id))
    # 修改用户表信息
    sts.user_code = request.GET.get('userCode')
    sts.user_name = user_name
    p= md5.new()
    p.update(request.GET.get('userPassWord'))
    user_password = p.hexdigest()
    sts.user_password = user_password
    sts.user_email = request.GET.get('userEmail')
    sts.user_tel = request.GET.get('userTel')
    #sts.user_phone = request.GET.get('userPhone')
    sts.user_type = request.GET.get('userType')
    sts.user_modify_time = time.strftime('%Y-%m-%d %H:%M:%S')
    sts.save()
    # st=User.objects.create(user_name=user_name,user_code=user_code,user_password=user_password,user_email=user_email,user_tel=user_tel,user_phone=user_phone,user_type=user_type,user_create_time=user_create_time)

    # 新增关联用户管理角色信息，存用户所被分配的角色，对应表：user_role_rec
    userids = sts.user_id
    # 查询用户已经拥有的权限
    userRolers = UserRole.objects.filter(user_role_user=userids)
    roleIdArray = request.GET.get('roleId').split(',')
    user_role_create_time = time.strftime('%Y-%m-%d %H:%M:%S')
    # 首先判断有没有去掉用户原有的权限
    for userRoler in userRolers:  # 用户已拥有的权限
        isDelete = False
        for roleVal in roleIdArray:  # 修改后的用户权限
            if userRoler.user_role_sys_role == roleVal:  # 判断权限是否同一个
                isDelete = True
                break
        if isDelete == False:  # 删除用户变更后没有该权限
            UserRole.objects.filter(user_role_id=userRoler.user_role_id).delete()

    # 将修改后的权限与已经有的权限进行对比，添加没有的，删除修改掉的
    for roleVal in roleIdArray:  # 修改后的用户权限
        isExist = False  # 标识用户权限是否存在
        for userRoler in userRolers:  # 用户已拥有的权限
            if userRoler.user_role_sys_role == roleVal:  # 判断权限是否同一个
                isExist = True
                break
        if isExist == False:  # 判断权限是否存在，存在则不变，不存在则新分配，
            UserRole.objects.create(user_role_user=int(userids), user_role_sys_role=roleVal)
    return HttpResponseRedirect("/returnUserList")

# 查询用户角色信息
@need_login
def userRoleSeach(request):
    sysRole = SysRole.objects.all().order_by('sys_role_id')
    itemRole = ['[']
    for sysRoles in sysRole:
        itemRole.append('{"sys_role_id":"%s","sys_role_name":"%s"},' % (sysRoles.sys_role_id, sysRoles.sys_role_name))
    itemRole.append(']')
    jsonstr = ''.join(itemRole)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

# 角色列表跳转页面
@need_login
def roleList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("user/roleList.html",dic)

# 角色信息列表展示
@csrf_exempt
@need_login
def roleListSeach(request):
    roleName = request.GET.get('roleNameParam')
    if roleName != None:
        role = getPaginator(SysRole.objects.filter(sys_role_name__icontains=roleName).order_by('-sys_role_id'), request)
    else:
        role = getPaginator(SysRole.objects.filter().order_by('-sys_role_id'), request)
    itemRole = ['{"total":%d,"totalPage":%d,"rows":[' % (role.paginator.count, role.paginator.num_pages)]
    for roles in role:
        itemRole.append(
            '{"sys_role_id":"%s","sys_role_code":"%s","sys_role_name":"%s","sys_role_remark":"%s","sys_role_create_user_id":"%s","sys_role_create_time":"%s","sys_role_modify_user_id":"%s","sys_role_modify_time":"%s"},' % (
            roles.sys_role_id, roles.sys_role_code, roles.sys_role_name, roles.sys_role_remark,
            roles.sys_role_create_user_id, roles.sys_role_create_time, roles.sys_role_modify_user_id,
            roles.sys_role_modify_time))
    itemRole.append(']}')
    jsonstr = ''.join(itemRole)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

# 用户新增信息跳转页面
@need_login
def roleAdd(request):
    return render_to_response("user/roleAdd.html")

# 新增角色
@csrf_exempt
def roleSave(request):
    # c={}
    # 新增角色表信息
    sysCode = request.POST.get('sysCode')
    sysName = request.POST.get('sysName')
    sysRemark = request.POST.get('sysRemark')
    sys = SysRole()
    sys.sys_role_code = sysCode
    sys.sys_role_name = sysName
    sys.sys_role_remark = sysRemark
    sys.save()
    return render_to_response("user/roleList.html")

# 新增角色成功后跳转到角色列表
@csrf_exempt
@need_login
def reRoleList(request):
    return render_to_response(request, 'user/roleList.html')

# 修改角色信息跳转页面
@csrf_exempt
@need_login
def roleUpdate(request):
    dic = {'sysRoleId': request.GET.get('sysRoleId'), 'sysRoleCode': request.GET.get('sysRoleCode'),
           'sysRoleName': request.GET.get('sysRoleName'), 'sysRoleRemark': request.GET.get('sysRoleRemark')}
    return render_to_response("user/roleUpdate.html", dic)

# 修改角色信息
@csrf_exempt
def roleInsert(request):
    # c={}
    # 根据角色名查询角色信息对该角色信息进行修改(角色名必须唯一)
    sys_role_name = request.GET.get('sysRoleName')
    sys_role_id = request.GET.get('sysRoleId')
    sysRe = SysRole.objects.get(sys_role_id=int(sys_role_id))
    # 修改用户表信息
    sysRe.sys_role_code = request.GET.get('sysRoleCode')
    sysRe.sys_role_name = sys_role_name
    sysRe.sys_role_remark = request.GET.get('sysRoleRemark')
    sysRe.save()
    return HttpResponseRedirect("/returnUserList")

@csrf_exempt
@need_login
def userDelete(request):
    ids = request.GET["userIds"]
    #先删除用户关联表UserRole
    UserRole.objects.filter(user_role_user=ids).delete()
    #UserRole.objects.filter(user_role_user__user_id=ids).delete()
    #删除用户信息
    User.objects.filter(user_id=ids).delete()
    return render_to_response('user/userList.html', context_instance=RequestContext(request))

# 授权角色跳转
@csrf_exempt
@need_login
def authorizationList(request):
    dic = {'sysRoleId': request.GET.get('sysRoleId')}
    #return render_to_response("user/userAuthorization.html", dic)
    return render_to_response("user/userAuthors.html", dic)

# 查询一级菜单角色信息
def roleSeacha(request):
    resourceRole = Resource.objects.filter(type=1).order_by('id')
    itemRoleR = ['[']
    for resourceRoles in resourceRole:
        itemRoleR.append('{"id":"%s","name":"%s","url":"%s","type":"%s"},' % (
        resourceRoles.id, resourceRoles.name, resourceRoles.url, resourceRoles.type))
    itemRoleR.append(']')
    jsonstr = ''.join(itemRoleR)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

# 查询二级菜单角色信息
def roleSeachb(request):
    parentIdVal = request.GET.get("parendId")
    resourceRole = Resource.objects.filter(parentId__in=parentIdVal.split(",")).order_by('id')
    itemRoleR = ['[']
    for resourceRoles in resourceRole:
        itemRoleR.append('{"id":"%s","name":"%s","url":"%s","type":"%s"},' % (
        resourceRoles.id, resourceRoles.name, resourceRoles.url, resourceRoles.type))
    itemRoleR.append(']')
    jsonstr = ''.join(itemRoleR)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

# 查询三级菜单角色信息
def roleSeachc(request):
    parentIdVal = request.GET.get("parendId")
    resourceRole = Resource.objects.filter(parentId__in=parentIdVal.split(",")).order_by('id')
    itemRoleR = ['[']
    for resourceRoles in resourceRole:
        itemRoleR.append('{"id":"%s","name":"%s","url":"%s","type":"%s"},' % (
        resourceRoles.id, resourceRoles.name, resourceRoles.url, resourceRoles.type))
    itemRoleR.append(']')
    jsonstr = ''.join(itemRoleR)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

# 保存授权角色
@csrf_exempt
def roleAuthorSaveqq(request):
    # c={}
    # 保存授权角色表信息
    roleId = request.POST.get('sysRoleId')
    resourceIdArray = request.GET.get('resourceId').split(',')

    # 根据角色ID查询角色已经拥有的资源
    roleResources = RoleResource.objects.filter(role_id=roleId)
    resourceIdArray = request.GET.get('resourceId').split(',')
    user_role_create_time = time.strftime('%Y-%m-%d %H:%M:%S')
    # 首先判断有没有去掉用户原有的权限
    for roleResource in roleResources:  # 角色已拥有的资源
        isDelete = False
        for resourceId in resourceIdArray:  # 修改后的角色资源
            if roleResource.resource_id == resourceId:  # 判断权限是否同一个
                isDelete = True
                break
            if isDelete == False:  # 删除用户变更后没有该权限
                RoleResource.objects.filter(id=roleResource.id).delete()
    # 将修改后的资源与已经有的资源进行对比，添加没有的，删除修改掉的
    for resourceId in resourceIdArray:  # 修改后的角色资源
        isExist = False  # 标识角色资源是否存在
        for roleResource in roleResources:  # 角色已拥有的资源
            if roleResource.resource_id == resourceId:
                isExist = True  # 判断资源是否同一个
                break
        if isExist == False:  # 判断资源是否存在，存在则不变，不存在则新分配，
            roleResourceObj = RoleResource()
            roleResourceObj.role_id = roleId
            roleResourceObj.resource_id = resourceId
            roleResourceObj.save()
    return HttpResponseRedirect("/returnUserList")

def saveRoleResourceInfo(roleId, resourceIdStr):
     # c={}
    # 保存授权角色表信息
    #roleId = request.POST.get('sysRoleId')
    #resourceIdArray = request.GET.get('resourceId').split(',')

    # 根据角色ID查询角色已经拥有的资源
    roleResources = RoleResource.objects.filter(role_id=roleId)
    resourceIdArray = resourceIdStr.split(',')
    user_role_create_time = time.strftime('%Y-%m-%d %H:%M:%S')
    # 首先判断有没有去掉用户原有的权限
    for roleResource in roleResources:  # 角色已拥有的资源
        isDelete = False
        for resourceId in resourceIdArray:  # 修改后的角色资源
            if roleResource.resource_id == resourceId:  # 判断权限是否同一个
                isDelete = True
                break
            if isDelete == False:  # 删除用户变更后没有该权限
                RoleResource.objects.filter(id=roleResource.id).delete()
    # 将修改后的资源与已经有的资源进行对比，添加没有的，删除修改掉的
    for resourceId in resourceIdArray:  # 修改后的角色资源
        isExist = False  # 标识角色资源是否存在
        for roleResource in roleResources:  # 角色已拥有的资源
            if roleResource.resource_id == resourceId:
                isExist = True  # 判断资源是否同一个
                break
        if isExist == False:  # 判断资源是否存在，存在则不变，不存在则新分配，
            roleResourceObj = RoleResource()
            roleResourceObj.role_id = roleId
            roleResourceObj.resource_id = resourceId
            roleResourceObj.create_time =user_role_create_time
            roleResourceObj.save()

@csrf_exempt
def roleAuthorSave(request):
    # c={}
    # 保存授权角色表信息
    sysRoleId = request.GET.get('sysRoleId')
    resourceId = request.GET.get('resourceId')
    #保存三个下拉宽的内容
    saveRoleResourceInfo(sysRoleId,resourceId)
    return HttpResponseRedirect("/returnUserList")

# 根据角色ID查询对应的资源信息
def seachResourceIdByRoleId(request):
    sysRoleId = request.GET.get('sysRoleId')
    #typeIndex = request.GET.get('type')
    roleResource = RoleResource.objects.filter(role_id=sysRoleId)
    itemRoleId = ['[']
    for roleResources in roleResource:
        itemRoleId.append('%s,' % (roleResources.resource_id))
    itemRoleId.append(']')
    jsonstr = ''.join(itemRoleId)
    jsonlen = len(jsonstr)
    if jsonlen > 2:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

#查询所有用户权限#(传入登录系统用户ID)s#
@csrf_exempt
def seachRoleUserId(request):
    seachUserId = request.GET.get('seachUserId')
    mySql = "SELECT id,name,url,type,parentId FROM resource WHERE id IN(SELECT DISTINCT resource_id FROM sys_role_resource WHERE role_id in(SELECT USER_ROLE_SYS_ROLE_ID FROM user_role_rec WHERE USER_ROLE_USER_ID = " + seachUserId +" )) ORDER BY id "
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    jsonItme = cursor.fetchall()
    desc = cursor.description
    cursor.close()

    items = ['{"datas":']
    li = []
    for item in jsonItme:
        repoerItem = {}
        i = 0
        for de in desc:
            if isinstance(item[i], Decimal):
                repoerItem[de[0]] = str(item[i])
            else:
                repoerItem[de[0]] = item[i]
            i = i + 1
        li.append(repoerItem)
    items.append(json.dumps(list(li)))
    items.append('}')
    return HttpResponse(items, content_type="application/json")

# 查询二级菜单角色信息
def loadResource(request):
    #一次性查询出所有资源数据
    resourceRoles = Resource.objects.all().order_by('type')
    itemRoleR = ['[']
    #循环处理一级菜单
    for resourceRoleOne  in resourceRoles:
        if resourceRoleOne.type == "1":
            #循环处理二级菜单
            twoResourceItem = ['[']
            for resourceRoleTwo  in resourceRoles:
                #筛选属于当前一级菜单的二级菜单项
                if resourceRoleTwo.type == "2" and resourceRoleTwo.parentId == resourceRoleOne.id:
                    #循环处理三级菜单
                    threeResourceItem = ['[']
                    for resourceRoleThree  in resourceRoles:
                        #筛选属于当前二级菜单的三级菜单项
                        if (resourceRoleThree.type == "3" or resourceRoleThree.type == "4") and resourceRoleThree.parentId == resourceRoleTwo.id:
                            threeResourceItem.append('{"id":"%s","text":"%s"},' % (resourceRoleThree.id, resourceRoleThree.name))
                    threeResourceItem.append(']')
                    threeJsonStr = ''.join(threeResourceItem)
                    threeLen = len(threeJsonStr)
                    #默认没有tree子节点
                    twoStr = '{"id":"%s","text":"%s"},'% (resourceRoleTwo.id, resourceRoleTwo.name)
                    if threeLen > 2:
                        #有tree子节点
                        threeJsonStr = threeJsonStr[:threeLen - 2] + threeJsonStr[threeLen - 1:]
                        twoStr = '{"id":"%s","text":"%s",'% (resourceRoleTwo.id, resourceRoleTwo.name)+'"children":'+threeJsonStr+',"state":"closed"},'
                    twoResourceItem.append(twoStr)
            twoResourceItem.append(']')
            twoJsonStr = ''.join(twoResourceItem)
            twoLen = len(twoJsonStr)
            oneStr = '{"id":"%s","text":"%s"},'% (resourceRoleOne.id, resourceRoleOne.name)
            if twoLen > 2:
                twoJsonStr = twoJsonStr[:twoLen - 2] + twoJsonStr[twoLen - 1:]
                oneStr = '{"id":"%s","text":"%s",'% (resourceRoleOne.id, resourceRoleOne.name)+'"children":'+twoJsonStr+'},'
            itemRoleR.append(oneStr)
    itemRoleR.append(']')
    jsonstr = ''.join(itemRoleR)
    jsonlen = len(jsonstr)
    if jsonlen > 2:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

#删除角色信息
@csrf_exempt
@need_login
def roleDelete(request):
    ids = request.GET["sysRoleId"]
    #先删除角色管理表RoleResource
    RoleResource.objects.filter(role_id=ids).delete()
    #删除角色表信息
    SysRole.objects.filter(sys_role_id=ids).delete()
    return render_to_response('user/roleList.html',context_instance=RequestContext(request))

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result
