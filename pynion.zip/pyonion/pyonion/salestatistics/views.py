# -*- coding: utf-8 -*-
#import codecs
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )

import xlwt
import json
from pyonion.auth.views import need_login

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from pyonion.models import SodItem,Le
from django.core.serializers.json import DjangoJSONEncoder
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django.db import connections
from decimal import *
import datetime
from django.db.models import Sum
import csv,codecs

# 订单查询页面跳转 New
@need_login
def saleStatisticsList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("salestatistics/saleStatisticsList.html",dic)

# 订单查询列表页面跳转 New
def saleStatisticsJsonaa(request):
    sodNameParam = request.GET.get('sodNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    # 查询商品销售过的订单
    queryset = SodItem.objects.filter(sod__sod_type=1)
    # 查询商品退款过的订单
    querysod = SodItem.objects.filter(sod__sod_type=2)
    le_list=Le.objects.all()
    #querySum = SodItem.objects.filter(le__in=le_list).order_by('sum').values('le__le_id','le__le_code','le__le_name').annotate(sum=Sum('sod_item_qty'))
    querySum = SodItem.objects.values('le__le_id','le__le_code','le__le_name').annotate(sum=Sum('sod_item_qty'))

    if sodNameParam:
        queryset = queryset.filter(le__le_name__icontains=sodNameParam)

    if start and end:
        start_time = datetime.datetime.strptime(start, '%Y-%m-%d')
        end_time = datetime.datetime.strptime(end, '%Y-%m-%d')
        queryset = queryset.filter(sod_item_create_time__range=(start_time, end_time))
    elif start and not end:
        start_time = datetime.datetime.strptime(start, '%Y-%m-%d')
        queryset = queryset.filter(sod_item_create_time__gte=start_time)
    elif not start and end:
        end_time = datetime.datetime.strptime(end, '%Y-%m-%d')
        queryset = queryset.filter(sod_item_create_time__lte=end_time)

    sodItems = getPaginator(queryset, request)
    sodItems2 = getPaginator(querysod, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (sodItems.paginator.count, sodItems.paginator.num_pages)]
    a = 0
    qyw = 0
    for sodItem in sodItems:
        # 获取商品销售的id
        leId = sodItem.le.le_id
        # 将退款的数量赋值
        for sodItem2s in sodItems2:
            # 比较销售订单id与退款的id是否有相同
            if (leId == sodItem2s.le.le_id):
                # 销售订单-退款订单
                if sodItem2s.sod_item_qty:
                    qyw = querySum[a]['sum'] - sodItem2s.sod_item_qty
                else:
                    qyw = querySum[a]['sum']
        items.append(
                '{"le_name":"%s","le_code":"%s","sod_stat":"%s","sod_item_qty":"%s"},' % (
                    sodItem.le.le_name, sodItem.le.le_code, sodItem.sod.sod_stat, qyw))
        a += 1
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if sodItems.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

@csrf_exempt
def saleStatisticsJsons(request):
    seacheNameParam = request.GET.get('sodNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    pageSzie = request.GET.get('size')
    pageNo = request.GET.get('pageNo')
    cursorA = connections['slave'].cursor()
    totalSql = "SELECT le_name,le_code,(round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END * SOD_ITEM_PRICE ))) as leprice,SOD_ITEM_LE_ID,round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END)) as sod_item_qty ,LE_SPRICE1 from sod_item_rec LEFT JOIN le_rec on LE_ID = SOD_ITEM_LE_ID LEFT JOIN sod_rec on SOD_ID = SOD_ITEM_SOD_ID "
    whereSql = " WHERE "
    likeSql = ""
    totalGroupSql = " GROUP BY LE_ID"
    if start == None:
        whereSql = whereSql + " DATE(sod_item_create_time) <= '%s' " % (end)
    else:
        whereSql = whereSql + " DATE(sod_item_create_time) >= '%s' AND DATE(sod_item_create_time) <= '%s'" % (start, end)
    if seacheNameParam != None:
        likeSql = " AND le_name like '%%%s%%' " % (seacheNameParam)
    whereSql = whereSql + " and SOD_STAT >=2 ";
    totalSql = totalSql + whereSql + likeSql + totalGroupSql
    cursorA.execute(totalSql)
    jsonItme = cursorA.fetchall()
    dataTotal = str(len(jsonItme))
    cursorA.close()

    startLimitNum = int(pageSzie) * (int(pageNo) - 1)
    mySql = "SELECT le_name,le_code,(round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END * SOD_ITEM_PRICE ))) as leprice,SOD_ITEM_LE_ID,round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END)) as sod_item_qty ,LE_SPRICE from sod_item_rec LEFT JOIN le_rec on LE_ID = SOD_ITEM_LE_ID LEFT JOIN sod_rec on SOD_ID = SOD_ITEM_SOD_ID "
    groupSql = "GROUP BY LE_ID"
    whereSql = whereSql + " and SOD_STAT >=2 "
    if seacheNameParam == None:
        mySql = mySql + whereSql + groupSql
    else:
        likeSql = " AND le_name like '%%%s%%' " % (seacheNameParam)
        mySql = mySql + whereSql + likeSql + groupSql
    temp = " limit %d,%d" % (startLimitNum, int(pageSzie))
    cursor = connections['slave'].cursor()
    cursor.execute(mySql + temp)
    jsonItme = cursor.fetchall()
    desc = cursor.description
    cursor.close()

    totalPage = int(dataTotal) / int(pageSzie)
    if (int(dataTotal) % int(pageSzie)) > 0:
        totalPage = totalPage + 1
    items = ['{"total":%s,"totalPage":%s,"rows":' % (dataTotal, str(totalPage))]
    li = []
    for item in jsonItme:
        repoerItem = {}
        i = 0
        for de in desc:
            if isinstance(item[i], Decimal):
                repoerItem[de[0]] = str(item[i])
            else:
                if(i == 4):
                    repoerItem[de[0]] = str(item[i].year)+"-"+str(item[i].month)+"-"+str(item[i].day)
                else:
                    repoerItem[de[0]] = item[i]
            i = i + 1
        li.append(repoerItem)
    items.append(json.dumps(list(li)))
    items.append('}')
    return HttpResponse(items, content_type="application/json")

@need_login
@csrf_exempt
def saleJson(request):
    seacheNameParam = request.GET.get('sodNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = " AND le_name like '%%%s%%' " % seacheNameParam

    start_sql=end_sql=""
    if start:
        start_sql = " and sod_item_create_time >= '%s'" % datetime.datetime.strptime(start,'%Y-%m-%d')

    if end:
        end = end + " 23:59:59"
        end_sql = " and sod_item_create_time <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    whereSql = " WHERE SOD_TYPE = 1 and SOD_STAT >=2 "
    groupSql = " GROUP BY LE_ID "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = '''
              SELECT le_name,le_code,(round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT
              WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END * SOD_ITEM_PRICE ))) as leprice,SOD_ITEM_LE_ID,
              round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END)) as sod_item_qty ,
              LE_SPRICE from sod_item_rec LEFT JOIN le_rec on LE_ID = SOD_ITEM_LE_ID LEFT JOIN sod_rec on SOD_ID = SOD_ITEM_SOD_ID %s %s
            ''' % (whereSql, groupSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#导出商品
@need_login
@csrf_exempt
def commodityExportTemp(request):
    seacheNameParam = request.GET.get('sodNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    cursorA = connections['slave'].cursor()
    totalSql = "SELECT le_name,le_code,round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END)) as sod_item_qty,(round(le_sprice1)*round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END))) as leprice from sod_item_rec LEFT JOIN le_rec on LE_ID = SOD_ITEM_LE_ID LEFT JOIN sod_rec on SOD_ID = SOD_ITEM_SOD_ID "
    whereSql = " WHERE "
    likeSql = ""
    totalGroupSql = " GROUP BY LE_ID"
    if start == None:
        whereSql = whereSql + " DATE(sod_item_create_time) <= '%s' " % (end)
    else:
        whereSql = whereSql + " DATE(sod_item_create_time) >= '%s' AND DATE(sod_item_create_time) <= '%s'" % (start, end)
    if seacheNameParam != None:
        likeSql = " AND le_name like '%%%s%%' " % (seacheNameParam)
    whereSql = whereSql + " and SOD_STAT >=2 ";
    totalSql = totalSql + whereSql + likeSql + totalGroupSql
    cursorA.execute(totalSql)
    row_all = cursorA.fetchall()
    cursorA.close()

    _lst = []
    _lst.extend(row_all[:])
    _lst.insert(0, ['商品名称', '商品编码', '商品销量','销售总量'])

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for row, rowdata in enumerate(_lst):
        for col, val in enumerate(rowdata):
            sheet.write(row, col, val, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=example.xls'
    book.save(response)
    return response

#导出商品
@need_login
@csrf_exempt
def commodityExport(request):
    seacheNameParam = request.GET.get('sodNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = " AND le_name like '%%%s%%' " % seacheNameParam

    start_sql=end_sql=""
    if start:
        start_sql = " and sod_item_create_time >= '%s'" % datetime.datetime.strptime(start,'%Y-%m-%d')

    if end:
        end = end + " 23:59:59"
        end_sql = " and sod_item_create_time <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    whereSql = " WHERE SOD_TYPE = 1 and SOD_STAT >=2 "
    groupSql = " GROUP BY LE_ID  "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = '''
              SELECT le_name,le_code,(round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT
              WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END * SOD_ITEM_PRICE ))) as leprice,SOD_ITEM_LE_ID,
              round(sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE -1 END * CASE SOD_ITEM_RC_AMT WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END)) as sod_item_qty ,
              LE_SPRICE from sod_item_rec LEFT JOIN le_rec on LE_ID = SOD_ITEM_LE_ID LEFT JOIN sod_rec on SOD_ID = SOD_ITEM_SOD_ID    %s %s
            ''' % (whereSql, groupSql)
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    results = cursor.fetchall()
    cursor.close()
    response = HttpResponse(content_type='text/csv')
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = 'attachment; filename=商品总额导出.csv'
    data = []
    writer = csv.writer(response)
    writer.writerow(['商品名称','商品编码','商品销量','销售总额','当前销售价'])
    for row in results:
        datas =(row[0],row[1],row[4],row[2],row[5])
        data.append(datas)
    writer.writerows(data)
    return response

#商品类别统计跳转
@need_login
@csrf_exempt
def productStatisticsList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("salestatistics/productStatisticsList.html",dic)

#计算库存
def inventory(leId):
    mySql = "SELECT le_rec.LE_ID,SOD_ITEM_CREATE_TIME, round( sum(CASE SOD_TYPE WHEN 1 THEN 1 ELSE - 1 END * CASE SOD_ITEM_RC_AMT WHEN NULL THEN 0 ELSE SOD_ITEM_QTY END ) ) AS sod_item_qty FROM sod_item_rec LEFT JOIN le_rec ON LE_ID = SOD_ITEM_LE_ID LEFT JOIN sod_rec ON SOD_ID = SOD_ITEM_SOD_ID  WHERE 1=1 AND DATE(now())-DATE(sod_item_create_time) <=7 AND SOD_STAT >= 2 AND SOD_STAT >= 2 AND LE_ID='"+ leId +"' GROUP BY LE_ID"
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    jsonItme = cursor.fetchall()
    cursor.close()
    valAll = 0
    if jsonItme:
        #list = [32, 12, 32, 12, 4, 23, 43, 54, 83, 13]
        #那么list[-1]的值就是13了
        valAll = jsonItme[0][2]
    return valAll

def productStatisticsJson(request):
    productName = request.GET.get('productName')
    setchoose = request.GET.get('setchoose')
    leState = request.GET.get('leState')
    queryset = Le.objects.all().order_by('-le_id')
    if productName:
        queryset = queryset.filter(le_name__icontains=productName)

    if setchoose:
        queryset = queryset.filter(product_type=setchoose)

    if leState:
        queryset = queryset.filter(le_stat=leState)

    les = getPaginator(queryset, request)
    items = ['{"total":%d,"totalPage":%d,"rows":[' % (les.paginator.count, les.paginator.num_pages)]
    for le in les:
        #计算库存
        leId = le.le_id
        inventoryAll = inventory(str(leId))
        #周库销比的计算方式为=“当天总库存/最近7天销售量”。
        le_qty_rate = 0.0
        if inventoryAll != 0:
            le_qty_rate = le.le_qty / Decimal(inventoryAll)

        try:
            leBrand = le.le_brand.brand_name
        except:
            leBrand =""
        items.append(
            '{"le_id":"%s","le_code":"%s","le_name":"%s","product_type":"%s","le_barcode":"%s","le_brand":"%s","le_country":"%s","let_type":"%s","le_qty_rates":"%.2f","le_stat":"%s","le_qty":"%s"},' % (
               le.le_id,le.le_code, le.le_name,le.product_type,le.le_barcode,leBrand,le.le_country.country_name,le.le_let.let_name,le_qty_rate,le.le_stat,le.le_qty))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if les.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr, content_type="application/json")

#商品类别编辑
@csrf_exempt
def productUpdateList(request):
    dic = {'id': request.GET.get('id'),'leId':request.GET.get('leId'),'leCode':request.GET.get('leCode'),'leName':request.GET.get('leName')}
    return render_to_response("salestatistics/productUpdate.html",dic)

# 修改资源信息
@csrf_exempt
def productUpdateJson(request):
    # c={}
    # 根据资源名查询资源信息对该资源信息进行修改()
    leId = request.GET.get('leId')
    productType = request.GET.get('productType')
    leRe = Le.objects.get(le_id=int(leId))
    leRe.product_type=productType
    leRe.save()
    return render_to_response("salestatistics/productStatisticsList.html")

#导出代理商明细
def productExportNew(request):
    productName = request.GET.get('productName')
    productBand = request.GET.get('productBand')
    cursorA = connections['slave'].cursor()
    mySql = "select t1.LE_CODE,t1.LE_NAME,t2.BRAND_NAME,case t1.PRODUCT_TYPE WHEN  '1' then '在线-常规' WHEN '2' then '在线-售完为止' WHEN '3' then '下架' WHEN '4' then '停止售卖' else  '--'  END  from le_rec t1 LEFT JOIN brand_rec t2 ON t1.LE_BRAND_ID=t2.BRAND_ID "
    whereSql = " WHERE "
    totalGroupSql = " GROUP BY t1.LE_ID "

    if productName == None and productBand == None:
	    totalSql = mySql
    else:
        if productName != None:
            likeSql = " t1.le_name like '%%%s%%' " % (productName)
            totalSql = mySql + whereSql + likeSql
        if productBand != None:
            if productName != None:
                likeSql = " AND t2.BRAND_NAME like '%%%s%%' " % (productBand)
                totalSql = totalSql  + likeSql
            else:
                likeSql = " t2.BRAND_NAME like '%%%s%%' " % (productBand)
                totalSql = mySql + whereSql + likeSql
    cursorA.execute(totalSql+totalGroupSql)
    row_all = cursorA.fetchall()
    cursorA.close()

    _lst = []
    _lst.extend(row_all[:])
    _lst.insert(0, ['条形码','商品名称','商品品牌','商品状态'])

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for row, rowdata in enumerate(_lst):
        for col, val in enumerate(rowdata):
            sheet.write(row, col, val, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=example.xls'
    book.save(response)
    return response

@need_login
@csrf_exempt
def productExport(request):
    productName = request.GET.get('productName')
    leState = request.GET.get('leState')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if productName:
        likeSql = " AND x.le_name like '%%%s%%' " % productName

    if leState:
        likeSql = " AND x.le_stat like '%%%s%%' " % leState

    whereSql = " WHERE 1=1 "
    whereSql = whereSql + likeSql
    mySql = u'''
              select x.le_code,x.le_barcode,x.le_name,y.`一级品类` as yi ,y.`二级品类` as er,y.`三级品类` as san,x.le_stat,x.le_sprice1,x.le_sprice,x.le_cost,x.le_qty from le_rec x LEFT JOIN
                (
                select a1.let_id 一级ID,a1.LET_NAME 一级品类,a2.let_id 二级ID,a2.LET_NAME 二级品类 ,a3.let_id 三级ID,a3.LET_NAME 三级品类 from (
                select a.let_id,a.LET_NAME from let_rec a where a.LET_ID1 is null and a.let_id!=92) a1 LEFT JOIN
                (select a.let_id,a.LET_PARENT_ID,a.LET_NAME from let_rec a where a.LET_PARENT_ID in(select a.let_id from let_rec a where a.LET_ID1 is null and a.let_id!=92
                ) ) a2 on a1.let_id=a2.LET_PARENT_ID
                LEFT JOIN(select a.let_id,a.LET_PARENT_ID,a.LET_NAME from let_rec a where a.LET_PARENT_ID in(select a.let_id from let_rec a where a.LET_PARENT_ID in
                   (select a.let_id from let_rec a where a.LET_ID1 is null and a.let_id!=92))) a3
                on a2.let_id=a3.LET_PARENT_ID
                ) y on x.LE_LET_ID=y.三级ID    %s
            ''' % (whereSql)
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    results = cursor.fetchall()
    cursor.close()
    response = HttpResponse(content_type='text/csv')
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = 'attachment; filename=商品类别导出.csv'
    data = []
    writer = csv.writer(response)
    writer.writerow(['货号','条码','品名','第一级类别','第二级类别','第三级类别','上架状态','市场价','售价','供货价','库存'])
    p_dicts = {1: '上架', 2: '下架'}
    for row in results:
        le_stat = p_dicts.get(row[6], '--')
        datas =(row[0],row[1],row[2],row[3],row[4],row[5],le_stat,row[7],row[8],row[9],row[10])
        data.append(datas)
    writer.writerows(data)
    return response

@need_login
@csrf_exempt
def productExportTemp(request):
    productName = request.GET.get('productName')
    prodcutType = request.GET.get('setchoose')
    leState = request.GET.get('leState')

    args = {}
    if productName:
        args['le_name__contains'] = productName
    if prodcutType:
        args['product_type'] = int(prodcutType)
    if leState:
        args['le_stat'] = int(leState)

    if args:
        les = Le.objects.filter(**args)
    else:
        les = Le.objects.all()

    title = ['条形码', '商品名称', '商品状态','上/下架状态','商品库存']

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for col, val in enumerate(title):
        sheet.write(0, col, val, style=xlwt.Style.default_style)

    p_dict = {1: '在线-常规', 2: '在线-售完为止', 3: '下架', 4: '停止售卖'}
    p_dicts = {1: '上架', 2: '下架'}

    for row, le in enumerate(les):
        product_type = p_dict.get(le.product_type, '--')
        le_stat = p_dicts.get(le.le_stat, '--')
        sheet.write(row + 1, 0, le.le_code, style=xlwt.Style.default_style)
        sheet.write(row + 1, 1, le.le_name, style=xlwt.Style.default_style)
        sheet.write(row + 1, 2, product_type, style=xlwt.Style.default_style)
        sheet.write(row + 1, 3, le_stat, style=xlwt.Style.default_style)
        sheet.write(row + 1, 4, le.le_qty, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=example.xls'
    book.save(response)
    return response


def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    pageNo = request.GET.get('pageNo')
    try:
        result = paginator.page(pageNo)
    except (EmptyPage, InvalidPage):
        result = paginator.page("1")
    return result
