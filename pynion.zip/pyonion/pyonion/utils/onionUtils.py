# -*- coding: utf-8 -*-

import urllib2
import urllib
import md5
import sys
type = sys.getfilesystemencoding()

headers = {'Content-type': 'application/x-www-form-urlencoded'}
#URL = "http://120.24.73.174/channel/"
URL = "http://172.16.10.229:8080/msonion-web/channel/"
compcode="yangcong";

#下单接口
#thirdNo第三方原始单号，不能重复,name 收货人姓名 proviceId 收货省份 cityId 收货城市 areaId 收货县区 address 收货地址
#phone 收货电话 cid 收货人身份证 goodsCode 商品货号 num 数量 name 姓名 partnerId 账号 key key (使用MD5加密)
def createOrder(i):
    p = md5.new()
    p.update(i['key'])
    key = p.hexdigest()
    #order1="%s"%i['order']
    body = {"order":i['order'],"partnerId":i['partentid'],"key":key}
    data = urllib.urlencode(body)
    full_url = URL+'createOrder'
    req = urllib2.Request(url = full_url,data=data,headers=headers)
    res_data = urllib2.urlopen(req).read()
    print res_data.decode("UTF-8").encode(type)
    return res_data


'''def createOrder(i):
    p = md5.new()
    p.update(i['passWord'])
    key = p.hexdigest()
    #full_url = URL+'createOrder'+"?order=%s"%json.dumps(i['order']) + "&passWord=%s"%key+"&partnerId=%s"%i['partentid']
    req = requests.post('http://120.25.85.67:8080/channel/createOrder/',
                 data = key)
    print req.status_code
    #req = requests.post(url = full_url,headers=headers)
    res_data = urllib2.urlopen(req)
    res = res_data.read()
    print(res)
    return res'''




