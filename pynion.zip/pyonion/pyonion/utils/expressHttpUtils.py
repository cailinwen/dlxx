# -*- coding: utf-8 -*-

import urllib2
import md5

headers = {'Content-type': 'application/x-www-form-urlencoded'}
URL = "http://www.kuaidi100.com/autonumber/auto"
compcode="yangcong";

#物流信息查询
def queryExpressNo(expNo):
    full_url = URL+'?num='+expNo
    req = urllib2.Request(url = full_url,headers=headers)
    res_data = urllib2.urlopen(req)
    res = res_data.read()
    return res