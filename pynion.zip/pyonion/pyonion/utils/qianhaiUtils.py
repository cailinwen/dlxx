# -*- coding: utf-8 -*-

import urllib2
import md5

headers = {'Content-type': 'application/x-www-form-urlencoded'}
URL = "http://120.25.85.67:8080/yc_intf/"
compcode="yangcong";

#订单查询
def queryOrder(orderSn):
    billno = orderSn
    p = md5.new()
    p.update("YD"+compcode+orderSn)
    key = p.hexdigest()
    full_url = URL+'soorderquery.action?compcode='+compcode+"&key="+key+"&billno="+billno
    req = urllib2.Request(url = full_url,headers=headers)
    res_data = urllib2.urlopen(req)
    res = res_data.read()
    return res
