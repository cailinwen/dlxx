# -*- coding: utf-8 -*-
#import codecs
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )
import json
from pyonion.auth.views import need_login

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import connections
from django.core.serializers.json import DjangoJSONEncoder
import datetime
import csv,codecs

#合伙人统计跳转页面
@csrf_exempt
@need_login
def partnerList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("report/partner/partnerList.html",dic)

#合伙人统计查询页面
@csrf_exempt
@need_login
def partnerJson(request):
    memberName = request.GET.get('memberName')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if memberName:
        likeSql = " AND MEMBER_NAME like '%%%s%%' " % memberName

    whereSql = " where s.STORE_TYPE = 2 AND s.STORE_FLG = 3 AND s.STORE_PARTNER in ('1','3') "
    groupSql = " GROUP BY d.AGENT_ID "
    whereSql = whereSql + likeSql
    mySql = '''
              SELECT AGENT_ID , MEMBER_NAME, sum(TOTAL) as  TOTAL, sum(AGENT_AMT) as AGENT_AMT ,concat( round(sum(AGENT_AMT)/sum(TOTAL)*100,2),'%%') as  PROFIT_RATE
            FROM report_agant_day d LEFT JOIN  store_rec s on s.STORE_MEMBER_ID = d.AGENT_ID  %s %s
            ''' % (whereSql, groupSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#合伙人代理商统计跳转页面
@csrf_exempt
@need_login
def agentList(request):
    dic = {'agentId': request.GET.get('agentId')}
    return render_to_response("report/partner/agentList.html",dic)

#店主代理统计查询页面
@csrf_exempt
@need_login
def agentJson(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    agentId = request.GET.get('agentId')
    startdata = request.GET.get('startdata')
    enddata = request.GET.get('enddata')
    count1 = request.GET.get('count1')
    count2 = request.GET.get('count2')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = " AND MEMBER_NAME like '%%%s%%' " % seacheNameParam

    if agentId:
        likeSql = likeSql + (" AND p.PARTNER_ID = %s" % agentId)

    start_sql=end_sql=""
    if startdata:
        start_sql = " and REPORT_DATE >= '%s'" % datetime.datetime.strptime(startdata,'%Y-%m-%d')

    if enddata:
        end = enddata + " 23:59:59"
        end_sql = " and REPORT_DATE <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    count1_sql=count2_sql=""
    if count1:
        count1_sql = " and STORECOUNT >= '%s' " % count1

    if count2:
        count2_sql = " and STORECOUNT <= '%s' " % count2

    whereSql = " where 1=1 "
    groupSql = " GROUP BY p.MEMBER_ID "
    whereSql = whereSql + likeSql + start_sql + end_sql + count1_sql + count2_sql
    mySql = '''
              SELECT
	           AGENT_ID ,
              MEMBER_NAME,
              sum(TOTAL) as  TOTAL,
              sum(AGENT_AMT) as AGENT_AMT ,
              concat( round(sum(AGENT_AMT)/sum(TOTAL)*100,2),'%%') as  PROFIT_RATE ,
              round(max(STORECOUNT),0) as  STORECOUNT,
              round(sum(MEMBER_COUNT),0) as MEMBER_COUNT ,
              round(sum(MEMBER_SOD_COUNT),0) as  MEMBER_SOD_COUNT,
              concat( round(sum(MEMBER_SOD_COUNT)/sum(MEMBER_COUNT)*100,2),'%%') as MEMBER_ACTIVE_RATE ,
              round(sum(SOD_ITEM_COUNT),0) as SOD_ITEM_COUNT ,
              round(sum(SOD_COUNT),0) as SOD_COUNT ,
              round(sum(TOTAL)/sum(SOD_COUNT),2)  as SODAVGPRICE ,
              round(sum(TOTAL)/sum(SOD_ITEM_COUNT),2) as SOD_ITEM_AVG_PRICE ,
              round(sum(SOD_COUNT)/sum(MEMBER_SOD_COUNT),2) as  MEMBER_SOD_AVG_COUNT ,
              round(sum(REGISTER_AMT),2) as REGISTER_AMT ,
              round(sum(TMN_AMT),2) as  TMN_AMT,
              round(sum(PROFIT_AMT),2) as PROFIT_AMT ,
              round(sum(PROFIT_AMT)/max(STORECOUNT),2) as AVGPROFIT ,
              concat(round(sum(PROFIT_AMT)/sum(TOTAL)*100,2),'%%') as PROFIT_RATE1 ,
              round(sum(AGENT_AMT)/max(STORECOUNT),2) as AVGAGENT ,
              round(sum(REFUND_AMT),2) as REFUND_AMT ,
              round(sum(REFUND_SOD_ITEM_COUNT),0) as  REFUND_SOD_ITEM_COUNT,
              concat(round(sum(REFUND_SOD_ITEM_COUNT)/sum(SOD_ITEM_COUNT)*100,2),'%%') as REFUND_RATE
              FROM report_agant_day d
              LEFT JOIN  partner_link p on d.AGENT_ID = p.MEMBER_ID  %s %s
            ''' % (whereSql, groupSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#代理商导出
@need_login
@csrf_exempt
def agentExprort(request):
    agentIdAll = request.GET.get('agentIdAll')
    seacheNameParam = request.GET.get('seacheNameParam')
    startdata = request.GET.get('startdata')
    enddata = request.GET.get('enddata')
    count1 = request.GET.get('count1')
    count2 = request.GET.get('count2')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if agentIdAll:
        likeSql = likeSql + (" AND p.PARTNER_ID = %s" % agentIdAll)

    if seacheNameParam:
        likeSql = " AND MEMBER_NAME like '%%%s%%' " % seacheNameParam

    start_sql=end_sql=""
    if startdata:
        start_sql = " and REPORT_DATE >= '%s'" % datetime.datetime.strptime(startdata,'%Y-%m-%d')

    if enddata:
        end = enddata + " 23:59:59"
        end_sql = " and REPORT_DATE <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    count1_sql=count2_sql=""
    if count1:
        count1_sql = " and STORECOUNT >= '%s' " % count1

    if count2:
        count2_sql = " and STORECOUNT <= '%s' " % count2

    whereSql = " where 1=1  "
    groupSql = " GROUP BY p.MEMBER_ID "
    whereSql = whereSql + likeSql + start_sql + end_sql + count1_sql + count2_sql
    mySql = '''
              SELECT MEMBER_NAME, sum(TOTAL) as  TOTAL,sum(AGENT_AMT) as AGENT_AMT,
              round(max(STORECOUNT),0) as  STORECOUNT, round(sum(TOTAL)/sum(SOD_COUNT),2)  as SODAVGPRICE,round(sum(TMN_AMT),2) as  TMN_AMT FROM report_agant_day d
              LEFT JOIN  partner_link p on d.AGENT_ID = p.MEMBER_ID  %s %s
            ''' % (whereSql, groupSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    results = cursorA.fetchall()
    cursorA.close()
    response = HttpResponse(content_type='text/csv')
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = 'attachment; filename=代理商统计导出.csv'
    data = []
    writer = csv.writer(response)
    writer.writerow(['代理商','零售总额','代理收入','经纪人总数','客单价','销售收入'])
    for row in results:
        datas =(row[0],row[1],row[2],row[3],row[4],row[5])
        data.append(datas)
    writer.writerows(data)
    return response

#分页控件
def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result