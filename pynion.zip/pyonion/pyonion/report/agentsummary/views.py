# -*- coding: utf-8 -*-
#import codecs
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
import json
import csv,codecs
from pyonion.auth.views import need_login

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import connections
from django.core.serializers.json import DjangoJSONEncoder

#经纪人统计跳转页面
@csrf_exempt
@need_login
def agentsummaryList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("report/agentsummary/agentsummaryList.html",dic)

#经纪人查询
@csrf_exempt
@need_login
def agentsummaryJson(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    seacheStoreName = request.GET.get('seacheStoreName')
    start = request.GET.get('start')
    end = request.GET.get('end')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = likeSql + (" AND agent.member_name like '%%%s%%' " % seacheNameParam)
    if seacheStoreName:
        likeSql = likeSql + (" AND di.store_name like '%%%s%%' " % seacheStoreName)

    start_sql=end_sql=""
    if start:
        start_sql = " and di.REPORT_MONTH >= '%s'" % start

    if end:
        end_sql = " and di.REPORT_MONTH <= '%s' " % end

    whereSql = " where st.STORE_IS_BROKER = 1 "
    groupSql = " GROUP BY di.member_id ORDER BY total desc "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = '''
                SELECT di.store_name,m.member_name,agent.member_name as nameAll,agent_id,sum(sales_amt) as total,sum(agent_amt) as agent_amt,
                CONCAT(IFNULL(round(sum(agent_amt)/sum(sales_amt)*100,2),0),'%%') as profit_rate,sum(member_count) as member_count,
                sum(member_sod_count) as member_sod_count,CONCAT(IFNULL(round(sum(member_sod_count)/sum(member_count)*100,2),0),'%%') as member_active_rate,
                sum(sod_item_count) as sod_item_count,sum(sod_count) as sod_count,IFNULL(round(sum(sales_amt)/sum(sod_count),2),0) as sodAvgPrice,
                IFNULL(round(sum(sales_amt)/sum(sod_item_count),2),0) as sod_item_avg_price ,IFNULL(round(sum(sod_count)/sum(member_sod_count),2),0) as  member_sod_avg_count ,
                sum(register_amt) as register_amt,sum(tmn_amt) as tmn_amt,sum(profit_amt) as profit_amt,
                CONCAT(IFNULL(round(sum(profit_amt)/sum(sales_amt)*100,2),0),'%%') as profit_rate1,
                sum(refund_amt) as refund_amt,sum(refund_sod_item_count) as refund_sod_item_count,
                CONCAT(IFNULL(round(sum(refund_sod_item_count)/sum(sod_item_count)*100,2),0),'%%') as refund_rate
                FROM dim_store_reports_month di LEFT JOIN member_rec m ON  m.MEMBER_ID=di.MEMBER_ID
                LEFT JOIN store_rec st on st.STORE_MEMBER_ID=di.MEMBER_ID
                LEFT JOIN member_rec agent ON  agent.MEMBER_ID= m.MEMBER_PARENT_ID %s %s
            ''' % (whereSql, groupSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#商品天数导出
@need_login
@csrf_exempt
def agentsummaryExport(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    seacheStoreName = request.GET.get('seacheStoreName')
    start = request.GET.get('start')
    end = request.GET.get('end')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = likeSql + (" AND agent.member_name like '%%%s%%' " % seacheNameParam)
    if seacheStoreName:
        likeSql = likeSql + (" AND di.store_name like '%%%s%%' " % seacheStoreName)

    start_sql=end_sql=""
    if start:
        start_sql = " and di.REPORT_MONTH >= '%s'" % start

    if end:
        end_sql = " and di.REPORT_MONTH <= '%s' " % end

    whereSql = " where st.STORE_IS_BROKER = 1 "
    groupSql = " GROUP BY di.member_id ORDER BY total desc "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = '''
              SELECT di.store_name,m.member_name,agent.member_name as nameAll,agent_id,sum(sales_amt) as total,sum(agent_amt) as agent_amt,
                CONCAT(IFNULL(round(sum(agent_amt)/sum(sales_amt)*100,2),0),'%%') as profit_rate,sum(member_count) as member_count,
                sum(member_sod_count) as member_sod_count,CONCAT(IFNULL(round(sum(member_sod_count)/sum(member_count)*100,2),0),'%%') as member_active_rate,
                sum(sod_item_count) as sod_item_count,sum(sod_count) as sod_count,IFNULL(round(sum(sales_amt)/sum(sod_count),2),0) as sodAvgPrice,
                IFNULL(round(sum(sales_amt)/sum(sod_item_count),2),0) as sod_item_avg_price ,IFNULL(round(sum(sod_count)/sum(member_sod_count),2),0) as  member_sod_avg_count ,
                sum(register_amt) as register_amt,sum(tmn_amt) as tmn_amt,sum(profit_amt) as profit_amt,
                CONCAT(IFNULL(round(sum(profit_amt)/sum(sales_amt)*100,2),0),'%%') as profit_rate1,
                sum(refund_amt) as refund_amt,sum(refund_sod_item_count) as refund_sod_item_count,
                CONCAT(IFNULL(round(sum(refund_sod_item_count)/sum(sod_item_count)*100,2),0),'%%') as refund_rate
                FROM dim_store_reports_month di LEFT JOIN member_rec m ON  m.MEMBER_ID=di.MEMBER_ID
                LEFT JOIN store_rec st on st.STORE_MEMBER_ID=di.MEMBER_ID
                LEFT JOIN member_rec agent ON  agent.MEMBER_ID= m.MEMBER_PARENT_ID %s %s
            ''' % (whereSql, groupSql)
    cursor = connections['slave'].cursor()
    cursor.execute(mySql)
    results = cursor.fetchall()
    cursor.close()
    response = HttpResponse(content_type='text/csv')
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = 'attachment; filename=经纪人统计导出.csv'
    data = []
    writer = csv.writer(response)
    writer.writerow(['所属代理商','店铺名称','店主名称','零售总额','利润率','新注册客户数','下单客户','活跃率','销售件数','销售单数','客单价','件单价','客件数','拓客收入','销售收入','总利润','退款金额','退款件数','退款率'])
    for row in results:
        datas =(row[0],row[1],row[2],row[4],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],row[16],row[17],row[19],row[20],row[21])
        data.append(datas)
    writer.writerows(data)
    return response

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result
