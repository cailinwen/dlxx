# -*- coding: utf-8 -*-
#import codecs

import json
import xlwt
from decimal import *
from pyonion.auth.views import need_login

from pyonion.models import Area
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from pyonion.paginatorutils.views import row_sql_pagination

from django.core.serializers.json import DjangoJSONEncoder

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import connections
import datetime

@need_login
@csrf_exempt
#代理商统计跳转页面
def agentReport(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("report/agentReport.html",dic)

#导出代理商明细
@need_login
@csrf_exempt
def agentReportExport(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    cursorA = connections['slave'].cursor()
    totalSql = "SELECT agent_id,member_name, total,agent_amt, profit_rate, storeCount , member_count, member_sod_count, member_active_rate, sod_item_count, sod_count, sodAvgPrice, sod_item_avg_price , member_sod_avg_count , register_amt, tmn_amt, profit_amt, round(	profit_amt / storeCount,2	) AS avgProfit, profit_rate1, round(agent_amt / storeCount, 2) AS avgAgent , refund_amt, refund_sod_item_count, refund_rate FROM (	SELECT z.*, (	SELECT count(1)	FROM	member_rec c	WHERE	c.MEMBER_PARENT_ID = Z.MEMBER_ID	AND c.MEMBER_TYPE = 3	) AS storeCount FROM (	SELECT m.MEMBER_ID, m.member_name, AGENT_ID, sum(sales_amt) AS total, sum(agent_amt) AS agent_amt, CONCAT( round( sum(agent_amt) / sum(sales_amt) * 100,2	),	'%'	) AS profit_rate,	sum(member_count) AS member_count, sum(member_sod_count) AS member_sod_count, CONCAT(	round( sum(member_sod_count) / sum(member_count) * 100, 2 ), '%' ) AS member_active_rate, sum(sod_item_count) AS sod_item_count, sum(sod_count) AS sod_count, round( sum(sales_amt) / sum(sod_count), 2 ) AS sodAvgPrice, round( sum(sales_amt) / sum(sod_item_count), 2 ) AS sod_item_avg_price, round( sum(sod_count) / sum(member_sod_count), 2 ) AS member_sod_avg_count, sum(register_amt) AS register_amt, sum(tmn_amt) AS tmn_amt, sum(profit_amt) AS profit_amt, CONCAT( round( sum(profit_amt) / sum(sales_amt) * 100, 2 ), '%' ) AS profit_rate1, sum(refund_amt) AS refund_amt, sum(refund_sod_item_count) AS refund_sod_item_count, CONCAT( round( sum(refund_sod_item_count) / sum(sod_item_count) * 100, 2 ), '%' ) AS refund_rate FROM dim_store_reports LEFT JOIN member_rec m ON m.MEMBER_ID = AGENT_ID  "
    whereSql = " WHERE "
    totalGroupSql = "GROUP BY agent_id ORDER BY total desc ) z	) y"
    if start == None:
        whereSql = whereSql + " report_date <= '%s' " % (end)
    else:
        whereSql = whereSql + "report_date >= '%s' AND report_date <= '%s'" % (start, end)
    if seacheNameParam != None:
        likeSql = " AND m.MEMBER_NAME like '%%%s%%' " % (seacheNameParam)
        totalSql = totalSql + whereSql + likeSql + totalGroupSql
    else:
        totalSql = totalSql + whereSql + totalGroupSql
    cursorA.execute(totalSql)
    row_all = cursorA.fetchall()
    cursorA.close()

    _lst = []
    _lst.extend(row_all[:])
    _lst.insert(0, ['ID','代理商','零售总额','代理收入','利润率','经纪人总数','新注册客户数','下单客户','活跃率','销售件数','销售单数','客单价','件单价','客件数','拓客收入','销售收入','总利润','平均利润','利润率','平均贡献','退款金额','退款件数','退款率'])

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for row, rowdata in enumerate(_lst):
        for col, val in enumerate(rowdata):
            sheet.write(row, col, val, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=代理商统计导出.xls'
    book.save(response)
    return response

#导出代理商明细
@need_login
@csrf_exempt
def agentReportNewExport(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = " AND MEMBER_NAME like '%%%s%%' " % seacheNameParam

    start_sql=end_sql=""
    if start:
        start_sql = " and REPORT_DATE >= '%s'" % datetime.datetime.strptime(start,'%Y-%m-%d')

    if end:
        end = end + " 23:59:59"
        end_sql = " and REPORT_DATE <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    whereSql = " WHERE 1 = 1 "
    groupSql = " GROUP BY   AGENT_ID ORDER BY TOTAL desc "
    whereSql = whereSql + likeSql + start_sql + end_sql
    cursorA = connections['slave'].cursor()
    mySql = '''
              SELECT
              AGENT_ID ,
              MEMBER_NAME,
              sum(TOTAL) as  TOTAL,
              sum(AGENT_AMT) as AGENT_AMT ,
              concat( round(sum(AGENT_AMT)/sum(TOTAL)*100,2),'%%') as  PROFIT_RATE ,
              round(max(STORECOUNT),0) as  STORECOUNT,
              round(sum(MEMBER_COUNT),0) as MEMBER_COUNT ,
              round(sum(MEMBER_SOD_COUNT),0) as  MEMBER_SOD_COUNT,
              concat( round(sum(MEMBER_SOD_COUNT)/sum(MEMBER_COUNT)*100,2),'%%') as MEMBER_ACTIVE_RATE ,
              round(sum(SOD_ITEM_COUNT),0) as SOD_ITEM_COUNT ,
              round(sum(SOD_COUNT),0) as SOD_COUNT ,
              round(sum(TOTAL)/sum(SOD_COUNT),2)  as SODAVGPRICE ,
              round(sum(TOTAL)/sum(SOD_ITEM_COUNT),2) as SOD_ITEM_AVG_PRICE ,
              round(sum(SOD_COUNT)/sum(MEMBER_SOD_COUNT),2) as  MEMBER_SOD_AVG_COUNT ,
              round(sum(REGISTER_AMT),2) as REGISTER_AMT ,
              round(sum(TMN_AMT),2) as  TMN_AMT,
              round(sum(PROFIT_AMT),2) as PROFIT_AMT ,
              round(sum(PROFIT_AMT)/max(STORECOUNT),2) as AVGPROFIT ,
              concat(round(sum(PROFIT_AMT)/sum(TOTAL)*100,2),'%%') as PROFIT_RATE1 ,
              round(sum(AGENT_AMT)/max(STORECOUNT),2) as AVGAGENT ,
              round(sum(REFUND_AMT),2) as REFUND_AMT ,
              round(sum(REFUND_SOD_ITEM_COUNT),0) as  REFUND_SOD_ITEM_COUNT,
              concat(round(sum(REFUND_SOD_ITEM_COUNT)/sum(SOD_ITEM_COUNT)*100,2),'%%') as REFUND_RATE
              from report_agant_day %s %s
            ''' % (whereSql, groupSql)
    cursorA.execute(mySql)
    row_all = cursorA.fetchall()
    cursorA.close()

    _lst = []
    _lst.extend(row_all[:])
    _lst.insert(0, ['ID','代理商','零售总额','代理收入','利润率','经纪人总数','新注册客户数','下单客户','活跃率','销售件数','销售单数','客单价','件单价','客件数','拓客收入','销售收入','总利润','平均利润','利润率','平均贡献','退款金额','退款件数','退款率'])

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for row, rowdata in enumerate(_lst):
        for col, val in enumerate(rowdata):
            sheet.write(row, col, val, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=代理商统计导出.xls'
    book.save(response)
    return response

#店主统计跳转页面
@need_login
@csrf_exempt
def storeReport(request):
    dic = {'agentId': request.GET.get('agentId')}
    return render_to_response("report/storeReport.html", dic)

#店主统计
@need_login
@csrf_exempt
def storeReportJson(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    agentId = request.GET.get('agentId')
    start = request.GET.get('start')
    end = request.GET.get('end')
    pageSzie = request.GET.get('size')
    pageNo = request.GET.get('pageNo')
    cursorA = connections['slave'].cursor()
    totalSql = "SELECT ID FROM dim_store_reports LEFT JOIN member_rec m ON  m.MEMBER_ID=AGENT_ID "
    whereSql = " WHERE "
    totalGroupSql = " GROUP BY dim_store_reports.member_id"
    if start == None:
        whereSql = whereSql + " report_date <= '%s' " % (end)
    else:
        whereSql = whereSql + "report_date >= '%s' AND report_date <= '%s'" % (start, end)
    if agentId != None:
        whereSql = whereSql + " AND agent_id = '%d' " % (int(agentId))
    if seacheNameParam != None:
        likeSql = " AND store_name like '%%%s%%' " % (seacheNameParam)
        totalSql = totalSql + whereSql + likeSql + totalGroupSql
    else:
        totalSql = totalSql + whereSql + totalGroupSql
    cursorA.execute(totalSql)
    jsonItme = cursorA.fetchall()
    dataTotal = str(len(jsonItme))
    cursorA.close()

    startLimitNum = int(pageSzie) * (int(pageNo) - 1)
    mySql = "SELECT store_name,member_name,agent_id,sum(sales_amt) as total,sum(agent_amt) as agent_amt,CONCAT(IFNULL(round(sum(agent_amt)/sum(sales_amt)*100,2),0),'%') as profit_rate,sum(member_count) as member_count,sum(member_sod_count) as member_sod_count,CONCAT(IFNULL(round(sum(member_sod_count)/sum(member_count)*100,2),0),'%') as member_active_rate,sum(sod_item_count) as sod_item_count,sum(sod_count) as sod_count,IFNULL(round(sum(sales_amt)/sum(sod_count),2),0) as sodAvgPrice,IFNULL(round(sum(sales_amt)/sum(sod_item_count),2),0) as sod_item_avg_price ,IFNULL(round(sum(sod_count)/sum(member_sod_count),2),0) as  member_sod_avg_count ,sum(register_amt) as register_amt,sum(tmn_amt) as tmn_amt,sum(profit_amt) as profit_amt,CONCAT(IFNULL(round(sum(profit_amt)/sum(sales_amt)*100,2),0),'%') as profit_rate1,sum(refund_amt) as refund_amt,sum(refund_sod_item_count) as refund_sod_item_count,CONCAT(IFNULL(round(sum(refund_sod_item_count)/sum(sod_item_count)*100,2),0),'%') as refund_rate FROM dim_store_reports LEFT JOIN member_rec m ON  m.MEMBER_ID=dim_store_reports.MEMBER_ID"
    likeSql = ""
    groupSql = " GROUP BY dim_store_reports.member_id ORDER BY total desc "
    if agentId != None:
        whereSql = whereSql + " AND agent_id = '%d' " % (int(agentId))
    if seacheNameParam != None:
        likeSql = " AND store_name like '%%%s%%' " % (seacheNameParam)
    mySql = mySql + whereSql + likeSql + groupSql
    temp = " limit %d,%d" % (startLimitNum, int(pageSzie))
    cursor = connections['slave'].cursor()
    cursor.execute(mySql + temp)
    jsonItme = cursor.fetchall()
    desc = cursor.description
    cursor.close()

    totalPage = int(dataTotal) / int(pageSzie)
    if (int(dataTotal) % int(pageSzie)) > 0:
        totalPage = totalPage + 1
    items = ['{"total":%s,"totalPage":%s,"rows":' % (dataTotal, str(totalPage))]
    li = []
    for item in jsonItme:
        repoerItem = {}
        i = 0
        for de in desc:
            if isinstance(item[i], Decimal):
                repoerItem[de[0]] = str(item[i])
            else:
                repoerItem[de[0]] = item[i]
            i = i + 1
        li.append(repoerItem)
    items.append(json.dumps(list(li)))
    items.append('}')
    return HttpResponse(items, content_type="application/json")

#导出店主、经纪人明 细
def agentExport(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    agentId = request.GET.get('agentId')
    start = request.GET.get('start')
    end = request.GET.get('end')
    cursorA = connections['slave'].cursor()
    totalSql = "SELECT store_name,MEMBER_NAME, sum(sales_amt) as total ,CONCAT(IFNULL(round(sum(agent_amt)/sum(sales_amt)*100,2),0),'%') as profit_rate, sum(member_count) as member_count, sum(member_sod_count) as member_sod_count, CONCAT(round(sum(member_sod_count)/sum(member_count)*100,2),'%') as member_active_rate, sum(sod_item_count) as sod_item_count, sum(sod_count) as sod_count, round(sum(sales_amt)/sum(sod_count),2) as sodAvgPrice, round(sum(sales_amt)/sum(sod_item_count),2) as sod_item_avg_price , round(sum(sod_count)/sum(member_sod_count),2) as  member_sod_avg_count , sum(register_amt) as register_amt, sum(tmn_amt) as tmn_amt, sum(profit_amt) as profit_amt, sum(refund_amt) as refund_amt, sum(refund_sod_item_count) as refund_sod_item_count, 	CONCAT(round(sum(refund_sod_item_count)/sum(sod_item_count)*100,2),'%') as refund_rate FROM dim_store_reports LEFT JOIN member_rec m ON  m.MEMBER_ID=dim_store_reports.MEMBER_ID  "
    whereSql = " WHERE "
    totalGroupSql = " GROUP BY dim_store_reports.member_id"
    if start == None:
        whereSql = whereSql + " report_date <= '%s' " % (end)
    else:
        whereSql = whereSql + "report_date >= '%s' AND report_date <= '%s'" % (start, end)
    if agentId != None:
        whereSql = whereSql + " AND agent_id = '%d' " % (int(agentId))
    if seacheNameParam != None:
        likeSql = " AND store_name like '%%%s%%' " % (seacheNameParam)
        totalSql = totalSql + whereSql + likeSql + totalGroupSql
    else:
        totalSql = totalSql + whereSql + totalGroupSql
    cursorA.execute(totalSql)
    row_all = cursorA.fetchall()
    cursorA.close()

    _lst = []
    _lst.extend(row_all[:])
    _lst.insert(0, ['店铺名称','店主名称','零售总额','利润率','新注册客户数','下单客户','活跃率','销售件数','销售单数','客单价','件单价','客件数','拓客收入','销售收入','利润','退款金额','退款件数','退款率'])

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for row, rowdata in enumerate(_lst):
        for col, val in enumerate(rowdata):
            sheet.write(row, col, val, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=店主统计导出.xls'
    book.save(response)
    return response

#代理统计查询页面 备用
@csrf_exempt
@need_login
def agentReportNewJsonTemp(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = " AND MEMBER_NAME like '%%%s%%' " % seacheNameParam

    start_sql=end_sql=""
    if start:
        start_sql = " and REPORT_DATE >= '%s'" % datetime.datetime.strptime(start,'%Y-%m-%d')

    if end:
        end = end + " 23:59:59"
        end_sql = " and REPORT_DATE <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    whereSql = " WHERE 1 = 1 "
    groupSql = " GROUP BY   AGENT_ID ORDER BY TOTAL desc "
    whereSql = whereSql + likeSql + start_sql + end_sql
    mySql = '''
              SELECT
              AGENT_ID ,
              MEMBER_NAME,
              sum(TOTAL) as  TOTAL,
              sum(AGENT_AMT) as AGENT_AMT ,
              concat( round(sum(AGENT_AMT)/sum(TOTAL)*100,2),'%%') as  PROFIT_RATE ,
              round(max(STORECOUNT),0) as  STORECOUNT,
              round(sum(MEMBER_COUNT),0) as MEMBER_COUNT ,
              round(sum(MEMBER_SOD_COUNT),0) as  MEMBER_SOD_COUNT,
              concat( round(sum(MEMBER_SOD_COUNT)/sum(MEMBER_COUNT)*100,2),'%%') as MEMBER_ACTIVE_RATE ,
              round(sum(SOD_ITEM_COUNT),0) as SOD_ITEM_COUNT ,
              round(sum(SOD_COUNT),0) as SOD_COUNT ,
              round(sum(TOTAL)/sum(SOD_COUNT),2)  as SODAVGPRICE ,
              round(sum(TOTAL)/sum(SOD_ITEM_COUNT),2) as SOD_ITEM_AVG_PRICE ,
              round(sum(SOD_COUNT)/sum(MEMBER_SOD_COUNT),2) as  MEMBER_SOD_AVG_COUNT ,
              round(sum(REGISTER_AMT),2) as REGISTER_AMT ,
              round(sum(TMN_AMT),2) as  TMN_AMT,
              round(sum(PROFIT_AMT),2) as PROFIT_AMT ,
              round(sum(PROFIT_AMT)/max(STORECOUNT),2) as AVGPROFIT ,
              concat(round(sum(PROFIT_AMT)/sum(TOTAL)*100,2),'%%') as PROFIT_RATE1 ,
              round(sum(AGENT_AMT)/max(STORECOUNT),2) as AVGAGENT ,
              round(sum(REFUND_AMT),2) as REFUND_AMT ,
              round(sum(REFUND_SOD_ITEM_COUNT),0) as  REFUND_SOD_ITEM_COUNT,
              concat(round(sum(REFUND_SOD_ITEM_COUNT)/sum(SOD_ITEM_COUNT)*100,2),'%%') as REFUND_RATE
              from report_agant_day %s %s
            ''' % (whereSql, groupSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

@csrf_exempt
@need_login
def agentReportNewJson(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')

    likeSql = ""
    #-----开始判断前端传的参数是否为空--------
    if seacheNameParam:
        likeSql = likeSql + (" AND MEMBER_NAME like '%%%s%%' " % seacheNameParam)

    start_sql=end_sql=""
    if start:
        start_sql = " and REPORT_DATE >= '%s'" % datetime.datetime.strptime(start,'%Y-%m-%d')

    if end:
        end = end + " 23:59:59"
        end_sql = " and REPORT_DATE <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    whereSql = " WHERE 1 = 1 "
    groupSql = " GROUP BY   AGENT_ID ORDER BY TOTAL desc "
    whereSql = whereSql + likeSql + start_sql + end_sql
    page_size = int(request.GET['size'])
    if 'pageNo' in request.GET:
        page_no = int(request.GET['pageNo'])
    else:
        page_no = 1
    sql = '''
              SELECT
              AGENT_ID ,
              MEMBER_NAME,
              sum(TOTAL) as  TOTAL,
              sum(AGENT_AMT) as AGENT_AMT ,
              concat( round(sum(AGENT_AMT)/sum(TOTAL)*100,2),'%%') as  PROFIT_RATE ,
              round(max(STORECOUNT),0) as  STORECOUNT,
              round(sum(MEMBER_COUNT),0) as MEMBER_COUNT ,
              round(sum(MEMBER_SOD_COUNT),0) as  MEMBER_SOD_COUNT,
              concat( round(sum(MEMBER_SOD_COUNT)/sum(MEMBER_COUNT)*100,2),'%%') as MEMBER_ACTIVE_RATE ,
              round(sum(SOD_ITEM_COUNT),0) as SOD_ITEM_COUNT ,
              round(sum(SOD_COUNT),0) as SOD_COUNT ,
              round(sum(TOTAL)/sum(SOD_COUNT),2)  as SODAVGPRICE ,
              round(sum(TOTAL)/sum(SOD_ITEM_COUNT),2) as SOD_ITEM_AVG_PRICE ,
              round(sum(SOD_COUNT)/sum(MEMBER_SOD_COUNT),2) as  MEMBER_SOD_AVG_COUNT ,
              round(sum(REGISTER_AMT),2) as REGISTER_AMT ,
              round(sum(TMN_AMT),2) as  TMN_AMT,
              round(sum(PROFIT_AMT),2) as PROFIT_AMT ,
              round(sum(PROFIT_AMT)/max(STORECOUNT),2) as AVGPROFIT ,
              concat(round(sum(PROFIT_AMT)/sum(TOTAL)*100,2),'%%') as PROFIT_RATE1 ,
              round(sum(AGENT_AMT)/max(STORECOUNT),2) as AVGAGENT ,
              round(sum(REFUND_AMT),2) as REFUND_AMT ,
              round(sum(REFUND_SOD_ITEM_COUNT),0) as  REFUND_SOD_ITEM_COUNT,
              concat(round(sum(REFUND_SOD_ITEM_COUNT)/sum(SOD_ITEM_COUNT)*100,2),'%%') as REFUND_RATE
              from report_agant_day  %s %s
        '''% (whereSql, groupSql)
    sql_all="""
            SELECT count(DISTINCT(AGENT_ID)),ceil(count(DISTINCT(AGENT_ID))/%d) from report_agant_day where 1=1 %s %s %s
            """% (page_size,likeSql,start_sql,end_sql)
    result=row_sql_pagination(page_no,sql_all,sql,page_size)
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

#查询所有的省
def seachArea(request):
    areax = Area.objects.filter(area_parent_id=0).order_by('area_id')
    itemArea = ['[']
    for area in areax:
        itemArea.append('{"area_id":"%s","area_name":"%s"},' % (area.area_id, area.area_name))
    itemArea.append(']')
    jsonstr = ''.join(itemArea)
    jsonlen = len(jsonstr)
    jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 1:]
    return HttpResponse(jsonstr, content_type="application/json")

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result
