# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )
import random

import json
import time
from pyonion.utils.qianhaiUtils import queryOrder
from django.http import HttpResponse, HttpResponseRedirect
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt

from django.shortcuts import render_to_response

@csrf_exempt
#商品库存统计跳转页面
def receiptList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("receipt/receiptList.html",dic)

def randomAll():
    id_length=23
    group_id = 'C'
    for _ in range(id_length):
       group_id+=str(random.randint(0, 9))
    return group_id

#回执单统计
@csrf_exempt
def receiptListJson(request):
    customs = randomAll()
    orderSn = request.GET.get('orderSn')
    res = queryOrder(str(orderSn))
    receipt = json.loads(res)
    if receipt['retmsg']:
        stattime = str(receipt['retmsg'][0]['statustime'])[:-3]
        timeTuple = time.localtime(float(stattime))
        times = time.strftime("%Y-%m-%d %H:%M:%S",timeTuple)
        receipt['retmsg'][0]['customs']=customs
        receipt['retmsg'][0]['country']='进境'
        receipt['retmsg'][0]['status']='放行'
        receipt['retmsg'][0]['platform']='IE150401173785'
        receipt['retmsg'][0]['type']='BC'
        receipt['retmsg'][0]['tax']='0.00'
        receipt['retmsg'][0]['vat']='0.00'
        receipt['retmsg'][0]['createTime']=times
        receipts=json.dumps(receipt)
    else:
        receipts = []
    return HttpResponse(receipts,content_type="application/json")

@csrf_exempt
#商品库存统计跳转页面
def receiptsList(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("receipt/receiptsList.html",dic)