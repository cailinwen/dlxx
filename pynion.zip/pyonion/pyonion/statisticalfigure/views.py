# -*- coding: utf-8 -*-
#import codecs

import json
from pyonion.auth.views import need_login
from django.shortcuts import render_to_response
from django.http import HttpResponse
# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
from django.db import connections
from django.shortcuts import render_to_response, render
from pyonion.utils.jsonEncoder import CJsonEncoder

@need_login
@csrf_exempt
def statisticalfigureList(request):
    dic = {'id': request.GET.get('id'), 'userID': request.GET.get('userID')}
    return render_to_response("statisticalfigure/statisticalfigureList.html", dic)

#折线图
@need_login
@csrf_exempt
def statisticalfigureJson(request):
    if 'operation' in request.GET and request.is_ajax():
        mySql = '''
              select date_format(report_date,'%Y-%m-%d'),sum(sod_count) as sodCount,sum(member_count) as member_count from dim_store_reports where report_date >= date_format(date_sub(now(),interval 30 day),'%Y-%m-%d')
              group by report_date ORDER BY  1
            '''
        cursor = connections['slave'].cursor()
        cursor.execute(mySql)
        jsonItme = cursor.fetchall()

        report_date=[]
        sodCount=[]
        memberCount=[]
        for i in jsonItme:
            report_date.append(i[0])
            sodCount.append(i[1])
            memberCount.append(i[2])
        return HttpResponse(json.dumps({"count":sodCount,"reportDate":report_date,"memberCount":memberCount},cls=CJsonEncoder))
    else:
        return render(request,"statisticalfigure/statisticalfigureList.html")




