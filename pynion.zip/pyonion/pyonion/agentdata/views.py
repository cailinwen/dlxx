# -*- coding: utf-8 -*-
#import codecs

# 包装csrf请求，避免django认为其实跨站攻击脚本
from django.views.decorators.csrf import csrf_exempt
import json
import xlwt
from decimal import *
import time
from pyonion.auth.views import need_login
from pyonion.models import UserAgent

from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db import connections
from django.template import RequestContext
from django.core.serializers.json import DjangoJSONEncoder
import datetime

@csrf_exempt
@need_login
def agentData(request):
    dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
    return render_to_response("agentdata/agentdataList.html",dic)

@csrf_exempt
@need_login
def agentDataTest(request):
    #agentIds = request.session.get('agentId_language',True)
    agentIds = request.COOKIES.get('agentId_language','')
    seacheNameParam = request.GET.get('seacheNameParam')
    start = request.GET.get('start')
    end = request.GET.get('end')
    pageSzie = request.GET.get('size')
    pageNo = request.GET.get('pageNo')
    area = request.GET.get('area')
    cursorA = connections['slave'].cursor()
    totalSql = "SELECT ID FROM dim_store_reports LEFT JOIN member_rec m ON  m.MEMBER_ID=AGENT_ID "
    if agentIds:
         whereSql = " WHERE  AGENT_ID IN (" + agentIds + ") AND "
    else:
         whereSql = "WHERE"
    likeSql = ""
    hql = ""
    totalGroupSql = " GROUP BY agent_id"
    if start == None:
        whereSql = whereSql + " report_date <= '%s' " % (end)
    else:
        whereSql = whereSql + " report_date >= '%s' AND report_date <= '%s'" % (start, end)
    if seacheNameParam != None:
        likeSql = " AND m.MEMBER_NAME like '%%%s%%' " % (seacheNameParam)
    if area:
        hql = " AND (SELECT STORE_SAREA_ID from store_rec WHERE STORE_MEMBER_ID = AGENT_ID AND STORE_FLG=3 and STORE_TYPE=2) = %s " % area
        whereSql = whereSql + hql
    totalSql = totalSql + whereSql + likeSql + totalGroupSql
    cursorA.execute(totalSql)
    jsonItme = cursorA.fetchall()
    dataTotal = str(len(jsonItme))
    cursorA.close()

    startLimitNum = int(pageSzie) * (int(pageNo) - 1)
    mySql = "SELECT 	member_name,agent_id, total,agent_amt, profit_rate, storeCount , member_count, member_sod_count, member_active_rate, sod_item_count, sod_count, sodAvgPrice, sod_item_avg_price , member_sod_avg_count , register_amt, tmn_amt, profit_amt, round(	profit_amt / storeCount,2	) AS avgProfit, profit_rate1, round(agent_amt / storeCount, 2) AS avgAgent , refund_amt, refund_sod_item_count, refund_rate FROM (	SELECT z.*, (	SELECT count(1)	FROM	member_rec c	WHERE	c.MEMBER_PARENT_ID = Z.MEMBER_ID	AND c.MEMBER_TYPE = 3	) AS storeCount FROM (	SELECT m.MEMBER_ID, m.member_name, AGENT_ID, sum(sales_amt) AS total, sum(agent_amt) AS agent_amt, CONCAT( round( sum(agent_amt) / sum(sales_amt) * 100,2	),	'%'	) AS profit_rate,	sum(member_count) AS member_count, sum(member_sod_count) AS member_sod_count, CONCAT(	round( sum(member_sod_count) / sum(member_count) * 100, 2 ), '%' ) AS member_active_rate, sum(sod_item_count) AS sod_item_count, sum(sod_count) AS sod_count, round( sum(sales_amt) / sum(sod_count), 2 ) AS sodAvgPrice, round( sum(sales_amt) / sum(sod_item_count), 2 ) AS sod_item_avg_price, round( sum(sod_count) / sum(member_sod_count), 2 ) AS member_sod_avg_count, sum(register_amt) AS register_amt, sum(tmn_amt) AS tmn_amt, sum(profit_amt) AS profit_amt, CONCAT( round( sum(profit_amt) / sum(sales_amt) * 100, 2 ), '%' ) AS profit_rate1, sum(refund_amt) AS refund_amt, sum(refund_sod_item_count) AS refund_sod_item_count, CONCAT( round( sum(refund_sod_item_count) / sum(sod_item_count) * 100, 2 ), '%' ) AS refund_rate FROM dim_store_reports LEFT JOIN member_rec m ON m.MEMBER_ID = AGENT_ID "
    groupSql = "GROUP BY agent_id ORDER BY total desc ) z	) y"
    if seacheNameParam == None:
        mySql = mySql + whereSql + groupSql
    else:
        likeSql = " AND m.member_name like '%%%s%%' " % (seacheNameParam)
        mySql = mySql + whereSql + likeSql + groupSql
    temp = " limit %d,%d" % (startLimitNum, int(pageSzie))
    cursor = connections['slave'].cursor()
    cursor.execute(mySql + temp)
    jsonItme = cursor.fetchall()
    desc = cursor.description
    cursor.close()

    totalPage = int(dataTotal) / int(pageSzie)
    if (int(dataTotal) % int(pageSzie)) > 0:
        totalPage = totalPage + 1
    items = ['{"total":%s,"totalPage":%s,"rows":' % (dataTotal, str(totalPage))]
    li = []
    for item in jsonItme:
        repoerItem = {}
        i = 0
        for de in desc:
            if isinstance(item[i], Decimal):
                repoerItem[de[0]] = str(item[i])
            else:
                repoerItem[de[0]] = item[i]
            i = i + 1
        li.append(repoerItem)
    items.append(json.dumps(list(li)))
    items.append('}')
    return HttpResponse(items, content_type="application/json")

@csrf_exempt
@need_login
def agentReport(request):
    dic = {'agentId': request.GET.get('agentId')}
    return render_to_response("agentdata/agentReport.html", dic)

@csrf_exempt
@need_login
def agentReportJson(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    agentId = request.GET.get('agentId')
    start = request.GET.get('start')
    end = request.GET.get('end')
    pageSzie = request.GET.get('size')
    pageNo = request.GET.get('pageNo')
    cursorA = connections['slave'].cursor()
    totalSql = "SELECT ID FROM dim_store_reports LEFT JOIN member_rec m ON  m.MEMBER_ID=AGENT_ID "
    whereSql = " WHERE "
    totalGroupSql = " GROUP BY dim_store_reports.member_id"
    if start == None:
        whereSql = whereSql + " report_date <= '%s' " % (end)
    else:
        whereSql = whereSql + "report_date >= '%s' AND report_date <= '%s'" % (start, end)
    if agentId != None:
        whereSql = whereSql + " AND agent_id = '%d' " % (int(agentId))
    if seacheNameParam != None:
        likeSql = " AND store_name like '%%%s%%' " % (seacheNameParam)
        totalSql = totalSql + whereSql + likeSql + totalGroupSql
    else:
        totalSql = totalSql + whereSql + totalGroupSql
    cursorA.execute(totalSql)
    jsonItme = cursorA.fetchall()
    dataTotal = str(len(jsonItme))
    cursorA.close()

    startLimitNum = int(pageSzie) * (int(pageNo) - 1)
    mySql = "SELECT store_name,member_name,agent_id,sum(sales_amt) as total,sum(agent_amt) as agent_amt,CONCAT(IFNULL(round(sum(agent_amt)/sum(sales_amt)*100,2),0),'%') as profit_rate,sum(member_count) as member_count,sum(member_sod_count) as member_sod_count,CONCAT(IFNULL(round(sum(member_sod_count)/sum(member_count)*100,2),0),'%') as member_active_rate,sum(sod_item_count) as sod_item_count,sum(sod_count) as sod_count,IFNULL(round(sum(sales_amt)/sum(sod_count),2),0) as sodAvgPrice,IFNULL(round(sum(sales_amt)/sum(sod_item_count),2),0) as sod_item_avg_price ,IFNULL(round(sum(sod_count)/sum(member_sod_count),2),0) as  member_sod_avg_count ,sum(register_amt) as register_amt,sum(tmn_amt) as tmn_amt,sum(profit_amt) as profit_amt,CONCAT(IFNULL(round(sum(profit_amt)/sum(sales_amt)*100,2),0),'%') as profit_rate1,sum(refund_amt) as refund_amt,sum(refund_sod_item_count) as refund_sod_item_count,CONCAT(IFNULL(round(sum(refund_sod_item_count)/sum(sod_item_count)*100,2),0),'%') as refund_rate FROM dim_store_reports LEFT JOIN member_rec m ON  m.MEMBER_ID=dim_store_reports.MEMBER_ID"
    likeSql = ""
    groupSql = " GROUP BY dim_store_reports.member_id ORDER BY total desc "
    if agentId != None:
        whereSql = whereSql + " AND agent_id = '%d' " % (int(agentId))
    if seacheNameParam != None:
        likeSql = " AND store_name like '%%%s%%' " % (seacheNameParam)
    mySql = mySql + whereSql + likeSql + groupSql
    temp = " limit %d,%d" % (startLimitNum, int(pageSzie))
    cursor = connections['slave'].cursor()
    cursor.execute(mySql + temp)
    jsonItme = cursor.fetchall()
    desc = cursor.description

    totalPage = int(dataTotal) / int(pageSzie)
    if (int(dataTotal) % int(pageSzie)) > 0:
        totalPage = totalPage + 1
    items = ['{"total":%s,"totalPage":%s,"rows":' % (dataTotal, str(totalPage))]
    li = []
    for item in jsonItme:
        repoerItem = {}
        i = 0
        for de in desc:
            if isinstance(item[i], Decimal):
                repoerItem[de[0]] = str(item[i])
            else:
                repoerItem[de[0]] = item[i]
            i = i + 1
        li.append(repoerItem)
    items.append(json.dumps(list(li)))
    items.append('}')
    return HttpResponse(items, content_type="application/json")

#导出代理商明细
@csrf_exempt
@need_login
def agentExportJson(request):
    seacheNameParam = request.GET.get('seacheNameParam')
    agentId = request.GET.get('agentId')
    start = request.GET.get('start')
    end = request.GET.get('end')
    cursorA = connections['slave'].cursor()
    totalSql = "SELECT store_name,MEMBER_NAME, sum(sales_amt) as total ,CONCAT(IFNULL(round(sum(agent_amt)/sum(sales_amt)*100,2),0),'%') as profit_rate, sum(member_count) as member_count, sum(member_sod_count) as member_sod_count, CONCAT(round(sum(member_sod_count)/sum(member_count)*100,2),'%') as member_active_rate, sum(sod_item_count) as sod_item_count, sum(sod_count) as sod_count, round(sum(sales_amt)/sum(sod_count),2) as sodAvgPrice, round(sum(sales_amt)/sum(sod_item_count),2) as sod_item_avg_price , round(sum(sod_count)/sum(member_sod_count),2) as  member_sod_avg_count , sum(register_amt) as register_amt, sum(tmn_amt) as tmn_amt, sum(profit_amt) as profit_amt, sum(refund_amt) as refund_amt, sum(refund_sod_item_count) as refund_sod_item_count, 	CONCAT(round(sum(refund_sod_item_count)/sum(sod_item_count)*100,2),'%') as refund_rate FROM dim_store_reports LEFT JOIN member_rec m ON  m.MEMBER_ID=dim_store_reports.MEMBER_ID  "
    whereSql = " WHERE "
    totalGroupSql = " GROUP BY dim_store_reports.member_id"
    if start == None:
        whereSql = whereSql + " report_date <= '%s' " % (end)
    else:
        whereSql = whereSql + "report_date >= '%s' AND report_date <= '%s'" % (start, end)
    if agentId != None:
        whereSql = whereSql + " AND agent_id = '%d' " % (int(agentId))
    if seacheNameParam != None:
        likeSql = " AND store_name like '%%%s%%' " % (seacheNameParam)
        totalSql = totalSql + whereSql + likeSql + totalGroupSql
    else:
        totalSql = totalSql + whereSql + totalGroupSql
    cursorA.execute(totalSql)
    row_all = cursorA.fetchall()
    cursorA.close()

    _lst = []
    _lst.extend(row_all[:])
    _lst.insert(0, ['店铺名称','店主名称','零售总额','利润率','新注册客户数','下单客户','活跃率','销售件数','销售单数','客单价','件单价','客件数','拓客收入','销售收入','利润','退款金额','退款件数','退款率'])

    book = xlwt.Workbook(encoding='utf8')
    sheet = book.add_sheet('untitled')

    for row, rowdata in enumerate(_lst):
        for col, val in enumerate(rowdata):
            sheet.write(row, col, val, style=xlwt.Style.default_style)

    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=代理商统计导出.xls'
    book.save(response)
    return response

#区域经理添加数据管理---跳转列表页面
@csrf_exempt
@need_login
def areaManagerList(request):
      dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
      return render_to_response("agentdata/areaManagerList.html",dic)

#资源信息信息列表展示
@csrf_exempt
@need_login
def areaManagerJson(request):
    nameParam = request.GET.get('nameParam')
    if nameParam != None:
	   areaManager = getPaginator(UserAgent.objects.filter(user_code__icontains=nameParam).order_by('-id'),request)
    else:
	   areaManager = getPaginator(UserAgent.objects.filter().order_by('-id'),request)
    items = ['{"total":%d,"totalPage":%d,"rows":['%(areaManager.paginator.count,areaManager.paginator.num_pages)]
    for areaManagers in areaManager:
     items.append('{"id":"%s","user_id":"%s","user_code":"%s","agent_id":"%s","create_time":"%s"},'%(areaManagers.id,areaManagers.user_id,areaManagers.user_code,areaManagers.agent_id,areaManagers.create_time))
    items.append(']}')
    jsonstr = ''.join(items)
    jsonlen = len(jsonstr)
    if areaManager.paginator.count == 0:
        jsonstr = jsonstr[:jsonlen - 2] + jsonstr[jsonlen - 2:]
    else:
        jsonstr = jsonstr[:jsonlen - 3] + jsonstr[jsonlen - 2:]
    return HttpResponse(jsonstr,content_type="application/json")

# 区域经理新增信息跳转页面
@need_login
def areaManagerAdd(request):
    return render_to_response("agentdata/areaManagerAdd.html")

# 新增区域经理数据
@csrf_exempt
@need_login
def areaManagerSave(request):
    if request.method == 'POST':
        # c={}
        # 新增角色表信息
        userId = request.POST.get('userId')
        userCode = request.POST.get('userCode')
        agentId = request.POST.get('agentId')
        create_time= time.strftime('%Y-%m-%d %H:%M:%S')
        areaItems = UserAgent(user_id=userId,user_code=userCode,agent_id=agentId,create_time=create_time)
        areaItems.save()
    return render_to_response("agentdata/areaManagerList.html")

# 区域经理修改信息跳转页面
@csrf_exempt
@need_login
def areaManagerUpdate(request):
    dic = {'Id': request.GET.get('Id'), 'userId': request.GET.get('userId'),
           'userCode': request.GET.get('userCode'), 'agentId': request.GET.get('agentId')}
    return render_to_response("agentdata/areaManagerUpdate.html",dic)

# 修改资源信息
@csrf_exempt
@need_login
def areaManagerInsert(request):
    # c={}
    # 根据资源名查询资源信息对该资源信息进行修改()
    userId = request.GET.get('userId')
    userCode = request.GET.get('userCode')
    agentId = request.GET.get('agentId')
    modify_time= time.strftime('%Y-%m-%d %H:%M:%S')
    Id  = request.GET.get('Id')
    areaRe = UserAgent.objects.get(id=int(Id))
    # 修改资源表信息
    areaRe.user_id = userId
    areaRe.user_code = userCode
    areaRe.agent_id = agentId
    areaRe.modify_time = modify_time
    areaRe.save()
    return render_to_response("agentdata/areaManagerList.html")

#删除区域经理信息
@csrf_exempt
@need_login
def areaManagerDelete(request):
    ids = request.GET["resourceId"]
    UserAgent.objects.filter(id=ids).delete()
    return render_to_response('agentdata/areaManagerList.html',context_instance=RequestContext(request))

#经纪人统计管理---跳转列表页面
@csrf_exempt
@need_login
def agentCountList(request):
      dic = {'id': request.GET.get('id'),'userID':request.GET.get('userID')}
      return render_to_response("agentdata/agentCountList.html",dic)

#经纪人统计加载数据
@csrf_exempt
@need_login
def agentCountJson(request):
    startdata = request.GET.get('start')
    enddata = request.GET.get('end')
    #-----开始判断前端传的参数是否为空--------
    start_sql=end_sql=""
    if startdata:
        start_sql = " where CONVERT(STORE_CHECK_TIME,DATE) >= '%s'" % datetime.datetime.strptime(startdata,'%Y-%m-%d')

    if enddata:
        end = enddata + " 23:59:59"
        end_sql = " and CONVERT(STORE_CHECK_TIME,DATE) <= '%s' " % datetime.datetime.strptime(end,'%Y-%m-%d %H:%M:%S')

    whereSql = start_sql + end_sql
    #查询拆单信息
    mySql = '''
              select sum(if(STORE_TYPE = 2 and STORE_FLG = 3 and STORE_ONLINE_TYPE = 1, 1, 0)) store_count1 ,
             sum(if(STORE_TYPE = 2 and STORE_FLG = 3 and STORE_ONLINE_TYPE = 2, 1, 0)) store_count2 ,
             sum(if(STORE_TYPE =2 and STORE_FLG = 3 and (STORE_ONLINE_TYPE =1 or STORE_ONLINE_TYPE = 2), 1, 0)) as total,
              sum(if(STORE_TYPE = 3 and STORE_FLG = 3 and STORE_IS_BROKER =1 and STORE_ONLINE_TYPE = 1, 1, 0)) store_count3 ,
              sum(if(STORE_TYPE = 3 and STORE_FLG = 3 and STORE_IS_BROKER =1 and STORE_ONLINE_TYPE = 2, 1, 0)) store_count4 ,
              sum(if(STORE_TYPE =3 and STORE_FLG = 3 and STORE_IS_BROKER =1 and (STORE_ONLINE_TYPE =1 or STORE_ONLINE_TYPE = 2), 1, 0)) as total2 from store_rec  %s
            ''' % (whereSql)
    #执行sql
    cursorA = connections['slave'].cursor()
    cursorA.execute(mySql)
    jsonItem = cursorA.fetchall()
    desc = cursorA.description
    cursorA.close()
    #调用分页器
    user = getPaginator(jsonItem, request)
    # ----------------封装数据--------------------
    result = {}
    result["total"] = user.paginator.count
    result["totalPage"] = user.paginator.num_pages
    rows = []
    TAG=[]
    for de in desc:
        TAG.append(de[0])
    for u in user:
        #zip方法会把几个相同长度的元祖或列表一一对应起来
        obj = dict(zip(TAG,u))
        rows.append(obj)
    result["rows"] = rows
    return HttpResponse(json.dumps(result,cls=DjangoJSONEncoder), content_type="application/json")

def getPaginator(objs, request):
    paginator = Paginator(objs, request.GET.get('size'))
    try:
        result = paginator.page(request.GET.get('pageNo'))
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result
