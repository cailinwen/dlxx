<?php
namespace RequireJs;

use Zend\Stdlib\ArrayUtils;

class Module
{

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . str_replace('\\', '/', __NAMESPACE__)
                )
            )
        );
    }

    public function getConfig()
    {
        $config = array();
        $configFiles = array(
            __DIR__ . '/config/module.config.php',
            __DIR__ . '/config/module.service.config.php',
            __DIR__ . '/config/module.requirejs.config.php'
        );
        foreach ( $configFiles as $configFile ) {
            $config = ArrayUtils::merge($config, include $configFile);
        }
        return $config;
    }

    public function onBootstrap($mvcEvent)
    {
        $app = $mvcEvent->getApplication();
        $em = $app->getEventManager()->getSharedManager();
        $sm = $mvcEvent->getApplication()->getServiceManager();
        
        $em->attach('*', 'render', function ($dispatchEvent) use($sm)
        {
            $requireJsPlugin = $sm->get('ControllerPluginManager')
                ->get('requireJs');
            $loadedModules = $requireJsPlugin->getLoadedJs();
            $requiredFiles = $requireJsPlugin->loadModules($loadedModules);
            
            $javascriptPlugin = $sm->get('ControllerPluginManager')
                ->get('javascript');
            $requireJs['config'] = $requiredFiles;
            $requireJs['loadedModules'] = $loadedModules;
            $javascriptPlugin->addSettings(compact('requireJs'));
            $javascriptPlugin->appendScripts();
            $conditional = 'lt IE 9';
            $headScriptPlugin = $sm->get('viewHelperManager')
                ->get('headScript');
            $headScriptPlugin()->appendFile('/js/vendor/html5.js', 'text/javascript', compact('conditional'));
            $headScriptPlugin()->appendFile('/js/vendor/requireJs/require.js');
            $headScriptPlugin()->appendFile('/js/vendor/requireJs/require-main.js', 'text/javascript');
        });
    }
}