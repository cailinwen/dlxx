<?php
/**
 * 
 * Featee
 * 
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * 
*/
return array(
    'requireJs' => array(
        
        // 'urlArgs' => uniqid(),
        
        // By default load any module IDs from js/lib
        'baseUrl' => '/js/',
        // 'priority' => array('jquery'),
        // except, if the module ID starts with "app", load it
        // from the js/app directory. paths config is relative to
        // the baseUrl, and never includes a ".js" extension
        // since the paths config could be for a directory.
        
        'paths' => array(
            'jquery' => 'vendor/jquery-2.1.3.min',
            'JqueryAutosize' => 'vendor/jquery.autosize',
            'JqueryFacebox' => 'vendor/facebox',
            'Translation' => 'translation/translation',
            'Dimzou' => 'dimzou/dianzou',
            'Header' => 'inc/header',
            'DZAudit' => 'dimzou/dz-audit'
        ),
        // load non-AMD
        'shim' => array(
            'JqueryAutosize' => array(
                'deps' => array('jquery'),
                'exports' => 'JqueryAutosize'
            ),
            'JqueryFacebox' => array(
                'deps' => array('jquery'),
                'exports' => 'JqueryFacebox'
            ),
        ),
        'waitSeconds' => 0,
        'global' => array()
    )
);
