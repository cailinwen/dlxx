<?php
/**
 * 
 * Featee
 * 
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * 
*/
return array(
    'service_manager' => array(
        'invokables' => array(
    	       'requireJs_service' => 'RequireJs\Service\RequireJs'
        ),
    )
);
