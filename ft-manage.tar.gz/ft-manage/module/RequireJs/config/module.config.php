<?php 
return array(
    'controller_plugins' => array(
    		'invokables' => array(
    		    'requireJs' => 'RequireJs\Plugin\RequireJs'
    		)
    ),
);