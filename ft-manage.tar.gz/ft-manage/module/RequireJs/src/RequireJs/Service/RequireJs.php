<?php
namespace RequireJs\Service; 

use Core\Service\AbstractService;

class RequireJs extends AbstractService
{

    static $config;
    static $instance = null;

    CONST BASEURL = 'baseUrl';
    CONST PATH = 'paths';
    CONST SHIM = 'shim';
    CONST DEPS = 'deps';
    CONST VGLOBAL = 'global';
    CONST EXPORTS = 'exports';
    CONST REQUIREJS = 'requireJs';
    
    protected $jsModules = array();
    
    protected $modulePreparePaths = array();
    
    public function __construct($config = array()){}

    public function run($config = array())
    {
        $cdnLinkBuilderContainer    = $this->getServiceLocator()->get('cdnLinkBuilderContainer');
        $cdnUri                     = $cdnLinkBuilderContainer->getUri('/js');
        $cdnUriArr                  = explode('?', $cdnUri);
        $baseUrl                    = array_shift($cdnUriArr);
        $default                    = self::defConf();
        $config[self::BASEURL]      = $baseUrl;
        self::$config               = $config ? array_replace_recursive($default, $config) : self::defConf();
    }

    public function defConf()
    {
        $config  = $this->getServiceLocator()->get('config');
        return isset($config[self::REQUIREJS]) ? $config[self::REQUIREJS] : array();
    }

    /**
     *
     * @param string | array $modules
     */
    public function loadModules($modules)
    {
        if (! is_array($modules)) {
            $modules = array($modules);
        }
        $this->run();
        $config = self::$config;
        $depsModules = array_keys($config[self::SHIM]);
        $deps = array();
        foreach ($modules as $moduleId) {
            if (isset($config[self::SHIM][$moduleId][self::DEPS])) {
                if (in_array($moduleId, $depsModules)) {
                    $deps = array_merge($config[self::VGLOBAL], $config[self::SHIM][$moduleId][self::DEPS]);
                    $config[self::SHIM][$moduleId][self::DEPS] = $deps;
                }  
            }
            else { 
                	$config[self::SHIM][$moduleId][self::DEPS]     = $config[self::VGLOBAL];
                	$config[self::SHIM][$moduleId][self::EXPORTS]  = $moduleId;
            }
            $deps = array_merge($deps, $config[self::SHIM][$moduleId][self::DEPS]);
        }
        
//         foreach (array_keys($config[self::PATH]) as $moduleId) {
//             if (! in_array($moduleId, $modules) && ! in_array($moduleId, $deps) && !in_array($moduleId, $this->getModulePreparePaths()))
//                 unset($config[self::PATH][$moduleId]);
//         } 
        
        return $config;
    }
    
    protected function getModulePreparePaths()
    {
    	   return $this->modulePreparePaths;
    }
    
    public function loadPaths($module)
    {
        $module = is_array($module) ? array($module) : $module;
        $this->modulePreparePaths = array_merge($this->modulePreparePaths, $module);
        return $this;
    }
    
    public function getScripts($modules) 
    {
        $config = $this->loadModules($modules);
        
        $script = 'requirejs.config(' . (string)json_encode($config) . ');';
        $script .= '__F(' . (string)json_encode($modules) . ', function(){})';
        return $script;
    }
    
    public function addJsModule($module, $loadFirst = false)
    {
        	if (! is_array($module)) $module = (array) $module;
        
        	$modules = $this->jsModules = $this->jsModules ?
        	   ($loadFirst ? array_merge($module, $this->jsModules) :
        			array_merge($this->jsModules, $module)) : $module;
        
        	return $modules;
    }
    
    public function getLoadedJs()
    {
     	return $this->jsModules;
    }
    
    /**
     * load files by requiredJS
     * 
     * @param array $module
     */
    public function loadRequiredFiles($module, $loadFirst = true)
    {
        return $this->addJsModule($module, $loadFirst);
    }
}