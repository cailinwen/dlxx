<?php
namespace RequireJs\Plugin; 

use Zend\Mvc\Controller\Plugin\AbstractPlugin;

class RequireJs extends AbstractPlugin
{
    protected $requireJs;
    
    protected $serviceLocator;
    
    function __call($method, $params) 
    {
        $requireJsService = $this->requireJs();
        $classMethod = array($requireJsService, $method);
        
        if(is_callable($classMethod)) {
        	   $callback = call_user_func_array($classMethod, $params);
        	   return $callback;
        }
    }
    
    function requireJs()
    {
        if (null === $this->requireJs && $this->getServiceLocator()) {
            $this->requireJs = $this->getServiceLocator()->get('requireJs_service');
        }
        return $this->requireJs;
    }
    
    function getServiceLocator() 
    {
        if(null === $this->serviceLocator && $this->getController()) 
        {
            $this->serviceLocator = $this->getController()->getServiceLocator();
        }
        return $this->serviceLocator;
    }
}