<?php
namespace AccountAdmin\Controller;

use Core\Controller\AbstractBaseCoreController;

class AccountAdminModuleBaseController extends AbstractBaseCoreController
{

    /**
     *
     * @var \AccountAdmin\Service\AccountAdminService
     */
    private $accountAdminService;

    /**
     *
     * @return the $accountAdminService
     */
    protected function getAccountAdminService()
    {
        if ( ! $this->accountAdminService ) {
            $this->accountAdminService = $this->getServiceLocator()->get('AccountAdminService');
        }
        return $this->accountAdminService;
    }
}