<?php
namespace AccountAdmin\Controller;

use Zend\View\Model\ViewModel;

class LoginController extends AccountAdminModuleBaseController
{

    public function loginAction()
    {
        if ( $this->loginUser ) {
            if ( $this->loginUser['level'] < 3 ) {
                return $this->redirect()->toRoute('dimzou-audit', array(
                    'action' => 'pendingAll'
                ));
            } else {
                return $this->redirect()->toRoute('category');
            }
        }
        $this->layout('layout/login');
        $view = new ViewModel();
        $view->setTemplate('account-admin/login.phtml');
        return $view;
    }

    public function authAction()
    {
        $this->exitNonXmlHttpRequest();
        $user = self::getSessionUser();
        $username = $this->getParam('username');
        $password = $this->getParam('password');
        $user = $this->getAccountAdminService()->login($username, $password);
        if ( ! $user ) {
            return self::createJsonView(0, $user, 'Failed');
        }
        $user = $this->getSessionUser();
        if ( $user['level'] < 3 ) {
            $redirectUrl = $this->baseUrl(true) . '/dimzou/audit/pendingAll';
        } else {
            $redirectUrl = $this->baseUrl(true) . '/category';
        }
        
        return self::createJsonView(1, $redirectUrl, 'Successed');
    }

    public function logoutAction()
    {
        if ( ! $this->loginUser ) {
            return $this->redirect()->toRoute('home');
        }
        $session = $this->getSessionManage();
        setcookie(session_name(), '', time() - 4200, '/');
        $session->getManager()->destroy();
        return $this->redirect()->toRoute('home');
    }

    public function signUpAction()
    {
        $username = $this->getParam('uname');
        $password = $this->getParam('pwd');
        $user_id = $this->getAccountAdminService()->regUser($username);
        return self::createJsonView($user_id ? 1 : 0, '', $user_id ? 'Successed' : 'Error');
    }
}