<?php
namespace AccountAdmin\Service;

use Core\Service\AbstractService;

class AccountAdminModuleBaseService extends AbstractService
{

    /**
     *
     * @var \AccountAdmin\Mapper\AccountAdminMapper
     */
    private $accountAdminMapper;

    /**
     *
     * @return the $accountAdminMapper
     */
    protected function getAccountAdminMapper()
    {
        if ( ! $this->accountAdminMapper ) {
            $this->accountAdminMapper = $this->getServiceLocator()->get('AccountAdminMapper');
        }
        return $this->accountAdminMapper;
    }
}