<?php
/**
 * Featee This is not a free software, unauthorized use is prohibited.
 *
 * @copyright Copyright © 2010－2015. Feat Technologies. All Rights Reserved.
 */
namespace AccountAdmin\Service;

use Zend\Crypt\Password\Bcrypt;
use Core\Controller\Plugin\Encryption;

/**
 *
 * @author parduswu
 */
class AccountAdminService extends AccountAdminModuleBaseService
{

    /**
     * 用户登录验证
     *
     * @param string $username            
     * @param string $password            
     * @return boolean
     */
    public function login( $username, $password )
    {
        $uInfo = $this->getAccountAdminMapper()->getAdminUser($username);
        if ( empty($uInfo) ) {
            return false;
        }
        $bcrypt = new Bcrypt();
        if ( ! $bcrypt->verify($password, $uInfo['upassword']) ) {
            return false;
        }
        self::setSessionUser($uInfo);
        $session = $this->getSessionManage();
        return true;
    }

    public function regUser( $username, $password = '123123' )
    {
        $data['username'] = $username;
        if ( $this->getAccountAdminMapper()->existUsername($username) ) {
            throw new \Exception('The username has exist');
        }
        $bcrypt = new Bcrypt();
        $data['upassword'] = $bcrypt->create($password);
        $data['level'] = 3;
        return $this->getAccountAdminMapper()->regUser($data);
    }
    
    ///////////////////////////////////////////////////////////////////////////
    public function getCurrentEnableUserInfo( $country, $level )
    {
        return $this->getAccountAdminMapper()->getCurrentEnableUserInfo($country, $level);
    }

    public function getUserLoginRecord( $r_user_id, $limit, $offset )
    {
        return $this->getAccountAdminMapper()->getUserLoginRecord($r_user_id, $limit, $offset);
    }

    public function handleHadExpSessions()
    {
        $sessions = $this->getAccountAdminMapper()->getHadExpSessions(); // 已过期的session
        $sids = array();
        foreach ( $sessions as $sess ) {
            $sids[] = $sess['id'];
        }
        if ( empty($sids) ) {
            return true;
        }
        $unLogoutRecords = $this->getAccountAdminMapper()->getUnLogoutRecord($sids);
        $flipSids = array_flip($sids);
        if ( ! empty($unLogoutRecords) ) {
            foreach ( $unLogoutRecords as $record ) {
                foreach ( $sessions as $sval ) {
                    if ( $record['session_id'] == $sval['id'] ) {
                        $data['updated'] = $data['logout_time'] = $sval['modified'] + $sval['lifetime'];
                        $this->getAccountAdminMapper()->logoutRecord($data, $record['session_id']);
                        unset($flipSids[$record['session_id']]);
                    }
                }
            }
        }
        if ( ! empty($flipSids) ) {
            $this->getAccountAdminMapper()->multiDeletHadExpSessions(array_flip($flipSids));
        }
        return true;
    }

    /**
     * 验证用户名是否存在（唯一）
     *
     * @param string $username            
     * @return boolean
     */
    public function existUserName( $username )
    {
        $result = $this->getAccountAdminMapper()->getRegulatoryUses($username, array(
            'username'
        ), 'status<>3');
        if ( $result ) {
            return false;
        }
        return true;
    }

    /**
     * 所有下属用户
     *
     * @param string $country            
     * @param number $level            
     * @param string $status            
     * @return array
     */
    public function getSubRegulatoryUsersBy( $country, $level, $status = 'status!=0' )
    {
        if ( empty($country) || empty($level) || empty($status) ) {
            throw new \Exception('参数错误');
        }
        return $this->getAccountAdminMapper()->getSubRegulatoryUsersBy($country, $level, $status);
    }

    /**
     * 保存登录或登出记录
     *
     * @param string $session_id            
     * @param string $actionType            
     * @param number $r_user_id            
     * @throws \Exception
     * @return boolean | number
     */
    public function saveLoginOrLogoutRecord( $session_id, $actionType = '', $r_user_id = 0 )
    {
        if ( $actionType == 'login' ) {
            $data['r_user_id'] = $r_user_id ? $r_user_id : self::getSessionUserId();
            $data['session_id'] = $session_id;
            $data = array_merge($data, $this->clientInfoFormat());
            $res = $this->getAccountAdminMapper()->loginRecord($data);
        } elseif ( $actionType == 'logout' ) {
            $data['updated'] = $data['logout_time'] = self::getCurrentTime();
            $res = $this->getAccountAdminMapper()->logoutRecord($data, $session_id);
        } else {
            throw new \Exception('参数错误');
        }
        return $res;
    }

    /**
     * 格式化客户端信息表信息
     *
     * @param string $resolution
     *            分辨率
     * @return array
     */
    private function clientInfoFormat( $resolution = '' )
    {
        $clientInfo = $this->plugin('getClientSystem');
        $clientInfo = $clientInfo->getClientData();
        $clientInfo['access_lang'] = $_COOKIE['cel_language'];
        $clientInfo['resolution'] = isset($_COOKIE['w']) ? $_COOKIE['w'] : $resolution;
        return $clientInfo;
    }

    /**
     * 启用(授权)新用户
     *
     * @param number $r_user_id            
     * @return boolean
     */
    private function enableUser( $r_user_id )
    {
        $adminUser = self::getSessionUser();
        $enableSubUsers = $this->getAccountAdminMapper()->getSubRegulatoryUsersBy($adminUser['country'], $adminUser['level'], 'status=1');
        $conn = $this->getAccountAdminMapper()
            ->getDbAdapter()
            ->getDriver()
            ->getConnection();
        $conn->beginTransaction();
        if ( $enableSubUsers ) {
            $r_user_ids = array();
            foreach ( $enableSubUsers as $users ) {
                $r_user_ids[] = $users['r_user_id'];
            }
            if ( ! $this->getAccountAdminMapper()->disableRegulatoryMultiUsers(join(',', $r_user_ids)) ) {
                $conn->rollback();
                return false;
            }
        }
        if ( ! $this->getAccountAdminMapper()->updateRegulatoryUser(array(
            'status' => 1
        ), $r_user_id) ) {
            $conn->rollback();
            return false;
        }
        $conn->commit();
        return true;
    }

    /**
     * 设置保存用户的状态
     *
     * @param number $r_user_id            
     * @param number $status            
     * @return boolean
     */
    public function saveUserStatus( $r_user_id, $status )
    {
        if ( $status == 2 ) {
            $result = $this->enableUser($r_user_id);
        } else {
            $result = $this->getAccountAdminMapper()->updateRegulatoryUser(compact('status'), $r_user_id);
        }
        return $result;
    }

    /**
     * 添加新用户
     *
     * @param string $username            
     * @param string $password            
     * @param string $mobile            
     * @param string $email            
     * @throws \Exception
     * @return boolean
     */
    public function addUser( $username, $password, $mobile = '', $email = '' )
    {
        if ( empty($username) || empty($password) ) {
            throw new \Exception('function=>' . __FUNCTION__ . ' param is error');
        }
        $conn = $this->getAccountAdminMapper()
            ->getDbAdapter()
            ->getDriver()
            ->getConnection();
        $conn->beginTransaction();
        $data['r_user_id'] = $this->getAccountAdminMapper()->getRUserId();
        $data['username'] = $username;
        $bcrypt = new Bcrypt();
        $data['r_password'] = $bcrypt->create($password);
        if ( ! empty($mobile) ) {
            $data['mobile'] = Encryption::encryption($data['r_user_id'], $mobile);
        }
        if ( ! empty($email) ) {
            $data['email'] = Encryption::encryption($data['r_user_id'], $email);
        }
        $data['status'] = 1;
        $data['level'] = 1;
        $adminUser = self::getSessionUser();
        if ( ! empty($adminUser) && $adminUser['pid'] == 0 && $adminUser['status'] == 1 ) {
            $data['pid'] = $adminUser['r_user_id'];
            $data['level'] = $adminUser['level'] + 1;
        }
        try {
            if ( ! $this->getAccountAdminMapper()->addRegulatoryUser($data) ) {
                $conn->rollback();
                return false;
            } else {
                $this->getAccountAdminMapper()->disableOtherMultiUsers($data['r_user_id']);
            }
        } catch ( \Exception $e ) {
            $conn->rollback();
            throw new \Exception($e->getMessage());
        }
        $conn->commit();
        return true;
    }
}