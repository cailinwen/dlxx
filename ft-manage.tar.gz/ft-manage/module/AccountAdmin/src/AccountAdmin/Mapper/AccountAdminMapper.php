<?php
/**
 * Featee This is not a free software, unauthorized use is prohibited.
 *
 * @copyright Copyright © 2010－2015. Feat Technologies. All Rights Reserved.
 */
namespace AccountAdmin\Mapper;

use Zend\Db\Adapter\Adapter;

/**
 *
 * @author parduswu
 */
class AccountAdminMapper extends AccountAdminModuleBaseMapper
{

    /**
     * 通过唯一用户名获取信息
     *
     * @param string $username            
     * @return array
     */
    public function getAdminUser( $username, $fields = array(), $status = 'status=1' )
    {
        $sql = $this->getSql()->setTable('ft_admin_users');
        $select = $sql->select();
        if ( ! empty($fields) ) {
            $select->columns($fields);
        }
        $select->where->equalTo('username', $username);
        if ( ! empty($status) ) {
            $select->where($status);
        }
        $select->limit(1);
        $result = $this->getAdminDbAdapter()
            ->query($sql->getSqlStringForSqlObject($select), Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
        return self::singleRow($result);
    }

    public function regUser( $data )
    {
        $data['created'] = $data['updated'] = $_SERVER['REQUEST_TIME'];
        return $this->dbInsert(self::BACKSTAGE_ADMIN_USER_TAB, $data, true, $this->getAdminDbAdapter());
    }

    public function existUsername( $username )
    {
        $sql = $this->getSql()->setTable('ft_admin_users');
        $select = $sql->select();
        $select->columns(array(
            'user_id'
        ));
        $select->where->equalTo('username', $username);
        $select->limit(1);
        return $this->getAdminDbAdapter()
            ->query($sql->getSqlStringForSqlObject($select), Adapter::QUERY_MODE_EXECUTE)
            ->count();
    }
    
    ///////////////////////////////////////////////////////////////////////////
    public function getCurrentEnableUserInfo( $country, $level )
    {
        $sql = $this->getSql()->setTable('ft_regulatory_users');
        $select = $sql->select();
        $select->columns(self::$ruser_fields);
        $select->where->equalTo('country', $country)
            ->greaterThan('level', $level)
            ->equalTo('status', 1);
        $select->limit(1);
        $select->order('updated DESC');
        return $this->fetchOneRow($select, $sql);
    }

    public function getUserLoginRecord( $r_user_id, $limit, $offset )
    {
        $sql = $this->getSql()->setTable('ft_regulatory_users_login_record');
        $select = $sql->select();
        $select->where->equalTo('r_user_id', $r_user_id);
        $select->where->equalTo('status', 1);
        $select->limit($limit)->offset($offset);
        return $this->fetchAll($select, $sql);
    }

    /**
     * 插入登录记录
     *
     * @param array $data            
     * @return number
     */
    public function loginRecord( $data )
    {
        $data['created'] = $data['updated'] = $data['login_time'] = self::getCurrentTime();
        return $this->dbInsert('ft_regulatory_users_login_record', $data);
    }

    /**
     * 保存登出记录
     *
     * @param string $session_id            
     * @return number
     */
    public function logoutRecord( $data, $session_id )
    {
        $this->dbDelete('ft_regulatory_sessions', array(
            'id' => $session_id
        ));
        return $this->dbUpdate('ft_regulatory_users_login_record', $data, compact('session_id'));
    }

    public function multiDeletHadExpSessions( $sids )
    {
        $sql = $this->getSql()->setTable('ft_regulatory_sessions');
        $del = $sql->delete();
        $del->where->in('id', $sids);
        return $this->getDbAdapter()
            ->query($sql->getSqlStringForSqlObject($del), Adapter::QUERY_MODE_EXECUTE)
            ->count();
    }

    /**
     * 获取已过期的session
     *
     * @return multitype:array
     */
    public function getHadExpSessions()
    {
        $sql = $this->getSql()->setTable('ft_regulatory_sessions');
        $select = $sql->select();
        $select->where('(modified+lifetime)<' . self::getCurrentTime());
        return $this->fetchAll($select, $sql);
    }

    /**
     * 根据session,获取未有登出的记录
     *
     * @param array $sids            
     * @return multitype:array
     */
    public function getUnLogoutRecord( $sids )
    {
        $sql = $this->getSql()->setTable('ft_regulatory_users_login_record');
        $select = $sql->select();
        $select->where->in('session_id', $sids);
        $select->where->equalTo('logout_time', 0);
        $select->where->equalTo('status', 1);
        return $this->fetchAll($select, $sql);
    }

    /**
     * 禁用多个用户
     *
     * @param string $r_user_ids            
     * @return number
     */
    public function disableRegulatoryMultiUsers( $r_user_ids )
    {
        $updated = $_SERVER['REQUEST_TIME'];
        $sql = 'UPDATE ft_regulatory_users SET status=2,updated=' . $updated . ' WHERE r_user_id IN (' . $r_user_ids . ') AND status=1';
        return $this->getDbAdapter()
            ->query($sql, Adapter::QUERY_MODE_EXECUTE)
            ->count();
    }

    public function disableOtherMultiUsers( $r_user_id )
    {
        $loginUser = self::getSessionUser();
        $updated = $_SERVER['REQUEST_TIME'];
        $sql = 'UPDATE ft_regulatory_users SET status=2,updated=' . $updated . ' WHERE r_user_id<>' . $r_user_id . ' AND status=1 AND country=\'' . $loginUser['country'] . '\' AND pid<>0 AND level<>1 ';
        return $this->getDbAdapter()
            ->query($sql, Adapter::QUERY_MODE_EXECUTE)
            ->count();
    }

    /**
     * 修改用户信息
     *
     * @param array $data            
     * @param number $r_user_id            
     */
    public function updateRegulatoryUser( $data, $r_user_id )
    {
        $data['updated'] = $_SERVER['REQUEST_TIME'];
        return $this->dbUpdate('ft_regulatory_users', $data, compact('r_user_id'));
    }

    /**
     * 查询某国所有的用户（不包括管理员）
     *
     * @param string $country            
     * @param number $level            
     * @param string $status            
     * @return multitype:array
     */
    public function getSubRegulatoryUsersBy( $country, $level, $status = 'status!=0' )
    {
        $sql = $this->getSql()->setTable('ft_regulatory_users');
        $select = $sql->select();
        $select->columns(self::$ruser_fields);
        $select->where->notEqualTo('pid', 0);
        $select->where->equalTo('country', $country);
        $select->where->greaterThan('level', $level);
        $select->where($status);
        $select->order('status ASC , created DESC');
        return $this->fetchAll($select, $sql);
    }

    /**
     * 获取全局用户ID
     *
     * @return number
     */
    public function getRUserId()
    {
        $auto['table_name'] = 'ft_regulatory_users';
        $auto['field_name'] = 'r_user_id	';
        $auto['created'] = $_SERVER['REQUEST_TIME'];
        return $this->dbInsert(self::AUTO_IDS, $auto);
    }

    /**
     * 添加新用户
     *
     * @param array $data            
     * @return boolean
     */
    public function addRegulatoryUser( $data )
    {
        $data['created'] = $data['updated'] = $_SERVER['REQUEST_TIME'];
        return $this->dbInsert('ft_regulatory_users', $data, false);
    }
}