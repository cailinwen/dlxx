<?php
namespace AccountAdmin\Mapper;

use Core\DbMapper\AbstractDbMapper;

class AccountAdminModuleBaseMapper extends AbstractDbMapper
{}
