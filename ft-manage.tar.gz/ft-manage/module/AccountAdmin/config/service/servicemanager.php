<?php
/**
 *
 * Featee
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
return array(
    'invokables' => array(
        'AccountAdmin_Mapper_AccountAdmin' => 'AccountAdmin\Mapper\AccountAdminMapper',
        'AccountAdmin_Service_AccountAdmin' => 'AccountAdmin\Service\AccountAdminService'
    ),
    'aliases' => array(
        'AccountAdminMapper' => 'AccountAdmin_Mapper_AccountAdmin',
        'AccountAdminService' => 'AccountAdmin_Service_AccountAdmin'
    )
);