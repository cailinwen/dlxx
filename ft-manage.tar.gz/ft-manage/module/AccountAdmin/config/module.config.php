<?php
namespace AccountAdmin;

return array(
    'controllers' => array(
        'invokables' => array(
            'AccountAdmin\Controller\Login' => 'AccountAdmin\Controller\LoginController'
        ),
        'factories' => array()
    ),
    'view_manager' => array(
        'template_map' => array(
            'layout/login' => __DIR__ . '/../view/layout/login-layout.phtml',
            'layout/account-admin' => __DIR__ . '/../view/layout/account-admin-layout.phtml'
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view'
        )
    )
);
