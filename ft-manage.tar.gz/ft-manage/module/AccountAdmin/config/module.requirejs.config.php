<?php
/**
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
return array(
    'requireJs' => array(
        'urlArgs' => uniqid(),
        'paths' => array(
            'AdminAccount' => 'account-admin/adminLogin'
        )
    )
);
