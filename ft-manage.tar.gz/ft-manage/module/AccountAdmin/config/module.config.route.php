<?php
return array(
    'router' => array(
        'routes' => array(
            'login' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/login',
                    'defaults' => array(
                        'controller' => 'AccountAdmin\Controller\Login',
                        'action' => 'login'
                    )
                )
            ),
            'do-login' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/auth',
                    'defaults' => array(
                        'controller' => 'AccountAdmin\Controller\Login',
                        'action' => 'auth'
                    )
                )
            ),
            'reguser' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/sign-up',
                    'defaults' => array(
                        'controller' => 'AccountAdmin\Controller\Login',
                        'action' => 'signUp'
                    )
                )
            ),
            'logout' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/logout',
                    'defaults' => array(
                        'controller' => 'AccountAdmin\Controller\Login',
                        'action' => 'logout'
                    )
                )
            )
        )
    )
);

