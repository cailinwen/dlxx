<?php
/**
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2016. Feat Technologies. All Rights Reserved.
 */
return array(
    'invokables' => array(
        'Cache_Service_Cache' => 'Cache\Service\CacheService'
    ),
    'factories' => array(
        'Redis_Cache' => 'Cache\Redis\Service\Factory\RedisCacheFactory',
        'Filesystem_Cache' => 'Cache\Filesystem\Service\FilesystemCacheFactory'
    ),
    
    'aliases' => array(
        'cacheService' => 'Cache_Service_Cache'
    )
);