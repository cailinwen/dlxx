<?php
/**
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2016. Feat Technologies. All Rights Reserved.
 */
return array(
    'redis' => array(
        'host' => HOST_IP,
        'port' => '6379',
        'timeout' => 30,
        'namespace' => 'develop-featee'
    ),
    'filesystem' => array(
        'cache_dir' => './data/cache',
        'dir_level' => 1,
        'dir_permission' => 0755,
        'file_permission' => 0666,
        'namespaceSeparator' => '-db-'
    )
);
