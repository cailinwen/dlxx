<?php
namespace Cache\Service;

trait ProvideCacheTrait
{

    protected static $cacheList = array(
        'redis' => 'redis',
        'filesystem' => 'filesystem',
        'memcached' => 'memcached'
    );

    protected static function existCacheType( $type )
    {
        if ( ! array_key_exists($type, self::$cacheList) ) {
            throw new \ErrorException('invalid cache type');
        }
    }
}