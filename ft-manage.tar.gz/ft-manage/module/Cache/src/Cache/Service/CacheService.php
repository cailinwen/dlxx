<?php
/**
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2016. Feat Technologies. All Rights Reserved.
 */
namespace Cache\Service;

class CacheService extends \Core\Service\AbstractService
{

    protected $redis;

    protected $filesystem;

    protected $memcache;

    public function caches( $type = CACHE_TYPE_DEFAULT )
    {
        switch ( $type ) {
            case 'redis':
                if ( ! $this->redis ) {
                    $this->redis = $this->getServiceLocator()->get('Redis\Cache');
                }
                return $this->redis;
            case 'memcache':
                if ( ! $this->memcache ) {
                    $this->memcache = $this->getServiceLocator()->get('memcache_service');
                }
                return $this->memcache;
            case 'filesystem':
                if ( ! $this->filesystem ) {
                    $this->filesystem = $this->getServiceLocator()->get('Filesystem\Cache');
                }
                return $this->filesystem;
        }
    }
}