<?php
/**
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2016. Feat Technologies. All Rights Reserved.
 */
namespace Cache\Filesystem\Service;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Cache\Storage\Adapter\FilesystemOptions;
use Zend\Cache\Storage\Adapter\Filesystem;

class FilesystemCacheFactory implements FactoryInterface
{

    public function createService( ServiceLocatorInterface $serviceLocator )
    {
        $config = $serviceLocator->get('Config');
        $config = $config['filesystem'];
        $filesystem_options = new FilesystemOptions();
        $filesystem_options->setCacheDir($config['cache_dir']);
        $filesystem_options->setDirLevel($config['dir_level']);
        $filesystem_options->setDirPermission($config['dir_permission']);
        $filesystem_options->setFilePermission($config['file_permission']);
        $filesystem_options->setNamespaceSeparator($config['namespaceSeparator']);
        return new Filesystem($filesystem_options);
    }
}