<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Category\Controller\Index' => 'Category\Controller\IndexController'
        )
    ),
    'service_manager' => array(
        'invokables' => array(
            'categoryDbMapper' => 'Category\Mapper\CategoryDbMapper',
            'categoryService' => 'Category\Service\CategoryService'
        ),
        'factories' => array(),
        'aliases' => array()
    ),
    'router' => array(
        'routes' => array(
            'category' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/category',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Category\Controller',
                        'controller' => 'Index',
                        'action' => 'index'
                    )
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'genel' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '[/:action]',
                            'constraints' => array(
                                'action' => '[a-zA-Z_-]*'
                            ),
                            'defaults' => array(
                                'controller' => 'Category\Controller\Index'
                            )
                        )
                    )
                )
            )
        )
    ),
    'view_manager' => array(
        'template_map' => array(
            'category-layout' => __DIR__ . '/../view/layout/category-layout.phtml'
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view'
        )
    )
);
