<?php
/**
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
return array(
    'requireJs' => array(
        'urlArgs' => uniqid(),
        'paths' => array(
            'Category' => 'category/category',
            "jquery.bootstrap" => "vendor/bootstrap",
            'bootstrap.switch' => 'vendor/bootstrap-switch/js/bootstrap-switch'
        ),
        'shim' => array(
            'bootstrap.switch' => [
                'deps' => [
                    'jquery'
                ]
            ],
            "jquery.bootstrap" => [
                'deps' => [
                    "jquery"
                ]
            ]
        )
    )
);
