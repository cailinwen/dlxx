<?php
namespace Category\Service;

use Core\Service\AbstractService;

class CategoryModuleBaseService extends AbstractService
{

    /**
     *
     * @var \Category\Mapper\CategoryDbMapper
     */
    private $categoryDbMapper;

    /**
     *
     * @return the $categoryDbMapper
     */
    protected function getCategoryDbMapper()
    {
        if ( ! $this->categoryDbMapper ) {
            $this->categoryDbMapper = $this->getServiceLocator()->get('categoryDbMapper');
        }
        return $this->categoryDbMapper;
    }
}