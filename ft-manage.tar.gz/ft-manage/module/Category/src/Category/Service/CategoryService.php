<?php
namespace Category\Service;

use Zend\Db\Adapter\Driver\Pdo\Connection;

class CategoryService extends CategoryModuleBaseService
{

    public function getUnAuditCount( $code = [] )
    {
        return $this->getCategoryDbMapper()->getUnAuditCount($code);
    }

    public function getMaxNumberCodeAndSortOrder()
    {
        return $this->getCategoryDbMapper()->getMaxNumberCodeAndSortOrder();
    }

    public function getJoinNodes( $where )
    {
        return $this->getCategoryDbMapper()->getJoinNodes($where);
    }

    public function updateCategoryStructure( $data, $where )
    {
        return $this->getCategoryDbMapper()->updateCategoryStructure($data, $where);
    }

    public function getCategoriesStructure( $where, $isMultiRows = true )
    {
        return $this->getCategoryDbMapper()->getCategoriesStructure($where, $isMultiRows);
    }

    public function editCategoryName( $code, $new_name, $old_name, $adminUserId )
    {
        $needAudit = false;
        if ( ! $needAudit ) {
            $res = $this->getCategoryDbMapper()->updateCategoryTitle(array(
                'description' => $new_name
            ), compact('code'));
            $status = 1;
        } else {
            $status = 2;
        }
        $data = array(
            'admin_user_id' => $adminUserId,
            'do_action' => 'edit name',
            'code' => $code,
            'origin_content' => $old_name,
            'new_content' => $new_name,
            'status' => $status
        );
        return $this->getCategoryDbMapper()->addCategoryOpRecord($data);
    }

    /**
     * 删除分类
     *
     * @param string $code            
     * @param int $level            
     * @return boolean
     */
    public function deleteCategory( $code, $level )
    {
        $conn = $this->getCategoryDbMapper()
            ->getDbAdapter()
            ->getDriver()
            ->getConnection();
        $conn->beginTransaction();
        // 删除后，删除(不通过审核)其（本身和子类以及孙类）所有的拖动动作和修改动作
        $this->handleInsAuditNo($level, $code);
        // 删除本身和子类孙类
        $res = $this->handleSelfAndLowerNodes($code, $level, 'update');
        if ( ! $res ) {
            $conn->rollback();
            return false;
        }
        $conn->commit();
        return $res;
    }

    /**
     * 格式化创建新的分类数据
     *
     * @param int $codeLevel            
     * @param string $name            
     * @param string $pcode            
     * @param number $adminUserId            
     * @param array $options            
     * @return boolean|array
     */
    private function createNewCategory( $codeLevel, $name, $pcode = '', $adminUserId = 0, $user_id = 0, $options = [] )
    {
        $maxNumberAry = $this->getMaxNumberCodeAndSortOrder();
        $structureData['user_id'] = $user_id;
        $structureData['codeLevel'] = $codeLevel;
        $structureData['code'] = ! $maxNumberAry['maxNumCode'] ? '100000' : $maxNumberAry['maxNumCode'] + 1;
        $structureData['sortorder'] = $maxNumberAry['maxSortOrder'] + 10;
        switch ( $codeLevel ) {
            case 1:
                $structureData['level1'] = $structureData['code'];
                break;
            case 2:
                $structureData['level1'] = $pcode ?  : '';
                $structureData['level2'] = $structureData['code'];
                break;
            case 3:
                $structureData['level3'] = $structureData['code'];
                $structureData['level2'] = $pcode;
                if ( $options ) {
                    $structureData['level1'] = $options['level1'];
                } elseif ( $pcode ) {
                    $pinfo = $this->getCategoriesStructure(array(
                        'code' => $pcode
                    ), false);
                    if ( $pinfo ) {
                        $structureData['level1'] = $pinfo['level1'];
                    }
                }
                break;
            case 4:
                $structureData['level4'] = $structureData['code'];
                $structureData['level3'] = $pcode;
                $structureData['level2'] = $options['level2'];
                $structureData['level1'] = $options['level1'];
                break;
        }
        $structureData['admin_user_id'] = $adminUserId;
        $structureData['row_type'] = 2;
        $cate_id = $this->getCategoryDbMapper()->addCategoryStructure($structureData);
        if ( ! $cate_id ) {
            return false;
        }
        $titleData = array(
            'cate_id' => $cate_id,
            'code' => $structureData['code'],
            'sortorder' => $structureData['sortorder'],
            'description' => $name,
            'explanatoryNoteInclusion' => '',
            'explanatoryNoteExclusion' => ''
        );
        if ( ! $this->getCategoryDbMapper()->addCategoryTitle($titleData) ) {
            return false;
        }
        $structureData['cate_id'] = $cate_id;
        $structureData['description'] = $name;
        return $structureData;
    }

    /**
     * 重命名审核
     *
     * @todo 选择名称，不通过，则删除记录，并修改移动记录和删除记录 如果通过，则删除记录，修改移动记录，应用新的名称
     * @param int $audit_status            
     * @param string $opids            
     * @param string $description
     *            category name
     * @param string $code            
     * @return boolean|int
     */
    private function auditEditName( $audit_status, $opids, $description, $code, &$conn )
    {
        if ( ! $opids || ! $conn instanceof Connection ) {
            return false;
        }
        $op_id = explode(',', $opids);
        $status = $audit_status ?  : 3;
        $options = [
            'op_id' => compact('op_id'),
            'code' => compact('code'),
            'status' => compact('status'), //1 OK, 3 NO
            'description' => compact('description')
        ];
        $res = $this->getCategoryDbMapper()->updateCategoryOpRecord($options['status'], $options['op_id']);
        if ( $res && $audit_status ) {
            //@todo 改成其它名称的操作，则不通过审核
            $this->getCategoryDbMapper()->updateCategoryOpRecord(array(
                'status' => 3
            ), array(
                'code' => $code,
                'status' => 2
            ));
            return $this->getCategoryDbMapper()->updateCategoryTitle($options['description'], $options['code']);
        }
        return $res;
    }

    /**
     * 删除操作的审核
     *
     * @param number $audit_status            
     * @param string $opids            
     * @param string|array $code            
     * @param Connection $conn            
     * @return boolean|int
     */
    private function auditDeleteCategory( $audit_status, $opids, $code, &$conn )
    {
        if ( ! $opids || ! $code || ! $conn instanceof Connection ) {
            return false;
        }
        $op_id = explode(',', $opids);
        $status = $audit_status ? 1 : 3;
        $options = [
            'op_id' => compact('op_id'),
            'code' => compact('code'),
            'status' => compact('status')
        ];
        $res = $this->getCategoryDbMapper()->updateCategoryOpRecord($options['status'], $options['op_id']);
        if ( $res && $audit_status ) {
            //本身数据信息
            $row = $this->getCategoriesStructure(array(
                'code' => $code,
                'status<>0'
            ), false);
            if ( ! $row ) {
                return true;
            }
            //@todo 删除本身、子级、孙级，的数据（修改名称记录，删除记录，拖动记录）
            $res = $this->handleInsAuditNo($row['codeLevel'], $code, array(
                'op_id' => $opids
            ));
            //@todo 删除本身和子类孙类
            $res = $this->handleSelfAndLowerNodes($code, $row['codeLevel'], 'update');
        }
        return $res;
    }

    /**
     * 审核拖动动作的处理
     *
     * @param int $audit_status            
     * @param string $code            
     * @param string $package_name            
     */
    private function handleAuditDragAction( $audit_status, $code, $package_name, &$conn )
    {
        if ( ! $code || ! $conn instanceof Connection ) {
            return false;
        }
        $code = explode(',', $code);
        $toId = 0;
        $originId = 0;
        //@todo 分析包是因拖动而生成的，还是本已存在的
        $res = $this->existPackage($code, $toId, $originId);
        if ( $res && $audit_status ) {
            return $this->okDragCategory($audit_status, $code, $package_name, $conn, $toId, $originId);
        }
        return $res;
    }

    /**
     * 分析包是因拖动而生成的，还是本已存在的
     *
     * @todo 无论拖动是否审查通过，都将删除因拖动而新生成的新记录（包、大类）。
     * @todo 如果是已存在，则只审核拖动记录
     * @todo 如果是因拖动而生成的新包，则都将删除因拖动而新生成的包、大类（新数据）。
     * @param unknown $level1            
     */
    private function existPackage( $code, &$toId, &$originId )
    {
        $woptions = [
            'dragenter' => 1,
            'user_id<>0',
            'status<>0'
        ];
        $woptions['code'] = $code;
        //通过code, 获取对应的数据行信息
        $rows = $this->getCategoriesStructure($woptions);
        if ( ! $rows ) {
            return true;
        }
        $status = 0;
        $level1 = [];
        foreach ( $rows as $val ) {
            if ( $val['level1'] ) {
                $level1[] = $val['level1']; //当前因拖动新生成的包（code集合）
            }
            $toId = $val['to_target_id']; //拖动到哪里（目标类）
            $originId = $val['modify_cate_id']; //把谁拖动（源类）,
            if ( $val['op_record_number'] ) {
                $op_version[] = $val['op_record_number'];
            }
        }
        //@todo 如果有包
        if ( ! empty($level1) ) {
            $woptions['code'] = array_unique($level1);
            $woptions['codeLevel'] = 1;
            $pkgInfos = $this->getCategoriesStructure($woptions);
            unset($woptions['codeLevel']);
            unset($woptions['code']);
            if ( $pkgInfos ) {
                //@todo 因拖动而生成的新包，则都将删除因拖动而新生成的包、大类（新数据）。
                $woptions['level1'] = array_column($pkgInfos, 'code');
            } else {
                //@todo 已存在，则只审核拖动记录
                $woptions['code'] = $code;
            }
        }
        $res = $this->getCategoryDbMapper()->updateCategoryStructure(compact('status'), $woptions);
        //从包中拖出并解散包的记录
        if ( empty($level1) && isset($op_version) ) {
            $this->getCategoryDbMapper()->updateCategoryStructure(compact('status'), array(
                'dragenter' => 1,
                'user_id<>0',
                'status<>0',
                'op_record_number' => $op_version
            ));
        }
        return $res;
    }

    /**
     * 拖动通过审核操作
     *
     * @todo 1. 如果有新的包名且使用新包名，则创建新的包数据（Code）, 再使用新的包（Code）去级联层次关系； 如果没有生成新包，则升级目标类为包类，源类继承包类（目标类）
     * @todo 2. 将源往其它类（不包括目标类）拖动的操作，全部作为不通过审核处理
     * @todo 3. 将其它类（包括目标类）往本类（源类）里拖动的操作，全部作为不通过审核处理
     * @todo 4. 目标类操作：（1）将目标类往其它类（包括源类）拖动的操作，全部作为不通过审核处理
     * @todo 5. 如果拖动源是从其它包内拖动（出）的，则考虑是否解散源包...
     */
    private function okDragCategory( $audit_status, $code, $package_name, &$conn, $toId, $originId )
    {
        $rows = $this->getCategoriesStructure(array(
            'cate_id' => array(
                $toId,
                $originId
            )
        ));
        if ( ! $rows || ! $conn instanceof Connection ) {
            return true;
        }
        $toInfo = [];
        $originInfo = [];
        foreach ( $rows as $row ) {
            if ( $row['cate_id'] == $toId ) {
                $toInfo = $row; //目标类
            } else {
                $originInfo = $row; //源类
            }
        }
        if ( ! $originInfo ) {
            return true;
        }
        if ( $originInfo['codeLevel'] == 2 ) {
            //（源类）是从无包大类，或有包大类内拖动的。
            $res = $this->dragTopCategory($package_name, $toId, $originId, $toInfo, $originInfo, $conn);
        } elseif ( $originInfo['level2'] && $originInfo['codeLevel'] == 3 ) {
            //（子类）是从大类内拖出的。
            $res = $this->dragFromSubNode($toId, $originId, $originInfo, $toInfo, $conn);
        } else {
            self::ajaxReturn(0, '', '开发中，请联系开发人员');
        }
        return $res;
    }

    /**
     * 子类拖动的操作
     *
     * @todo 1. 拖出的子类不能同大类或包同名
     * @todo 2. 子类不能包含已通过审核的具体事物类，否则不能通过审核
     * @todo 3. 删除子类其它所有的拖动记录，删除数据记录
     * @param number $toId            
     * @param number $originId            
     * @param array $originInfo            
     * @param array $toInfo            
     * @param Connection $conn            
     * @throws \Exception
     * @return boolean
     */
    private function dragFromSubNode( $toId, $originId, $originInfo, $toInfo, &$conn )
    {
        // if true 表示没有目标类，只是把子类拖出作为无包大类
        if ( ! $toInfo ) {
            //直接升级设置。codeLevel=2, level2=code,并且level1＝''
            $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                'level1' => '',
                'level2' => $originInfo['code'],
                'level3' => '',
                'codeLevel' => 2
            ), array(
                'code' => $originInfo['code'],
                'status<>0',
                'codeLevel' => 3
            ));
        } elseif ( $toInfo && $toInfo['codeLevel'] == 1 ) { //if true 表示有目标类，且目标类是包，即将子类拖动包下，作为有包大类
            //直接升级设置。codeLevel=2, level2=code,并且level1＝toCode
            $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                'level1' => $toInfo['code'],
                'level2' => $originInfo['code'],
                'level3' => '',
                'codeLevel' => 2
            ), array(
                'code' => $originInfo['code'],
                'status<>0',
                'codeLevel' => 3
            ));
        } elseif ( $toInfo && $toInfo['codeLevel'] == 2 && $toInfo['level1'] ) { //if true 表示有目标类，且目标类是有包大类，即将子类拖动有包大类下，作为有包大类的子类
            //直接更改上级继承设置。
            $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                'level1' => $toInfo['level1'],
                'level2' => $toInfo['code']
            ), array(
                'code' => $originInfo['code'],
                'status<>0',
                'codeLevel' => 3
            ));
        } elseif ( $toInfo && $toInfo['codeLevel'] == 2 && ! $toInfo['level1'] ) { //if true 表示有目标类，且目标类是无包大类，即将子类拖动无包大类下，作为无包大类的子类
            //直接更改上级继承设置。
            $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                'level1' => $toInfo['level1'],
                'level2' => $toInfo['code']
            ), array(
                'code' => $originInfo['code'],
                'status<>0',
                'codeLevel' => 3
            ));
        }
        
        //@todo 将源往其它类（不包括目标类）拖动的操作，全部作为不通过审核处理( modify_cate_id=$originId)
        //@todo 将其它类（包括目标类）往本类（源类）里拖动的操作，全部作为不通过审核处理(to_target_id=$originId)
        //@todo 如果有目标类。目标类操作：（1）将目标类往其它类（包括源类）拖动的操作，全部作为不通过审核处理(modify_cate_id=$toId)
        if ( $toId && $toInfo['codeLevel'] == 2 ) {
            $rows = $this->getCategoriesStructure(array(
                'status<>0',
                '(modify_cate_id=' . $originId . ' or to_target_id=' . $originId . ' or modify_cate_id=' . $toId . ')'
            ));
        } else {
            $rows = $this->getCategoriesStructure(array(
                'status<>0',
                '(modify_cate_id=' . $originId . ' or to_target_id=' . $originId . ')'
            ));
        }
        if ( $rows ) {
            if ( count($rows) > 11 ) {
                throw new \Exception('检查审核是否有问题');
            }
            $level1 = array();
            foreach ( $rows as $val ) {
                $level1[] = $val['level1'];
            }
            $level1 = array_unique($level1);
            $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                'status' => 0
            ), array(
                'level1' => $level1,
                'status<>0'
            ));
        }
        return $res;
    }

    /**
     * 拖动大类的操作
     *
     * @param string $package_name            
     * @param number $toId            
     * @param number $originId            
     * @param array $toInfo            
     * @param array $originInfo            
     * @param Connection $conn            
     * @throws \Exception
     * @return boolean
     */
    private function dragTopCategory( $package_name, $toId, $originId, $toInfo, $originInfo, &$conn )
    {
        //if true, 则表示源是从其它包内容拖出的。
        if ( $originInfo['level1'] ) {
            $topNodes = $this->getCategoriesStructure(array(
                'level1' => $originInfo['level1'],
                'codeLevel' => 2,
                'user_id' => 0,
                'status<>0'
            ));
            //if true 则表示是从其它包内容拖出的，且包内只有一个大类，拖出后需解散包
            if ( $topNodes && count($topNodes) == 1 ) {
                // 解散包（包降级为大类）
                $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                    'codeLevel' => 2,
                    'level2' => $originInfo['level1'],
                    'level1' => ''
                ), array(
                    'code' => $originInfo['level1'],
                    'status<>0',
                    'codeLevel' => 1
                ));
                if ( ! $res ) {
                    return false;
                }
            }
        }
        if ( ! $package_name ) {
            if ( ! isset($toInfo['level1']) ) {
                //@todo 没有目标类，则说明是将类拖出作为大类，最直接设置level2=code,并且level1＝'',子类或孙类的level1=''
                $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                    'level1' => '',
                    'level2' => $originInfo['code']
                ), array(
                    'level2' => $originInfo['code'],
                    'status<>0',
                    'codeLevel' => [
                        2,
                        3,
                        4
                    ]
                ));
            } else {
                //@todo 目标类是包还是大类.
                if ( ! $toInfo['level1'] ) {
                    //@todo 目标类是大类（外大类里拖动，且大类无子类），无新包。升级目标类为包，code值不变
                    $res = $this->useTopCategoryAsPackage($toId, $toInfo['code']);
                    if ( ! $res ) {
                        return false;
                    }
                } else {
                    //@todo 目标类是包（往包里拖动）
                }
                //@todo 源类继承包类, 源类的子类也继承新包类，即 level1=$toInfo['code']
                $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                    'level1' => $toInfo['code']
                ), array(
                    'level2' => $originInfo['code'],
                    'status<>0',
                    'codeLevel' => [
                        2,
                        3,
                        4
                    ]
                ));
            }
        } else {
            $res = $this->mergeAndUseNewPackage($package_name, $toInfo, $originInfo, $conn);
        }
        //@todo 将源往其它类（不包括目标类）拖动的操作，全部作为不通过审核处理( modify_cate_id=$originId)
        //@todo 将其它类（包括目标类）往本类（源类）里拖动的操作，全部作为不通过审核处理(to_target_id=$originId)
        //@todo 目标类操作：（1）将目标类往其它类（包括源类）拖动的操作，全部作为不通过审核处理(modify_cate_id=$toId)
        if ( $toId ) {
            $rows = $this->getCategoriesStructure(array(
                'status<>0',
                '(modify_cate_id=' . $originId . ' or to_target_id=' . $originId . ' or modify_cate_id=' . $toId . ')'
            ));
        } else {
            $rows = $this->getCategoriesStructure(array(
                'status<>0',
                '(modify_cate_id=' . $originId . ' or to_target_id=' . $originId . ')'
            ));
        }
        if ( $rows ) {
            if ( count($rows) > 11 ) {
                throw new \Exception('检查审核是否有问题');
            }
            $level1 = array();
            foreach ( $rows as $val ) {
                $level1[] = $val['level1'];
            }
            $level1 = array_unique($level1);
            $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                'status' => 0
            ), array(
                'level1' => $level1,
                'status<>0'
            ));
        }
        return $res;
    }

    /**
     * 合并大类，并使用新的包
     *
     * @see 操作：拖动类到一个包含子类的大类中，此时会生成一个新的包，包含两个大类（源类和目标类。源类:拖动的对象，目标类:拖动到哪里）
     * @todo 1. 创建新包
     * @todo 2. 更改层次关系。目标类和其子类，孙类都继承新包，源类和子类，孙类也都继承新包
     */
    private function mergeAndUseNewPackage( $package_name, $toInfo, $originInfo, &$conn )
    {
        //@todo 创建新包
        $data = $this->createNewCategory(1, $package_name);
        if ( ! $data ) {
            return false;
        }
        //@todo 更改层次关系。目标类和其子类，孙类都继承新包，源类和子类，孙类也都继承新包
        return $this->getCategoryDbMapper()->updateCategoryStructure(array(
            'level1' => $data['code']
        ), array(
            'status<>0',
            'level2' => array(
                $toInfo['code'],
                $originInfo['code']
            ),
            'codeLevel' => [
                2,
                3,
                4
            ]
        ));
    }

    /**
     * 使用大类作为包类
     *
     * @see 操作：拖动内容到一个无子类的大类中，此时不创建新的包，而是将大类升级作为包类
     */
    private function useTopCategoryAsPackage( $cate_id, $code, $options = [] )
    {
        //@todo 升级目大类为包
        $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
            'level1' => $code,
            'codeLevel' => 1,
            'level2' => ''
        ), array(
            'cate_id' => $cate_id,
            'codeLevel' => 2,
            'level1' => '',
            'level2' => $code
        ));
        return $res;
    }

    public function auditDragAndEditCategory( $audit_status, $code, $opids, $audit_op, $category_name, $package_name )
    {
        $conn = $this->getCategoryDbMapper()
            ->getDbAdapter()
            ->getDriver()
            ->getConnection();
        $conn->beginTransaction();
        if ( $opids && $audit_op == 'edit_name' ) {
            // 审核重命名
            $res = $this->auditEditName($audit_status, $opids, $category_name, $code, $conn);
        } elseif ( $opids && $audit_op == 'delete' ) {
            // 删除操作审核
            $res = $this->auditDeleteCategory($audit_status, $opids, $code, $conn);
        } else {
            // 拖动操作审核
            $res = $this->handleAuditDragAction($audit_status, $code, $package_name, $conn);
        }
        if ( ! $res ) {
            $conn->rollback();
            return false;
        }
        $conn->commit();
        return $res;
    }

    /**
     * 用户添加的分类不通过审核时的处理
     *
     * @todo 其本身拖动操作，包括其子类或孙类的拖动操作也不通过（拖动包括拖进和拖出）
     * @param int $level            
     * @param string|array $code            
     * @throws \Exception
     * @return boolean|Ambigous
     */
    private function handleInsAuditNo( $level, $code, $options = [] )
    {
        if ( ! $level || ! $code ) {
            return false;
        }
        if ( ! is_array($code) ) {
            $code = explode(',', $code);
        }
        //本级//子级//孙级
        $nodes = $this->handleSelfAndLowerNodes($code, $level);
        if ( ! $nodes ) {
            return true;
        }
        $strCateIds = join(',', array_column($nodes, 'cate_id'));
        //@todo 其本身拖动操作，包括其子类或孙类的拖动操作也不通过（拖动包括拖进和拖出）
        $rows = $this->getCategoriesStructure(array(
            'status<>0',
            'dragenter' => 1,
            '(modify_cate_id in (' . $strCateIds . ') or to_target_id in (' . $strCateIds . '))'
        ));
        if ( $rows ) {
            $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                'status' => 0
            ), array(
                'level1' => array_unique(array_column($rows, 'level1')),
                'status<>0',
                'dragenter' => 1
            ));
        }
        // @todo 作废所有的修改（修改名称、删除）记录
        $where = array(
            'code' => array_column($nodes, 'code'),
            'status' => 2
        );
        if ( isset($options['op_id']) ) {
            array_push($where, 'op_id not in( ' . $options['op_id'] . ' )');
        }
        $this->getCategoryDbMapper()->updateCategoryOpRecord(array(
            'status' => 0
        ), $where);
        return isset($res) ? $res : true;
    }

    /**
     * 作废类其它的修改（修改名称、删除）记录
     *
     * @param string|array $code            
     */
    private function abolitionOtherOpRecord( $code )
    {
        return $this->getCategoryDbMapper()->updateCategoryOpRecord(array(
            'status' => 0
        ), array(
            'code' => $code,
            'status' => 2
        ));
    }

    /**
     * 本级//子级//孙级
     *
     * @param string|array $code            
     * @param int $level            
     */
    private function handleSelfAndLowerNodes( $code, $level, $opAction = 'fetch' )
    {
        $options = array(
            'status<>0'
        );
        switch ( $level ) {
            case 1:
                $options['level1'] = $code;
                break;
            case 2:
                $options['level2'] = $code;
                $options['codeLevel'] = [
                    2,
                    3,
                    4
                ];
                break;
            case 3:
                $options['level3'] = $code;
                $options['codeLevel'] = [
                    3,
                    4
                ];
                break;
            case 4:
                $options['code'] = $code;
                $options['codeLevel'] = 4;
                break;
            default:
                $this->_recordLog('等级错误', 'err');
                exit(1);
                break;
        }
        switch ( $opAction ) {
            case 'fetch': // 本身和其下级（子级，孙级）的数据
                return $this->getCategoriesStructure($options);
                break;
            case 'update': // 本身和其下级（子级，孙级）都不通过
                return $this->updateCategoryStructure(array(
                    'status' => 0
                ), $options);
                break;
            default:
                $this->_recordLog('操作动作错误', 'err');
                exit(1);
                break;
        }
    }

    private function okInsAuditCategory( $category_name, $code, $level, $conn, &$cate_id )
    {
        if ( ! $conn instanceof Connection ) {
            return false;
        }
        $countCode = count($code);
        if ( $level == 1 ) {
            return false;
        }
        if ( $countCode == 1 ) {
            return $this->getCategoryDbMapper()->updateCategoryStructure(array(
                'user_id' => 0
            ), array(
                'code' => $code,
                'status<>0'
            ));
        }
        //获取分类信息，以便查找上级信息
        $row = $this->getCategoriesStructure(array(
            'code' => current($code)
        ), false);
        if ( ! $row ) {
            return false;
        }
        //@todo 多人都添加了同名的类或事物时，审核时，删除源数据，创建新数据。（如果是大类（level=2）或细分类（level=3），还需更改层次关系）
        

        //删除
        $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
            'status' => 0
        ), array(
            'code' => $code,
            'status<>0'
        ));
        if ( ! $res ) {
            $conn->rollback();
            return false;
        }
        
        switch ( $level ) {
            case 2:
                
                //@todo 多人都添加了同名的类，审核时，删除源数据，创建新数据，并更改层次关系
                //创建
                $newData = $this->createNewCategory(2, $category_name, $row['level1'], 0, 0, $row);
                if ( ! $newData ) {
                    return false;
                }
                $cate_id = $newData['cate_id'];
                //更改子级（细分类）和孙级（具体事物类）层次关系
                $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                    'level2' => $newData['code']
                ), array(
                    'level2' => $code,
                    'status<>0',
                    'codeLevel' => array(
                        3,
                        4
                    )
                ));
                break;
            case 3:
                
                //@todo 多人都添加了同名的类，审核时，删除源数据，创建新数据，并更改层次关系
                //创建
                $newData = $this->createNewCategory(3, $category_name, $row['level2'], 0, 0, $row);
                if ( ! $newData ) {
                    return false;
                }
                $cate_id = $newData['cate_id'];
                //更改子级（具体事物类）层次关系
                $res = $this->getCategoryDbMapper()->updateCategoryStructure(array(
                    'level3' => $newData['code']
                ), array(
                    'level3' => $code,
                    'status<>0',
                    'codeLevel' => 4
                ));
                break;
            case 4:
                
                //@todo 多人都添加了同名的具体事物，审核时，删除源数据，创建新数据(合并)
                //创建
                $newData = $this->createNewCategory(4, $category_name, $row['level3'], 0, 0, $row);
                if ( ! $newData ) {
                    return false;
                }
                $cate_id = $newData['cate_id'];
                break;
        }
        return $res;
    }

    /**
     * 审核添加
     *
     * @param unknown $category_name            
     * @param unknown $code            
     * @param number $level            
     * @param string $isOk            
     * @param unknown $audit_op            
     * @return boolean|unknown|multitype:
     */
    public function auditCategory( $category_name, $code, $level = 1, $isOk = true, $audit_op )
    {
        if ( ! $code || ! $category_name || ! $level ) {
            return false;
        }
        $code = explode(',', $code);
        $conn = $this->getCategoryDbMapper()
            ->getDbAdapter()
            ->getDriver()
            ->getConnection();
        $conn->beginTransaction();
        if ( ! $isOk ) { //ins 不通过审核处理。当前数据不通过，并且其子类也不通过审核，其本身和子类的拖动操作也不通过
            //@todo 1. 其本身拖动操作，包括其子类或孙类的拖动操作也不通过（拖动包括拖进和拖出）
            $this->handleInsAuditNo($level, $code);
            //@todo 2. 本身和其子级都不通过
            $res = $this->handleSelfAndLowerNodes($code, intval($level), 'update');
        } else {
            $cate_id = 0;
            $res = $this->okInsAuditCategory($category_name, $code, $level, $conn, $cate_id);
        }
        if ( ! $res ) {
            $conn->rollback();
            return false;
        }
        $conn->commit();
        $cate = isset($cate_id) && $cate_id ? $this->getJoinNodes(array(
            'cate_id' => $cate_id
        )) : [];
        return $cate;
    }

    public function addCategory( $data, $lang = '' )
    {
        return $this->createNewCategory($data['codeLevel'], $data['name'], $data['pcode'], $data['admin_user_id'], '-1', $data);
    }

    /**
     * 分类的操作记录
     *
     * @see 先添加后拖动的分类，分步审核，先审核添加，再审核拖动
     * @param array $code            
     * @param array $options            
     * @return multitype:|unknown|Ambigous
     */
    public function categoryOpRecord( $code, $options = [] )
    {
        $res = [];
        if ( count($code) > 1 ) {
            die('developer');
        }
        $cate = $this->getCategoriesStructure(array(
            'code' => $code,
            'user_id' => 0
        ), false);
        if ( ! $cate ) {
            return $res;
        }
        //@todo edit
        $opRecords = $this->getCategoryDbMapper()->getCategoryOpRecord(array(
            'status' => 2,
            'code' => $code
        ));
        if ( $opRecords ) {
            foreach ( $opRecords as $key => $value ) {
                if ( $value['do_action'] == 'edit name' ) {
                    $res['editNameRecord'][$value['new_content']][] = $value;
                    $res['editNameRecord'][$value['new_content']]['op_ids'][] = $value['op_id'];
                    $res['editNameRecord'][$value['new_content']]['code'] = $value['code'];
                } else {
                    $res['delRecord'][$value['code']]['op_ids'][] = $value['op_id'];
                    $res['delRecord'][$value['code']]['code'] = $value['code'];
                }
            }
        }
        if ( isset($options['level']) && $options['level'] == 1 ) {
            return $res;
        }
        
        //@todo drag out or drag in
        $records = $this->getCategoryDbMapper()->getJoinNodes(array(
            '(modify_cate_id=' . $cate['cate_id'] . ' or to_target_id=' . $cate['cate_id'] . ')',
            'status<>0',
            'user_id<>0',
            'dragenter' => 1
        ));
        if ( ! $records ) {
            return $res;
        }
        foreach ( $records as $rkey => $val ) {
            if ( $val['modify_cate_id'] && $val['modify_cate_id'] != $cate['cate_id'] ) {
                $ids[] = $val['modify_cate_id'];
            }
            if ( $val['to_target_id'] && $val['to_target_id'] != $cate['cate_id'] ) {
                $ids[] = $val['to_target_id'];
            }
            //@todo 从包内或子类往外拖记录
            if ( $val['modify_cate_id'] && ! $val['level1'] ) {
                $ids[] = $val['modify_cate_id'];
            }
        }
        if ( ! isset($ids) || empty($ids) ) {
            return $res;
        }
        $cinfo = $this->getCategoryDbMapper()->getJoinNodes(array(
            'cate_id' => $ids,
            'status<>0'
        ));
        foreach ( $cinfo as $ckey => $cval ) {
            foreach ( $records as $key => $val ) {
                if ( $val['modify_cate_id'] == $cate['cate_id'] && ! empty($val['to_target_id']) ) {
                    //@todo drag out
                    $val['to'] = $cval;
                    if ( $cval['cate_id'] == $val['to_target_id'] ) {
                        $res['drag-out'][$cval['description']][] = $val;
                        $res['drag-out'][$cval['description']]['code'][] = $val['code'];
                        $pgk = $this->getCategoryDbMapper()->getJoinNodes(array(
                            'code' => $val['level1'],
                            'modify_cate_id' => 0
                        ));
                        if ( $pgk ) {
                            $pgk = current($pgk);
                            if ( $pgk['description'] != $cval['description'] ) {
                                $res['drag-out'][$cval['description']]['pkg'][] = $pgk;
                            }
                        }
                    }
                } elseif ( $val['to_target_id'] == $cate['cate_id'] && $val['dragenter'] ) {
                    //@todo drag in
                    $val['origin'] = $cval;
                    if ( ! $val['modify_cate_id'] && $val['dragenter'] && $val['cate_id'] == $cval['cate_id'] ) { //用户新创建一个分类后，再拖动
                        $res['drag-in'][$cval['description']][] = $val;
                        $res['drag-in'][$cval['description']]['code'][] = $val['code'];
                        $res['drag-in'][$cval['description']]['isNewCreated'] = 1;
                        $pgk = $this->getCategoryDbMapper()->getJoinNodes(array(
                            'code' => $val['level1'],
                            'modify_cate_id' => 0
                        ));
                        if ( $pgk ) {
                            $pgk = current($pgk);
                            $res['drag-in'][$cval['description']]['pkg'][] = $pgk;
                        }
                    } elseif ( $cval['cate_id'] == $val['modify_cate_id'] ) {
                        $res['drag-in'][$cval['description']][] = $val;
                        $res['drag-in'][$cval['description']]['code'][] = $val['code'];
                        $pgk = $this->getCategoryDbMapper()->getJoinNodes(array(
                            'code' => $val['level1'],
                            'modify_cate_id' => 0
                        ));
                        if ( $pgk && $cval['codeLevel'] == 2 ) {
                            $pgk = current($pgk);
                            $res['drag-in'][$cval['description']]['pkg'][] = $pgk;
                        }
                    }
                } elseif ( $val['modify_cate_id'] == $cate['cate_id'] && empty($val['to_target_id']) && $val['dragenter'] && ! $val['level1'] ) {
                    if ( isset($options['level']) && $options['level'] == 3 ) {
                        //@todo 从子类内拖出作为大类
                        $res['drag-out-from-subnode'][$cval['description']][] = $val;
                        $res['drag-out-from-subnode'][$cval['description']]['code'][] = $val['code'];
                    } elseif ( isset($options['level']) && $options['level'] == 2 ) {
                        //@todo 从包内拖出大类作为大类
                        $res['drag-out-from-pkg'][$cval['description']][] = $val;
                        $res['drag-out-from-pkg'][$cval['description']]['code'][] = $val['code'];
                    }
                } else {
                    continue;
                }
            }
        }
        if ( isset($res['drag-out']) ) {
            foreach ( $res['drag-out'] as $key => $val ) {
                if ( isset($val['pkg']) ) {
                    foreach ( $val['pkg'] as $pkey => $pval ) {
                        unset($res['drag-out'][$key]['pkg'][$pkey]);
                        $res['drag-out'][$key]['pkg'][$pval['description']][] = $pval;
                    }
                }
            }
        }
        if ( isset($res['drag-in']) ) {
            foreach ( $res['drag-in'] as $key => $val ) {
                if ( isset($val['pkg']) ) {
                    foreach ( $val['pkg'] as $pkey => $pval ) {
                        unset($res['drag-in'][$key]['pkg'][$pkey]);
                        $res['drag-in'][$key]['pkg'][$pval['description']][] = $pval;
                    }
                }
            }
        }
        return $res;
    }
}