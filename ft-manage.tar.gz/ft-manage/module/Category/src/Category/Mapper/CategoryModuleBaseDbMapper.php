<?php
namespace Category\Mapper;

use Core\DbMapper\AbstractDbMapper;

class CategoryModuleBaseDbMapper extends AbstractDbMapper
{
}