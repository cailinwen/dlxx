<?php
namespace Category\Mapper;

use Zend\Db\Sql\Select;
use Zend\Db\Sql\Expression as SqlExpression;
use Zend\Db\Adapter\Adapter;

class CategoryDbMapper extends CategoryModuleBaseDbMapper
{

    public function getUnAuditCount()
    {
        $sql = $this->getSql()->setTable(self::CATEGORY_OP_RECORD_TAB);
        $select1 = $sql->select();
        $select1->where->equalTo('status', 2);
        $c1 = $sql->prepareStatementForSqlObject($select1)
            ->execute()
            ->count();
        $select2 = $sql->setTable(self::CATEGORY_STRUCTURE_TAB)->select();
        $select2->where->notEqualTo('user_id', 0);
        $select2->where->notEqualTo('status', 0);
        $c2 = $sql->prepareStatementForSqlObject($select2)
            ->execute()
            ->count();
        return $c1 + $c2;
    }

    public function getUnAuditCount_bak( $code = [] )
    {
        $sql = $this->getSql()->setTable(self::CATEGORY_OP_RECORD_TAB);
        $select1 = $sql->select();
        $select1->columns(array(
            'code',
            'op_count' => new SqlExpression('count(*)')
        ));
        $select1->where->equalTo('status', 2);
        if ( $code ) {
            $select1->where(compact('code'));
        }
        $select1->group('code');
        $c1 = $this->fetchAll($select1, $sql);
        $select2 = $sql->setTable(self::CATEGORY_STRUCTURE_TAB)->select();
        $select2->columns(array(
            'code',
            'op_count' => new SqlExpression('count(*)')
        ));
        $select2->where->notEqualTo('user_id', 0);
        $select2->where->notEqualTo('status', 0);
        if ( $code ) {
            $select2->where(compact('code'));
        }
        $select2->group('code');
        $c2 = $this->fetchAll($select2, $sql);
        zp_dump($c1);
        zp_dump($c2);
        
        $c3 = array_merge($c1, $c2);
        zp_dump($c3);
        die();
    }

    public function addCategoryStructure( $data )
    {
        $data['c_time'] = $data['u_time'] = $_SERVER['REQUEST_TIME'];
        return $this->dbInsert(self::CATEGORY_STRUCTURE_TAB, $data);
    }

    public function addCategoryTitle( $data, $lang = 'en_US' )
    {
        return $this->dbInsert(self::CATEGORY_TITLE_EN_US_TAB, $data, false);
    }

    public function getCategoryOpRecord( $where )
    {
        $sql = $this->getSql()->setTable(self::CATEGORY_OP_RECORD_TAB);
        $select = $sql->select();
        $select->where($where);
        return $this->fetchAll($select, $sql);
    }

    public function addCategoryOpRecord( $data )
    {
        $data['updated'] = $data['created'] = $_SERVER['REQUEST_TIME'];
        return $this->dbInsert(self::CATEGORY_OP_RECORD_TAB, $data);
    }

    public function updateCategoryOpRecord( $data, $where )
    {
        $data['updated'] = $_SERVER['REQUEST_TIME'];
        return $this->dbUpdate(self::CATEGORY_OP_RECORD_TAB, $data, $where);
    }

    public function updateCategoryTitle( $data, $where )
    {
        return $this->dbUpdate(self::CATEGORY_TITLE_EN_US_TAB, $data, $where);
    }

    public function updateCategoryStructure( $data, $where )
    {
        if ( ! $where ) {
            return false;
        }
        $data['u_time'] = $_SERVER['REQUEST_TIME'];
        return $this->dbUpdate(self::CATEGORY_STRUCTURE_TAB, $data, $where);
    }

    public function getMaxNumberCodeAndSortOrder()
    {
        $sql = "SELECT MAX(`code`) AS maxNumCode, MAX(`sortorder`) AS maxSortOrder FROM `ft_categories_structure` WHERE `code` REGEXP ('(^[0-9]+$)') AND `row_type`=2 LIMIT 1";
        return $this->fetchOneRow($sql);
    }

    public function getJoinNodes( $where )
    {
        $sql = $this->getSql()->setTable(array(
            'sc' => self::CATEGORY_STRUCTURE_TAB
        ));
        $select = $sql->select();
        $select->join(array(
            'sct' => self::CATEGORY_TITLE_EN_US_TAB
        ), 'sc.cate_id=sct.cate_id and sc.code=sct.code', array(
            'description'
        ), $select::JOIN_INNER);
        
        foreach ( $where as $key => $val ) {
            if ( ! is_numeric($key) ) {
                $where['sc.' . $key] = $val;
                unset($where[$key]);
            }
        }
        $select->where($where);
        $select->order('sc.c_time DESC');
        return $this->fetchAll($select, $sql);
    }

    public function getCategoriesTitle( $where )
    {
        $sql = $this->getSql()->setTable(self::CATEGORY_TITLE_EN_US_TAB);
        $select = $sql->select();
        $select->where($where);
        return $this->fetchAll($select, $sql);
    }

    public function getCategoriesStructure( $where, $isMultiRows = true )
    {
        $sql = $this->getSql()->setTable(self::CATEGORY_STRUCTURE_TAB);
        $select = $sql->select();
        $select->where($where);
        if ( ! $isMultiRows ) {
            $select->limit(1);
            return $sql->prepareStatementForSqlObject($select)
                ->execute()
                ->current();
        }
        return $this->fetchAll($select, $sql);
    }
}