<?php
namespace Category\Controller;

use Core\Controller\AbstractBaseCoreController;

class CategoryModuleBaseController extends AbstractBaseCoreController
{

    /**
     *
     * @var \Category\Service\CategoryService
     */
    private $categoryService;

    /**
     *
     * @return the $categoryService
     */
    protected function getCategoryService()
    {
        if ( ! $this->categoryService ) {
            $this->categoryService = $this->getServiceLocator()->get('categoryService');
        }
        return $this->categoryService;
    }

    protected $allowAdminUser = array(
        1,
        2,
        3
    );

    public function preDisPatch()
    {
        parent::preDisPatch();
        $this->checkLoginAndXmlRequest($this->loginUser);
        if ( ! in_array($this->loginUser['level'], $this->allowAdminUser) ) {
            exit('You do not have access!');
        }
    }

    protected function formatCustomCategory( $categories, $level = 2 )
    {
        if ( ! $categories ) {
            return array();
        }
        $scategories = $categories;
        foreach ( $categories as $key => $tval ) {
            $tval['description'] = htmlspecialchars_decode($tval['description']);
            if ( $level == 2 ) {
                if ( $tval['modify_cate_id'] ) {
                    $plevel = $tval['modify_cate_id'] . '-' . $tval['level1'];
                } else {
                    $plevel = $tval['level1'];
                }
            } else {
                $plevel = '';
            }
            $md5Name = md5($tval['description']);
            $uukey = $md5Name . '-' . $plevel;
            $formatArray[$uukey][] = $tval;
            $formatArray[$uukey]['description'] = $tval['description'];
        }
        foreach ( $formatArray as $key => $val ) {
            unset($val['description']);
            $formatArray[$key]['counts'] = count($val);
            $cate = current($val);
            $formatArray[$key]['codeLevel'] = $cate['codeLevel'];
            $formatArray[$key]['row_type'] = $cate['row_type'];
            $formatArray[$key]['is_public'] = $cate['is_public'];
            if ( $formatArray[$key]['counts'] <= 1 ) {
                $formatArray[$key]['level1'] = $cate['level1'];
                $formatArray[$key]['cate_id'] = $cate['cate_id'];
                $formatArray[$key]['code'] = $cate['code'];
                if ( $cate['user_id'] && (! $cate['modify_cate_id'] || $cate['modify_cate_id'] > 766) ) {
                    $formatArray[$key]['actionStyleClass'] = 'diffInserted';
                    $formatArray[$key]['do_action'] = 'ins';
                    if ( $cate['modify_cate_id'] || $cate['to_target_id'] ) {
                        $formatArray[$key]['do_action'] = 'drag';
                    }
                } else {
                    $delData = [];
                    if ( isset($delData) && ! empty($delData) ) {
                        foreach ( $delData as $dkey => &$delVal ) {
                            if ( $key == md5(htmlspecialchars_decode($delVal['description'])) ) {
                                $formatArray[$key]['actionStyleClass'] = 'diffDeleted';
                                $formatArray[$key]['del']['list'][] = $delVal;
                                $formatArray[$key]['del']['counts'] = isset($formatArray[$key]['del']['counts']) ? $formatArray[$key]['del']['counts'] + 1 : 1;
                                unset($delData[$dkey]);
                            } else {
                                continue;
                            }
                        }
                    }
                }
            } else {
                foreach ( $val as $k => $var ) {
                    $ids[] = $var['cate_id'];
                    $codes[] = $var['code'];
                    $levels1[] = $var['level1'];
                }
                $formatArray[$key]['level1'] = join(',', $levels1);
                $formatArray[$key]['cate_id'] = join(',', $ids);
                $formatArray[$key]['actionStyleClass'] = 'diffInserted';
                $formatArray[$key]['do_action'] = 'ins';
                $formatArray[$key]['code'] = join(',', $codes);
            }
        }
        return $formatArray;
    }
}