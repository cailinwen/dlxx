<?php
namespace Category\Controller;

class IndexController extends CategoryModuleBaseController
{
    //一级分类，只查询系统原始分类和用户自定义添加的分类。
    public function indexAction()
    {
        $this->layout('category-layout');
        $unA = $this->getCategoryService()->getUnAuditCount();
        $packageAndTopNodes = $this->getCategoryService()->getJoinNodes(array(
            'status' => 1,
            'modify_cate_id' => 0,
            'to_target_id' => 0,
            'sc.code > 100000', //过滤正式数据
            //过滤拖动产生的包和大类
            '( (codeLevel=1 and user_id=0) or (codeLevel=2 ) )'
        ));
        foreach ( $packageAndTopNodes as $key => $node ) {
            if ( $node['codeLevel'] == 1 ) {
                $packages[] = $node; //包裹集合
            } else {
                $topNodes[] = $node; //大类集合
            }
        }
        foreach ( $topNodes as $key => $val ) {
            if ( $val['user_id'] ) {
                $customTopNodes[] = $val; //自定义未审核大类
            } else {
                $officialTopNodes[] = $val; //正式（系统提供或已通过审核）大类
            }
        }
        if ( isset($customTopNodes) ) {
            $formatCustomTopNodes = $this->formatCustomCategory($customTopNodes, 2); //格式化未审核的大类
            $formatTopNodes = array_merge($formatCustomTopNodes, $officialTopNodes); //合并正式和未审核大类
        } else {
            $formatTopNodes = $officialTopNodes;
        }
        //按照多维层次组装包裹和大类（大类组合到包裹里）
        foreach ( $packages as $key => $pkgNode ) {
            foreach ( $formatTopNodes as $tkey => &$tNode ) {
                if ( ! $tNode['level1'] ) {
                    continue;
                }
                $level1 = explode(',', $pkgNode['level1']);
                $tlevel1 = explode(',', $tNode['level1']);
                if ( array_intersect($level1, $tlevel1) ) {
                    $packages[$key]['topNodes'][] = $tNode;
                    unset($formatTopNodes[$tkey]); //删除组合后的大类
                }
            }
        }
        $noPackageTopNodes = $formatTopNodes; //剩余的大类，则是没有包裹的大类
        $rNodes = array_merge($noPackageTopNodes, $packages); //最终将有包裹类和无包裹的类合并
        return array(
            'categories' => $rNodes,
            'unAuditCount' => $unA
        );
    }

    public function changeCategoryAction()
    {
        $pcode = $this->getParam('pcode');
        $topNodes = $this->getCategoryService()->getCategoriesStructure(array(
            'code' => $pcode,
            'status<>0'
        ));
        if ( ! $topNodes ) {
            return self::createJsonView(0, '', 'Error');
        }
        $topNode = current($topNodes);
        $nodes = $this->getCategoryService()->getJoinNodes(array(
            'codeLevel' => 3,
            'level2' => explode(',', $pcode),
            'status<>0',
            'dragenter<>1'
        ));
        if ( $nodes ) {
            $formatArray = $this->formatCustomCategory($nodes);
        } else {
            $formatArray = $nodes;
        }
        $html = $this->getView('category/index/sub-node-list', array(
            'subCategories' => $formatArray,
            'level1' => $topNode['level1'],
            'level2' => $pcode,
            'previousLevelIsNewCreated' => $topNode['user_id'] ? 1 : 0
        ));
        
        //拖动记录
        $code = explode(',', $pcode);
        $res = $this->getCategoryService()->categoryOpRecord($code, [
            'level' => 2
        ]);
        if ( $res ) {
            $loghtml = $this->getView('category/index/op-log', array(
                'data' => $res
            ));
        }
        
        return self::createJsonView(1, array(
            'html' => $html,
            'logHtml' => isset($loghtml) ? $loghtml : '',
            'data' => $formatArray
        ), 'Successed', false);
    }

    /**
     * 切换子级
     *
     * @return \Zend\View\Model\JsonModel
     */
    public function changeSubCategoryAction()
    {
        $pcode = $this->getParam('pcode');
        $subNodes = $this->getCategoryService()->getCategoriesStructure(array(
            'code' => $pcode
        ));
        if ( ! $subNodes ) {
            return self::createJsonView(0, '', 'Error');
        }
        $subNode = current($subNodes);
        $things = $this->getCategoryService()->getJoinNodes(array(
            'codeLevel' => 4,
            'level3' => explode(',', $pcode),
            'status<>0'
        ));
        if ( $things ) {
            $formatArray = $this->formatCustomCategory($things);
        } else {
            $formatArray = $things;
        }
        $html = $this->getView('category/index/specific-things', array(
            'things' => $formatArray,
            'level1' => $subNode['level1'],
            'level2' => $subNode['level2'],
            'level3' => $pcode,
            
            //判断上一级是否是新增，如果是则下级，只能NO 不能OK 
            'previousLevelIsNewCreated' => $subNode['user_id'] ? 1 : 0
        ));
        
        //拖动记录
        $code = explode(',', $pcode);
        $res = $this->getCategoryService()->categoryOpRecord($code, [
            'level' => 3
        ]);
        if ( $res ) {
            $loghtml = $this->getView('category/index/op-log', array(
                'data' => $res
            ));
        }
        
        return self::createJsonView(1, array(
            'html' => $html,
            'logHtml' => isset($loghtml) ? $loghtml : '',
            'data' => $formatArray
        ), 'Successed', false);
    }

    public function packageRecordAction()
    {
        //拖动记录
        $code = explode(',', $this->getParam('code'));
        $res = $this->getCategoryService()->categoryOpRecord($code, [
            'level' => 1
        ]);
        if ( $res ) {
            $loghtml = $this->getView('category/index/op-log', array(
                'data' => $res
            ));
        }
        return self::createJsonView(1, array(
            'logHtml' => isset($loghtml) ? $loghtml : '',
            'data' => $res
        ), 'Successed', false);
    }

    /**
     * 添加类型
     *
     * @return \Zend\View\Model\JsonModel
     */
    public function addCategoryAction()
    {
        $data['name'] = $this->getParam('category_name');
        $data['codeLevel'] = $this->getParam('codeLevel');
        $data['level1'] = $this->getParam('level1');
        $data['level2'] = $this->getParam('level2');
        $data['level3'] = $this->getParam('level3');
        if ( $data['codeLevel'] == 2 ) {
            $data['pcode'] = $data['level1'];
        } elseif ( $data['codeLevel'] == 3 ) {
            $data['pcode'] = $data['level2'];
        } elseif ( $data['codeLevel'] == 4 ) {
            $data['pcode'] = $data['level3'];
        } else {
            return self::createJsonView(0, '', 'Eroor', false);
        }
        $data['admin_user_id'] = 1;
        $res = $this->getCategoryService()->addCategory($data, self::$language);
        if ( ! $res ) {
            return self::createJsonView(0, '', 'Eroor', false);
        }
        $html = $this->getView('category/index/result-tpl', array(
            'type' => 'newCategory',
            'data' => $res
        ));
        return self::createJsonView(1, array(
            'data' => $res,
            'html' => $html
        ), 'Successed', false);
    }

    public function auditCategoryAction()
    {
        $code = $this->getParam('code');
        $category_name = $this->getParam('category_name');
        $level = $this->getParam('level');
        $audit_status = $this->getParam('audit_status');
        $audit_op = $this->getParam('audit_op');
        $res = $this->getCategoryService()->auditCategory($category_name, $code, $level, $audit_status, $audit_op);
        if ( is_bool($res) ) {
            return self::createJsonView(0, '', 'Eroor', false);
        }
        return self::createJsonView(1, array(
            'data' => $res
        ), 'Successed', false);
    }

    public function deleteCategoryAction()
    {
        $code = $this->getParam('code');
        $level = $this->getParam('level');
        if ( ! $code || ! $level ) {
            return self::createJsonView(0, '', 'Eroor', false);
        }
        $res = $this->getCategoryService()->deleteCategory($code, $level);
        if ( ! $res ) {
            return self::createJsonView(0, $res, 'Eroor', false);
        }
        return self::createJsonView(1, $res, 'Successed', false);
    }

    public function auditDropCategoryAction()
    {
        $opids = $this->getParam('opids');
        $audit_status = $this->getParam('audit_status');
        $category_name = $this->getParam('category_name');
        $code = $this->getParam('code');
        $package_name = $this->getParam('package_name');
        $audit_op = $this->getParam('audit_op');
        $res = $this->getCategoryService()->auditDragAndEditCategory($audit_status, $code, $opids, $audit_op, $category_name, $package_name);
        if ( ! $res ) {
            return self::createJsonView(0, '', 'Eroor', false);
        }
        return self::createJsonView(1, array(
            'data' => $res
        ), 'Successed', false);
    }

    public function editCategoryNameAction()
    {
        $new_name = $this->getParam('new_name');
        $old_name = $this->getParam('old_name');
        $code = $this->getParam('code');
        $adminUserId = 1;
        if ( ! $new_name || ! $old_name || ! $code || ! $adminUserId ) {
            return self::createJsonView(0, '', 'Eroor', false);
        }
        $res = $this->getCategoryService()->editCategoryName($code, $new_name, $old_name, $adminUserId);
        if ( ! $res ) {
            return self::createJsonView(0, '', 'Eroor', false);
        }
        return self::createJsonView(1, '', 'Successed', false);
    }

    public function switchCategoryAction()
    {
        $this->exitNonXmlHttpRequest();
        $state = $this->getParam('state');
        $code = $this->getParam('code');
        $codeLevel = $this->getParam('level');
        if ( ! $code || $codeLevel > 4 || $codeLevel < 1 ) {
            return self::createJsonView(0, '', 'Eroor', false);
        }
        $whereOption = array(
            'status<>0',
            'user_id' => 0
        );
        switch ( $codeLevel ) {
            case 1:
                $whereOption['level1'] = $code;
                break;
            case 2:
                $whereOption['level2'] = $code;
                $whereOption['codeLevel'] = [
                    2,
                    3,
                    4
                ];
                break;
            case 3:
                $whereOption['level3'] = $code;
                $whereOption['codeLevel'] = [
                    3,
                    4
                ];
                break;
            case 4:
                $whereOption['code'] = $code;
                $whereOption['level4'] = $code;
                $whereOption['codeLevel'] = 4;
                break;
            default:
                return self::createJsonView(0, '', 'Eroor', false);
                break;
        }
        $res = $this->getCategoryService()->updateCategoryStructure(array(
            'is_public' => $state
        ), $whereOption);
        if ( ! $res ) {
            return self::createJsonView(0, '', 'Eroor', false);
        }
        return self::createJsonView(1, $res, 'Successed', false);
    }

    public function opRecordAction()
    {
        $code = $this->getParam('code');
        $level = $this->getParam('level');
        $res = $this->getCategoryService()->categoryOpRecord($code, [
            'level' => $level
        ]);
        zp_dump($res);
        die();
    }
}