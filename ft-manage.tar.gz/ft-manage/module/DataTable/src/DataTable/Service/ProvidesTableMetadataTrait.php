<?php
/**
 * Featee This is not a free software, unauthorized use is prohibited.
 *
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 * @author : pardus
 */
namespace DataTable\Service;

trait ProvidesTableMetadataTrait
{

    protected static $tableNameList = array(
        
        // Dimzou
        'ft_dz_category' => 'ft_dz_category',
        'cel_profile_art' => 'cel_profile_art',
        'ft_dz_audit_record' => 'ft_dz_audit_record',
        'ft_dz_veto_reasons' => 'ft_dz_veto_reasons',
        
        'ft_feat_praise' => 'ft_feat_praise',
        'cel_profile_art_comment' => 'cel_profile_art_comment',
        'ft_author_oper_history' => 'ft_author_oper_history',
        
        // Settings
        'ft_enable_multiplayer' => 'ft_enable_multiplayer',
        'ft_trusted_friends' => 'ft_trusted_friends',
        'ft_user_part_time_service' => 'ft_user_part_time_service',
        'ft_part_time_service' => 'ft_part_time_service',
        'ft_currency' => 'ft_currency',
        'ft_user_part_time_free_times' => 'ft_user_part_time_free_times',
        
        // service setting
        'ft_order_number' => 'ft_order_number',
        'ft_order_of_service' => 'ft_order_of_service',
        'ft_order_info' => 'ft_order_info',
        'ft_users_address' => 'ft_users_address',
        'ft_position_province' => 'ft_position_province',
        'ft_position_city' => 'ft_position_city',
        'ft_position_county' => 'ft_position_county',
        
        // Good At
        'ft_good_at' => 'ft_good_at',
        
        // Profile
        'user' => 'user',
        'cel_user_other' => 'cel_user_other',
        'resume_tag' => 'resume_tag',
        'resume_education' => 'resume_education', // 教育
        'resume_experience' => 'resume_experience', // 工作经历
        'cel_user_evaluate' => 'cel_user_evaluate',
        'cel_user_lang' => 'cel_user_lang',
        'ft_languages' => 'ft_languages',
        'ft_country' => 'ft_country',
        'ft_user_good_at' => 'ft_user_good_at',
        'cel_display_setting' => 'cel_display_setting',
        'cel_display_to' => 'cel_display_to',
        'cel_display_var' => 'cel_display_var',
        'cel_contacter' => 'cel_contacter',
        'job_title' => 'job_title',
        'job_title_category' => 'job_title_category',
        'resume_study' => 'resume_study',
        
        // Operate
        'cel_operate_record' => 'cel_operate_record',
        
        // Feed
        'cel_feed' => 'cel_feed',
        
        // Experience
        'cel_user_experience' => 'cel_user_experience',
        'chat_photo' => 'chat_photo',
        'cel_experience_operate_record' => 'cel_experience_operate_record',
        'cel_experience_modify_time_record' => 'cel_experience_modify_time_record',
        'cel_experience_attachment_update' => 'cel_experience_attachment_update',
        'ft_history_in_today' => 'ft_history_in_today',
        
        // filter
        'ft_filter_cate' => 'ft_filter_cate',
        'ft_filter_words' => 'ft_filter_words',
        'ft_filter_record' => 'ft_filter_record',
        'ft_record_clientInfo' => 'ft_record_clientInfo',
        
        // menu
        'cel_menu_links' => 'cel_menu_links',
        
        // request
        'cel_request' => 'cel_request',
        
        // pull
        'ft_of_users' => 'ft_of_users',
        
        // Translation
        'ft_translation_all_basic_words' => 'ft_translation_all_basic_words',
        
        //ads
        'ft_ads' => 'ft_ads',
        'ft_ads_series' => 'ft_ads_series',
        'ft_ads_campaign' => 'ft_ads_campaign',
        
        //category
        'ft_categories_title_en_us' => 'ft_categories_title_en_us',
        'ft_categories_structure' => 'ft_categories_structure',
        'ft_categories_op_record' => 'ft_categories_op_record',
        
        //db-ft-manage
        'ft_admin_users' => 'ft_admin_users'
    );

    protected $tableFields;

    protected $tableName;

    protected static function existDataTable( $tableName )
    {
        if ( ! array_key_exists($tableName, self::$tableNameList) ) {
            throw new \ErrorException('invalid table name');
        }
    }

    /**
     *
     * @return string
     */
    protected function getTableName()
    {
        return $this->tableName;
    }

    /**
     *
     * @param string $tableName            
     * @return self
     */
    public function setTableName( $tableName )
    {
        $this->tableName = $tableName;
        return $this;
    }

    /**
     *
     * @return tableFields
     */
    public function getTableFields()
    {
        return $this->tableFields;
    }

    /**
     *
     * @param array $tableFields            
     * @return self
     */
    public function setTableFields( $tableFields )
    {
        $this->tableFields = $tableFields;
        return $this;
    }
}

