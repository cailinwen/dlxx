<?php
/**
 * Featee This is not a free software, unauthorized use is prohibited.
 *
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 * @author : pardus
 */
namespace DataTable\Service;

interface ProvidesTableMetadataInterface
{
    
    // Dimzou
    const DZ_CATEGORY = 'ft_dz_category';

    const DZ_ARTICLE = 'cel_profile_art';

    const DZ_AUDIT_RECORD = 'ft_dz_audit_record';

    const DZ_VETO_REASONS = 'ft_dz_veto_reasons';

    const COMMENT_TABLE = 'cel_profile_art_comment';

    const AUTHOR_OPER_HISTORY = 'ft_author_oper_history';
    
    // Profile Exp Feed
    const ROOM_CLOSE_CHAT = 'room_close_chat';

    const CONTACTER_INTERACTIVE = 'cel_contacter_interactive';

    const CHAT_MESSAGE = 'chat_message';

    const CHAT_PHOTO = 'chat_photo';

    const CHAT_MESSAGE_DELETE = 'chat_message_delete';

    const ROOM_CHAT_MUTE = 'room_chat_mute';

    const ROOM_MEMBER = 'room_member';

    const ROOM_LOG = 'room_log';

    const ROOM = 'room';
    // Feed
    const FEED_TABLE = 'cel_feed';
    
    // 擅长综合
    const GOOD_AT_TABLE = 'ft_good_at';
    // profile
    const USER = 'user';

    const USER_OTHER = 'cel_user_other';

    const USER_RESUME_TAG = 'resume_tag'; // 用户技能

    const USER_LANGUAGES = 'cel_user_lang';

    const USER_EDUCATION = 'resume_education'; // 教育

    const USER_WORK_EXPERIENCE = 'resume_experience'; // 工作经历

    const USER_EVALUATE = 'cel_user_evaluate'; // 评价

    const LANGUAGE = 'ft_languages';

    const JOB_CATEGORY_TABLE = 'job_title_category';

    const JOB_TITLE_TABLE = 'job_title';

    const RESUME_STUDY = 'resume_study';

    const USER_GOOD_AT_TABLE = 'ft_user_good_at'; // 用户擅长

    const COUNTRY = 'ft_country';

    const OF_USER = 'ft_of_users';

    const DISPLAY_SETTING = 'cel_display_setting';

    const DISPLAY_TO = 'cel_display_to';

    const DISPLAY_VAR = 'cel_display_var';

    const CONTACTER = 'cel_contacter';
    
    // ///////////
    const PROFILE_ART_COMMENT = 'cel_profile_art_comment';
    
    // settings
    const ENABLE_MULTI = 'ft_enable_multiplayer';

    const TRUSTED_FRIENDS = 'ft_trusted_friends';

    const USER_PART_TIME = 'ft_user_part_time_service';

    const PART_TIME = 'ft_part_time_service';

    const USER_PART_TIME_FREE_TIMES = 'ft_user_part_time_free_times';

    const CURRENCY = 'ft_currency';
    
    // Experience
    const EXPERIENCE_ATTACHMENT_UPDATE = 'cel_experience_attachment_update';

    const EXPERIENCE_MODIFY_TIME_RECORD = 'cel_experience_modify_time_record';

    const EXPERIENCE_OPERATE_RECORD = 'cel_experience_operate_record';

    const EXPERIENCE_OF_USER = 'cel_user_experience';

    const EXPERIENCE_HISTORY_TODAY = 'ft_history_in_today';
    
    // fileter
    const FILTER_CATE_TABLE = 'ft_filter_cate';

    const FILTER_WORD_TABLE = 'ft_filter_words';

    const FILTER_RECORD_TABLE = 'ft_filter_record';

    const CLIENT_RECORD_TABLE = 'ft_record_clientInfo';
    
    // Block
    const MENU_LINK = 'cel_menu_links';
    
    // request
    const REQUEST_TABLE = 'cel_request';
    
    // Translation
    // ads
    const ADS_TABLE = 'ft_ads';

    const ADS_SERIES_TAB = 'ft_ads_series';

    const ADS_CAMPAIGN_TAB = 'ft_ads_campaign';
    
    //category
    const CATEGORY_TITLE_EN_US_TAB = 'ft_categories_title_en_us';

    const CATEGORY_OP_RECORD_TAB = 'ft_categories_op_record';

    const CATEGORY_STRUCTURE_TAB = 'ft_categories_structure';
    
    //db-ft-manage
    const BACKSTAGE_ADMIN_USER_TAB = 'ft_admin_users';
}
