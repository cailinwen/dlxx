<?php
return array(
    
    'controllers' => array(
        'invokables' => array(
            'Dimzou\Controller\Index' => 'Dimzou\Controller\IndexController',
            'Dimzou\Controller\Audit' => 'Dimzou\Controller\AuditController'
        )
    ),
    'view_manager' => array(
        'template_map' => array(
            'dimzou/audit-layout' => __DIR__ . '/../view/layout/audit-layout.phtml',
            'dimzou/audit/index' => __DIR__ . '/../view/dimzou/audit/index.phtml',
            'dimzou/audit/article-frame' => __DIR__ . '/../view/dimzou/audit/auditArticleFrame.phtml',
            'dimzou/audit/audit-list' => __DIR__ . '/../view/dimzou/audit/auditList.phtml'
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view'
        )
    )
);
