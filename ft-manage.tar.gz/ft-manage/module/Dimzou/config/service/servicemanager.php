<?php
/**
 *
 * Featee
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
return array(
    'invokables' => array(
        'Dimzou_Db_Mapper_DzArticle'=>'Dimzou\Mapper\DzArticleDbMapper',
        'Dimzou_Service_DzArticle' => 'Dimzou\Service\DzArticleService'
    ),
    
    'factories' => array(),
    'aliases' => array(
        'dzArticleService' => 'Dimzou_Service_DzArticle',
        'dzArticleDbMapper'=>'Dimzou_Db_Mapper_DzArticle'
    )
);