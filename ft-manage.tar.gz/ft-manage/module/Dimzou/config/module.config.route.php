<?php
return array(
    'router' => array(
        'routes' => array(
            'dimzou' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/dimzou',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Dimzou\Controller',
                        'controller' => 'Index',
                        'action' => 'index'
                    )
                )
            ),
            'dimzou-audit' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/dimzou/audit[/:action]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*'
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Dimzou\Controller',
                        'controller' => 'Audit',
                        'action' => 'index'
                    )
                )
            )
        )
    )
);