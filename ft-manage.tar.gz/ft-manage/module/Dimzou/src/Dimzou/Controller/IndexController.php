<?php
namespace Dimzou\Controller;

class IndexController extends ModuleBaseController
{

    public function indexAction()
    {
        exit();
    }
}
