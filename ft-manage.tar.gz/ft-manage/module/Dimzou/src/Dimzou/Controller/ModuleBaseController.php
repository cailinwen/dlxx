<?php
namespace Dimzou\Controller;

use Core\Controller\AbstractBaseCoreController;

class ModuleBaseController extends AbstractBaseCoreController
{

    const AUDIT_PENDING = 0;

    const DF_TAXONOMY = 1;

    const PAGE_COUNT = 20;

    const DF_OFFSET = 0;

    const AUDIT_RECORD_VETO = 0;

    const AUDIT_RECORD_APPROVED = 1;

    protected $allowAdminUser = array(
        1,
        2,
        3
    );

    public function preDisPatch()
    {
        parent::preDisPatch();
        $this->checkLoginAndXmlRequest($this->loginUser);
        if ( ! in_array($this->loginUser['level'], $this->allowAdminUser) ) {
            exit('你无权访问！');
        }
    }

    protected function checkRequestMethod($method = 'POST')
    {
        switch ( $method ) {
            case 'POST':
                if ( $this->getRequest()->isPost() ) {
                    return true;
                }
                break;
            case 'GET':
                if ( $this->getRequest()->isGet() ) {
                    return true;
                }
                break;
            default:
                return self::ajaxReturn(0, null, 'Method is error');
                break;
        }
        return self::ajaxReturn(0, null, 'Must be ' . $method . ' method');
    }

    /**
     *
     * @var \Dimzou\Service\DzArticleService
     */
    private $dzArticleService;

    /**
     *
     * @return the $dzArticleService
     */
    protected function getDzArticleService()
    {
        if ( ! $this->dzArticleService ) {
            $this->dzArticleService = $this->getServiceLocator()->get('dzArticleService');
        }
        return $this->dzArticleService;
    }

    /**
     *
     * @var \Core\Service\DimzouCoverDiffSizePathService
     */
    private $dimzouDiffSizeCover;

    /**
     *
     * @return the $dimzouDiffSizeCover
     */
    protected function getDimzouDiffSizeCover()
    {
        if ( ! $this->dimzouDiffSizeCover ) {
            $this->dimzouDiffSizeCover = $this->getServiceLocator()->get('dimzouDiffSizeCover');
        }
        return $this->dimzouDiffSizeCover;
    }
}