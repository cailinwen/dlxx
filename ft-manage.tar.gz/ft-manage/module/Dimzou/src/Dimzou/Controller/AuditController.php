<?php
namespace Dimzou\Controller;

use Zend\View\Model\ViewModel;

class AuditController extends ModuleBaseController
{

    public function indexAction()
    {
        $view = new ViewModel();
        $this->reloadData(0, $view);
        return $view;
    }

    /**
     * 切换文章类型
     *
     * @return \Zend\View\Model\JsonModel
     */
    public function getArtsByCateAction()
    {
        $this->checkRequestMethod();
        $params = $this->params()->fromPost();
        if ( ! isset($params['taxonomy']) || ! isset($params['auditStatus']) ) {
            return self::createJsonView(0, '', '缺少必要的参数');
        }
        $taxonomy = $params['taxonomy'];
        $lastArtId = isset($params['lastArtId']) ? $params['lastArtId'] : 0;
        $offset = isset($params['offset']) ? $params['offset'] : self::DF_OFFSET;
        $auditStatus = $params['auditStatus'] ? $params['auditStatus'] : self::AUDIT_PENDING;
        
        $auditInfos = $this->getDzArticleService()->getAuditInfo($auditStatus, self::PAGE_COUNT + 1, $offset, $taxonomy);
        $accessUrl = $this->getServiceLocator()->get('access_upload_message');
        
        $viewData = array(
            'offset' => $offset,
            'lastArtId' => $lastArtId,
            'accessUrl' => $accessUrl
        );
        
        $cnt = count($auditInfos['auditList']);
        if ( $cnt > self::PAGE_COUNT ) {
            $pageEndArt = array_pop($auditInfos['auditList']);
            $viewData['pageEndArtId'] = $pageEndArt['art_id'];
        } else {
            $viewData['pageEndArtId'] = 0;
        }
        $viewData['artlist'] = $auditInfos['auditList'];
        $viewData['userInfo'] = $this->loginUser;
        
        $view = $this->getView('dimzou/audit/audit-list', $viewData);
        $data = array(
            'auditListHtml' => $view,
            'auditList' => $auditInfos['auditList'],
            'pendingCnt' => $auditInfos['pendingCnt'],
            'passCnt' => $auditInfos['passCnt'],
            'vetoCnt' => $auditInfos['vetoCnt'],
            'hasMore' => $cnt > self::PAGE_COUNT,
            'offset' => $cnt > self::PAGE_COUNT ? $cnt + $offset - 1 : $cnt + $offset
        );
        self::ajaxReturn(1, $data, 'success');
    }

    /**
     * 查询详细文章
     */
    public function ajaxGetArtByIdAction()
    {
        $this->checkRequestMethod();
        $params = $this->params()->fromPost();
        if ( ! isset($params['art_id']) || empty($params['art_id']) || ! isset($params['pre']) || ! isset($params['next']) ) {
            return self::createJsonView(0, $params, '缺少必要的参数');
        }
        $artInfo = $this->getDzArticleService()->getArtById($params['art_id']);
        if ( empty($artInfo) ) {
            self::ajaxReturn(0, '', 'Failed');
        }
        if ( $artInfo['is_audit'] === '2' ) {
            $reasons = $this->getDzArticleService()->getVetoReasons($params['art_id'], self::AUDIT_RECORD_VETO);
        }
        $view = $this->getView('dimzou/audit/article-frame', array(
            'artInfo' => $artInfo,
            'pre' => $params['pre'],
            'next' => $params['next'],
            'userInfo' => $this->loginUser,
            'accessUrl' => $this->getServiceLocator()
                ->get('access_upload_message')
        ));
        $data = array(
            'view' => $view,
            'artInfo' => $artInfo,
            'reasons' => isset($reasons) ? $reasons : array()
        );
        self::ajaxReturn(1, $data, 'success');
    }

    private function reloadData($statusType = 0, &$viewModel, $taxonomyId = 1)
    {
        $cate = $this->getParam('cate');
        $this->layout('dimzou/audit-layout');
        $this->headLink()->appendStylesheet('/css/common/base.css');
        $this->headLink()->appendStylesheet('/css/admin/admin.css');
        $this->requireJs()->loadRequiredFiles('JqueryAutosize');
        $this->requireJs()->loadRequiredFiles('DZAudit');
        $renderer = $this->getServiceLocator()->get('Zend\View\Renderer\PhpRenderer');
        $renderer->headTitle(GLOBAL_PROJECT . ' | Audit');
        $sort = $this->getDzArticleService()->getDzCategroies();
        if ( $taxonomyId == 0 ) {
            $taxonomyName = 'All';
        } else {
            $taxonomyName = $sort[0]['name'];
        }
        if ( ! empty($cate) ) {
            foreach ( $sort as $val ) {
                if ( ucfirst($cate) == $val['name'] ) {
                    $taxonomyId = $val['cate_id'];
                    $taxonomyName = $val['name'];
                    break;
                }
            }
        }
        $auditInfos = $this->getDzArticleService()->getAuditInfo($statusType, self::PAGE_COUNT + 1, self::DF_OFFSET, $taxonomyId);
        $viewData = array(
            'lastArtId' => 0,
            'accessUrl' => $this->getDimzouDiffSizeCover()->getAccessUploadMessage()
        );
        $cnt = count($auditInfos['auditList']);
        if ( $cnt > self::PAGE_COUNT ) {
            $pageEndArt = array_pop($auditInfos['auditList']);
            $viewData['pageEndArtId'] = $pageEndArt['art_id'];
        } else {
            $viewData['pageEndArtId'] = 0;
        }
        
        $viewData['artlist'] = $auditInfos['auditList'];
        $viewData['userInfo'] = $this->loginUser;
        $view = $this->getView('dimzou/audit/audit-list', $viewData);
        
        $this->javascript()->addSettings(array(
            'artSort' => json_encode($sort)
        ));
        $this->layout()->sort = $sort;
        $this->layout()->module = 'dimzou';
        $this->layout()->currentSort = $taxonomyName;
        $this->layout()->statusType = $statusType;
        $this->layout()->hasMore = ($cnt > self::PAGE_COUNT) ? 'true' : 'false';
        $this->layout()->offset = $cnt > self::PAGE_COUNT ? $cnt - 1 : $cnt;
        if ( $viewModel instanceof ViewModel ) {
            $viewModel->setTemplate('dimzou/audit/index');
            $viewModel->setVariables(array(
                'auditListHtml' => $view,
                'pendingCnt' => $auditInfos['pendingCnt'],
                'passCnt' => $auditInfos['passCnt'],
                'vetoCnt' => $auditInfos['vetoCnt']
            ));
        }
    }

    /**
     * 待审核
     */
    public function pendingAction()
    {
        $cate = $this->getParam('cate');
        $url = $this->url()->fromRoute('dimzou-audit');
        return $this->redirect()->toUrl($url . '?cate=' . $cate);
    }

    /**
     * 通过
     */
    public function approvedAction()
    {
        if ( ! $this->isXmlHttpRequest ) {
            $viewModel = new ViewModel();
            $this->reloadData(1, $viewModel);
            return $viewModel;
        }
        $artId = $this->getParam('artId');
        $nextId = $this->getParam('nextId');
        $lastArtId = $this->getParam('lastArtId');
        $title = $this->getParam('title');
        $content = $this->getParam('content');
        $taxonomy = $this->getParam('taxonomy');
        $offset = $this->getParam('offset');
        
        $state = $this->getDzArticleService()->approvedById($artId, $title, $content);
        if ( ! $state )
            self::ajaxReturn(0, '', 'Failed');
        $newAudit = $this->getDzArticleService()->getAuditInfo(self::AUDIT_PENDING, 2, $offset - 1, $taxonomy);
        $cnt = count($newAudit['auditList']);
        $accessUrl = $this->getServiceLocator()->get('access_upload_message');
        $viewData = array(
            'lastArtId' => $lastArtId,
            'accessUrl' => $accessUrl
        );
        if ( $cnt == 2 ) {
            $pageEndArt = array_pop($newAudit['auditList']);
            $viewData['pageEndArtId'] = $pageEndArt['art_id'];
        } else {
            $viewData['pageEndArtId'] = 0;
        }
        $viewData['artlist'] = array(
            array_shift($newAudit['auditList'])
        );
        $viewData['userInfo'] = $this->loginUser;
        $view = $viewData['artlist'][0] ? $this->getView('dimzou/audit/audit-list', $viewData) : '';
        $data = array(
            'newAuditHtml' => $view,
            'state' => $state,
            'newAudit' => $viewData['artlist']
        );
        $this->clearDimzouCache();
        self::ajaxReturn(1, $data, 'Successed');
    }

    /**
     * 保存否决操作
     */
    public function vetoingAction()
    {
        $artId = $this->getParam('artId');
        $lastArtId = $this->getParam('lastArtId');
        $title = $this->getParam('title');
        $content = $this->getParam('content');
        $offset = $this->getParam('offset');
        $taxonomy = $this->getParam('taxonomy');
        $reasoninfo = $this->params()->fromPost('reasoninfo');
        $reasoninfo = self::jsonToArray($reasoninfo);
        if ( ! $artId || ! $reasoninfo )
            self::ajaxReturn(0);
        $res = $this->getDzArticleService()->vetoing($artId, $title, $content, $reasoninfo);
        
        $newAudit = $this->getDzArticleService()->getAuditInfo(self::AUDIT_PENDING, 2, $offset - 1, $taxonomy);
        $cnt = count($newAudit['auditList']);
        $accessUrl = $this->getServiceLocator()->get('access_upload_message');
        $viewData = array(
            'lastArtId' => $lastArtId,
            'accessUrl' => $accessUrl
        );
        
        if ( $cnt == 2 ) {
            $pageEndArt = array_pop($newAudit['auditList']);
            $viewData['pageEndArtId'] = $pageEndArt['art_id'];
        } else {
            $viewData['pageEndArtId'] = 0;
        }
        $viewData['artlist'] = array(
            array_shift($newAudit['auditList'])
        );
        $viewData['userInfo'] = $this->loginUser;
        
        $view = $viewData['artlist'][0] ? $this->getView('dimzou/audit/audit-list', $viewData) : '';
        $data = array(
            'newAuditHtml' => $view,
            'state' => $res,
            'newAudit' => $viewData['artlist']
        );
        
        self::ajaxReturn(1, $data, 'success');
    }

    /**
     * 清除缓存
     */
    private function clearDimzouCache()
    {
        $cache = $this->cache();
        if ( $cache->hasItem('dimzou:articles:getUnionArt') ) {
            $cache->removeItem('dimzou:articles:getUnionArt');
        }
        if ( $cache->hasItem('dimzou:home:top') ) {
            $cache->removeItem('dimzou:home:top');
        }
        if ( $cache->hasItem('dimzou:home:html') ) {
            $cache->removeItem('dimzou:home:html');
        }
        if ( $cache->hasItem('dimzou:home:author') ) {
            $cache->removeItem('dimzou:home:author');
        }
        if ( $cache->hasItem('dimzou:home:hotArts') ) {
            $cache->removeItem('dimzou:home:hotArts');
        }
        if ( $cache->hasItem('dimzou:home:hotModify') ) {
            $cache->removeItem('dimzou:home:hotModify');
        }
    }

    public function vetoAction()
    {
        if ( ! $this->isXmlHttpRequest ) {
            $viewModel = new ViewModel();
            $this->reloadData(2, $viewModel);
            return $viewModel;
        }
    }

    /**
     * 所有未通过审核的文章
     *
     * @return \Zend\View\Model\ViewModel
     */
    public function pendingAllAction()
    {
        $view = new ViewModel();
        $this->reloadData(0, $view, 0);
        return $view;
    }
}