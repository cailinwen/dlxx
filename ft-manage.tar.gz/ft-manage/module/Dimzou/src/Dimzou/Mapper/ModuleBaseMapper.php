<?php
namespace Dimzou\Mapper;

use Core\DbMapper\AbstractDbMapper;

class ModuleBaseMapper extends AbstractDbMapper
{

    public static $userBaseFields = array(
        'user_id',
        'username',
        'handle',
        'personal_image',
        'personal_image_id'
    );

    public static $artBaseFields = array(
        'art_id',
        'title',
        'summary',
        'content',
        'author',
        'columns',
        'taxonomy',
        'art_image',
        'taxonomy',
        'publish_time',
        'created',
        'updated',
        'is_audit'
    );
}
