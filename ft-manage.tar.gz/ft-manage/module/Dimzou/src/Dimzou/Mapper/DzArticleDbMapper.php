<?php
namespace Dimzou\Mapper;

use Zend\Db\Adapter\Adapter;

class DzArticleDbMapper extends ModuleBaseMapper
{

    const DF_TAXONOMY = 1;

    const AUDIT_RECORD_APPROVED = 1;

    const AUDIT_RECORD_VETO = 0;

    const ART_AUDIT_APPROVED = 1;

    const ART_AUDIT_VETO = 2;

    const MOD_PARTI_TYPE_DIMZOU = 'dimzou';

    public function getVetoReasons($artId, $audit_status)
    {
        $record = $this->getRecordBystatusAndId($artId, $audit_status);
        return $this->getReasons($record['audit_record_id']);
    }

    private function getReasons($recordId)
    {
        $sql = $this->getSql()->setTable(array(
            'vr' => self::DZ_VETO_REASONS
        ));
        $select = $sql->select();
        $select->where->equalTo('vr.audit_record_id', $recordId);
        $selectString = $sql->getSqlStringForSqlObject($select);
        return $this->getDbAdapter()
            ->query($selectString, Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
    }

    private function getRecordBystatusAndId($artId, $auditStatus)
    {
        $sql = $this->getSql()->setTable(array(
            'r' => self::DZ_AUDIT_RECORD
        ));
        $select = $sql->select();
        $select->where->equalTo('r.article_id', $artId);
        $select->where->equalTo('r.audit_result', $auditStatus);
        $select->where->equalTo('r.status', 1);
        $select->order('r.audit_record_id DESC')->limit(1);
        $selectString = $sql->getSqlStringForSqlObject($select);
        $results = $this->getDbAdapter()
            ->query($selectString, Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
        return self::singleRow($results);
    }

    public function updateArt(array $data, array $where)
    {
        if ( ! $data || ! $where ) {
            throw new \Exception('Invalid arguments class:' . __CLASS__ . 'func:' . __FUNCTION__);
        }
        return $this->dbUpdate(self::DZ_ARTICLE, $data, $where);
    }

    public function vetoing($art_id, $title, $content, $reasoninfo, $user)
    {
        $rid = $this->addAuditRecord($art_id, $title, $content, self::AUDIT_RECORD_VETO, $user);
        $is_audit = self::ART_AUDIT_VETO;
        $state = $this->updateArt(compact('is_audit'), compact('art_id'));
        $batchData = array();
        foreach ( $reasoninfo as $key => $val ) {
            $batchData[] = array(
                'art_id' => $art_id,
                'audit_record_id' => $rid,
                'paragraphs_id' => $val['pid'],
                'reason' => $val['reason'],
                'c_time' => $_SERVER['REQUEST_TIME']
            );
        }
        return $this->multiInsert(self::DZ_VETO_REASONS, $batchData);
    }

    private function addAuditRecord($artId, $title, $content, $audit_result, $user)
    {
        if ( ! $artId ) {
            throw new \Exception('Invalid arguments class:' . __CLASS__ . 'func:' . __FUNCTION__);
        }
        $data = array(
            'article_id' => $artId,
            'article_title' => $title,
            'article_content' => $content,
            'admin_user_id' => $user['user_id'],
            'admin_username' => $user['username'],
            'audit_result' => $audit_result,
            'c_time' => $_SERVER['REQUEST_TIME']
        );
        return $this->dbInsert(self::DZ_AUDIT_RECORD, $data);
    }

    /**
     * 通过审核操作
     *
     * @param unknown $artId            
     * @param unknown $title            
     * @param unknown $content            
     * @param unknown $user            
     * @throws \Exception
     * @return number boolean
     */
    public function approvedById($art_id, $title, $content, $user)
    {
        if ( ! $art_id ) {
            throw new \Exception('Invalid arguments class:' . __CLASS__ . 'func:' . __FUNCTION__);
        }
        $data = array(
            'article_id' => $art_id,
            'article_title' => $title,
            'article_content' => $content,
            'admin_user_id' => $user['user_id'],
            'admin_username' => $user['username'],
            'audit_result' => self::AUDIT_RECORD_APPROVED,
            'c_time' => $_SERVER['REQUEST_TIME']
        );
        $rid = $this->dbInsert(self::DZ_AUDIT_RECORD, $data);
        if ( $rid ) {
            $is_audit = self::ART_AUDIT_APPROVED;
            return $this->dbUpdate(self::DZ_ARTICLE, compact('is_audit'), compact('art_id'));
        }
        return false;
    }

    public function getArtById($art_id)
    {
        $sql = $this->getSql()->setTable(array(
            'art' => self::DZ_ARTICLE
        ));
        $select = $sql->select();
        $select->columns(self::$artBaseFields);
        $select->join(array(
            'u' => 'user'
        ), 'u.user_id=art.author', self::$userBaseFields, $select::JOIN_LEFT);
        $select->where->equalTo('art.art_id', $art_id);
        $select->limit(1); // 返回条目
        $results = $this->getDbAdapter()
            ->query($sql->getSqlStringForSqlObject($select), Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
        return self::singleRow($results);
    }

    public function getAuditInfo($audit_status, $pageCount, $offset, $taxonomy)
    {
        $auditList = $this->getArtListBy($audit_status, $pageCount, $offset, $taxonomy);
        $pendingCnt = $this->getArtCntByAuditStatus(0, $taxonomy); // 待审核数量
        $passCnt = $this->getArtCntByAuditStatus(1, $taxonomy); // 已通过数量
        $vetoCnt = $this->getArtCntByAuditStatus(2, $taxonomy); // 已否决数量
        return array(
            'auditList' => $auditList,
            'pendingCnt' => $pendingCnt,
            'passCnt' => $passCnt,
            'vetoCnt' => $vetoCnt
        );
    }

    private function getArtCntByAuditStatus($auditStatus, $taxonomy)
    {
        $sql = $this->getSql()->setTable(array(
            'art' => self::DZ_ARTICLE
        ));
        $select = $sql->select();
        $select->columns(array(
            'num' => new \Zend\Db\Sql\Expression('COUNT(*)')
        ));
        
        if ( $auditStatus === 0 ) {
            $select->where->in('art.is_audit', array(
                $auditStatus,
                3
            ));
        } else {
            $select->where->equalTo('art.is_audit', $auditStatus);
        }
        $select->where->equalTo('art.is_del', 0)->equalTo('art.status', 2);
        if ( $taxonomy != 0 ) {
            $select->where->equalTo('art.taxonomy', $taxonomy);
        }
        $select->limit(1); // 返回条目
        $results = $this->getDbAdapter()
            ->query($sql->getSqlStringForSqlObject($select), Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
        return self::singleRow($results);
    }

    private function getArtListBy($auditState = 0, $pageCount = 20, $offset = 0, $taxonomy = self::DF_TAXONOMY, $isGetOpen = false)
    {
        $sql = $this->getSql()->setTable(array(
            'art' => self::DZ_ARTICLE
        ));
        $select = $sql->select();
        $select->columns(self::$artBaseFields);
        $select->join(array(
            'u' => 'user'
        ), 'u.user_id=art.author', self::$userBaseFields, $select::JOIN_LEFT);
        if ( $auditState === '0' ) {
            $select->where->in('art.is_audit', array(
                $auditState,
                3
            ));
        } else {
            $select->where->equalTo('art.is_audit', $auditState);
        }
        $select->where->equalTo('art.is_del', 0)
            ->equalTo('art.status', 2)
            ->equalTo('art.pid', 0);
        $select->where->notEqualTo('art.summary', '')->notEqualTo('art.art_image', '');
        if ( $taxonomy != 0 ) {
            $select->where->equalTo('art.taxonomy', $taxonomy);
        }
        $select->order('art.publish_time DESC');
        $select->limit($pageCount)->offset($offset); // 偏移位置
        return $this->getDbAdapter()
            ->query($sql->getSqlStringForSqlObject($select), Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
    }

    public function getDzCategroies($status = 'status!=0')
    {
        return $this->getTableGateway(self::DZ_CATEGORY)
            ->select(array(
            $status
        ))
            ->toArray();
    }
}