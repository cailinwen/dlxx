<?php
namespace Dimzou\Service;

class DzArticleService extends ModuleBaseService
{

    /**
     *
     * @var \Dimzou\Mapper\DzArticleDbMapper
     */
    private $dzArticleDbMapper;

    /**
     *
     * @return the $dzArticleDbMapper
     */
    private function getDzArticleDbMapper()
    {
        if ( ! $this->dzArticleDbMapper ) {
            $this->dzArticleDbMapper = $this->getServiceLocator()->get('dzArticleDbMapper');
        }
        return $this->dzArticleDbMapper;
    }

    public function getDzCategroies()
    {
        $key = 'dimzou:category:category';
        $cache = $this->cache();
        if ( $cache->hasItem($key) ) {
            return $cache->getItem($key);
        }
        $cates = $this->getDzArticleDbMapper()->getDzCategroies();
        $cache->setItem($key, $cates);
        return $cates;
    }

    public function getArtById($art_id)
    {
        return $this->getDzArticleDbMapper()->getArtById($art_id);
    }

    public function approvedById($artId, $title, $content)
    {
        $user = self::getSessionUser();
        return $this->getDzArticleDbMapper()->approvedById($artId, $title, $content, $user);
    }

    public function vetoing($artId, $title, $content, $reasoninfo)
    {
        $user = self::getSessionUser();
        return $this->getDzArticleDbMapper()->vetoing($artId, $title, $content, $reasoninfo, $user);
    }

    public function getAuditInfo($audit_status, $pageCount, $offset, $taxonomy)
    {
        $result = $this->getDzArticleDbMapper()->getAuditInfo($audit_status, $pageCount, $offset, $taxonomy);
        if ( ! empty($result) ) {
            $result['auditList'] = isset($result['auditList']) ? $result['auditList'] : '';
            $result['pendingCnt'] = isset($result['pendingCnt']['num']) ? $result['pendingCnt']['num'] : '';
            $result['passCnt'] = isset($result['passCnt']['num']) ? $result['passCnt']['num'] : '';
            $result['vetoCnt'] = isset($result['vetoCnt']['num']) ? $result['vetoCnt']['num'] : '';
        }
        return $result;
    }

    public function getVetoReasons($artId, $audit_status)
    {
        return $this->getDzArticleDbMapper()->getVetoReasons($artId, $audit_status);
    }
}