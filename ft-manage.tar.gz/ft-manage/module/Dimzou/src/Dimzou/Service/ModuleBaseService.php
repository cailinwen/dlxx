<?php
namespace Dimzou\Service;

use Core\Service\AbstractService;

class ModuleBaseService extends AbstractService
{
}