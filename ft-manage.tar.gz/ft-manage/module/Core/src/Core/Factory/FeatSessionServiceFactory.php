<?php
namespace Core\Factory;

use Zend\ServiceManager\FactoryInterface;

class FeatSessionServiceFactory implements FactoryInterface
{

    public function createService(\Zend\ServiceManager\ServiceLocatorInterface $serviceLocator)
    {
        $config = $serviceLocator->get('config');
        $dbAdapter = $serviceLocator->get('ft_manage');
        $sessionOptions = new \Zend\Session\SaveHandler\DbTableGatewayOptions();
        $sessionTableGateway = new \Zend\Db\TableGateway\TableGateway('ft_admin_sessions', $dbAdapter);
        $saveHandler = new \Zend\Session\SaveHandler\DbTableGateway($sessionTableGateway, $sessionOptions);
        $sessionManager = $serviceLocator->get('Zend\Session\SessionManager');
        $sessionManager->setSaveHandler($saveHandler);
        return $sessionManager;
    }
}