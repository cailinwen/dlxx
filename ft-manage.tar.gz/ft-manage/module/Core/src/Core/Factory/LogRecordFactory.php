<?php
namespace Core\Factory;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

class LogRecordFactory implements FactoryInterface
{

    public function createService( ServiceLocatorInterface $serviceLocator )
    {
        $filename = 'log_' . date('Y') . '_' . date('F') . '_' . date('d') . '.txt';
        $log = new \Zend\Log\Logger();
        $writer = new \Zend\Log\Writer\Stream('./data/logs/' . $filename);
        $log->addWriter($writer);
        return $log;
    }
} 