<?php
/**
 * 
 * Featee
 * 
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * 
 *
*/
namespace Core\Service;

use Core\Controller\Plugin\UploadHandler as UploadHandlerPlugin;

class FileOperationService extends AbstractService
{

    private $uploadHandleErrors;

    /**
     *
     * @param array $fileArr            
     * @param string $paramName            
     * @param array $allowed_ext            
     * @return string boolean
     */
    public function uploadHandle($fileArr, $destination, $paramName = 'image_url', $allowed_ext = array('jpeg','jpg','png','gif'))
    {
        $adapter = new \Zend\File\Transfer\Adapter\Http();
        $size = new \Zend\Validator\File\Size(array(
            'min' => 1
        ));
        // minimum bytes filesize, max too..
        $imageSize = new \Zend\Validator\File\ImageSize(array(
            'minwidth' => 49,
            'minheight' => 10
        ));
        $extension = new \Zend\Validator\File\Extension(array(
            'extension' => $allowed_ext
        ));
        $adapter->setValidators(array(
            $size,
            $extension,
            $imageSize
        ), $fileArr['name']);
        
        if ( $adapter->isValid() ) {
            $upload_handler = new UploadHandlerPlugin(array(
                'upload_dir' => $destination,
                'param_name' => $paramName
            ), false);
            $fileArray = $upload_handler->post(false);
            $image_name = $fileArray[$paramName][0]->name;
            return $image_name;
        }
        $this->uploadHandleErrors = $adapter->getMessages();
        return false;
    }

    public function uploadHandleError()
    {
        $uploadHandleErrors = $this->uploadHandleErrors;
        $this->uploadHandleErrors = null;
        return $uploadHandleErrors;
    }

    function download($destination, $file_name)
    {
        header("Content-type:text/html;charset=utf-8");
        $file_path = $destination . $file_name;
        if ( ! file_exists($file_path) ) {
            return false;
        }
        $fp = fopen($file_path, "r");
        $file_size = filesize($file_path);
        // 下载文件需要用到的头
        Header("Content-type: application/octet-stream");
        Header("Accept-Ranges: bytes");
        Header("Accept-Length:" . $file_size);
        Header("Content-Disposition: attachment; filename=" . $file_name);
        $buffer = 1024;
        $file_count = 0;
        // 向浏览器返回数据
        while ( ! feof($fp) && $file_count < $file_size ) {
            $file_con = fread($fp, $buffer);
            $file_count += $buffer;
            echo $file_con;
        }
        fclose($fp);
        exit();
    }

    /**
     *
     * @todo 创建文件夹，可创建多级文件夹
     *      
     * @param string $path            
     * @return bool
     */
    function make_dir($path, $mode = 0777)
    {
        $path = str_replace('\\', '/', $path);
        if ( is_dir($path) )
            return true;
        $arr = explode('/', $path);
        $pathNew = '/';
        // 以数组中的值为文件夹名建立文件夹
        foreach ( $arr as $dir ) {
            $dir = trim($dir);
            if ( $dir == '.' || empty($dir) )
                continue;
            $dir .= '/';
            if ( ! is_dir($pathNew . $dir) )
                @mkdir($pathNew . $dir, $mode);
            $pathNew .= $dir;
        }
        return is_dir($path) && $this->chmod($path);
    }

    /**
     *
     * @todo Cope file 复制文件
     *      
     * @param string $fileUrl            
     * @param string $aimUrl            
     * @param boolean $overWrite
     *            该参数控制是否覆盖原文件
     * @return boolean
     */
    public function copyFile($fileUrl, $aimUrl, $overWrite = false)
    {
        try {
            if ( ! file_exists($fileUrl) ) {
                return false;
            }
            if ( file_exists($aimUrl) && $overWrite == false ) {
                return false;
            } elseif ( file_exists($aimUrl) && $overWrite == true ) {
                $this->unlinkImg($aimUrl);
            }
            $boolean = copy($fileUrl, $aimUrl);
            if ( ! file_exists($aimUrl) ) {
                var_dump($fileUrl, $aimUrl);
                throw new \Exception(sprintf('file %s doesn\'t exists', $aimUrl));
            }
            return $boolean;
        } catch ( \Exception $e ) {
            var_dump($e->__toString());
        }
    }

    public function unlinkImg($imgUri)
    {
        if ( file_exists($imgUri) ) {
            @unlink($imgUri);
        }
    }

    /**
     *
     * @todo Get file extension
     *      
     * @param string $file_name            
     * @return string
     */
    public function get_extension($file_name)
    {
        $ext = explode('.', $file_name);
        $ext = array_pop($ext);
        return strtolower($ext);
    }

    public function chmod($path = '.', $level = 0)
    {
        $return = true;
        if ( ! is_dir($path) && ! is_file($path) ) {
            $return = false;
        }
        
        $ignore = array(
            'cgi-bin',
            '.',
            '..'
        );
        $dh = @opendir($path);
        while ( false !== ($file = readdir($dh)) ) { // Loop through the directory
            
            if ( ! in_array($file, $ignore) ) {
                
                if ( is_dir("$path/$file") ) {
                    $this->chmod("$path/$file", ($level + 1));
                } else {
                    if ( ! chmod("$path/$file", 0777) && $return ) {
                        $return = false;
                    } // desired
                          // permission
                          // settings
                } // elseif
            } // if in array
        } // while
        
        closedir($dh);
        
        if ( ! chmod($path, 0777) && $return ) {
            $return = false;
        }
        
        return $return;
    }

    /**
     * delete dir and file
     * 删除目录下的文件和文件夹，包括自身。
     *
     * @param string $dirName
     *            file path
     * @return boolean
     */
    function delDirAndFile($dirName, $rmcurDir = true)
    {
        if ( ! file_exists($dirName) ) {
            return 'NoDirectory';
        }
        $handle = opendir("$dirName");
        if ( $handle ) {
            while ( false !== ($item = readdir($handle)) ) {
                if ( $item != "." && $item != ".." ) {
                    if ( is_dir("$dirName/$item") ) {
                        $this->delDirAndFile("$dirName/$item");
                    } else {
                        @unlink("$dirName/$item");
                    }
                }
            }
            closedir($handle);
            if ( $rmcurDir ) {
                if ( rmdir($dirName) ) {
                    return true;
                } else {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    public function deleteCelestraImage($imageDestination, $image_name)
    {
        if ( ! empty($image_name) ) {
            $delImage = $imageDestination . $image_name;
            if ( file_exists($delImage) )
                @unlink($delImage);
        }
    }

    /**
     *
     * @todo 移除临时文件
     * @todo Remove temporaty files
     *      
     * @access public
     * @author zeqiang
     * @return boolean
     */
    public function removeTemporaryFiles()
    {
        $dirName = FAIRFEAT_PUBLIC_PATH . '/uploads/temporary';
        if ( ! file_exists($dirName) )
            return false;
        $handle = opendir("$dirName");
        if ( $handle ) {
            $nime = time() - 3600;
            while ( false !== ($item = readdir($handle)) ) {
                if ( $item != "." && $item != ".." ) {
                    if ( is_dir("$dirName/$item") ) {
                        continue;
                    } else {
                        $ctime = filectime("$dirName/$item");
                        if ( $ctime < $nime )
                            @unlink("$dirName/$item");
                    }
                }
            }
            closedir($handle);
            return true;
        } else {
            return false;
        }
    }
}