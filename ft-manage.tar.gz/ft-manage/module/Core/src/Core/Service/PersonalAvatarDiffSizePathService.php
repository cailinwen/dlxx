<?php
namespace Core\Service;

class PersonalAvatarDiffSizePathService extends ModuleBaseService
{

    private $userAavatarSize;

    public function getUserAavatarSize()
    {
        $config = $this->getConfig();
        if ( ! $this->userAavatarSize ) {
            $this->userAavatarSize = $config['Thumbnail_Size']['user_avatar'];
        }
        return $this->userAavatarSize;
    }

    /**
     * 用户封面上头像
     *
     * @param array $logo            
     * @param array $user            
     * @param array $logoInfo            
     */
    public function userCoverUpAvatar($logo, &$user, $logoInfo)
    {
        $accessUrl = $this->getAccessUploadMessage();
        $imgFullName = $logoInfo['image'];
        $imgName = explode('.', $imgFullName)[0];
        $user_id = $user['user_id'];
        $logo['photo_name'] = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgFullName;
        $logo['logo_url'] = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgFullName;
        $personal_image_path = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgName . '/' . $imgFullName;
        if ( $this->img_exits($personal_image_path) ) {
            $logo['personal_image_origin'] = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgFullName;
            $logo['personal_image'] = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgName . '/' . $imgFullName;
            foreach ( $this->getUserAavatarSize() as $key => $val ) {
                $logo['personal_image_othersize_' . $val[0] . 'x' . $val[1]] = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgName . '/' . $val[0] . 'x' . $val[1] . '/' . $imgFullName;
            }
        } else {
            $linkCdn = $this->getLinkCdn();
            $logo['personal_image'] = $linkCdn('/imgs/personal.jpg');
        }
        $user['personal_image_info'] = $logo;
    }

    /**
     * 处理穿入的是图片的完整路径的情况。
     *
     * @param stirng $img            
     * @return boolean string
     */
    private static function is_imgUrl($img)
    {
        $expImg = explode('/', $img);
        if ( count($expImg) < 2 ) {
            return false;
        }
        return end($expImg);
    }

    public function echoImgPath($user_id, $fileName, $size = 2)
    {
        $imgName = $fileName;
        $is_imgUrl = self::is_imgUrl($imgName);
        if ( $is_imgUrl ) {
            $imgName = $is_imgUrl;
        }
        $onlyName = explode('.', $imgName)[0];
        switch ( $size ) {
            case 1:
                $path = 'user/' . $user_id . '/avatar/' . $imgName;
                $defImg = '/imgs/personal.jpg';
                break;
            case 2:
                $path = 'user/' . $user_id . '/avatar/' . $onlyName . '/' . $imgName;
                $defImg = '/imgs/personal.jpg';
                break;
            case 3:
                $path = 'user/' . $user_id . '/avatar/' . $onlyName . '/50x50/' . $imgName;
                $defImg = '/imgs/personal_50x50.jpg';
                break;
            case 4:
                $path = 'user/' . $user_id . '/avatar/' . $onlyName . '/32x32/' . $imgName;
                $defImg = '/imgs/personal_32x32.jpg';
                break;
            case 5:
                $path = 'user/' . $user_id . '/avatar/' . $onlyName . '/24x24/' . $imgName;
                $defImg = '/imgs/personal_24x24.jpg';
                break;
            case 6:
                $path = 'user/' . $user_id . '/avatar/' . $onlyName . '/100x100/' . $imgName;
                $defImg = '/imgs/personal.jpg';
                break;
            case 7:
                $path = 'user/' . $user_id . '/avatar/' . $onlyName . '/150x150/' . $imgName;
                $defImg = '/imgs/personal.jpg';
                break;
        }
        $fullImgPath = $this->getAccessUploadMessage() . $path;
        if ( ! $imgName || ! $this->img_exits($fullImgPath) ) {
            $linkCdn = $this->getLinkCdn();
            return $linkCdn($defImg);
        }
        return $fullImgPath;
    }

    /**
     * 获取参与或采纳人的头像（type=1）
     * 获取经历的用户头像(type=2)
     *
     * @param array $user            
     * @param number $type            
     * @return string
     */
    public function getEditorUserImg($user, $type = 1)
    {
        $linkCdn = $this->getLinkCdn();
        if ( ! $user ) {
            return $linkCdn('/imgs/personal.jpg');
        }
        if ( $user['personal_image'] ) {
            if ( $type == 1 ) {
                $imgUrl = $this->getAccessUploadMessage() . 'user/' . $user['user_id'] . '/avatar/' . explode('.', $user['personal_image'])[0] . '/' . $user['personal_image'];
            } else {
                $imgUrl = $this->getAccessUploadMessage() . 'user/' . $user['user_id'] . '/avatar/' . explode('.', $user['personal_image'])[0] . '/32x32/' . $user['personal_image'];
            }
            $bool = $this->img_exits($imgUrl);
            if ( $bool ) {
                return $imgUrl;
            }
            return $linkCdn('/imgs/personal.jpg');
        } else {
            return $linkCdn('/imgs/personal.jpg');
        }
    }

    /**
     * Save into Session
     *
     * @param array $user            
     */
    public function userAvatar(&$user)
    {
        $logoInfo = $user;
        if ( $user['personal_image'] && $user['personal_image_id'] ) {
            $imgFullName = $logoInfo['personal_image'];
            $imgName = explode('.', $imgFullName)[0];
            $user_id = $logoInfo['user_id'];
            $accessUrl = $this->getAccessUploadMessage();
            $personal_image_url = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgName . '/' . $imgFullName;
            if ( $this->img_exits($personal_image_url) ) {
                $user['personal_image_origin'] = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgFullName;
                $user['personal_image'] = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgName . '/' . $imgFullName;
                foreach ( $this->getUserAavatarSize() as $key => $val ) {
                    $user['personal_image_othersize_' . $val[0] . 'x' . $val[1]] = $accessUrl . 'user/' . $user_id . '/avatar/' . $imgName . '/' . $val[0] . 'x' . $val[1] . '/' . $imgFullName;
                }
            } else {
                $linkCdn = $this->getLinkCdn();
                $user['personal_image'] = $linkCdn('/imgs/personal.jpg');
            }
        } else {
            $linkCdn = $this->getLinkCdn();
            $user['personal_image'] = $linkCdn('/imgs/personal.jpg');
        }
    }
}