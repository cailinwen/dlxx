<?php
/**
 * 
 * @name Featee
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved
 *
*/
namespace Core\Service;

class SoapHandleService extends AbstractService
{
    /**
     *
     * @var object
     */
    protected $soapClient;
    protected $sessionId;
    protected $clientSet;
    protected $sessionIds;
    
    public function callSoapService($project, $serviceApi, $parameters = array())
    {
        $sessionId = $this->getAuthorization($project);
        $client = $this->getClient($project);
        if(!is_string($sessionId)) {
        	   throw new \Exception(json_encode($sessionId));
        }
        $result = false;
        
        $result = $client->call($sessionId, $serviceApi, $parameters);
        if(is_string($result) && strpos($result, 'Stack trace')) {
        	   throw new \ErrorException($result);
        }
        return $result;
    }
    
    public function multiCallSoapService($project, $options, $path = '')
    {
        $sessionId = $this->getAuthorization($project);
        $client = $this->getClient($project);
        if(!is_string($sessionId)) {
        	   throw new \Exception(json_encode($sessionId));
        }
        $result = $client->multiCall($sessionId, $options, $path);
        if(is_string($result) && strpos($result, 'Stack trace')) {
            	throw new \ErrorException($result);
        }
        return $result;
    }

    private function setSoapClient(\SoapClient $client)
    {
        $this->soapClient = $client;
        return $this;
    }

    public function getSoapClient()
    {
        if (isset($this->soapClient)) {
            return $this->soapClient;
        }
        return false;
    }
    
    protected function attachClient($id, \SoapClient $instance) 
    {
    	   if(!isset($this->clientSet[$id])) {
    	       $this->clientSet[$id] = $instance;
    	   }
    	   return $this;
    }
    
    protected function getClient($id)
    {
    		return isset($this->clientSet[$id]) ?  $this->clientSet[$id] : false;
    }
    
    /**
     *
     * @todo Get authorization from a remoted server by using SOAP
     * @todo 通过使用SOAP获取远程服务器授权
     * @param string $role User's name of a role
     * @param string $apiKey Accessing password
     * @return string an identifier of the authorization
     */
    public function getAuthorization($project)
    {
        try {
            $config = $this->getServiceLocator()->get('config');
            $url = $config['soap_manager'][$project]['remote_server'];
            $options = array(
                'keep_alive' => true,
            		'compression' => SOAP_COMPRESSION_ACCEPT | SOAP_COMPRESSION_GZIP | 5,
//             		'connection_timeout' => 600,
                'trace'=>true,
                'cache_wsdl' => WSDL_CACHE_BOTH,
            );
            if(strpos($url, '?wsdl')>-1) {
                $this->attachClient($project, new \SoapClient($url, $options));
            }  else {
                $options['location'] =  $url;
                $options['uri'] = $url;
                $this->attachClient($project, new \SoapClient(null, $options));
            }
            $client = $this->getClient($project);
            foreach ($_COOKIE as $key => $value) {
            	   if(strpos($key, '_language')>-1) {
            	       $client->__setCookie('cel_language', $value);
            	   }
            }
            
            $soapManager = $config['soap_manager'][$project];
            $this->setSoapClient($client);
            if(!($sessionId = $this->getSessionId($project))) {
                $sessionId = $client->login($soapManager['api_user'],   $soapManager['api_key']);
                $this->setSessionId($sessionId, $project);
            } 
            if(!is_string($sessionId)) {
                	throw new \Exception(json_encode($sessionId) .$project);;
            }
            return $sessionId ;
        } catch (\SoapFault $e) {
            zp_dump($e->__toString());
        } catch (\Exception $e) {
            zp_dump($e->__toString());
        }
    }
    
    public function setSessionId($sessionId, $project) 
    {
    	   $this->sessionIds[$project] = $sessionId;
    	   return $this;   
    }
    
    public function getSessionId($project) 
    {
    	   return isset($this->sessionIds[$project]) ?  $this->sessionIds[$project] : false;
    }
}
