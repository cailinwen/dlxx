<?php
namespace Core\Service;

class DimzouCoverDiffSizePathService extends ModuleBaseService
{

    public function echoDimzouImgPath($user_id, $art_id, $filename, $size)
    {
        if ( $size == 1 ) { // 547x341
            $path = 'user/' . $user_id . '/dimzou/' . $art_id . '/photo/cover/547x341/' . $filename;
        } elseif ( $size == 2 ) { // 138x86
            $path = 'user/' . $user_id . '/dimzou/' . $art_id . '/photo/cover/138x86/' . $filename;
        } else { // 原图
            $path = 'user/' . $user_id . '/dimzou/' . $art_id . '/photo/cover/' . $filename;
        }
        $fullImgPath = $this->getAccessUploadMessage() . $path;
        if ( ! $this->img_exits($fullImgPath) ) {
            $linkCdn = $this->getLinkCdn();
            if($size==1){
                return $linkCdn('/imgs/def-dz-cover_547x341.png');
            }elseif ($size==2){
                return $linkCdn('/imgs/def-dz-cover_138x86.png');
            }else{
                return $linkCdn('/imgs/def-dz-cover_138x86.png');
            }
        }
        return $fullImgPath;
    }
}