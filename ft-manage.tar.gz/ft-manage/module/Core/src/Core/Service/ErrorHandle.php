<?php
/**
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved. @date: 2014-3-1 下午6:50:27
 * @author : pardus
 */
namespace Core\Service;

class ErrorHandle extends AbstractService
{

    protected $logger;

    public function _init()
    {
        $this->logger = $this->getServiceLocator()->get('LogRecordFactory');
        return $this;
    }

    public function logException( \Exception $e )
    {
        $trace = $e->getTraceAsString();
        $i = 1;
        $where = $e->getPrevious();
        do {
            $messages[] = $i ++ . ' : ' . $e->getMessage();
        } while ($where);
        $log = "Exception:\n" . implode("\n", $messages);
        $log .= "\nTrace:\n" . $trace;
        
        $this->logger->err($log);
    }
}