<?php
namespace Core\Service;

/**
 * 有关时间操作的函数集合
 *
 * @author parduswu
 *        
 */
trait RelatedTimeTrait
{

    /**
     * 计时函数
     *
     * @param number $mode            
     * @return void string
     */
    protected static function runtime($mode = 0)
    {
        static $t;
        if ( ! $mode ) {
            $t = microtime();
            return;
        }
        $t1 = microtime();
        list ($m0, $s0) = explode(" ", $t);
        list ($m1, $s1) = explode(" ", $t1);
        return sprintf("%.3f ms", ($s1 + $m1 - $s0 - $m0) * 1000);
    }

    /**
     * 格式化时间戳
     *
     * @param int $time            
     * @return string
     */
    protected static function formatTime($time)
    {
        return date('Y-m-d H:i:s', $time);
    }

    protected static function handleTime($timestamp)
    {
        $awayTime = time() - $timestamp;
        if ( 0 == $awayTime ) {
            return '1 sec';
        } else if ( 0 < $awayTime && $awayTime < 60 ) {
            return $awayTime . 'sec';
        } else if ( 60 <= $awayTime && $awayTime < 3600 ) {
            return floor($awayTime / 60) . ' minutes';
        } else if ( 3600 <= $awayTime && $awayTime < 3600 * 24 ) {
            return floor($awayTime / 3600) . ' hours';
        } else if ( 3600 * 24 <= $awayTime ) {
            return floor($awayTime / 86400) . ' days';
        }
    }

    /**
     * 获取当前时间戳
     *
     * @return int
     */
    protected static function getCurrentTime()
    {
        return $_SERVER['REQUEST_TIME'];
    }

    /**
     * 格式化时间
     *
     * @param int $time            
     * @param number $type            
     * @param boolean $abbreviation            
     * @param string $locale            
     * @return string
     */
    protected static function formatTimeByLocale($time, $type = 1, $abbreviation = true, $locale = 'en_US')
    {
        switch ( $type ) {
            case 1:
                // 显示格式如 2014-10-28 10:11:41
                $time = date('Y-m-d H:i:s', $time);
                break;
            case 2:
                // 显示格式如 2014-10-28
                $time = date("Y-m-d", $time);
                break;
            case 3:
                // 显示格式如 2014.10.28
                $time = date("Y.m.d", $time);
                break;
            case 4:
                if ( date('Y') == date('Y', $time) ) { // 同年
                    if ( $locale == 'zh_CN' ) {
                        // 显示格式如: 12月15日 上午 11:14
                        $time = date('m', $time) . '月' . date('d', $time) . '日' . ' ' . (date('A', $time) == 'AM' ? '上午' : '下午') . ' ' . date('H:i', $time);
                    } else {
                        if ( ! $abbreviation ) {
                            // 显示格式如: December 28 at 10:11 AM
                            $time = date('F d', $time) . ' at ' . date('H:i A', $time);
                        } else {
                            // 显示格式如: Dec 28 at 10:11 AM
                            $time = date('M d', $time) . ' at ' . date('H:i A', $time);
                        }
                    }
                } else {
                    if ( $locale == 'zh_CN' ) {
                        // 显示格式如: 2014年12月15日 上午 11:14
                        $time = date('Y', $time) . '年' . date('m', $time) . '月' . date('d', $time) . '日' . ' ' . (date('A', $time) == 'AM' ? '上午' : '下午') . ' ' . date('H:i', $time);
                    } else {
                        if ( ! $abbreviation ) {
                            // 显示格式如: December 28, 2013 at 10:11 AM
                            $time = date('F d, Y', $time) . ' at ' . date('H:i A', $time);
                        } else {
                            // 显示格式如: Dec 28, 2013 at 10:11 AM
                            $time = date('F d, Y', $time) . ' at ' . date('H:i A', $time);
                        }
                    }
                }
                break;
        }
        return $time;
    }
}