<?php
namespace Core\Service;

use Core\Service\AbstractService as CoreAbstractService;

class ModuleBaseService extends CoreAbstractService
{

    private $access_upload_message;

    private $config;

    private $base_upload_dir;

    private $linkCdn;

    /**
     *
     * @return http://10.0.10.110:911/
     */
    public function getAccessUploadMessage()
    {
        if ( ! $this->access_upload_message ) {
            $this->access_upload_message = $this->getServiceLocator()->get('access_upload_message');
        }
        return $this->access_upload_message;
    }

    protected function getConfig()
    {
        if ( ! $this->config ) {
            $this->config = $this->getServiceLocator()->get('config');
        }
        return $this->config;
    }

    /**
     *
     * @return ../uploads/
     */
    public function getBaseUploadDir()
    {
        if ( ! $this->base_upload_dir ) {
            $this->base_upload_dir = $this->getServiceLocator()->get('upload_setting');
        }
        return $this->base_upload_dir;
    }

    public function getLinkCdn()
    {
        if ( ! $this->linkCdn ) {
            $this->linkCdn = $this->getServiceLocator()
                ->get('ViewHelperManager')
                ->get('linkCdn');
        }
        return $this->linkCdn;
    }

    /**
     * 判断是否是远程
     *
     * @return boolean
     */
    private function is_remote()
    {
        $ip = $this->get_client_ip();
        if ( $ip == HOST_IP ) {
            return false;
        }
        return true;
    }

    /**
     * 判断远程图片是否存在
     *
     * @param string $url            
     * @return boolean
     */
    protected function img_exits($url)
    {
        if ( $this->is_remote() ) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_NOBODY, 1); // 不下载
            curl_setopt($ch, CURLOPT_FAILONERROR, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $contents = curl_exec($ch);
            if ( $contents !== false ) {
                return true;
            } else {
                return false;
            }
        }
    }
}