<?php
namespace Core\Service;

use Zend\Http\Client as HttpClient;
use Zend\Http\PhpEnvironment\Response as HttpResponse;
use Core\Controller\Plugin\Encryption;

class RestfulClientService extends AbstractService
{

    const ACCESS_KEY = '719a76565181e104942802c68ff406f7';

    const SECRET_KEY = '0396c0128a904efb272f08abf7f4b797';

    public function getAndCallRestfulApi($project, $path, $method, $parameters = array())
    {
        $appConfig = $this->getAppconfig($project);
        extract($appConfig);
        if ( isset($remote_server) ) {
            $fristPath = $remote_server;
        }else{
            $fristPath = $protocol . $host . ':' . $port . '/';
        }
        $uri = $fristPath . $path;
        $client = new HttpClient();
        $client->setAdapter('Zend\Http\Client\Adapter\Curl');
        $client->setUri($uri);
        $encodeAuthHeader = $client->encodeAuthHeader(self::ACCESS_KEY, Encryption::encryption(self::SECRET_KEY, self::ACCESS_KEY . ':' . self::SECRET_KEY));
        $headers = array(
            'Authorization' => $encodeAuthHeader
        );
        switch ( $method ) {
            case 'GET':
                $headers = array_merge($headers, array(
                    'Content-Type' => 'application/json; charset=UTF-8'
                ));
                $client->setParameterGet($parameters);
                break;
            case 'POST':
                $client->setParameterPost($parameters);
                break;
            case 'PUT':
                $headers = array_merge($headers, array(
                    'Content-Type' => 'application/json; charset=UTF-8'
                ));
                $adapter = $client->getAdapter();
                $adapter->connect($host, $port);
                $adapter->write('PUT', new \Zend\Uri\Uri($uri), 1.1, $headers, http_build_query($parameters));
                $responsecurl = $adapter->read();
                list ($headers, $content) = explode("\r\n\r\n", $responsecurl, 2);
                if ( empty($content) ) {
                    return \Zend\Json\Json::encode(array(
                        'reslut' => explode("\r", $headers)[0]
                    ));
                }
                return $content;
                break;
            case 'DELETE':
                $headers = array_merge($headers, array(
                    'Content-Type' => 'application/json; charset=UTF-8'
                ));
                $adapter = $client->getAdapter();
                $adapter->connect($host, $port);
                $adapter->write('DELETE', new \Zend\Uri\Uri($uri), 1.1, $headers, http_build_query($parameters));
                $responsecurl = $adapter->read();
                list ($headers, $content) = explode("\r\n\r\n", $responsecurl, 2);
                if ( empty($content) ) {
                    return \Zend\Json\Json::encode(array(
                        'reslut' => explode("\r", $headers)[0]
                    ));
                }
                return $content;
                break;
        }
        $client->setHeaders($headers);
        $client->setMethod($method);
        
        $response = $client->send();
        if ( ! $response->isSuccess() ) {
            return $response->getContent();
        }
        return $response->getBody();
    }

    private function getAppconfig($project)
    {
        $config = $this->getServiceLocator()->get('config');
        return $config['restful-manage'][$project];
    }

    protected $response;

    protected function getResponse()
    {
        if ( ! $this->response ) {
            $this->response = new HttpResponse();
        }
        return $this->response;
    }
}