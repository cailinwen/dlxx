<?php
namespace Core\Service;

use Zend\View\Model\JsonModel;

trait AjaxReturnTrait
{

    protected static function createJsonView( $status = 0, $data = null, $info = null, $useJson = true )
    {
        $jsonView = new JsonModel();
        $returnData = array(
            'status' => 0,
            'data' => '',
            'info' => ''
        );
        $returnData['status'] = $status;
        if ( isset($data) && $data ) {
            if ( is_array($data) && $useJson ) {
                $data = \Zend\Json\Json::encode($data);
            }
            $returnData['data'] = $data;
        }
        if ( isset($info) && $info ) {
            $returnData['info'] = $info;
        }
        $jsonView->setVariables($returnData);
        return $jsonView;
    }

    /**
     *
     * @todo Ajax方式返回数据到客户端
     * @param mixed $data
     *            要返回的数据
     * @param String $info
     *            提示信息
     * @param boolean $status
     *            返回状态
     * @param String $status
     *            ajax返回类型 JSON XML
     * @return void
     */
    protected static function ajaxReturn( $status = 1, $data = '', $info = '', $type = '' )
    {
        $result = array();
        $result['status'] = $status;
        $result['info'] = $info;
        $result['data'] = $data;
        if ( empty($type) )
            $type = 'JSON';
        if ( strtoupper($type) == 'JSON' ) {
            header("Content-Type:text/html; charset=utf-8");
            exit(json_encode($result));
            exit(\Zend\Json\Json::encode($result));
        } elseif ( strtoupper($type) == 'XML' ) {
            header("Content-Type:text/xml; charset=utf-8");
            exit(self::xml_encode($result));
        } elseif ( strtoupper($type) == 'EVAL' ) {
            header("Content-Type:text/html; charset=utf-8");
            exit($data);
        } else {
            // TODO 增加其它格式
        }
    }

    /**
     * 数据XML编码
     *
     * @param mixed $data
     *            数据
     * @param string $item
     *            数字索引时的节点名称
     * @param string $id
     *            数字索引key转换为的属性名
     * @return string
     */
    private static function data_to_xml( $data, $item = 'item', $id = 'id' )
    {
        $xml = $attr = '';
        foreach ( $data as $key => $val ) {
            if ( is_numeric($key) ) {
                $id && $attr = " {$id}=\"{$key}\"";
                $key = $item;
            }
            $xml .= "<{$key}{$attr}>";
            $xml .= (is_array($val) || is_object($val)) ? self::data_to_xml($val, $item, $id) : $val;
            $xml .= "</{$key}>";
        }
        return $xml;
    }

    /**
     * XML编码
     *
     * @param mixed $data
     *            数据
     * @param string $root
     *            根节点名
     * @param string $item
     *            数字索引的子节点名
     * @param string $attr
     *            根节点属性
     * @param string $id
     *            数字索引子节点key转换的属性名
     * @param string $encoding
     *            数据编码
     * @return string
     */
    private static function xml_encode( $data, $root = 'featee', $item = 'item', $attr = '', $id = 'id', $encoding = 'utf-8' )
    {
        if ( is_array($attr) ) {
            $_attr = array();
            foreach ( $attr as $key => $value ) {
                $_attr[] = "{$key}=\"{$value}\"";
            }
            $attr = implode(' ', $_attr);
        }
        $attr = trim($attr);
        $attr = empty($attr) ? '' : " {$attr}";
        $xml = "<?xml version=\"1.0\" encoding=\"{$encoding}\"?>";
        $xml .= "<{$root}{$attr}>";
        $xml .= self::data_to_xml($data, $item, $id);
        $xml .= "</{$root}>";
        return $xml;
    }
}