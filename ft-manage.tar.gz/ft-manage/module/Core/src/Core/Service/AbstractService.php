<?php
/**
 * Featee This is not a free software, unauthorized use is prohibited.
 *
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
namespace Core\Service;

use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Mvc\Controller\PluginManager;
use Zend\Mvc\MvcEvent;
use Zend\EventManager\EventManager;
use Zend\Mvc\InjectApplicationEventInterface;
use Zend\EventManager\EventInterface as Event;
use Zend\EventManager\EventManagerInterface;
use Core\Service\AjaxReturnTrait;
use Core\Controller\ProvideCommonTrait;
use Cache\Service\ProvideCacheTrait;

abstract class AbstractService implements ServiceLocatorAwareInterface, InjectApplicationEventInterface
{
    
    use AjaxReturnTrait,ProvideCommonTrait,ProvideCacheTrait;

    protected $serviceLocator;

    protected $entityMapper;

    protected $plugins;

    protected $eventManager;

    protected $event;

    protected $eventIdentifier;

    protected $events;

    public function setServiceLocator( ServiceLocatorInterface $serviceLocator )
    {
        $this->serviceLocator = $serviceLocator;
        return $this;
    }

    public function getServiceLocator()
    {
        return $this->serviceLocator;
    }

    public function getEntityMapper()
    {
        return $this->entityMapper;
    }

    public function setEntityMapper( $entityMapper )
    {
        $this->entityMapper = $entityMapper;
        return $this;
    }

    /**
     * Get plugin manager
     *
     * @return PluginManager
     */
    public function getPluginManager()
    {
        if ( ! $this->plugins ) {
            $this->setPluginManager($this->getServiceLocator()
                ->get('ControllerPluginManager'));
        }
        return $this->plugins;
    }

    /**
     * 写入日志
     *
     * @param string $errorMessage            
     * @ignore EMERG = 0; // Emergency: 系统不可用 ALERT = 1; // Alert: 报警 CRIT = 2; // Critical: 紧要 ERR = 3; // Error: 错误 WARN = 4; // Warning: 警告 NOTICE = 5; // Notice: 通知 INFO = 6; // Informational: 一般信息 DEBUG = 7; // Debug: 小时消息
     * @example EMERG = 0; // Emergency: system is unusable
     * @example ALERT = 1; // Alert: action must be taken immediately
     * @example CRIT = 2; // Critical: critical conditions
     * @example ERR = 3; // Error: error conditions
     * @example WARN = 4; // Warning: warning conditions
     * @example NOTICE = 5; // Notice: normal but significant condition
     * @example INFO = 6; // Informational: informational messages
     * @example DEBUG = 7; // Debug: debug messages
     */
    public function _recordLog( $errorMessage, $priority = 'INFO' )
    {
        $this->getServiceLocator()
            ->get('Zend\Log')
            ->{strtolower($priority)}($errorMessage);
    }

    /**
     * Set plugin manager
     *
     * @param PluginManager $plugins            
     * @return AbstractController
     */
    public function setPluginManager( PluginManager $plugins )
    {
        $this->plugins = $plugins;
        
        return $this;
    }

    /**
     * Get plugin instance
     *
     * @param string $name
     *            Name of plugin to return
     * @param null|array $options
     *            Options to pass to plugin constructor (if not already instantiated)
     * @return mixed
     */
    public function plugin( $name, array $options = null )
    {
        return $this->getPluginManager()->get($name, $options);
    }

    /**
     * Method overloading: return/call plugins If the plugin is a functor, call it, passing the parameters provided. Otherwise, return the plugin instance.
     *
     * @param string $method            
     * @param array $params            
     * @return mixed
     */
    public function __call( $method, $params )
    {
        $plugin = $this->plugin($method);
        if ( is_callable($plugin) ) {
            return call_user_func_array($plugin, $params);
        }
    }

    public function t( $text, $text_domain = 'default', $lang = null )
    {
        if ( ! $lang ) {
            $languageSetting = $this->getServiceLocator()->get('config');
            $lang = $languageSetting['language']['default'];
        }
        
        if ( ! $text_domain )
            $text_domain = 'default';
        
        $translator = $this->getServiceLocator()->get('MvcTranslator');
        return $translator->translate($text, $text_domain, $lang);
    }

    /**
     * Set the event manager instance used by this context
     *
     * @param EventManagerInterface $events            
     * @return AbstractService
     */
    public function setEventManager( EventManagerInterface $events )
    {
        $events->setIdentifiers(array(
            'Zend\Stdlib\DispatchableInterface',
            __CLASS__,
            get_class($this),
            $this->eventIdentifier,
            substr(get_class($this), 0, strpos(get_class($this), '\\'))
        ));
        $this->events = $events;
        
        return $this;
    }

    /**
     * Retrieve the event manager Lazy-loads an EventManager instance if none registered.
     *
     * @return EventManagerInterface
     */
    public function getEventManager()
    {
        if ( ! $this->events ) {
            $this->setEventManager(new EventManager());
        }
        
        return $this->events;
    }

    /**
     * Set an event to use during dispatch By default, will re-cast to MvcEvent if another event type is provided.
     *
     * @param Event $e            
     * @return void
     */
    public function setEvent( Event $e )
    {
        if ( ! $e instanceof MvcEvent ) {
            $eventParams = $e->getParams();
            $e = new MvcEvent();
            $e->setParams($eventParams);
            unset($eventParams);
        }
        $this->event = $e;
    }

    /**
     * Get the attached event Will create a new MvcEvent if none provided.
     *
     * @return MvcEvent
     */
    public function getEvent()
    {
        if ( ! $this->event ) {
            $this->setEvent(new MvcEvent());
        }
        
        return $this->event;
    }

    public function setPage( $page, $limit = 10 )
    {
        return $this->getEntityMapper()->setPage($page, $limit);
    }

    public function setOffset( $offset )
    {
        return $this->getEntityMapper()->setOffset($offset);
    }

    public function setLimit( $limit )
    {
        return $this->getEntityMapper()->setLimit($limit);
    }

    public function setGroup( $group )
    {
        return $this->getEntityMapper()->setGroup($group);
    }

    public function cache( $type = CACHE_TYPE_DEFAULT )
    {
        self::existCacheType($type);
        if ( is_string(self::$cacheList[$type]) ) {
            self::$cacheList[$type] = $this->getServiceLocator()->get('cacheService');
        }
        return self::$cacheList[$type]->caches($type);
    }
}