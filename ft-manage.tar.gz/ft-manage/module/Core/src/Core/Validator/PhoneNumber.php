<?php
/**
 * @author Ron Dobley
 */
namespace Core\Validator;

class PhoneNumber extends \Zend\Validator\AbstractValidator
{

    /**
     * Error codes
     * @const string
     */
    const INVALID_URL = 'invalidPhoneNumber';

    /**
     * Error messages
     * 
     * @var array
     */
    protected $_messageTemplates = array(
        self::INVALID_URL => "'%value%' is not a valid URL. It must start with http(s):// and be valid."
    );

    /**
     * Defined by Zend_Validate_Interface
     *
     * Returns true if and only if the $value is a valid url that starts with http(s)://
     * and the hostname is a valid TLD
     *
     * @param string $value            
     * @throws Zend_Validate_Exception if a fatal error occurs for validation process
     * @return boolean
     */
    public function isValid($value)
    {
        $pattern = "/^13[0-9]{1}[0-9]{8}$|15[0-9]{1}[0-9]{8}$|18[0-9]{1}[0-9]{8}$/";
        
        if ( preg_match($pattern, $value) ) {
            return true;
        } else {
            return false;
        }
    }
}