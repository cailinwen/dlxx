<?php
/**
 * @author Ron Dobley
 */
namespace Core\Validator;

class IsUrl extends \Zend\Validator\AbstractValidator
{

    /**
     * Error codes
     * @const string
     */
    const INVALID_URL = 'invalidUrl';

    /**
     * Error messages
     *
     * @var array
     */
    protected $messageTemplates = array(
        self::INVALID_URL => "'%value%' is not a valid URL. It must start with http(s):// and be valid."
    );

    /**
     * Sets validator options
     *
     * @param int|array|\Traversable $options            
     */
    public function __construct($options = array())
    {
        parent::__construct($options);
    }

    /**
     * Defined by Zend_Validate_Interface
     *
     * Returns true if and only if the $value is a valid url that starts with http(s)://
     * and the hostname is a valid TLD
     *
     * @param string $value            
     * @throws Zend_Validate_Exception if a fatal error occurs for validation process
     * @return boolean
     */
    public function isValid($value)
    {
        if ( ! is_string($value) ) {
            $this->error(self::INVALID_URL);
            return false;
        }
        
        if ( strpos($value, 'http://') === false ) {
            $value = 'http://' . $value;
        }
        
        $this->setValue($value);
        
        try {
            $http = new \Zend\Uri\Http($value);
        } catch ( \Zend\Uri\Exception\InvalidUriPartException $e ) {
            $this->error(self::INVALID_URL);
            return false;
        }
        
        $hostnameValidator = new \Zend\Validator\Hostname(\Zend\Validator\Hostname::ALLOW_DNS); // do not allow local hostnames, this is the default
        
        if ( ! $hostnameValidator->isValid($http->getHost()) ) {
            $this->error(self::INVALID_URL);
            return false;
        }
        
        return true;
    }
}