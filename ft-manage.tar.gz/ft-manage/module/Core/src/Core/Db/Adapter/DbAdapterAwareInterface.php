<?php
/**
 * 
 * @name Featee
 * 
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * 
 *
*/
namespace Core\Db\Adapter;

use Zend\Db\Adapter\Adapter;

interface DbAdapterAwareInterface
{

    public function getDbAdapter();

    public function setDbAdapter(Adapter $dbAdapter);

    public function getAdminDbAdapter();

    public function setAdminDbAdapter(Adapter $dbAdapter);

    public function getFeatDbAdapter();

    public function setFeatDbAdapter(Adapter $dbAdapter);
}
