<?php
namespace Core\Event;

use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\EventManager\EventManagerInterface;
use Zend\EventManager\EventManager;
use Zend\Mvc\Controller\PluginManager;
use Core\Service\AjaxReturnTrait;

abstract class AbstractEvent implements ServiceLocatorAwareInterface
{
    use AjaxReturnTrait;

    protected $serviceLocator;

    protected $plugins;

    protected $soapService;

    protected $options;

    protected $config;

    protected $controllerPluginManager;

    protected $javascriptPlugin;

    protected $cdnLinkBuilder;

    protected $viewHelperManager;

    /**
     *
     * @return serviceLocator
     */
    public function getServiceLocator()
    {
        return $this->serviceLocator;
    }

    /**
     *
     * @param
     *            $serviceLocator
     * @return self
     */
    public function setServiceLocator(ServiceLocatorInterface $serviceLocator)
    {
        $this->serviceLocator = $serviceLocator;
        return $this;
    }

    /**
     * Set the event manager instance used by this context
     *
     * @param EventManagerInterface $events            
     * @return AbstractService
     */
    public function setEventManager(EventManagerInterface $events)
    {
        $events->setIdentifiers(array(
            'Zend\Stdlib\DispatchableInterface',
            __CLASS__,
            get_class($this),
            $this->eventIdentifier,
            substr(get_class($this), 0, strpos(get_class($this), '\\'))
        ));
        $this->events = $events;
        
        return $this;
    }

    /**
     * Retrieve the event manager
     *
     * Lazy-loads an EventManager instance if none registered.
     *
     * @return EventManagerInterface
     */
    public function getEventManager()
    {
        if ( ! $this->events ) {
            $this->setEventManager(new EventManager());
        }
        
        return $this->events;
    }

    /**
     * Get plugin manager
     *
     * @return PluginManager
     */
    public function getPluginManager()
    {
        if ( ! $this->plugins ) {
            $this->setPluginManager($this->getServiceLocator()
                ->get('ControllerPluginManager'));
        }
        return $this->plugins;
    }

    /**
     * Set plugin manager
     *
     * @param PluginManager $plugins            
     * @return AbstractController
     */
    public function setPluginManager(PluginManager $plugins)
    {
        $this->plugins = $plugins;
        return $this;
    }

    /**
     * Get plugin instance
     *
     * @param string $name
     *            Name of plugin to return
     * @param null|array $options
     *            Options to pass to plugin constructor (if not already instantiated)
     * @return mixed
     */
    public function plugin($name, array $options = null)
    {
        return $this->getPluginManager()->get($name, $options);
    }

    /**
     * Method overloading: return/call plugins
     *
     * If the plugin is a functor, call it, passing the parameters provided.
     * Otherwise, return the plugin instance.
     *
     * @param string $method            
     * @param array $params            
     * @return mixed
     */
    public function __call($method, $params)
    {
        $plugin = $this->plugin($method);
        if ( is_callable($plugin) ) {
            return call_user_func_array($plugin, $params);
        }
    }

    public function getAndCallSoapService($project, $soapServiceApi, $parameters = array())
    {
        return $this->getSoapService()->callSoapService($project, $soapServiceApi, $parameters);
    }

    public function getSoapService()
    {
        if ( null === $this->soapService ) {
            $this->soapService = $this->getServiceLocator()->get('soapService');
        }
        return $this->soapService;
    }

    /**
     * Prepare options
     *
     * @param array $options            
     * @return object
     */
    function setOptions(array $options)
    {
        $this->options[] = $options;
        return $this;
    }

    function clearSettings()
    {
        $this->options = array();
        return $this;
    }

    /**
     * Get options
     *
     * @return array
     */
    function getOptions()
    {
        return $this->options;
    }

    public function chainStyleCallSoapService($project, $soapServiceApi, $parameters = array())
    {
        $this->setOptions(array(
            $soapServiceApi,
            $parameters
        ));
        $options = $this->getOptions();
        $this->clearSettings();
        $soapService = $this->getSoapService();
        $sid = $soapService->getAuthorization($project);
        $client = $soapService->getSoapClient();
        return $client->multiCall($sid, $options, $soapServiceApi);
    }

    function getConfig()
    {
        if ( null === $this->config ) {
            $this->config = $this->getServiceLocator()->get('config');
        }
        
        return $this->config;
    }

    function getControllerPluginManager()
    {
        if ( null === $this->controllerPluginManager ) {
            $this->controllerPluginManager = $this->getServiceLocator()->get('controllerPluginManager');
        }
        return $this->controllerPluginManager;
    }

    function getJavascriptPluginManager()
    {
        if ( null === $this->javascriptPlugin ) {
            $this->javascriptPlugin = $this->getControllerPluginManager()->get('javascript');
        }
        return $this->javascriptPlugin;
    }

    function getCdnLinkBuilder()
    {
        if ( null === $this->cdnLinkBuilder ) {
            $this->cdnLinkBuilder = $this->getServiceLocator()->get('cdnLinkBuilderContainer');
        }
        return $this->cdnLinkBuilder;
    }

    function getViewHelperManager()
    {
        if ( null === $this->viewHelperManager ) {
            $this->viewHelperManager = $this->getServiceLocator()->get('viewHelperManager');
        }
        return $this->viewHelperManager;
    }
}