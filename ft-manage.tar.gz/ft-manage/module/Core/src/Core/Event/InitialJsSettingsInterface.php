<?php
namespace Core\Event;

interface InitialJsSettingsInterface
{

    function initBaseurl();

    function initImageServer();

    function initStaticSourcesServer();
}