<?php
namespace Core\Event;

use Core\Event\AbstractEvent;
use Core\Event\InitialJsSettingsInterface;

class InitialJsSettings extends AbstractEvent implements InitialJsSettingsInterface
{

    const COLON = ':';

    public function initBaseurl()
    {
        $viewHelperManager = $this->getViewHelperManager();
        $basePathPlugin = $viewHelperManager->get('basePath');
        $baseUrl = $basePathPlugin();
        $javascriptPlugin = $this->getJavascriptPluginManager();
        $javascriptPlugin->addSettings(compact('baseUrl'));
    }

    public function initImageServer()
    {
        $config = $this->getConfig();
        $imageServer = $config['upload_resouce_base_url'];
        $javascriptPlugin = $this->getJavascriptPluginManager();
        $javascriptPlugin->addSettings(compact('imageServer'));
    }

    public function initStaticSourcesServer()
    {
        $cdnLinkBuilderContainer = $this->getCdnLinkBuilder();
        $cdnUri = $cdnLinkBuilderContainer->getUri('/');
        $cdnUriArr = explode('?', $cdnUri);
        $reversedCdnUriArr = array_reverse($cdnUriArr);
        $staticServer = array_pop($reversedCdnUriArr);
        $javascriptPlugin = $this->getJavascriptPluginManager();
        $javascriptPlugin->addSettings(compact('staticServer'));
    }
}