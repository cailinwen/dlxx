<?php
/**
 *
 * @name Featee
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
namespace Core\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Core\Controller\ProvideCommonTrait;
use Core\Service\AjaxReturnTrait;
use Zend\View\Model\ViewModel;
use Zend\Mvc\MvcEvent;
use Cache\Service\ProvideCacheTrait;

/**
 * 核心controller的基类
 */
abstract class AbstractBaseCoreController extends AbstractActionController
{
    use ProvideCommonTrait,ProvideCacheTrait,AjaxReturnTrait;

    protected $translator;

    /**
     *
     * @var \Translation\Service\TranslationService
     */
    private $translationService;

    /**
     *
     * @return the $translationService
     */
    private function getTranslationService()
    {
        if ( ! $this->translationService ) {
            $this->translationService = $this->getServiceLocator()->get('transService');
        }
        return $this->translationService;
    }

    protected static $language;

    protected $headLink;

    protected $headScript;

    /**
     *
     * @var This filter can strip XML and HTML tags from given content.
     */
    protected $filter;

    public function attachDefaultListeners()
    {
        parent::attachDefaultListeners();
        $events = $this->getEventManager();
        $events->attach(MvcEvent::EVENT_DISPATCH, array(
            $this,
            'preDisPatch'
        ), 100);
        
        $events->attach(MvcEvent::EVENT_DISPATCH, array(
            $this,
            'setLanguage'
        ), 100);
    }

    protected $loginUser;

    protected $isXmlHttpRequest;

    protected $loginUserId;

    public function preDisPatch()
    {
        $this->isXmlHttpRequest = $this->getRequest()->isXmlHttpRequest();
        $this->loginUser = self::getSessionUser();
        if ( ! empty($this->loginUser) ) {
            $this->loginUserId = $this->loginUser['user_id'];
        }
    }

    public function t( $text, $text_domain = 'default', $lang = null )
    {
        if ( ! $lang )
            $lang = self::$language;
        
        if ( ! $text_domain )
            $text_domain = 'default';
        
        return $this->getTranslatorService()->translate($text, $text_domain, $lang);
    }

    public function setLanguage()
    {
        self::$language = $this->getTranslatorService()->getLocale();
        $translationService = $this->getTranslationService();
        $allLanguage = $translationService->getAllLanguage();
        $this->layout()->footerLanguageList = $translationService->groupLauguage($allLanguage);
        $current_language = self::$language;
        foreach ( $allLanguage as $language ) {
            if ( $language['unique_title'] == $current_language ) {
                $this->layout()->currentLanguage = $language;
            }
        }
    }

    public function getTranslatorService()
    {
        if ( $this->translator === null ) {
            $this->translator = $this->getServiceLocator()->get('translator');
        }
        return $this->translator;
    }

    /**
     * get template of view
     *
     * @param template $viewHtml            
     * @return Ambigous <string, \Zend\Filter\mixed, mixed>
     */
    protected function getView( $viewHtml, $arrValue = array() )
    {
        $view = new ViewModel($arrValue);
        $view->setTemplate($viewHtml);
        $view->setTerminal(true);
        $htmlOutput = $this->getServiceLocator()
            ->get('viewrenderer')
            ->render($view);
        return $htmlOutput;
    }

    protected function getParam( $param )
    {
        $request = $this->getRequest();
        
        if ( $request->isPost() ) {
            $v = $this->params()->fromPost($param);
        } else {
            $v = $this->params()->fromQuery($param);
        }
        if ( ! isset($v) ) {
            return $this->params()->fromRoute($param);
        }
        return self::filterStr($v);
    }

    public function filter( $string, $allowTags = array() )
    {
        if ( ! $this->filter ) {
            $this->setVariable('filter', new \Zend\Filter\StripTags($allowTags));
        }
        return $this->filter->filter($string);
    }

    public function notFoundAction()
    {
        parent::notFoundAction();
        $this->layout('error/layout');
    }

    /**
     * 写入日志
     *
     * @param string $errorMessage            
     * @ignore EMERG = 0; // Emergency: 系统不可用 ALERT = 1; // Alert: 报警 CRIT = 2; // Critical: 紧要 ERR = 3; // Error: 错误 WARN = 4; // Warning: 警告 NOTICE = 5; // Notice: 通知 INFO = 6; // Informational: 一般信息 DEBUG = 7; // Debug: 小时消息
     * @example EMERG = 0; // Emergency: system is unusable
     * @example ALERT = 1; // Alert: action must be taken immediately
     * @example CRIT = 2; // Critical: critical conditions
     * @example ERR = 3; // Error: error conditions
     * @example WARN = 4; // Warning: warning conditions
     * @example NOTICE = 5; // Notice: normal but significant condition
     * @example INFO = 6; // Informational: informational messages
     * @example DEBUG = 7; // Debug: debug messages
     */
    public function _recordLog( $errorMessage, $priority = 'INFO' )
    {
        $this->getServiceLocator()
            ->get('Zend\Log')
            ->{strtolower($priority)}($errorMessage);
    }

    /**
     * exit if current request is not xml http request
     */
    protected function exitNonXmlHttpRequest()
    {
        if ( ! $this->getRequest()->isXmlHttpRequest() ) {
            exit('Invalid Reqeust');
        }
    }

    /**
     * return if current request is not xml http request
     */
    protected function returnNonXmlHttpRequest()
    {
        if ( ! $this->getRequest()->isXmlHttpRequest() ) {
            return false;
        } else {
            return true;
        }
    }

    protected function headLink()
    {
        if ( null === $this->headLink ) {
            $this->headLink = $this->getServiceLocator()
                ->get('viewhelpermanager')
                ->get('headLink');
        }
        return $this->headLink;
    }

    protected function headScript()
    {
        if ( null === $this->headScript ) {
            $this->headScript = $this->getServiceLocator()
                ->get('viewhelpermanager')
                ->get('headScript');
        }
        return $this->headScript;
    }

    /**
     * Check if specific template exists
     *
     * @param string $template            
     * @return boolean
     */
    protected function existTemplate( $template )
    {
        $resolver = $this->getEvent()
            ->getApplication()
            ->getServiceManager()
            ->get('Zend\View\Resolver\TemplatePathStack');
        
        return (false !== $resolver->resolve($template));
    }

    public function cache( $type = CACHE_TYPE_DEFAULT )
    {
        self::existCacheType($type);
        if ( is_string(self::$cacheList[$type]) ) {
            self::$cacheList[$type] = $this->getServiceLocator()->get('cacheService');
        }
        return self::$cacheList[$type]->caches($type);
    }

    public function getAndCallSoapService( $project, $soapServiceApi, $parameters = array() )
    {
        $soapService = $this->getServiceLocator()->get('soapService');
        return $soapService->callSoapService($project, $soapServiceApi, $parameters);
    }

    /**
     * 判断登录和请求类型
     *
     * @param array $loginUser            
     * @param boolean $mustXmlHttpRequest            
     */
    protected function checkLoginAndXmlRequest( $loginUser, $mustXmlHttpRequest = false )
    {
        if ( $loginUser ) {
            if ( $mustXmlHttpRequest ) {
                $this->exitNonXmlHttpRequest();
            }
            return true;
        } else {
            if ( $this->isXmlHttpRequest ) {
                self::ajaxReturn(0, '', $this->t('User session has expired'));
            } else {
                $uri = urlencode($this->getRequest()->getUriString());
                $redirect = $this->url()->fromRoute('login');
                return $this->redirect()->toUrl($redirect . '?next=' . $uri);
            }
        }
    }
}