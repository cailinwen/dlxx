<?php
/**
 *
 * Featee This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
namespace Core\Controller;

class CoreController extends AbstractBaseCoreController
{

    public function indexAction()
    {
        if ( empty($this->loginUser) ) {
            $url = $this->url()->fromRoute('login');
            return $this->redirect()->toUrl($url);
        }
    }
}