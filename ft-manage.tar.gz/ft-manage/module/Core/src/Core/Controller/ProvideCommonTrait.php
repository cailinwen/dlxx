<?php
namespace Core\Controller;

use Zend\Session\Container;

trait ProvideCommonTrait
{

    protected static function uuid($prefix = '')
    {
        $charid = md5(uniqid(mt_rand(), true));
        $uuid = substr($charid, 0, 8) . substr($charid, 8, 4) . substr($charid, 12, 4) . substr($charid, 16, 4) . substr($charid, 20, 12);
        return $prefix . $uuid;
    }

    protected static function jsonToArray($jsonString)
    {
        if ( ! is_string($jsonString) ) {
            throw new \Exception('Param is not a json string');
        }
        return \Zend\Json\Json::decode($jsonString, true);
    }

    /**
     * 格式化时间戳
     *
     * @param int $time            
     * @return string
     */
    protected static function formatTime($time)
    {
        return date('Y-m-d H:i:s', $time);
    }

    /**
     * 产生随机字符串（数字）。可以回调重新生成。
     *
     * @param int $length
     *            输出长度
     * @return string 字符串
     */
    protected static function random($length)
    {
        $hash = '';
        $chars = '0123456789';
        $max = strlen($chars) - 1;
        for ( $i = 0; $i < $length; $i ++ ) {
            $hash .= $chars[mt_rand(0, $max)];
        }
        if ( substr($hash, 0, 1) == 0 ) {
            return self::random($length);
        } elseif ( false ) {} else {}
        return $hash;
    }

    /**
     * 特殊字符过滤和转义。过滤字段。
     *
     * @param sting $str            
     * @return string
     */
    protected static function filterStr($str)
    {
        return self::add_slashes(self::getVar($str));
    }

    protected static function randomNumber($len, $Zero = true)
    {
        $number = '';
        for ( $i = 0; $i < $len; $i ++ ) {
            if ( ! $Zero && $i === 0 ) {
                $number .= rand(1, 9);
            } else {
                $number .= rand(0, 9);
            }
        }
        return $number;
    }

    /**
     * 创建临时的session
     *
     * @param string $sessionName            
     * @param string $exsitNumber            
     * @return int
     */
    protected static function createTemporarySession($sessionName, $exsitNumber = null)
    {
        $session = new Container($sessionName);
        $number = $this->randomNumber('7', false);
        while ( $exsitNumber && in_array($number, $exsitNumber) ) {
            $number = $this->randomNumber('7', false);
        }
        $isSession = $session->offsetExists($sessionName);
        if ( $isSession ) {
            $sesionValue = unserialize($session->offsetGet($sessionName));
            $sesionValue[] = $number;
            $session->offsetSet($sessionName, serialize($sesionValue));
        } else {
            $sesionValue[] = $number;
            $session->offsetSet($sessionName, serialize($sesionValue));
        }
        return $number;
    }

    /**
     * 销毁临时的session
     */
    protected static function destroyTemporarySession()
    {
        $sessionContact = new Container('contact');
        $isSession = $sessionContact->offsetExists('contact');
        if ( $isSession ) {
            $sessionContact->offsetSet('contact', null);
        }
        
        $sessionLink = new Container('link');
        $isSession = $sessionLink->offsetExists('link');
        if ( $isSession ) {
            $sessionLink->offsetSet('link', null);
        }
        
        $sessionTelephone = new Container('telephone');
        $isSession = $sessionTelephone->offsetExists('telephone');
        if ( $isSession ) {
            $sessionTelephone->offsetSet('telephone', null);
        }
        
        $sessionTelephone = new Container('fex');
        $isSession = $sessionTelephone->offsetExists('fex');
        if ( $isSession ) {
            $sessionTelephone->offsetSet('fex', null);
        }
    }

    protected static function removeCompanySuffix($subject)
    {
        $allLang = 'ar_SY|cs_CZ|de_DE|en_US|es_ES|fr_CA|fr_FR|it_IT|ja_JP|nb_NO|nl_NL|pl_PL|pt_BR|ru_RU|tr_TR|zh_CN|zh_TW';
        $replace = strtolower('corporation|inc.|ltd|company limited|company|co.|limited|by share');
        $langs = explode('|', $allLang);
        foreach ( $langs as $language ) {
            $replaceTranslated = array();
            $rep = explode('|', $replace);
            foreach ( $rep as $key ) {
                $search = strtolower($this->t($key, null, $language));
                $subject = trim(str_replace($search, '', $subject));
            }
        }
        return $subject;
    }

    /**
     * 计时函数
     *
     * @param number $mode            
     * @return void string
     */
    protected static function runtime($mode = 0)
    {
        static $t;
        if ( ! $mode ) {
            $t = microtime();
            return;
        }
        $t1 = microtime();
        list ($m0, $s0) = explode(" ", $t);
        list ($m1, $s1) = explode(" ", $t1);
        return sprintf("%.3f ms", ($s1 + $m1 - $s0 - $m0) * 1000);
    }

    /**
     * 过滤安全字符
     *
     * @param string $string            
     * @return string
     */
    protected static function add_slashes($string)
    {
        if ( is_array($string) ) {
            foreach ( $string as $key => $value ) {
                if ( is_array($value) ) {
                    $string[$key] = $this->add_slashes($value);
                } else {
                    $string[$key] = addslashes($value);
                }
            }
        } else {
            $string = addslashes($string);
        }
        return $string;
    }

    protected static function getVar($str)
    {
        return @htmlspecialchars(trim($str));
    }

    protected static function getSessionUser()
    {
        $session_user = new Container('user');
        $isSession = $session_user->offsetExists('userInfos');
        if ( $isSession ) {
            return unserialize($session_user->offsetGet('userInfos'));
        } else {
            return false;
        }
    }

    private static $sessionManage;

    protected static function getSessionManage()
    {
        if ( ! self::$sessionManage ) {
            self::$sessionManage = new Container('user');
        }
        return self::$sessionManage;
    }

    /**
     *
     * @param array $userResult            
     */
    protected static function setSessionUser($userResult)
    {
        $session_user = new Container('user');
        $session_user->setExpirationSeconds(60 * 60 * 2);
        if ( is_array($userResult) ) {
            $session_user->offsetSet('userInfos', serialize($userResult));
        } else {
            $session_user->offsetSet('userInfos', $userResult);
        }
    }

    protected static function getSessionUserId()
    {
        $session_user = new Container('user');
        $isSession = $session_user->offsetExists('userInfos');
        if ( $isSession ) {
            $userObj = unserialize($session_user->offsetGet('userInfos'));
            return $userObj['user_id'];
        } else {
            return null;
        }
    }

    /**
     * 获取客户端IP地址
     * @
     */
    protected function get_client_ip()
    {
        if ( getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown') )
            $ip = getenv('HTTP_CLIENT_IP');
        else if ( getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown') )
            $ip = getenv('HTTP_X_FORWARDED_FOR');
        else if ( getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown') )
            $ip = getenv('REMOTE_ADDR');
        else if ( isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown') )
            $ip = $_SERVER['REMOTE_ADDR'];
        else
            $ip = 'unknown';
        return $ip;
    }
}

