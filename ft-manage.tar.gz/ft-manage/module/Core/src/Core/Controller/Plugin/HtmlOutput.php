<?php
/**
 * 
 * Featee
 * 
 * ==============================================
 * 这不是一个自由软件，未经授权不许任何使用和传播。
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * ==============================================
 * 
 * @date: 2014-3-1 下午6:48:05
 * @author: pardus
 *
*/
namespace Core\Controller\Plugin;

use Zend\Mvc\InjectApplicationEventInterface;
use Zend\Mvc\Controller\Plugin\AbstractPlugin;
use Zend\Mvc\Exception;
use Zend\View\Model\ViewModel;

class HtmlOutput extends AbstractPlugin
{

    protected $controller;
    protected $event;

    public function __invoke($variables, $template, $json_tag = true)
    {
        if (! $this->controller) {
            $this->controller = $this->getController();
        }
        if (! $this->controller instanceof InjectApplicationEventInterface) {
            throw new Exception\DomainException(' AjaxCallback plugin requires a controller that implements InjectApplicationEventInterface ');
        }
        if (! $this->event) {
            $this->event = $this->controller->getEvent();
        }
        
        $htmlViewPart = new ViewModel();
        
        if (!empty($variables)) {
            $htmlViewPart->setVariables($variables);
        }
        
        $htmlViewPart->setTemplate($template);
        $htmlViewPart->setTerminal(true);
        
        $htmlOutput = $this->controller->getServiceLocator()
            ->get('viewrenderer')
            ->render($htmlViewPart);
        
        if ($json_tag) {
            $html = json_encode($htmlOutput, JSON_HEX_TAG);
        } else {
            $html = $htmlOutput;
        }
        
        return $html;
    }
}