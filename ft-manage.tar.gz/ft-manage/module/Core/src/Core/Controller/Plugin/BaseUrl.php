<?php
/**
 *
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 *
 * @date: 2014-3-1 下午6:47:02
 * @author: pardus
 *
 */
namespace Core\Controller\Plugin;

use Zend\Mvc\InjectApplicationEventInterface;
use Zend\Mvc\Controller\Plugin\AbstractPlugin;
use Zend\Mvc\MvcEvent;
use Zend\Mvc\Exception;

class BaseUrl extends AbstractPlugin
{

    protected $controller;

    protected $event;

    /**
     * 获取基本路径，该方法在Controller中调用。
     *
     * @example 在本地调用：$this->baseUrl() ,输出结果:"/zf2-celestra/public"
     * @example 在本地调用：$this->baseUrl(true), 输出结果: "http://10.0.1.176/zf2-celestra/public"
     * @example 在服务器调用：$this->baseUrl(),输出结果：""
     * @example 在服务器调用：$this->baseUrl(true), 输出结果: "http://10.0.10.110:898"
     * @param Boolean $host            
     * @throws Exception\InvalidArgumentException
     * @author Pardus
     * @return string
     */
    public function __invoke($host = false)
    {
        if ( ! $this->controller ) {
            $this->controller = $this->getController();
        }
        if ( ! $this->controller instanceof InjectApplicationEventInterface ) {
            throw new Exception\DomainException(' BaseUrl plugin requires a controller that implements InjectApplicationEventInterface ');
        }
        if ( ! $this->event ) {
            $this->event = $this->controller->getEvent();
        }
        
        if ( $host === true || $host === false ) {
            return $this->baseUrl($host);
        } else {
            throw new Exception\InvalidArgumentException("baseUrl parameter is invalid, do not fill or true.");
        }
    }

    public function baseUrl($host = false)
    {
        $router = null;
        if ( $this->event instanceof MvcEvent ) {
            $request = $this->event->getRequest();
            $router = $this->event->getRouter();
            $uri = $router->getRequestUri();
            $scheme = $uri->getScheme();
            $host_port = $_SERVER['HTTP_HOST'];
            $url = $request->getBaseUrl();
            if ( $host === true ) {
                $baseUrl = sprintf('%s://%s%s', $scheme, $host_port, $url);
            } else {
                $baseUrl = $url;
            }
            
            return $baseUrl;
        } else {
            if ( isset($_SERVER['HTTP_HOST']) ) {
                $http = isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off' ? 'https' : 'http';
                $hostname = $_SERVER['HTTP_HOST'];
                $dir = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
                
                $core = preg_split('@/@', str_replace($_SERVER['DOCUMENT_ROOT'], '', realpath(dirname(__FILE__))), NULL, PREG_SPLIT_NO_EMPTY);
                $core = $core[0];
                
                $tmplt = "%s://%s";
                $end = $hostname;
                $base_url = sprintf($tmplt, $http, $hostname, $end);
            } else
                $base_url = 'http://localhost/';
            
            return $base_url;
        }
    }
}