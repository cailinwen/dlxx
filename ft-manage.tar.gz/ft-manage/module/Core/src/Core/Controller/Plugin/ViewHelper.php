<?php
/**
 * 
 * Featee
 * 
 * ==============================================
 * 这不是一个自由软件，未经授权不许任何使用和传播。
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * ==============================================
 * 
 * @date: 2014-3-1 下午6:49:07
 * @author: pardus
 *
*/
namespace Core\Controller\Plugin;

use Zend\Mvc\Controller\Plugin\AbstractPlugin;
use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\Mvc\Exception;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Mvc\InjectApplicationEventInterface;
use Zend\Mvc\MvcEvent;

/**
 * ***
 * 设置页面加载js 或css,页面标题，以及编码 。
 * 注意：页面底部只能加载Js ,不能加载css ,如果想加载css，请调用importJsOrCssFooter()。
 * 在传入js 和 css 时，必须制定是在头部加载还是在底部加载。
 * 如果在头部加载，则使用‘header’作为数组的key ,如果在底部加载，则使用‘footer'作为数组的key
 * 例如：
 *
 * $cssOrJsList=array('header'=>array(),'footer'=>array());
 *
 *
 * @example $cssOrJsList = array (
 *          'header' => array (
 *          '/unlogindex.css',
 *          '/unheader.css',
 *          '/base.css',
 *          '/register.js',
 *          '/jquery-1.7.1.min.js'
 *          ),
 *          'footer' => array (
 *          '/jquery-1.7.1.min.js',
 *          '/signInfo.js'
 *          )
 *          );
 *          $this->viewhelper ( $cssOrJsList ,'featee','utf-8');
 *         
 *          在页面底部输出js 时，使用<?php echo $this->inlinescript();?>
 *         
 */
class ViewHelper extends AbstractPlugin
{

    /**
     *
     * @param array $jsOrCssList            
     * @param string $title            
     * @param string $charset            
     * @throws Exception\InvalidArgumentException
     */
    public function __invoke($jsOrCssList = array(), $title = 'Featee', $charset = '')
    {
        if ($jsOrCssList !== null && ! is_array($jsOrCssList)) {
            throw new Exception\InvalidArgumentException('ViewHelper plugin request parameter error! ');
        }
        if (! is_string($title) && ! empty($title)) {
            throw new Exception\InvalidArgumentException('ViewHelper plugin request parameter error! ');
        }
        $this->viewHelper($jsOrCssList, $title, $charset);
    }

    private function viewHelper($jsOrCssList, $title = 'Featee', $charset = '')
    {
        $controller = $this->getController();
        if (! $controller instanceof ServiceLocatorAwareInterface) {
            throw new Exception\DomainException('ViewHelper plugin requires controller implements ServiceLocatorAwareInterface');
        }
        $locator = $controller->getServiceLocator();
        if (! $locator instanceof ServiceLocatorInterface) {
            throw new Exception\DomainException('ViewHelper plugin requires controller composes Locator');
        }
        $renderer = $locator->get('Zend\View\Renderer\PhpRenderer');
        if (is_string($charset) && ! empty($charset)) {
            $metas = $renderer->headMeta()->setCharset($charset); // charset
        }
        $renderer->headTitle($title, 'SET'); // title
        
        if ($jsOrCssList) {
            $linkAry = $renderer->headLink();
            $scriptAry = $renderer->headScript();
            $ins = $renderer->inlineScript();
            foreach ($jsOrCssList as $key => $value) {
                switch ($key) {
                    case 'header':
                        foreach ($value as $key => $val) {
                            if (gettype($val) == 'string') {
                                $str = strrchr($val, '.');
                                $str = substr($str, 0, 3);
                                switch ($str) {
                                    case '.js':
                                        $scriptAry = $scriptAry->appendFile($this->getCssOrJsBaseUrl('js') . $val);
                                        break;
                                    case '.cs':
                                        $linkAry = $linkAry->appendStylesheet($this->getCssOrJsBaseUrl('cs') . $val);
                                        break;
                                    default:
                                        throw new Exception\InvalidArgumentException('ViewHelper plugin request parameter error! ');
                                        break;
                                }
                            } elseif (gettype($val) == 'array') {
                                $str = strrchr($val['js'], '.');
                                $str = substr($str, 0, 3);
                                switch ($str) {
                                    case '.js':
                                        $scriptAry = $scriptAry->appendFile($this->getCssOrJsBaseUrl('js') . $val['js'], 'text/javascript', array(
                                            'conditional' => 'lt IE 9'
                                        ));
                                        break;
                                    case '.cs':
                                        $linkAry = $linkAry->appendStylesheet($this->getCssOrJsBaseUrl('cs') . $val);
                                        break;
                                    default:
                                        throw new Exception\InvalidArgumentException('ViewHelper plugin request parameter error! ');
                                        break;
                                }
                            }
                        }
                        
                        break;
                    case 'footer':
                        foreach ($value as $val) {
                            if ($val != '') {
                                $str = strrchr($val, '.');
                                $str = substr($str, 0, 3);
                                switch ($str) {
                                    case '.js':
                                        $ins = $ins->appendFile($this->getCssOrJsBaseUrl('js') . $val);
                                        break;
                                    default:
                                        throw new Exception\InvalidArgumentException('ViewHelper plugin request parameter error! ');
                                        break;
                                }
                            }
                        }
                        break;
                }
            }
        }
    }

    private function getCssOrJsBaseUrl($fileType)
    {
        $controller = $this->getController();
        if (! $controller instanceof InjectApplicationEventInterface)
            throw new Exception\DomainException(' JsOrCssPath plugin requires a controller that implements InjectApplicationEventInterface ');
        $event = $controller->getEvent();
        $router = null;
        if ($event instanceof MvcEvent) {
            $request = $event->getRequest();
            $router = $event->getRouter();
            $uri = $router->getRequestUri();
            $scheme = $uri->getScheme();
            $host_port = $_SERVER['HTTP_HOST'];
            $url = $request->getBaseUrl();
            if ($fileType == 'cs' || $fileType == 'jc') {
                $url = $url . '/css';
            } else {
                $url = $url . '/js';
            }
            $baseUrl = sprintf('%s://%s%s', $scheme, $host_port, $url);
        }
        return $baseUrl;
    }
}