<?php
/**
 * 
 * Featee
 * 
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * 
 * @date: 2014-9-5 下午6:47:46
 * @author: Pardus
 *
*/
namespace Core\Controller\Plugin;

use Zend\Mvc\Controller\Plugin\AbstractPlugin;

class GetClientSystem extends AbstractPlugin
{

    private static $clientInfo = array();

    public static function getClientData()
    {
        self::get_client_ip();
        self::get_address_from_ip();
        self::getBrowser();
        self::getClientSystem();
        return self::$clientInfo;
    }

    /**
     * 获取客户端IP地址
     * ipaddress
     */
    public static function get_client_ip()
    {
        if ( getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown") )
            $ip = getenv("HTTP_CLIENT_IP");
        elseif ( getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown") )
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        elseif ( getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown") )
            $ip = getenv("REMOTE_ADDR");
        elseif ( isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown") )
            $ip = $_SERVER['REMOTE_ADDR'];
        else
            $ip = "unknown";
        return self::$clientInfo['ipaddress'] = $ip;
    }

    /**
     * 根据IP获取地址
     * location
     */
    public static function get_address_from_ip($ip = '')
    {
        if ( IS_ONLINE ) {
            if ( empty($ip) ) {
                $ip = self::$clientInfo['ipaddress'];
            }
            $url = "http://ip.taobao.com/service/getIpInfo.php?ip=" . $ip;
            $ip = json_decode(file_get_contents($url));
            if ( (string) $ip->code == '1' ) {
                return false;
            }
            $data = (array) $ip->data;
            $locations['country'] = $data['country'];
            $locations['area'] = $data['area'];
            if ( $data['country'] == '中国' ) {
                $locations['area'] = $data['area'] . '地区';
            }
            $locations['region'] = $data['region'];
            $locations['city'] = $data['city'];
            $locations['isp'] = ' ' . $data['isp'];
            return self::$clientInfo['location'] = join('', $locations);
        } else {
            return self::$clientInfo['location'] = '内部网络';
        }
    }

    /**
     * op_system,op_system_version
     */
    private static function getClientSystem()
    {
        $agent = $_SERVER['HTTP_USER_AGENT'];
        $systemInfo = '';
        // 判断系统
        $os = null;
        preg_match('/(Mac OS X)|(Windows)|(Linux)/', $agent, $systems);
        preg_match('/\b(iPhone|iP[ao]d)/', $agent, $mobiles);
        
        if ( $systems ) {
            preg_match('/(?:Mac OS X (\d+(?:[._]\d+)?+(?:[._]\d+)?))/', $agent, $mac);
            if ( $mac ) {
                if ( strpos($mac[0], '_') !== false ) {
                    $version = str_replace('_', '.', $mac[1]);
                } else {
                    $version = $mac[1];
                }
                self::$clientInfo['op_system'] = 'Mac OS X';
                self::$clientInfo['op_system_version'] = $version;
            } elseif ( isset($systems[2]) ) {
                self::$clientInfo['op_system'] = isset($systems[2]) ? $systems[2] : null;
                self::$clientInfo['op_system_version'] = $mac[1];
            } elseif ( isset($systems[3]) ) {
                self::$clientInfo['op_system'] = isset($systems[3]) ? $systems[3] : null;
                self::$clientInfo['op_system_version'] = $mac[1];
            }
        }
        if ( $mobiles ) {
            self::$clientInfo['op_system'] = isset($mobiles[0]) ? $mobiles[0] : $mobiles[1];
        }
        return self::$clientInfo;
    }

    /**
     * browser_name,browser_version,browser_lang
     */
    public static function getBrowser()
    {
        $agent = $_SERVER['HTTP_USER_AGENT'];
        $browserlang = explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE'])[0];
        $browser = '';
        $browser_ver = '';
        if ( preg_match('/MSIE\s([^\s|;]+)/i', $agent, $regs) ) {
            $browser = 'Internet Explorer'; // 当匹配到了MSIE 的时候，取得数字的那一部分房在数组$regs里
            $browser_ver = $regs[1];
        } elseif ( preg_match('/FireFox\/([^\s]+)/i', $agent, $regs) ) {
            $browser = 'FireFox'; // 当匹配到了firefox/的时候，取得后面紧跟的数字部分
            $browser_ver = $regs[1];
        } elseif ( preg_match('/Maxthon/i', $agent, $regs) ) {
            $browser = '(Internet Explorer ' . $browser_ver . ') Maxthon';
            $browser_ver = '';
        } elseif ( preg_match('/Opera[\s|\/]([^\s]+)/i', $agent, $regs) ) {
            $browser = 'Opera';
            $browser_ver = $regs[1];
        } elseif ( preg_match('/OmniWeb\/(v*)([^\s|;]+)/i', $agent, $regs) ) {
            $browser = 'OmniWeb';
            $browser_ver = $regs[2];
        } elseif ( preg_match('/Netscape([\d]*)\/([^\s]+)/i', $agent, $regs) ) {
            $browser = 'Netscape';
            $browser_ver = $regs[2];
        } elseif ( preg_match('/Chrome\/([^\s]+)/i', $agent, $regs) ) {
            $browser = 'Chrome';
            $browser_ver = $regs[1];
        } elseif ( preg_match('/safari\/([^\s]+)/i', $agent, $regs) ) {
            $browser = 'Safari';
            $browser_ver = $regs[1];
        } elseif ( preg_match('/NetCaptor\s([^\s|;]+)/i', $agent, $regs) ) {
            $browser = '(Internet Explorer ' . $browser_ver . ') NetCaptor';
            $browser_ver = $regs[1];
        } elseif ( preg_match('/Lynx\/([^\s]+)/i', $agent, $regs) ) {
            $browser = 'Lynx';
            $browser_ver = $regs[1];
        }
        if ( ! empty($browser) ) {
            self::$clientInfo['browser_name'] = $browser;
            self::$clientInfo['browser_version'] = addslashes($browser_ver);
            self::$clientInfo['browser_lang'] = $browserlang;
        } else {
            self::$clientInfo['browser_name'] = self::$clientInfo['browser_version'] = 'Unknow browser';
        }
        return self::$clientInfo;
    }
}

