<?php
namespace Core\Controller\Plugin;

class Javascript extends CoreBasePlugin
{

    /**
     *
     * @var javascript global settings
     */
    protected $settings = array();

    const PROJECT = 'Project';

    const DECLARATION = 'var';

    const SETTINGS = 'settings';

    const BEHAVIORS = 'behaviors';

    const EQUAL_SIGN = '=';

    const PERIOD = '.';

    const EMPTY_SPACE = ' ';

    const SEMICOLON = ';';

    const JSON_OBJECT = '{}';

    public function addSettings( $settings )
    {
        $this->settings = array_merge($this->settings, $settings);
    }

    public function getSettings()
    {
        return $this->settings;
    }

    public function appendScripts()
    {
        $async = 'async';
        $config = $this->getConfig();
        $this->addSettings($config['Javascript']);
        $body = $this->buildScriptBody();
        $this->headScript()
            ->setAllowArbitraryAttributes(true)
            ->prependScript($body, 'text/javascript', compact('async'));
        return $this;
    }

    private function buildScriptBody()
    {
        $settings = $this->getSettings();
        $config = $this->getConfig();
        $global = isset($config['Javascript']['global']) ? $config['Javascript']['global'] : self::PROJECT;
        $body = $this->setVariable($global, self::JSON_OBJECT);
        $name = $global;
        $name .= self::PERIOD;
        $name .= self::SETTINGS;
        $body .= $this->setVariable($name, json_encode($settings), false);
        $body .= $this->setVariable($global . self::PERIOD . self::BEHAVIORS, self::JSON_OBJECT, false);
        
        return $body;
    }

    private function setVariable( $name, $value, $isDeclaration = true )
    {
        $body = '';
        if ( $isDeclaration ) {
            $body .= self::DECLARATION;
        }
        $body .= self::EMPTY_SPACE;
        $body .= $name;
        $body .= self::EQUAL_SIGN;
        $body .= $value;
        $body .= self::SEMICOLON;
        
        return $body;
    }
}