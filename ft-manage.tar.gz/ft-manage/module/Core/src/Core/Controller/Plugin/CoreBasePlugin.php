<?php
namespace Core\Controller\Plugin;

use Zend\Mvc\Controller\Plugin\AbstractPlugin;
use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

class CoreBasePlugin extends AbstractPlugin implements ServiceLocatorAwareInterface
{

    protected $serviceLocator;

    protected $config;

    protected $headScript;

    public function headScript()
    {
        if ( ! $this->headScript ) {
            $this->headScript = $this->getServiceLocator()
                ->get('viewHelperManager')
                ->get('headScript');
        }
        return $this->headScript;
    }

    /**
     * Set service locator
     *
     * @param ServiceLocatorInterface $serviceLocator            
     */
    public function setServiceLocator(ServiceLocatorInterface $serviceLocator)
    {
        $this->serviceLocator = $serviceLocator;
        return $this;
    }

    /**
     * Get service locator
     *
     * @return ServiceLocatorInterface
     */
    public function getServiceLocator()
    {
        return $this->serviceLocator->getServiceLocator();
    }

    public function getConfig()
    {
        if ( ! $this->config ) {
            $this->config = $this->getServiceLocator()->get('config');
        }
        return $this->config;
    }
}
