<?php
/**
 * 
 * Featee
 * 
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * 
*/
namespace Core\Controller\Plugin;

//MySQL数据分页类
 
class Pagination{
 //定义公共属性
 public $total_pages;//分页总数量
 public $page_start;//查询起始位置
 public $total_records;//记录总数量
 public $per_page_count;//每页显示记录数量
 public $page_link_next;//下一页页码
 public $page_link_prev;//上一页页码
 public $page_link_limit;//页码链接显示范围
 public $page_link_class;//页码链接样式
 public $current_page_number;//当前页码
//-----------------------------初始化分页类--------------------------------------------------------------------
 function __construct($total_records,$per_page_count,$current_page_number){
  $this->total_records = $total_records;
  $this->per_page_count = $per_page_count;
  $this->current_page_number = $current_page_number;
  $this->adjust_options();
  $this->get_total_pages();
  $this->adjust_current_page_number();
  $this->get_start();
  $this->get_next();
  $this->get_prev();
 }
//-----------------------------内部基本功能--------------------------------------------------------------------
 //校正记录总数量和每页显示数量
 private function adjust_options(){
  $this->total_records = !is_numeric($this->total_records) ? 1 : $this->total_records;
  $this->total_records = !is_int($this->total_records) ? ceil($this->total_records) : $this->total_records;
  $this->total_records = $this->total_records < 1 ? 1 : $this->total_records;
  $this->per_page_count = !is_numeric($this->per_page_count) ? 1 : $this->per_page_count;
  $this->per_page_count = !is_int($this->per_page_count) ? ceil($this->per_page_count) : $this->per_page_count;
  $this->per_page_count = $this->per_page_count < 1 ? 1 : $this->per_page_count;
 }
 //获取总页数
 private function get_total_pages(){
  $this->total_pages = ceil($this->total_records/$this->per_page_count);
 }
 //校正当前页码
 private function adjust_current_page_number(){
  $this->current_page_number = !is_numeric($this->current_page_number) ? 1 : $this->current_page_number;
  $this->current_page_number = !is_int($this->current_page_number) ? 1 : $this->current_page_number;
  $this->current_page_number = $this->current_page_number < 1 ? 1 : $this->current_page_number;
  $this->current_page_number = $this->current_page_number > $this->total_pages ? $this->total_pages : $this->current_page_number;
 }
 //获取查询起始位置
 private function get_start(){
  $this->page_start = ($this->current_page_number - 1) * $this->per_page_count;
 }
 //获取下一页页码
 private function get_next(){
  $this->page_link_next = $this->current_page_number >= $this->total_pages ? 1 : $this->current_page_number + 1;
 }
 //获取上一页码
 private function get_prev(){
  $this->page_link_prev = $this->current_page_number <= 1 ? $this->total_pages : $this->current_page_number - 1;
 }
}
?>