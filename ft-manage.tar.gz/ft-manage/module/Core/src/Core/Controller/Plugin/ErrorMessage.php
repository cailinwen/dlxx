<?php
/**
 *
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 *
 * @date: 2014-3-1 下午6:47:02
 * @author: pardus
 *
 */
namespace Core\Controller\Plugin;

use Zend\Mvc\Controller\Plugin\AbstractPlugin;

class ErrorMessage extends AbstractPlugin
{

    public function __invoke($form)
    {
        $elements = $form->getElements();
        $errorInfo = null;
        foreach ( $elements as $k => $element ) {
            $errorsMessageArray = $form->get($k)->getMessages();
            if ( key($errorsMessageArray) ) {
                $errorInfo[$k] = $errorsMessageArray[key($errorsMessageArray)];
            }
        }
        
        return $errorInfo;
    }
}

