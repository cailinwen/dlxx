<?php
/**
 *
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 *
 * @date: 2014-3-1 下午6:47:02
 * @author: Kent Yen
 *
 */
namespace Core\Controller\Plugin;

use Zend\Mvc\Controller\Plugin\AbstractPlugin;

class Encryption extends AbstractPlugin
{

    /**
     *
     * @param string $key            
     * @param string $string            
     * @return string
     */
    public static function encryption($key, $string)
    {
        return base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $string, MCRYPT_MODE_CBC, md5(md5($key))));
    }

    /**
     *
     * @param string $key            
     * @param string $encrypted            
     * @return string
     */
    public static function decryption($key, $encrypted)
    {
        return rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode($encrypted), MCRYPT_MODE_CBC, md5(md5($key))), "\0");
    }
}