<?php
/**
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
namespace Core\Mapper;

use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Core\Controller\ProvideCommonTrait;
use Cache\Service\ProvideCacheTrait;

class AbstractMapper implements ServiceLocatorAwareInterface
{
    
    use ProvideCommonTrait,ProvideCacheTrait;

    protected $serviceLocator;

    protected $options = array();

    public function getServiceLocator()
    {
        return $this->serviceLocator;
    }

    public function setServiceLocator( ServiceLocatorInterface $serviceLocator )
    {
        $this->serviceLocator = $serviceLocator;
        return $this;
    }

    /**
     *
     * @var \Core\Service\SoapHandleService
     */
    private $soapService;

    /**
     *
     * @return the $soapService
     */
    private function getSoapService()
    {
        if ( ! $this->soapService ) {
            $this->soapService = $this->getServiceLocator()->get('soapService');
        }
        return $this->soapService;
    }

    public function getAndCallSoapService( $project, $soapServiceApi, $parameters = array() )
    {
        return $this->getSoapService()->callSoapService($project, $soapServiceApi, $parameters);
    }

    public function chainStyleCallSoapService( $project, $soapServiceApi, $parameters = array() )
    {
        $this->setOptions(array(
            $soapServiceApi,
            $parameters
        ));
        $options = $this->getOptions();
        $this->clearSettings();
        $soapService = $this->getSoapService();
        $sid = $soapService->getAuthorization($project);
        $client = $soapService->getSoapClient();
        return $client->multiCall($sid, $options, $soapServiceApi);
    }

    /**
     * 写入日志
     *
     * @param string $errorMessage            
     * @ignore EMERG = 0; // Emergency: 系统不可用 ALERT = 1; // Alert: 报警 CRIT = 2; // Critical: 紧要 ERR = 3; // Error: 错误 WARN = 4; // Warning: 警告 NOTICE = 5; // Notice: 通知 INFO = 6; // Informational: 一般信息 DEBUG = 7; // Debug: 小时消息
     * @example EMERG = 0; // Emergency: system is unusable
     * @example ALERT = 1; // Alert: action must be taken immediately
     * @example CRIT = 2; // Critical: critical conditions
     * @example ERR = 3; // Error: error conditions
     * @example WARN = 4; // Warning: warning conditions
     * @example NOTICE = 5; // Notice: normal but significant condition
     * @example INFO = 6; // Informational: informational messages
     * @example DEBUG = 7; // Debug: debug messages
     */
    public function _recordLog( $errorMessage, $priority = 'INFO' )
    {
        $this->getServiceLocator()
            ->get('Zend\Log')
            ->{strtolower($priority)}($errorMessage);
    }

    /**
     * Prepare options
     *
     * @param array $options            
     * @return object
     */
    public function setOptions( array $options )
    {
        $this->options[] = $options;
        return $this;
    }

    public function clearSettings()
    {
        $this->options = array();
        return $this;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function getOptions()
    {
        return $this->options;
    }

    protected function cache( $type = CACHE_TYPE_DEFAULT )
    {
        self::existCacheType($type);
        if ( is_string(self::$cacheList[$type]) ) {
            self::$cacheList[$type] = $this->getServiceLocator()->get('cacheService');
        }
        return self::$cacheList[$type]->caches($type);
    }

    /**
     *
     * @var \Core\Service\RestfulClientService
     */
    public $restfulClientService;

    /**
     *
     * @return the $restfulClientService
     */
    public function getRestfulClientService()
    {
        if ( ! isset($this->restfulClientService) ) {
            $this->restfulClientService = $this->getServiceLocator()->get('restfulClient');
        }
        return $this->restfulClientService;
    }

    protected function getAndCallRestfulClientService( $project, $path, $method, $parameters = array(), $is_pretreatment = false )
    {
        $jsonResult = $this->getRestfulClientService()->getAndCallRestfulApi($project, $path, $method, $parameters);
        if ( $is_pretreatment === true ) {
            $result = self::jsonToArray($jsonResult);
            
            if ( (isset($result['result']) && ! empty($result['result'])) ) {
                return $result['result'];
            }
            
            if ( isset($result['result']) ) {
                return $result['result'];
            }
            
            return $result;
        }
        return $jsonResult;
    }
}