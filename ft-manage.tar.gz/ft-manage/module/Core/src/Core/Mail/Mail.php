<?php
/**
 * 
 * Featee
 * 
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * 
 * @date: 2014-3-1 下午6:26:54
 * @author: Kaizhen Wang
 *
*/
namespace Core\Mail;

use Core\Mail\Message;
use Zend\Mail\Exception;
use Zend\Di\Di;
use Zend\Di\Config as DiConfig;
use Zend\Mail\Message as ZendMessage;

/**
 * Core Mail
 *
 * @category Core
 * @package Core_Mail
 */
class Mail
{

    protected $message;

    protected $transports;

    protected $conflictTransports = array(
        'sendmail',
        'smtp',
        'queue'
    );

    protected $transportsClasses = array(
        'sendmail' => 'Zend\Mail\Transport\Sendmail',
        'smtp' => 'Zend\Mail\Transport\Smtp',
        'file' => 'Zend\Mail\Transport\File'
    );

    public function setTransportsClasses(array $classes)
    {
        $this->transportsClasses = $classes;
        return $this;
    }

    public function setMessage(ZendMessage $message)
    {
        $this->message = $message;
        return $this;
    }

    public function getMessage()
    {
        return $this->message;
    }

    public function getTransport($type)
    {
        if ( isset($this->transports[$type]) ) {
            return $this->transports[$type];
        }
    }

    public function send(ZendMessage $message = null)
    {
        $message = $message ? $message : $this->message;
        if ( ! $message ) {
            throw new Exception\InvalidArgumentException(sprintf('Mail message not set'));
        }
        
        $transports = $this->transports;
        if ( ! $transports ) {
            throw new Exception\InvalidArgumentException(sprintf('Mail transport not set'));
        }
        
        $conflictTransports = $this->conflictTransports;
        $transportTypes = array_keys($transports);
        
        if ( count(array_intersect($conflictTransports, $transportTypes)) > 1 ) {
            throw new Exception\InvalidArgumentException(sprintf('Mail transports conflicted by %s', implode(",", array_intersect($conflictTransports, $transportTypes))));
        }
        
        $zendMessage = new ZendMessage();
        $zendMessage->setBody($message->getBody());
        $zendMessage->setHeaders($message->getHeaders());
        $zendMessage->setEncoding($message->getEncoding());
        $message = $zendMessage;
        
        $sendResult = false;
        foreach ( $transports as $transportType => $transport ) {
            $sendResult = $transport->send($message);
        }
    }

    public function __construct(array $config = array())
    {
        $defaultConfig = array(
            'transports' => array(
                'smtp' => true,
                'sendmail' => false,
                'file' => false
            ),
            'message' => array(),
            'di' => array(
                'definition' => array(
                    'class' => array(
                        'Zend\View\Resolver\AggregateResolver' => array(
                            'attach' => array(
                                'resolver' => array(
                                    'required' => true,
                                    'type' => 'Zend\View\Resolver\TemplatePathStack'
                                )
                            )
                        )
                    )
                ),
                'instance' => array(
                    'Zend\View\Resolver\TemplatePathStack' => array(
                        'parameters' => array(
                            'paths' => array(
                                Message::VIEW_PATH_NAME => FAIRFEAT_ROOT_PATH . '/data/'
                            )
                        )
                    ),
                    'Zend\View\Resolver\AggregateResolver' => array(
                        'injections' => array(
                            'Zend\View\Resolver\TemplatePathStack'
                        )
                    ),
                    'Zend\View\Renderer\PhpRenderer' => array(
                        'parameters' => array(
                            'resolver' => 'Zend\View\Resolver\AggregateResolver'
                        )
                    ),
                    // Zend View Di Config End
                    'Core\Mail\Message' => array(
                        'parameters' => array(
                            'view' => 'Zend\View\Renderer\PhpRenderer',
                            'viewModel' => 'Zend\View\Model\ViewModel',
                            'encoding' => 'UTF-8'
                        )
                    ),
                    'Zend\Mail\Transport\FileOptions' => array(
                        'parameters' => array(
                            'path' => FAIRFEAT_ROOT_PATH . '/data/mail'
                        )
                    ),
                    'Zend\Mail\Transport\File' => array(
                        'injections' => array(
                            'Zend\Mail\Transport\FileOptions'
                        )
                    ),
                    'Zend\Mail\Transport\SmtpOptions' => array(
                        'parameters' => array(
                            'name' => 'celestra',
                            'host' => 'smtp.celestra.cn',
                            'port' => 25,
                            'connectionClass' => 'login',
                            'connectionConfig' => array(
                                'username' => 'admin@celestra.cn',
                                'password' => 'miBjaHXl1haXm2'
                            )
                        )
                    ),
                    'Zend\Mail\Transport\Smtp' => array(
                        'injections' => array(
                            'Zend\Mail\Transport\SmtpOptions'
                        )
                    )
                )
            )
        );
        
        $config = array_merge($defaultConfig, $config);
        
        $diConfig = array();
        if ( $config['di'] ) {
            $diConfig = $config['di'];
        }
        $di = new Di();
        
        $di->configure(new DiConfig($diConfig));
        $this->message = $di->get('Core\Mail\Message');
        $allowTransports = $this->transportsClasses;
        $transportType = '';
        if ( is_string($config['transports']) ) {
            $transportType = $config['transports'];
            $transportClass = isset($allowTransports[$transportType]) ? $allowTransports[$transportType] : null;
            if ( ! $transportClass ) {
                throw new Exception\InvalidArgumentException(sprintf('Unknow transport type %s in method %s"', $transportType, __METHOD__));
            }
            
            $transport = $di->get($transportClass);
            // \Zend\Di\Display\Console::export($di);
            $this->transports[$transportType] = $transport;
        } elseif ( is_array($config['transports']) ) {
            $transportTypes = $config['transports'];
            foreach ( $transportTypes as $transportType => $value ) {
                if ( ! $value ) {
                    continue;
                }
                $transportClass = isset($allowTransports[$transportType]) ? $allowTransports[$transportType] : null;
                if ( ! $transportClass ) {
                    throw new Exception\InvalidArgumentException(sprintf('Unknow transport type %s in method %s"', $transportType, __METHOD__));
                }
                $this->transports[$transportType] = $di->get($transportClass);
            }
        } else {
            throw new Exception\InvalidArgumentException(sprintf('%s expects a string or array as transport config, "%s" received', __METHOD__, gettype($config['transports'])));
        }
    }
}