<?php
namespace Core\View\Helper;

use Zend\View\Helper\AbstractHelper;

class BaseUploadResouceUrl extends AbstractHelper
{

    /**
     * 
     * @var string
     */
    protected $url;
    
    public function __construct($accessUrl)
    {
        $this->url = $accessUrl;
    }
    
    /**
     *
     * @return string
     */
    public function __invoke()
    {
        return $this->url;
    }

}