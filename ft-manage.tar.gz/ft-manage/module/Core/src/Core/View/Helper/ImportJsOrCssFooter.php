<?php
/**
 * 
 * Featee
 * 
 * ==============================================
 * 这不是一个自由软件，未经授权不许任何使用和传播。
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * ==============================================
 * 
 * @date: 2014-3-1 下午6:51:03
 * @author: pardus
 *
*/
namespace Core\View\Helper;

use Zend\View\Helper\AbstractHelper;
use Zend\Mvc\Exception;

class ImportJsOrCssFooter extends AbstractHelper
{

    /**
     * 页面的底部加载Js和Css 文件。
     *
     * @example 在controller 中, 使用$this->layout()->importCssOrJsFooter=array('/home.css');
     * @example 在layout 中，使用 <?php echo $this->importJsOrCssFooter($this->basePath()); ?>
     * @param String $basePath            
     * @throws Exception\DomainException
     */
    public function __invoke($basePath)
    {
        if (empty($basePath)) {
            throw new Exception\DomainException('ImportJsOrCssFooter plugin request parameter error! ');
        }
        $this->importJsOrCssFooter($basePath);
    }

    private function importJsOrCssFooter($basePath)
    {
        $cssOrJsList = $this->view->layout()->importCssOrJsFooter;
        
        if (isset($cssOrJsList)) {
            if (is_array($cssOrJsList)) {
                foreach ($cssOrJsList as $key => $val) {
                    $jc = strrchr($val, '.');
                    $jc = substr($jc, 0, 3);
                    if ($jc == '.js') {
                        echo '<script type="text/javascript" src="' . $basePath . '/js' . $val . '"></script>';
                    } elseif ($jc == '.cs') {
                        echo '<link rel="stylesheet" media="screen" type="text/css" href="' . $basePath . '/css' . $val . '" />';
                    }
                }
            }
        } else {
            return false;
        }
    }
}