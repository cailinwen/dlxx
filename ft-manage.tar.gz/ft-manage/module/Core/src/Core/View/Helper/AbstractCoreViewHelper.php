<?php
namespace Core\View\Helper;

use Zend\View\Helper\AbstractHelper;
use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Session\Container;
class AbstractCoreViewHelper extends AbstractHelper implements ServiceLocatorAwareInterface
{

    protected $serviceLocator;

    /**
     * Set service locator
     *
     * @param object $serviceLocator            
     * @see \Zend\ServiceManager\ServiceLocatorAwareInterface::setServiceLocator()
     */
    public function setServiceLocator(ServiceLocatorInterface $serviceLocator)
    {
        $this->serviceLocator = $serviceLocator;
        return $this;
    }

    public function getServiceLocator()
    {
        return $this->serviceLocator;
    }

    public function t($text, $text_domain = 'default', $lang = null)
    {
        if ( ! $text_domain )
            $text_domain = 'default';
        return $this->getTranslationService()->translate($text, $text_domain, $lang);
    }

    public function getCurrentLocale()
    {
        return $this->getTranslationService()->getLocale();
    }

    private $translationService;

    public function getTranslationService()
    {
        if ( ! $this->translationService ) {
            $this->translationService = $this->getServiceLocator()
                ->getServiceLocator()
                ->get('translator');
        }
        return $this->translationService;
    }

    /**
     *
     * @var \Profile\service\User
     */
    private $userService;

    public function getUserService()
    {
        if ( ! $this->userService ) {
            $this->userService = $this->getServiceLocator()
                ->getServiceLocator()
                ->get('profile_user_service');
        }
        return $this->userService;
    }

    private static $sessionUser;

    protected static function getSessionUser()
    {
        if ( ! self::$sessionUser ) {
            $session_user = new Container('user');
            $isSession = $session_user->offsetExists('userInfos');
            if ( $isSession ) {
                self::$sessionUser = unserialize($session_user->offsetGet('userInfos'));
            } else {
                self::$sessionUser = false;
            }
        }
        return self::$sessionUser;
    }
}