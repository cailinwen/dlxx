<?php
/**
 * 
 * Featee
 * 
 * ==============================================
 * 这不是一个自由软件，未经授权不许任何使用和传播。
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * ==============================================
 * 
 * @date: 2014-3-1 下午6:50:59
 * @author: Kent Yen
 *
*/
namespace Core\View\Helper;

use Zend\View\Helper\AbstractHelper;

class ConvertArrToUrl extends AbstractHelper
{
 
    
    public function __invoke($array)
    {
        return $this->convertArrToUrl($array);
    }
 
 	public function convertArrToUrl($array){
 		if (!$array) {
 			return false;
 		} 
 		foreach ($array as $key => $value) {
 			$joinArr[] = $key.'='.$value;
 		}
 		$str = implode('&', $joinArr);
 		return urlencode($str);
 	}
}