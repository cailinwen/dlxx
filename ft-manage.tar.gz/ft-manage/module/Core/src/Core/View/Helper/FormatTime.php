<?php
namespace Core\View\Helper;

use Core\Service\RelatedTimeTrait;

/**
 *
 * @author parduswu
 *        
 */
class FormatTime extends AbstractCoreViewHelper
{
    use RelatedTimeTrait;

    public function __invoke($time, $type = 1, $abbreviation = true)
    {
        return self::formatTimeByLocale($time, $type, $abbreviation, $this->getCurrentLocale());
    }
}