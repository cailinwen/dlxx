<?php
/**
 * 
 * Featee
 * 
 * ==============================================
 * 这不是一个自由软件，未经授权不许任何使用和传播。
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * ==============================================
 * 
 * @date: 2014-3-1 下午6:51:12
 * @author: Kent Yen
 *
*/
namespace Core\View\Helper;

use Zend\View\Helper\AbstractHelper;

class RelativeDate extends AbstractHelper
{
	
	public function __invoke($time) {
		if (empty ( $time )) { 
		    list($msec, $sec) = explode(' ', microtime());
            $time = ($sec + $msec) * 100000000;
		}
		return $this->relativeDate ( $time );
	}
	
	function relativeDate($time) { 
	    
	    $time = strlen($time) > 10 ? substr($time, 0, 10) : $time;
		$today = strtotime(date('M j, Y')); 
		$reldays = ($time - $today)/86400; 
// 		if ($reldays >= 0 && $reldays < 1) { 
// 			return date('H:i, ',$time).$this->t('Today'); 
// 		} else if ($reldays >= 1 && $reldays < 2) { 
// 			return date('H:i, ',$time).$this->t('Tomorrow'); 
// 		} else if ($reldays >= -1 && $reldays < 0) { 
// 			return date('H:i, ',$time).$this->t('Yesterday'); 
// 		} 
// 		if (abs($reldays) < 7) { 
// 			if ($reldays > 0) { 
// 				$reldays = floor($reldays); 
// 				return date('H:i, ',$time).str_replace("'%day%'", EMPTYSPACE.$reldays .EMPTYSPACE, $this->t("In '%day%' days")); 
// 			} else { 
// 				$reldays = abs(floor($reldays)); 
// 				return str_replace("'%day%'", date('H:i, ',$time).$reldays, $this->t("'%day%' days ago")); 
// 			} 
// 		} 
		
// 		$week =array(
//             $this->t('Sun'),
//             $this->t('Mon'),
//             $this->t('Tue'),
//             $this->t('Wed'),
//             $this->t('Thu'),
//             $this->t('Fri'),
//             $this->t('Sat')
// 		);

		if (abs($reldays) < 182) { 
			return sprintf(date('m/d%\sH:i', $time), '&nbsp;&nbsp;&nbsp;');
		} else {
			return sprintf(date('m/d/Y%\sH:i', $time), '&nbsp;&nbsp;&nbsp;');
		} 
	} 
	

	function t($message, $textDomain='default', $locale=null){
	    if(null == $locale) {
	        $locale = $this->getView()->layout()->language;
	    }
	    return $this->getView()->translate($message, $textDomain, $locale);
	}
 	
}