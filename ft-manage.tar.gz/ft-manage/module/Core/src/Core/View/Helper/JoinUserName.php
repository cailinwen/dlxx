<?php
/**
 * 
 * Featee
 * 
 * ==============================================
 * 这不是一个自由软件，未经授权不许任何使用和传播。
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * ==============================================
 * 
 * @date: 2014-3-1 下午6:51:07
 * @author: Kent Yen
 *
*/
namespace Core\View\Helper;

use Zend\View\Helper\AbstractHelper;

class JoinUserName extends AbstractHelper
{

    public function __invoke($lastname, $firstname)
    {
        return $this->joinUserName($lastname, $firstname);
    }

 /**
     * 参照类的说明
     * 
     * @param string $lastname 姓
     * @param string $firstname 名字
     * @return string 返回组装好的用户名称
     */
    public function joinUserName($lastname, $firstname)
    {
        if (mb_strlen($lastname, 'utf8') != strlen($lastname)) {
			return $lastname.$firstname;
		} else {
			return $firstname.' '.$lastname;
		}
    }
}