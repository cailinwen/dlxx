<?php
namespace Core\View\Helper;

class OutPutImgUrlViewHelper extends AbstractCoreViewHelper
{

    /**
     *
     * @var \Core\Service\PersonalAvatarDiffSizePathService
     */
    private $userDiffSizeAvatar;

    /**
     *
     * @return the $userDiffSizeAvatar
     */
    private function getUserDiffSizeAvatar()
    {
        if ( ! $this->userDiffSizeAvatar ) {
            $this->userDiffSizeAvatar = $this->getServiceLocator()
                ->getServiceLocator()
                ->get('userDiffSizeAvatar');
        }
        return $this->userDiffSizeAvatar;
    }

    /**
     *
     * @var \Core\Service\DimzouCoverDiffSizePathService
     */
    private $dimzouDiffSizeCover;

    /**
     *
     * @return the $dimzouDiffSizeCover
     */
    private function getDimzouDiffSizeCover()
    {
        if ( ! $this->dimzouDiffSizeCover ) {
            $this->dimzouDiffSizeCover = $this->getServiceLocator()
                ->getServiceLocator()
                ->get('dimzouDiffSizeCover');
        }
        return $this->dimzouDiffSizeCover;
    }

    public function echoDiffSizeUserImg($user_id, $imgName, $size = 2)
    {
        return $this->getUserDiffSizeAvatar()->echoImgPath($user_id, $imgName, $size);
    }

    public function echoDiffSizeDimzouImg($user_id, $art_id, $filename, $size)
    {
        return $this->getDimzouDiffSizeCover()->echoDimzouImgPath($user_id, $art_id, $filename, $size);
    }
}