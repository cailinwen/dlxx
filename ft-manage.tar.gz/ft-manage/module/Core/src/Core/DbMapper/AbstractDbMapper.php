<?php
/**
 * Featee This is not a free software, unauthorized use is prohibited.
 *
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 * @author : pardus
 */
namespace Core\DbMapper;

use Core\Db\Adapter\DbAdapterAwareInterface;
use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use DataTable\Service\ProvidesTableMetadataInterface;
use Zend\Db\Adapter\Driver\ResultInterface;
use Zend\Db\Sql\Sql;
use Zend\Db\Adapter\Adapter;
use Zend\EventManager\EventManagerInterface;
use Zend\EventManager\EventManager;
use Zend\EventManager\Event;
use Zend\Mvc\MvcEvent;
use Zend\Db\Adapter\ParameterContainer;
use Core\Controller\ProvideCommonTrait;
use Cache\Service\ProvideCacheTrait;

abstract class AbstractDbMapper implements DbAdapterAwareInterface, ServiceLocatorAwareInterface, ProvidesTableMetadataInterface
{
    use ProvideCommonTrait,ProvideMapperCommonTrait,PagingOptionsTrait,ProvideCacheTrait;

    protected $eventManager;

    protected $event;

    protected $events;

    protected $eventIdentifier;

    public function setAdminDbAdapter( Adapter $dbAdapter )
    {
        $this->adminDbAdaper = $this->getServiceLocator()->get('ft_manage');
        return $this;
    }

    public function getAdminDbAdapter()
    {
        if ( ! $this->adminDbAdaper ) {
            $this->adminDbAdaper = $this->getServiceLocator()->get('ft_manage');
        }
        return $this->adminDbAdaper;
    }

    public function setFeatDbAdapter( Adapter $dbAdapter )
    {
        $this->featDbAdapter = $this->getServiceLocator()->get('ft_feat');
        return $this;
    }

    public function getFeatDbAdapter()
    {
        if ( ! $this->featDbAdapter ) {
            $this->featDbAdapter = $this->getServiceLocator()->get('ft_feat');
        }
        return $this->featDbAdapter;
    }

    /**
     * 对象转数组
     *
     * @param object $arrayObject            
     * @return array
     */
    protected static function beArray( $arrayObject )
    {
        $result = array();
        for ( $iterator = $arrayObject->getIterator(); $iterator->valid(); $iterator->next() ) {
            $result[$iterator->key()] = $iterator->current();
        }
        return $result;
    }

    /**
     * 返回单条数组
     *
     * @param array $result            
     * @return NULL | array
     */
    protected static function singleRow( $result )
    {
        return empty($result) ? null : $result[0];
    }

    /**
     *
     * @param unknown $sqlObj            
     * @param string $sql            
     * @return array
     */
    public function fetchAll( $sqlObj, $sql = '' )
    {
        if ( ! $sql ) {
            $sql = $this->getSql();
        }
        if ( is_object($sqlObj) ) {
            $sqlString = $sql->getSqlStringForSqlObject($sqlObj);
        } elseif ( is_string($sqlObj) ) {
            $sqlString = $sqlObj;
        }
        return $this->getDbAdapter()
            ->query($sqlString, Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
    }

    /**
     *
     * @param unknown $sqlObj            
     * @param string $sql            
     * @return array
     */
    public function fetchOneRow( $sqlObj, $sql = '' )
    {
        if ( ! $sql ) {
            $sql = $this->getSql();
        }
        if ( is_object($sqlObj) ) {
            $sqlString = $sql->getSqlStringForSqlObject($sqlObj);
        } elseif ( is_string($sqlObj) ) {
            $sqlString = $sqlObj;
        }
        $result = $this->getDbAdapter()
            ->query($sqlString, Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
        return self::singleRow($result);
    }

    /**
     *
     * @todo insert
     * @param string $table            
     * @param array $data            
     * @param boolean $getId            
     * @return id;
     */
    protected function dbInsert( $tableName, $data, $getId = true, $dbAdapter = '' )
    {
        $tableGateway = $this->getTableGateway($tableName, $dbAdapter);
        if ( $tableGateway->insert($data) ) {
            if ( ! $getId )
                return true;
            $lastId = $tableGateway->getLastInsertValue();
            return $lastId;
        } else {
            return false;
        }
    }

    /**
     * Insert many rows as one query
     *
     * @param array $data
     *            Insert array(array('field_name' => 'field_value'), array('field_name' => 'field_value_new'))
     * @return bool
     */
    public function multiInsert( $tableName, array $data )
    {
        $sqlStringTemplate = 'INSERT INTO %s (%s) VALUES %s';
        $adapter = $this->getDbAdapter();
        $driver = $adapter->getDriver();
        $platform = $adapter->getPlatform();
        
        $parameterContainer = new ParameterContainer();
        $statementContainer = $adapter->createStatement();
        $statementContainer->setParameterContainer($parameterContainer);
        
        /* Preparation insert data */
        $insertQuotedValue = [];
        $insertQuotedColumns = [];
        $i = 0;
        foreach ( $data as $insertData ) {
            $fieldName = 'field' . ++ $i . '_';
            $oneValueData = [];
            $insertQuotedColumns = [];
            foreach ( $insertData as $column => $value ) {
                $oneValueData[] = $driver->formatParameterName($fieldName . $column);
                $insertQuotedColumns[] = $platform->quoteIdentifier($column);
                $parameterContainer->offsetSet($fieldName . $column, $value);
            }
            $insertQuotedValue[] = '(' . implode(',', $oneValueData) . ')';
        }
        
        /* Preparation sql query */
        $query = sprintf($sqlStringTemplate, $tableName, implode(',', $insertQuotedColumns), implode(',', array_values($insertQuotedValue)));
        $statementContainer->setSql($query);
        $result = $statementContainer->execute();
        return is_object($result);
    }

    /**
     *
     * @todo update
     * @param string $tableName            
     * @param array $data            
     * @param array $where            
     * @return int 返回影响行数
     */
    protected function dbUpdate( $tableName, $data, $where )
    {
        return $this->getTableGateway($tableName)->update($data, $where);
    }

    /**
     * Delete
     *
     * @param unknown $tableName            
     * @param unknown $where            
     */
    protected function dbDelete( $tableName, $where )
    {
        return $this->getTableGateway($tableName)->delete($where);
    }

    public function dbSave( $table, $data = array(), $where = array() )
    {
        if ( empty($table) || empty($data) ) {
            return false;
        }
        $sql = new Sql($this->getDbAdapter());
        $save = null;
        if ( empty($where) ) {
            $save = $sql->insert($table);
            $save->values($data);
        } else {
            if ( ! $where ) {
                return false;
            }
            $save = $sql->update($table);
            $save->set($data);
            $save->where($where);
        }
        $sqlString = $sql->getSqlStringForSqlObject($save);
        $result = $this->getDbAdapter()->query($sqlString, Adapter::QUERY_MODE_EXECUTE);
        return true;
    }

    /**
     *
     * @param Zend\Db\Adapter\ResultInterface $source            
     * @return array
     */
    protected static function toArray( ResultInterface $source )
    {
        $result = array();
        foreach ( $source as $item ) {
            $result[] = $item;
        }
        return $result;
    }

    protected function cache( $type = CACHE_TYPE_DEFAULT )
    {
        self::existCacheType($type);
        if ( is_string(self::$cacheList[$type]) ) {
            self::$cacheList[$type] = $this->getServiceLocator()->get('cacheService');
        }
        return self::$cacheList[$type]->caches($type);
    }

    /**
     * Set the event manager instance used by this context
     *
     * @param EventManagerInterface $events            
     * @return AbstractService
     */
    public function setEventManager( EventManagerInterface $events )
    {
        $events->setIdentifiers(array(
            'Zend\Stdlib\DispatchableInterface',
            __CLASS__,
            get_class($this),
            $this->eventIdentifier,
            substr(get_class($this), 0, strpos(get_class($this), '\\'))
        ));
        $this->events = $events;
        return $this;
    }

    /**
     * Retrieve the event manager Lazy-loads an EventManager instance if none registered.
     *
     * @return EventManagerInterface
     */
    public function getEventManager()
    {
        if ( ! $this->events ) {
            $this->setEventManager(new EventManager());
        }
        
        return $this->events;
    }

    /**
     * Set an event to use during dispatch By default, will re-cast to MvcEvent if another event type is provided.
     *
     * @param Event $e            
     * @return void
     */
    public function setEvent( Event $e )
    {
        if ( ! $e instanceof MvcEvent ) {
            $eventParams = $e->getParams();
            $e = new MvcEvent();
            $e->setParams($eventParams);
            unset($eventParams);
        }
        $this->event = $e;
    }

    /**
     * Get the attached event Will create a new MvcEvent if none provided.
     *
     * @return MvcEvent
     */
    public function getEvent()
    {
        if ( ! $this->event ) {
            $this->setEvent(new MvcEvent());
        }
        
        return $this->event;
    }

    public function getServiceLocator()
    {
        return $this->serviceLocator;
    }

    public function setServiceLocator( ServiceLocatorInterface $serviceLocator )
    {
        $this->serviceLocator = $serviceLocator;
        return $this;
    }
}
