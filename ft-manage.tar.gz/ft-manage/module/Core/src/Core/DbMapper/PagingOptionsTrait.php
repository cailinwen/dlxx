<?php
namespace Core\DbMapper;

trait PagingOptionsTrait
{

    protected $limit = 10;

    protected $offset = 0;

    protected $page = 1;

    protected $order = array();

    protected $group = array();

    public function setPage($page, $limit = 10)
    {
        if ( ! $page ) {
            $page = 1;
        }
        $offset = ($page - 1) * $limit;
        $this->setLimit($limit);
        $this->setOffset($offset);
        $this->page = $page;
        return $this;
    }

    public function getPage()
    {
        return $this->page;
    }

    public function getOffset()
    {
        return $this->offset;
    }

    public function setOffset($offset)
    {
        $this->offset = $offset;
        return $this;
    }

    public function setLimit($limit)
    {
        $this->limit = $limit;
        return $this;
    }

    public function getLimit()
    {
        return $this->limit;
    }

    public function setGroup($group)
    {
        $this->group = $group;
        return $this;
    }

    public function getGroup()
    {
        return $this->group;
    }

    public function setOrder($order)
    {
        $this->order = $order;
        return $this;
    }

    public function getOrder()
    {
        return $this->order;
    }

    public function clearSettings()
    {
        $this->limit = 10;
        $this->offset = 0;
        $this->page = 1;
        $this->group = array();
        $this->order = array();
        return $this;
    }
}