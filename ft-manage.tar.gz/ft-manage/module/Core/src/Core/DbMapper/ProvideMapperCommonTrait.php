<?php
/**
 * Featee This is not a free software, unauthorized use is prohibited.
 *
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 * @author : pardus
 */
namespace Core\DbMapper;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;
use DataTable\Service\ProvidesTableMetadataTrait;
use Zend\Db\Sql\Sql;

trait ProvideMapperCommonTrait
{
    use ProvidesTableMetadataTrait;

    protected $dbAdapter;

    protected $adminDbAdaper;

    protected $featDbAdapter;

    /**
     *
     * @return Adapter
     */
    public function getDbAdapter()
    {
        return $this->dbAdapter;
    }

    /**
     *
     * @param Adapter $dbAdapter            
     * @return AbstractDbMapper
     */
    public function setDbAdapter( Adapter $dbAdapter )
    {
        $this->dbAdapter = $dbAdapter;
        return $this;
    }

    /**
     * Get TableGateway object
     *
     * @param string $name            
     * @return \Zend\Db\TableGateway\TableGateway
     */
    protected function setTableGateway( $tableName, $dbAdapter = '' )
    {
        return new TableGateway($tableName, $dbAdapter ? $dbAdapter : $this->getDbAdapter());
    }

    protected function getTableGateway( $tableName, $dbAdapter = '' )
    {
        self::existDataTable($tableName);
        if ( is_string(self::$tableNameList[$tableName]) ) {
            self::$tableNameList[$tableName] = $this->setTableGateway($tableName, $dbAdapter);
        }
        return self::$tableNameList[$tableName];
    }

    /**
     *
     * @var Sql
     */
    private $sql;

    /**
     *
     * @return Sql
     */
    protected function getSql()
    {
        if ( ! $this->sql instanceof Sql ) {
            $this->sql = new Sql($this->getDbAdapter());
        }
        return $this->sql;
    }
}