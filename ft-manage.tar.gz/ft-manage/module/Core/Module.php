<?php
/**
 * Featee This is not a free software, unauthorized use is prohibited.
 *
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
namespace Core;

use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;
use Zend\Validator\AbstractValidator;
use Zend\Http\Request;
use Zend\Session\Container;

class Module implements AutoloaderProviderInterface
{

    public function onBootstrap( MvcEvent $e )
    {
        $eventManager = $e->getApplication()->getEventManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
        $this->_initDbSession($e);
        
        $this->_initTranslator($e);
        
        $this->_ifAjaxNotRequest($e);
        
        $this->onDispatchError($e);

//         $this->initRequireFile($e);
        

        $this->initialJsSettings($e);
    }

    public function _initDbSession( MvcEvent $e )
    {
        $sm = $e->getApplication()->getServiceManager();
        $sessionManager = $sm->get('Feat_Session_Manager');
        $sessionManager->start();
    }

    private static $adminUser = array(
        1, // 超级管理员
        2, // 管理员
        3, // 文章审核管理员
        4, // 公安局
        5
    ); // 翻译审核管理员

    
    /**
     * Ajax 请求不用执行的事件
     *
     * @param MvcEvent $e            
     */
    public function _ifAjaxNotRequest( MvcEvent $e )
    {
        $application = $e->getTarget();
        $eventManager = $application->getEventManager();
        $targetRequest = $application->getRequest();
        
        if ( $targetRequest instanceof Request && ! $targetRequest->isXmlHttpRequest() ) {
            $eventManager->attach(MvcEvent::EVENT_RENDER, array(
                $this,
                'setUserToView'
            ), 100);
            $this->_initDefaultMeta($e);
            $this->checkBrower($e);
        }
    }

    public function _initDefaultMeta( MvcEvent $e )
    {
        $app = $e->getApplication();
        $em = $app->getEventManager();
        $sm = $e->getApplication()->getServiceManager();
        $em->attach(MvcEvent::EVENT_DISPATCH, function ( $event ) use($sm )
        {
            $renderer = $sm->get('Zend\View\Renderer\PhpRenderer');
            $renderer->headMeta()
                ->appendName('keywords', 'Featfair, Feat, fairfeat,fair,goodfeat,featee')
                ->appendName('author', 'Feat Technologies Corporation Limited');
        });
    }

    /**
     * Set the sessionUser to view
     *
     * @param unknown $event            
     */
    public function setUserToView( $event )
    {
        $viewModel = $event->getViewModel();
        if ( $viewModel instanceof \Zend\View\Model\JsonModel ) {
            return;
        }
        $user = self::getSessionUser() ? self::getSessionUser() : '';
        $viewModel->setVariables(array(
            'sessionUser' => $user
        ));
    }

    private static function getSessionUser()
    {
        $session_user = new Container('user');
        $isSession = $session_user->offsetExists('userInfos');
        
        if ( $isSession ) {
            $user = unserialize($session_user->offsetGet('userInfos'));
            return $user;
        } else
            return false;
    }

    /**
     * Set error layout from route
     *
     * @param MvcEvent $e            
     */
    public function onDispatchError( MvcEvent $e )
    {
        $app = $e->getApplication();
        $eventManager = $app->getEventManager();
        $eventManager->attach(MvcEvent::EVENT_DISPATCH_ERROR, function ( $event ) use($e )
        {
//             $exception = $e->getResult()->exception;
//             if ( $exception ) {
//                 $sm = $e->getApplication()
//                     ->getServiceManager();
//                 $service = $sm->get('ErrorHandling');
//                 $service->_init()
//                     ->logException($exception);
//             }
            $view = $e->getViewModel();
            $view->setTemplate('error/layout');
        });
    }

    /**
     * Recommends that users use other browsers check user browsers
     */
    public function checkBrower( MvcEvent $e )
    {
        $app = $e->getApplication();
        $em = $app->getEventManager();
        $sm = $app->getServiceManager();
        $em->attach(MvcEvent::EVENT_DISPATCH, function ( $event ) use($e )
        {
            $controller = $e->getTarget();
            $config = $controller->getServiceLocator()
                ->get('config');
            $translator = $controller->getServiceLocator()
                ->get('translator');
            $language = $translator->getLocale();
            $browser = $controller->getServiceLocator()
                ->get('ControllerPluginManager')
                ->get('getClientSystem')
                ->getBrowser();
            
            if ( $browser['browser_name'] == 'Internet Explorer' && $browser['browser_name'] . ' ' . $browser['browser_version'] != 'Internet Explorer 10.0' ) {
                if ( $language == 'zh_CN' || $language == 'zh_cn' ) {
                    $msg = '为了更好的浏览体验，建议使用chrome、firefox、opera、safari、IE8+ 浏览器';
                } else {
                    $msg = 'For a better browsing experience, we recommend using chrome, Firefox, Opera, Safari, IE8+ browsers.';
                }
                $controller->layout()
                    ->setVariable('ieTips', $msg);
            }
        });
    }

    /**
     * translator
     */
    public function _initTranslator( MvcEvent $e )
    {
        $lang = 'en_US';
        $translator = $e->getApplication()
            ->getServiceManager()
            ->get('translator');
        if ( isset($_POST['l']) ) {
            $lang = $_POST['l'];
            $translator->setLocale($lang);
            setcookie("cel_language", $lang, time() + 30 * 24 * 60 * 60, '/');
        } elseif ( isset($_GET['l']) ) {
            $lang = $_GET['l'];
            $translator->setLocale($lang);
            setcookie("cel_language", $lang, time() + 30 * 24 * 60 * 60, '/');
        } elseif ( isset($_COOKIE['cel_language']) || ! empty($_COOKIE['cel_language']) ) {
            if ( $_COOKIE['cel_language'] == 'zh_CN' ) {
                $lang = $lang;
                setcookie("cel_language", $lang, time() + 30 * 24 * 60 * 60, '/');
            } else {
                $lang = $_COOKIE['cel_language'];
            }
            $translator->setLocale($lang);
        } else {
            $translator->setLocale($lang);
            setcookie("cel_language", $lang, time() + 30 * 24 * 60 * 60, '/');
        }
        $viewModel = $e->getViewModel();
        $viewModel->setVariable('languages', $lang);
        
        AbstractValidator::setDefaultTranslator($translator);
    }

    public function initRequireFile( MvcEvent $mvcEvent )
    {
        //         $app = $mvcEvent->getApplication();
        //         $em = $app->getEventManager()->getSharedManager();
        //         $em->attach('*', 'render', function ($dispatchEvent)
        //         {
        //             $sm = $dispatchEvent->getApplication()
        //                 ->getServiceManager();
        // //             $requireJsPlugin = $sm->get('ControllerPluginManager')
        // //                 ->get('requireJs');
        // //             $headScriptPlugin = $sm->get('viewHelperManager')
        // //                 ->get('headScript');
        // //             $headScriptPlugin()->appendFile('/js/vendor/jquery-2.1.1.min.js');
        //         });
    }

    public function initialJsSettings( MvcEvent $mvcEvent )
    {
        $app = $mvcEvent->getApplication();
        $em = $app->getEventManager()->getSharedManager();
        $sm = $mvcEvent->getApplication()->getServiceManager();
        
        $em->attach('*', MvcEvent::EVENT_DISPATCH, function ( $dispatchEvent ) use($sm )
        {
            $ijs = $sm->get('initial_js_settings_service');
            $ijs->initBaseurl();
            $ijs->initImageServer();
            $ijs->initStaticSourcesServer();
        });
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . str_replace('\\', '/', __NAMESPACE__)
                )
            )
        );
    }

    public function getControllerPluginConfig()
    {
        return include (__DIR__ . '/config/service/controllerpluginmanager.php');
    }

    public function getServiceConfig()
    {
        return include (__DIR__ . '/config/service/servicemanager.php');
    }

    public function getViewHelperConfig()
    {
        return include (__DIR__ . '/config/service/viewhelpermanager.php');
    }

    public function getConfig()
    {
        $config = array();
        $configFiles = array(
            __DIR__ . '/config/module.config.php',
            __DIR__ . '/config/module.service.config.php',
            __DIR__ . '/config/module.route.config.php'
        );
        foreach ( $configFiles as $configFile ) {
            $config = \Zend\Stdlib\ArrayUtils::merge($config, include $configFile);
        }
        return $config;
    }
}
