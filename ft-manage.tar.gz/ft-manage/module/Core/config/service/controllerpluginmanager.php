<?php
/**
 *
 * Featee This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
return array(
    'invokables' => array(
        'baseUrl' => 'Core\Controller\Plugin\BaseUrl',
        'viewhelper' => 'Core\Controller\Plugin\ViewHelper',
        'errorMessage' => 'Core\Controller\Plugin\ErrorMessage',
        'getClientSystem' => 'Core\Controller\Plugin\GetClientSystem', // all client info
        'htmlOutPut' => 'Core\Controller\Plugin\HtmlOutPut',
        'encryption' => 'Core\Controller\Plugin\Encryption',
        'javascript' => 'Core\Controller\Plugin\Javascript'
    )
);