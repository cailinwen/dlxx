<?php
/**
 * 
 * Featee
 * 
 * ==============================================
 * 这不是一个自由软件，未经授权不许任何使用和传播。
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies.  All Rights Reserved.
 * ==============================================
 * 
 * @date: 2014-3-10 下午5:13:12
 * @author: pardus
 *
*/
use Core\View\Helper\BaseUploadResouceUrl;

return array(
    'factories' => array(
        'baseUploadResouceUrl' => function ($sm) {
            /*上传文件的基本访问路径*/
            $accessUrl = $sm->getServiceLocator()->get('access_upload_message');
            return new BaseUploadResouceUrl($accessUrl);
        }
    ),
    'invokables' => array(
        
        'relativeDate' => '\Core\View\Helper\RelativeDate',
        
        'convertArrToUrl' => '\Core\View\Helper\ConvertArrToUrl',
        
        'removeCompanySuffix' => '\Core\View\Helper\RemoveCompanySuffix',
        
        'joinUsername' => '\Core\View\Helper\JoinUserName',
         'formatTime'=>'\Core\View\Helper\FormatTime',
        
        'outputImgUrl'=>'\Core\View\Helper\OutPutImgUrlViewHelper'
    )
);