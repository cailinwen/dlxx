<?php
/**
 *
 * Featee
 * This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
use Core\Db\Adapter\DbAdapterAwareInterface;
return array(
    'initializers' => array(
        function ($instance, $sm)
        {
            if ( $instance instanceof DbAdapterAwareInterface ) {
                $dbAdapter = $sm->get('dbAdapter');
                $instance->setDbAdapter($dbAdapter);
            }
        }
    ),
    'invokables' => array(
        'restful_client_service' => 'Core\Service\RestfulClientService',
        'users_avatar_path_service' => 'Core\Service\PersonalAvatarDiffSizePathService',
        'dimzou_cover_path_service' => 'Core\Service\DimzouCoverDiffSizePathService'
    ),
    'factories' => array(
        'Zend\Session\SessionManager' => 'Zend\Session\Service\SessionManagerFactory',
        'Zend\Session\Config\ConfigInterface' => function ($sm)
        {
            $config = $sm->get('config');
            if ( isset($config['session']) ) {
                $session = $config['session'];
                $sessionConfig = null;
                if ( isset($session['config']) ) {
                    $class = isset($session['config']['class']) ? $session['config']['class'] : 'Zend\Session\Config\SessionConfig';
                    $options = isset($session['config']['options']) ? $session['config']['options'] : array();
                    $sessionConfig = new $class();
                    $sessionConfig->setOptions($options);
                }
            }
            return $sessionConfig;
        },
        'upload_setting' => function ($serviceManager)
        {
            $config = $serviceManager->get('config');
            return $config['upload_setting'];
        },
        'access_upload_message' => function ($serviceManager)
        {
            $config = $serviceManager->get('config');
            return $config['upload_resouce_base_url'];
        },
        'Core_Service_FileOperationService' => function ($sm)
        {
            $fileOperationService = new \Core\Service\FileOperationService($sm);
            return $fileOperationService;
        },
        'Feat_Session_Manager' => 'Core\Factory\FeatSessionServiceFactory'
    ),
    'aliases' => array(
        'fileOperaService' => 'Core_Service_FileOperationService',
        'restfulClient' => 'restful_client_service',
        'userDiffSizeAvatar' => 'users_avatar_path_service',
        'dimzouDiffSizeCover' => 'dimzou_cover_path_service'
    )
);