<?php
/**
 * Featee
 *
 * @license This is not a free software, unauthorized use is prohibited.
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
namespace CoreConfig;

return array(
    'Javascript' => array(
        'global' => 'Project'
    ),
    'service_manager' => array(
        'factories' => array(),
        'aliases' => array(
            'translator' => 'MvcTranslator'
        )
    ),
    
    'translator' => array(
        'translation_file_patterns' => array(
            array(
                'type' => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern' => '%s.mo'
            )
        )
    ),
    
    'cookie' => array(
        'remember_me_seconds' => 2419200,
        'use_cookies' => true,
        'cookie_httponly' => true
    ),
    
    'controllers' => array(
        'invokables' => array(
            'Core\Controller\Core' => 'Core\Controller\CoreController'
        )
    ),
    
    'formats' => array(
        'en_US' => array(
            'M j' => 'M j',
            'm/d/y' => 'm/d/y',
            'F j, Y' => 'F j, Y',
            'F j' => 'F j',
            'F j, Y' => 'F j, Y',
            'g:ia' => 'g:ia',
            'n/j, g:ia' => 'n/j, g:ia'
        ),
        'zh_CN' => array(
            'M j' => 'n\月j\日',
            'm/d/y' => 'Y-n-j',
            'F j, Y' => 'Y\年n\月j\日',
            'F j' => 'n\月j\日',
            'F j, Y' => 'Y\年n\月j\日',
            'g:ia' => 'A g:i',
            'n/j, g:ia' => 'Y-n-d A g:i'
        )
    ),
    
    'upload_setting' => array(
        'base_upload_dir' => FAIRFEAT_PUBLIC_PATH . '/uploads/',
        'mode' => 0777
    ),
    
    'upload_resouce_base_url' => 'http://' . HOST_IP . ':911/',
    'view_manager' => array(
        'display_not_found_reason' => true,
        'display_exceptions' => true,
        'doctype' => 'HTML5',
        'not_found_template' => 'error/404',
        'exception_template' => 'error/index',
        'template_map' => array(
            'error/404' => __DIR__ . '/../view/error/error.phtml',
            'error/index' => __DIR__ . '/../view/error/index.phtml',
            'error/layout' => __DIR__ . '/../view/layout/errorlayout.phtml',
            'common/header' => __DIR__ . '/../view/layout/inc/header.phtml',
            'common/footer' => __DIR__ . '/../view/layout/inc/footer.phtml',
            
            'core/json' => __DIR__ . '/../view/layout/result.json'
        ),
        'template_path_stack' => array(
            'Core' => __DIR__ . '/../view',
            'core/core/index' => __DIR__ . '/../view/core/core/index.phtml'
        ),
        'strategies' => array(
            'ViewJsonStrategy'
        )
    )
);


