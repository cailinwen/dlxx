<?php
/**
 *
 * Featee
 * 
 * @license This is not a free software, unauthorized use is prohibited.
 * 
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/',
                    'defaults' => array(
                        'controller' => 'Core\Controller\Core',
                        'action' => 'index'
                    )
                )
            ),
            'core' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/core',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Core\Controller',
                        'controller' => 'Core',
                        'action' => 'index'
                    )
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'user' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '[/:action]',
                            'constraints' => array(
                                'action' => '[a-zA-Z][a-zA-Z0-9_-]*'
                            ),
                            'defaults' => array(
                                'controller' => 'Core\Controller\Core',
                                'action' => 'index'
                            )
                        )
                    )
                )
            )
        )
    )
);