<?php
namespace Translation\Common;

trait TranslationModuleCacheTrait
{

    protected static $basicWordsCacheKey = 'translation:translationKey:basicWords';
}