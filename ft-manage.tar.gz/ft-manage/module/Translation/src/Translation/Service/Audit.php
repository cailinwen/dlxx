<?php
namespace Translation\Service;

use Core\Service\AbstractService;

class Audit extends ModuleBaseService
{

    /**
     * 翻译审核
     *
     * @param array $auditData            
     * @return boolean
     */
    public function saveAudit($data)
    {
        if ( ! isset($data['user_id']) || ! isset($data['locale_id']) || ! isset($data['to_translation_locale']) || ! isset($data['msgid']) ) {
            return false;
        }
        $cacheId = 'translation:audit:' . $data['user_id'] . ':' . $data['locale_id'] . ':' . $data['to_translation_locale'];
        $cacheAuditId = 'translation:audit:' . $data['locale_id'] . ':' . $data['to_translation_locale'];
        $this->getAuditDbMapper()->clearAuditCache($cacheId);
        $this->getAuditDbMapper()->clearAuditCache($cacheAuditId);
        if ( ! isset($data['msgstr']) ) {
            return $this->getAuditDbMapper()->discardAudit($data);
        }
        $deleteAudit = $data;
        unset($deleteAudit['msgstr']);
        $this->getAuditDbMapper()->discardAudit($deleteAudit);
        $data['created'] = time();
        return $this->getAuditDbMapper()->saveAudit($data);
    }

    /**
     * 获取用户的审核记录
     *
     * @param number $user_id
     *            用户编号
     * @param string $language
     *            基础语言
     * @param string $target_locale
     *            目标语言
     *            
     * @return boolean
     */
    public function getUserAudit($user_id, $language, $target_locale)
    {
        return $this->getAuditDbMapper()->getAuditList($user_id, $language, $target_locale);
    }

    /**
     * 获取所有审核记录
     *
     * @param string $language            
     * @param string $target_locale            
     *
     * @return boolean array
     */
    public function getAllAudit($language, $target_locale)
    {
        return $this->getAuditDbMapper()->getAllAuditList($language, $target_locale);
    }
}

