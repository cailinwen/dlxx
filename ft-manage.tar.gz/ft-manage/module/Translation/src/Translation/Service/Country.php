<?php
namespace Translation\Service;

class Country extends ModuleBaseService
{

    /**
     * 根据国家ID获取国家信息
     */
    public function countryLoad($cid, $eventArgs = array())
    {
        return $this->getCountryDbMapper()->countryLoad($cid, $eventArgs);
    }

    public function findCountryByISO2($iso)
    {
        return $this->getCountryDbMapper()->findCountryByISO2($iso);
    }

    /**
     * 根据语言标识关联国家信息
     */
    public function countryLanguageLoad($localeId, $eventArgs = array())
    {
        return $this->getCountryDbMapper()->countryLanguageLoad($localeId, $eventArgs);
    }

    public function chinaCountry()
    {
        $province = $this->getCountryDbMapper()->province();
        $city = $this->getCountryDbMapper()->city();
        $county = $this->getCountryDbMapper()->district();
        
        return compact('province', 'city', 'county');
    }
}

