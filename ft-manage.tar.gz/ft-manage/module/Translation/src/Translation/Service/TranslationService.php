<?php
namespace Translation\Service;

class TranslationService extends ModuleBaseService
{

    /**
     *
     * @var \Translation\Mapper\TranslationMapper
     */
    private $translationMapper;

    /**
     *
     * @var \Translation\Mapper\Locale
     */
    private $localeService;

    /**
     *
     * @var \Translation\Service\BasicWord
     */
    private $basicWordService;

    /**
     *
     * @var \Translation\Service\Audit
     */
    private $auditService;

    /**
     * 审核列表
     *
     * @param array $auditList            
     * @return array
     */
    public function auditList( &$auditList )
    {
        $result = array();
        if ( ! $auditList ) {
            return $result;
        }
        foreach ( $auditList as $audit ) {
            $messageKey = md5($audit['msgid']);
            if ( ! $result || ($result && ! isset($result[$messageKey])) ) {
                $result[$messageKey]['audits'][] = $audit;
            } else {
                $result[$messageKey]['audits'][] = $audit;
            }
        }
        
        return $result;
    }

    public function clearCache()
    {
        $this->getBasicWordService()->clearCache();
    }

    public function createNewLanguage()
    {}

    /**
     * 获取所有要翻译内容
     *
     * @return array
     */
    public function getAllTranslationKey()
    {
        return $this->totalTranslate();
    }

    /**
     * 获取语言列表
     *
     * @return array
     */
    public function getAllLanguage()
    {
        return $this->getTranslationDbMapper()->getLanguageList();
    }

    /**
     * 将语言分组
     *
     * @param array $languages            
     * @return array
     */
    public function groupLauguage( $languages )
    {
        $tops[0] = array(
            "l_id" => "0",
            "language_name" => "All Language",
            "pid" => "0",
            'children' => $languages
        );
        
        if ( $languages ) {
            $languageTops = $this->getTranslationDbMapper()->getTopLanguageGroup();
            if ( ! $languageTops ) {
                return $tops;
            }
            $groupLanguage = array();
            foreach ( $languages as $key => $value ) {
                if ( isset($value['unique_title']) && isset($value['pid']) ) {
                    $groupLanguage[$value['pid']][] = $value;
                    if ( isset($value['otherPid']) && $value['otherPid'] != 0 ) {
                        $groupLanguage[$value['otherPid']][] = $value;
                    }
                } else {
                    unset($languages[$key]);
                }
            }
            foreach ( $languageTops as $topKey => $topValue ) {
                $tops[$topValue['l_id']] = $topValue;
                $tops[$topValue['l_id']]['children'] = isset($groupLanguage[$topValue['l_id']]) ? $groupLanguage[$topValue['l_id']] : false;
            }
        }
        
        return $tops;
    }

    /**
     * 获取多语言详细信息
     *
     * @param array $language            
     * @return boolean array
     */
    public function groupMessageDomain( $language )
    {
        $translateTargetList = $this->getLocaleDbMapper()->groupMessageDomain($language);
        if ( ! $translateTargetList ) {
            return false;
        }
        $languages = array();
        foreach ( $translateTargetList as $languageTitle ) {
            $languages[] = $languageTitle['message_domain'];
        }
        $languageInfos = $this->getTranslationDbMapper()->languageLoadByTitles($languages);
        return $languageInfos ? $languageInfos : false;
    }

    /**
     * 查询语言翻译内容
     *
     * @param string $language
     *            基础语言
     * @param string $queryLanguage
     *            查询翻译目标语言
     * @param number $user_id
     *            查询用户
     * @param boolean $isAdmin
     *            是否为管理员
     * @return boolean array
     */
    public function loadTranslation( $language, $queryLanguage, $user_id, $isAdmin )
    {
        if ( ! $language || ! $queryLanguage ) {
            return false;
        }
        
        $allTranslationList = $this->getTranslationDbMapper()->getMessageList();
        if ( ! $allTranslationList ) {
            return false;
        }
        $auditItem = $this->getAuditDbMapper()->getAuditList($user_id, $language, $queryLanguage);
        $currentUserAuditKey = array();
        $currentAudit = array();
        $translationList = array();
        $hasTranslate = 0;
        $allMustTranslate = 0;
        $mustTranslate = array();
        $auditList = array();
        foreach ( $auditItem as $key => $value ) {
            $currentUserAuditKey[] = md5($value['msgid']);
            $currentAudit[$value['msgid']] = $value['msgstr'];
        }
        if ( $isAdmin ) {
            $allAudit = $this->getAuditDbMapper()->getAllAuditList($language, $queryLanguage);
            $auditList = $this->auditList($allAudit);
            $mustTranslate = $this->totalTranslate($language); // 需要翻译的内容
            $allMustTranslate = count($mustTranslate); // 总共需要翻译的内容统计
        }
        foreach ( $allTranslationList as $key => &$value ) {
            if ( $value['locale_id'] == $language && $value['message_domain'] == $queryLanguage ) {
                $rwValue = htmlspecialchars_decode($value['message_key']);
                $messagekey = md5($rwValue);
                $translation_value = $value['message_translation'];
                $existsTranslation = array();
                
                if ( ! isset($translationList[$messagekey]) ) {
                    $translationList[$messagekey]['key'] = $rwValue;
                }
                
                if ( isset($translationList[$messagekey]['translation_value']) ) {
                    $existsTranslation = $translationList[$messagekey]['translation_value'];
                }
                
                if ( $currentUserAuditKey && in_array($messagekey, $currentUserAuditKey) ) {
                    $translationList[$messagekey]['hasAudit'] = true;
                    if ( $currentAudit && in_array($translation_value, $currentAudit) && $currentAudit[$rwValue] == $translation_value ) {
                        $value['chose'] = true;
                    }
                }
                
                $index = array_search($translation_value, $existsTranslation);
                if ( ! $existsTranslation || ($existsTranslation && $index === false) ) {
                    $translationList[$messagekey]['translation_value'][] = $translation_value;
                } else if ( $index !== false ) {
                    $translationList[$messagekey]['translations'][$index]['count'] += 1;
                    continue;
                }
                
                $value['count'] = 1;
                $translationList[$messagekey]['translations'][] = $value;
            }
        }
        $config = $this->getServiceLocator()->get('config');
        $minimum_audit = $config['minimum_audit'];
        $notAudit = 0;
        foreach ( $translationList as $key => &$translation ) {
            $hasAudit = isset($auditList[$key]['audits']) ? count($auditList[$key]['audits']) >= $minimum_audit : false;
            if ( $isAdmin && array_key_exists($key, $mustTranslate) && $hasAudit ) { // 已翻译
                ++ $hasTranslate;
            } else if ( ! array_key_exists($key, $mustTranslate) ) { // 过滤已删除的翻译
                unset($translationList[$key]);
                continue;
            } else { // 统计未审核的翻译词
                ++ $notAudit;
            }
            
            if ( count($translation['translations']) > 1 ) {
                $translation['translations'] = $this->multiArraySort($translation['translations'], 'count', SORT_DESC);
            }
        }
        $percent = false;
        if ( $isAdmin ) {
            $percent = number_format($hasTranslate * 100 / $allMustTranslate, 1) . '%';
        }
        $total = count($translationList);
        // $notAudit = $total - count($currentUserAuditKey);
        return array(
            'hasTranslationTotal' => $total, // 已翻译词个数
            'allTranslationKeyTotal' => count($mustTranslate), // 总共需要翻译词个数
            'percent' => $percent,
            'not_audit' => $notAudit < 0 ? 0 : $notAudit, // 未审核的翻译词个数
            'translationList' => $translationList
        );
    }

    /**
     * 查询某语言未翻译的内容
     *
     * @param string $language
     *            基础语言
     * @param string $queryLanguage
     *            查询翻译目标语言
     * @param number $user_id
     *            查询用户
     * @param boolean $isAdmin
     *            是否为管理员
     * @return boolean array
     */
    public function getUnTranslationKey( $language, $queryLanguage, $user_id, $isAdmin )
    {
        if ( ! $language || ! $queryLanguage ) {
            return false;
        }
        $allTranslationList = $this->getTranslationDbMapper()->getMessageList();
        if ( ! $allTranslationList ) {
            return false;
        }
        $auditItem = $this->getAuditService()->getUserAudit($user_id, $language, $queryLanguage);
        $currentUserAuditKey = array();
        $currentAudit = array();
        $translationList = array();
        $mustTranslate = array();
        
        foreach ( $auditItem as $key => $value ) {
            $currentUserAuditKey[] = md5($value['msgid']);
            $currentAudit[] = $value['msgstr'];
        }
        
        $mustTranslate = $this->totalTranslate($language);
        
        $currentUserAuditCount = 0;
        foreach ( $allTranslationList as $key => &$value ) {
            if ( $value['locale_id'] == $language && $value['message_domain'] == $queryLanguage ) {
                $messagekey = md5($value['message_key']);
                $translation_value = $value['message_translation'];
                $existsTranslation = array();
                
                if ( ! isset($translationList[$messagekey]) ) {
                    $translationList[$messagekey]['key'] = $value['message_key'];
                }
                
                if ( isset($translationList[$messagekey]['translation_value']) ) {
                    $existsTranslation = $translationList[$messagekey]['translation_value'];
                }
                
                if ( $currentUserAuditKey && in_array($messagekey, $currentUserAuditKey) ) {
                    $translationList[$messagekey]['hasAudit'] = true;
                    if ( $currentAudit && in_array($translation_value, $currentAudit) ) {
                        $value['chose'] = true;
                    }
                }
                
                $index = array_search($translation_value, $existsTranslation);
                if ( ! $existsTranslation || ($existsTranslation && $index === false) ) {
                    $translationList[$messagekey]['translation_value'][] = $translation_value;
                } else if ( $index !== false ) {
                    $translationList[$messagekey]['translations'][$index]['count'] += 1;
                    continue;
                }
                
                $value['count'] = 1;
                $translationList[$messagekey]['translations'][] = $value;
            }
        }
        
        $unTranslation = array_diff_key($mustTranslate, $translationList);
        
        return $unTranslation;
    }

    private function multiArraySort( $sortArray, $sort_key, $sort )
    {
        if ( is_array($sortArray) ) {
            foreach ( $sortArray as $row_array ) {
                if ( is_array($row_array) ) {
                    $key_array[] = $row_array[$sort_key];
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
        
        array_multisort($key_array, $sort, $sortArray);
        return $sortArray;
    }

    /**
     * 发布新语言
     *
     * @param string $current_language            
     * @param string $language            
     * @param number $loginUser            
     * @return boolean array
     */
    public function publishNewLanguage( $current_language, $language, $loginUser )
    {
        $allTranslationList = $this->getTranslationDbMapper()->getMessageList();
        if ( ! $allTranslationList ) {
            return false;
        }
        
        $user_id = $loginUser['user_id'];
        $translationList = array();
        $hasTranslate = 0;
        $allMustTranslate = 0;
        $mustTranslate = array();
        $auditList = array();
        $isAdmin = $loginUser['level'] == 1;
        
        $allAudit = $this->getAuditService()->getAllAudit($current_language, $language);
        $auditList = $this->auditList($allAudit);
        $auditFormat = array();
        foreach ( $auditList as $auditKey => &$auditData ) {
            $auditGroup = array();
            foreach ( $auditData['audits'] as $key => &$audit ) {
                $index = array_search($audit['msgstr'], $auditGroup);
                if ( ! $auditGroup || ($auditGroup && $index === false) ) {
                    $auditGroup[] = $audit['msgstr'];
                } else if ( $index !== false ) {
                    $auditFormat[$auditKey]['audits'][$index]['count'] = $auditFormat[$auditKey]['audits'][$index]['count'] + 1;
                    continue;
                }
                
                $audit['count'] = 1;
                $auditFormat[$auditKey]['audits'][] = $audit;
            }
        }
        
        $mustTranslate = $this->totalTranslate($current_language);
        $allMustTranslate = count($mustTranslate);
        foreach ( $allTranslationList as $key => &$value ) {
            if ( $value['locale_id'] == $current_language && $value['message_domain'] == $language ) {
                $messagekey = md5($value['message_key']);
                $translation_value = $value['message_translation'];
                $existsTranslation = isset($translationList[$messagekey]['translation_value']) ? $translationList[$messagekey]['translation_value'] : array();
                
                if ( ! isset($translationList[$messagekey]) ) {
                    $translationList[$messagekey]['key'] = $value['message_key'];
                }
                
                $index = array_search($translation_value, $existsTranslation);
                if ( ! $existsTranslation || ($existsTranslation && $index === false) ) {
                    $translationList[$messagekey]['translation_value'][] = $translation_value;
                } else if ( $index !== false ) {
                    $translationList[$messagekey]['translations'][$index]['count'] += 1;
                    continue;
                }
                
                $value['count'] = 1;
                $translationList[$messagekey]['translations'][] = $value;
            }
        }
        
        $config = $this->getServiceLocator()->get('config');
        $minimum_audit = $config['minimum_audit'];
        
        foreach ( $translationList as $key => &$translation ) {
            $hasAudit = isset($auditList[$key]['audits']) ? count($auditList[$key]['audits']) >= $minimum_audit : false;
            if ( $isAdmin && array_key_exists($key, $mustTranslate) && $hasAudit ) {
                ++ $hasTranslate;
            }
            
            if ( count($translation['translations']) > 1 ) {
                $translation['translations'] = $this->multiArraySort($translation['translations'], 'count', SORT_DESC);
            }
        }
        $auditTranslations = array();
        foreach ( $auditFormat as $auditKey => $auditValue ) {
            $translate = array();
            $auditInfo = array();
            
            if ( is_array($auditValue['audits']) && count($auditValue['audits']) > 1 ) {
                $countIndexList = array_map(function ( $var )
                {
                    return $var['count'];
                }, $auditValue['audits']);
                
                $max = max($countIndexList);
                $totalArray = array_count_values($countIndexList);
                if ( $totalArray[$max] == 1 ) {
                    $auditInfo = $auditValue['audits'][array_search($max, $countIndexList)];
                } else {
                    if ( isset($translationList[$auditKey]) ) {
                        $auditValues = array_map(function ( $var )
                        {
                            return $var['msgstr'];
                        }, $auditValue['audits']);
                        
                        $translate_values = array_map(function ( $var )
                        {
                            return $var['message_translation'];
                        }, $translationList[$auditKey]['translations']);
                        
                        $new = array_intersect($translate_values, $auditValues);
                        $auditedTranslateList = array();
                        foreach ( $new as $key => $value ) {
                            $auditedTranslateList[] = $translationList[$auditKey]['translations'][$key];
                        }
                        
                        $maxCount = array_filter($auditedTranslateList, function ( $var )
                        {
                            $max = 1;
                            if ( $var['count'] > $max ) {
                                return $var['message_translation'];
                            }
                        });
                        
                        $maxCount = current($maxCount);
                        $index = array_search($maxCount['message_translation'], $auditValues);
                        $auditInfo = $auditValue['audits'][$index];
                    }
                }
            } else if ( isset($auditValue['audits']) ) {
                $auditInfo = current($auditValue['audits']);
                $translate = array(
                    'locale_id' => $auditInfo['locale_id'],
                    'locale_id' => $auditInfo['to_translation_locale'],
                    'key' => $auditInfo['msgid'],
                    'translate' => $auditInfo['msgstr']
                );
            }
            
            $auditTranslations[] = $auditInfo;
        }
        
        if ( $hasTranslate / $allMustTranslate < 1 ) {
            return false;
        }
        
        $publishList = array_map(function ( $var )
        {
            $flag = array();
            $flag['from_locale_title'] = $var['locale_id'];
            $flag['to_locale_title'] = $var['to_translation_locale'];
            $flag['msgid'] = $var['msgid'];
            $flag['source_msgstr'] = $var['msgid'];
            $flag['to_msgstr'] = $var['msgstr'];
            return $flag;
        }, $auditTranslations);
        
        $prevVersionPublishList = $this->getTranslationDbMapper()->getPublishTranslationCache($current_language, $language);
        if ( $prevVersionPublishList ) {
            $prevTranslationValue = array_map(function ( $var )
            {
                return $var['to_msgstr'];
            }, $prevVersionPublishList);
            
            $currentPublishValue = array_map(function ( $var )
            {
                return $var['to_msgstr'];
            }, $publishList);
            $diffrent = array_diff($currentPublishValue, $prevTranslationValue);
            
            if ( ! $diffrent ) {
                return false;
            }
        }
        
        return $this->getTranslationDbMapper()->publishTranslation($publishList, $current_language, $language, $user_id);
    }

    /**
     * 获取需要翻译的内容
     *
     * @return boolean array
     */
    public function totalTranslate()
    {
        $list = $this->getBasicWordDbMapper()->getAll();
        if ( ! $list ) {
            return false;
        }
        $all = array();
        foreach ( $list as $basic ) {
            $all[md5(htmlspecialchars_decode($basic['msgid']))] = $basic;
        }
        return $all;
    }

    public function setI()
    {
        $list = $this->getBasicWordDbMapper()->getAll();
        if ( ! $list ) {
            return false;
        }
        
        $cacheTran = array();
        foreach ( $list as $key => $val ) {
            $cacheTran[$val['msgid']] = $val['msgid'];
        }
        $cacheId = 'Zend_I18n_Translator_Messages_' . md5('default' . 'en_US');
        if ( $this->cache()->hasItem($cacheId) ) {
            $this->cache()->removeItem($cacheId);
        }
        $this->cache()->addItem($cacheId, $cacheTran);
        return $list;
    }
    
    
    public function getBasicWords( $module='', $msgid = array() )
    {
        $words = $this->getBasicWordDbMapper()->getBasicWords($module, $msgid);
        if ( $words ) {
            foreach ( $words as $key => $word ) {
                $newWords[$word['art_key']][] = $word;
            }
        }
        return isset($newWords) ? $newWords : [];
    }
    
    public function updateText( $data, $where )
    {
        return $this->getBasicWordDbMapper()->updateText($data, $where);
    }
    

    /**
     *
     * @return the $auditService
     */
    private function getAuditService()
    {
        if ( null === $this->auditService ) {
            $this->setAuditService($this->getServiceLocator()
                ->get('auditService'));
        }
        return $this->auditService;
    }

    /**
     *
     * @return the $basicWordService
     */
    private function getBasicWordService()
    {
        if ( null === $this->basicWordService ) {
            $this->setBasicWordService($this->getServiceLocator()
                ->get('basicWordService'));
        }
        return $this->basicWordService;
    }

    /**
     *
     * @return the $localeService
     */
    private function getLocaleService()
    {
        if ( null === $this->localeService ) {
            $this->setLocaleService($this->getServiceLocator()
                ->get('localeService'));
        }
        return $this->localeService;
    }

    /**
     *
     * @return the $translationMapper
     */
    private function getTranslationMapper()
    {
        if ( ! $this->translationMapper ) {
            $this->translationMapper = $this->getServiceLocator()->get('transMapper');
        }
        return $this->translationMapper;
    }

    /**
     *
     * @param \Translation\Service\Audit $auditService            
     */
    private function setAuditService( $auditService )
    {
        $this->auditService = $auditService;
    }

    /**
     *
     * @param \Translation\Service\BasicWord $basicWordService            
     */
    private function setBasicWordService( $basicWordService )
    {
        $this->basicWordService = $basicWordService;
    }

    /**
     *
     * @param \Translation\Mapper\Locale $localeService            
     */
    private function setLocaleService( $localeService )
    {
        $this->localeService = $localeService;
    }
}