<?php
namespace Translation\Service;

use Translation\Service\ModuleBaseService;

class Locale extends ModuleBaseService
{

    public function getMessageList()
    {
        return $this->getTranslationDbMapper()->getMessageList();
    }

    public function countMessageList()
    {
        return $this->getTranslationDbMapper()->countMessageList();
    }

    public function translationSave($message)
    {
        return $this->getTranslationDbMapper()->translationSave($message);
    }

    public function translationLoad($tid)
    {
        return $this->getTranslationDbMapper()->translationLoad($tid);
    }

    public function batchTranslationSave($messageSet)
    {
        return $this->getTranslationDbMapper()->batchTranslationSave($messageSet);
    }

    public function getTranslationRecord($message)
    {
        return $this->getTranslationDbMapper()->getTranslationRecord($message);
    }

    public function localeLoad($localeId)
    {
        return $this->getTranslationDbMapper()->localeLoad($localeId);
    }

    public function translationLoadByColumns($message)
    {
        return $this->getTranslationDbMapper()->translationLoadByColumns($message);
    }

    public function groupMessageDomain($language)
    {
        return $this->getTranslationDbMapper()->groupMessageDomain($language);
    }
}

