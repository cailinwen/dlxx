<?php
namespace Translation\Service;

use Core\Service\AbstractService;
use Translation\Common\TranslationModuleCacheTrait;

class ModuleBaseService extends AbstractService
{
    
    use TranslationModuleCacheTrait;

    /**
     *
     * @var \Translation\Mapper\LocaleDbMapper
     */
    private $localeDbMapper;

    /**
     *
     * @var \Translation\Mapper\TranslationDbMapper
     */
    private $translationDbMapper;

    /**
     *
     * @var \Translation\Mapper\AuditDbMapper
     */
    private $auditDbMapper;

    /**
     *
     * @var \Translation\Mapper\BasicWordDbMapper
     */
    private $basicWordDbMapper;

    /**
     *
     * @var \Translation\Mapper\Country
     */
    private $countryDbMapper;

    /**
     *
     * @return the $countryDbMapper
     */
    protected function getCountryDbMapper()
    {
        if ( ! $this->countryDbMapper ) {
            $this->countryDbMapper = $this->getServiceLocator()->get('countryDbMapper');
        }
        return $this->countryDbMapper;
    }

    /**
     *
     * @return the $basicWordDbMapper
     */
    protected function getBasicWordDbMapper()
    {
        if ( ! $this->basicWordDbMapper ) {
            $this->basicWordDbMapper = $this->getServiceLocator()->get('basicWordDbMapper');
        }
        return $this->basicWordDbMapper;
    }

    /**
     *
     * @return the $auditDbMapper
     */
    protected function getAuditDbMapper()
    {
        if ( ! $this->auditDbMapper ) {
            $this->auditDbMapper = $this->getServiceLocator()->get('auditDbMapper');
        }
        return $this->auditDbMapper;
    }

    /**
     *
     * @return the $translationDbMapper
     */
    protected function getTranslationDbMapper()
    {
        if ( ! $this->translationDbMapper ) {
            $this->translationDbMapper = $this->getServiceLocator()->get('translationDbMapper');
        }
        return $this->translationDbMapper;
    }

    /**
     *
     * @return the $localeDbMapper
     */
    protected function getLocaleDbMapper()
    {
        if ( ! $this->localeDbMapper ) {
            $this->localeDbMapper = $this->getServiceLocator()->get('localeDbMapper');
        }
        return $this->localeDbMapper;
    }
}