<?php
namespace Translation\Service;

use Core\Service\AbstractService;

class BasicWord extends ModuleBaseService
{

    /**
     * 添加翻译内容
     *
     * @param string $key            
     * @param number $invisable            
     * @return boolean
     */
    public function add($key, $invisable = 0)
    {
        if ( empty($key) ) {
            return false;
        }
        return $this->getBasicWordDbMapper()->add($key, self::getSessionUserId(), $invisable);
    }

    public function clearCache()
    {
        $cacheBasicWord = 'translation:translationKey:basicWords';
        $this->cache()->removeItem($cacheBasicWord);
    }

    /**
     * 获取所有翻译内容
     *
     * @return boolean array
     */
    public function getAll()
    {
        return $this->getBasicWordDbMapper()->getAll();
    }
}

