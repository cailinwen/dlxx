<?php
namespace Translation\Controller;

use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;

class TranslationController extends ModuleBaseController
{

    const TRANSLATION_LIMIT = 5;

    public function auditAction()
    {
        $original = $this->params()->fromPost('trans_key');
        $chose = $this->params()->fromPost('trans_message');
        $accept = $this->params()->fromPost('accept');
        
        $current_language = self::$language;
        $target_locale = $this->params()->fromPost('target_locale');
        
        $auditService = $this->getAuditService();
        $auditData = array(
            'locale_id' => $current_language,
            'to_translation_locale' => $target_locale,
            'user_id' => $this->loginUser['user_id'],
            'msgid' => htmlspecialchars_decode($original)
        );
        
        if ( $accept ) {
            $auditData['msgstr'] = $chose;
        }
        
        $result = $auditService->saveAudit($auditData);
        $responseData = array(
            'status' => $auditData ? 1 : 0,
            'data' => array(
                'key' => md5($original),
                'accept' => $accept
            )
        );
        
        return new JsonModel($responseData);
    }

    private function isAdmin()
    {
        return $this->loginUser['level'] == 1;
    }

    public function setDefaultDomainTranslationAction()
    {
        $default = 'en_US';
        $list = $this->getTranslationService()->getAllTranslationKey($default);
        $key = 'Zend_I18n_Translator_Messages_';
        
        $cacheTran = array();
        foreach ( $list as $tran ) {
            $cacheTran[$tran['msgid']] = $tran['msgid'];
        }
        
        $cacheId = $key . md5('default' . 'en_US');
        if ( $this->cache()->hasItem($cacheId) ) {
            $this->cache()->removeItem($cacheId);
        }
        $this->cache()->addItem($cacheId, $cacheTran);
        die('set default domain translation success');
    }

    public function indexAction()
    {
        $user_id = $this->loginUser['user_id'];
        $this->layout('translation/layout');
        $this->headLink()->appendStylesheet('/css/common/base.css');
        $this->headLink()->appendStylesheet('/css/vendor/jquery.mCustomScrollbar.css');
        $this->headLink()->appendStylesheet('/css/vendor/facebox.css');
        $this->headLink()->appendStylesheet('/css/admin/admin.css');
        $this->requireJs()->loadRequiredFiles('JqueryFacebox');
        $this->requireJs()->loadRequiredFiles('TranslationReview');
        $this->requireJs()->loadRequiredFiles('Translation');
        $this->requireJs()->loadRequiredFiles('Header');
        
        $this->layout()->module = 'translation';
        
        $current_language = self::$language;
        $translationService = $this->getTranslationService();
        
        $translateTargetLanguages = $translationService->groupMessageDomain($current_language);
        
        if ( $translateTargetLanguages ) {
            $this->layout()->sort = $sort = $translationService->groupLauguage($translateTargetLanguages);
            $allTranslationLangage = array_map(function ($var)
            {
                if ( array_key_exists('unique_title', $var) ) {
                    return $var['unique_title'];
                }
            }, $translateTargetLanguages);
            $defaultTranslation = $translateTargetLanguages[array_search($this->defTransToLocale, $allTranslationLangage)];
            $translateList = $translationService->loadTranslation($current_language, $defaultTranslation['unique_title'], $user_id, $this->isAdmin());
        } else {
            $defaultTranslation = array();
            $translateList = array();
        }
        $this->layout()->defaultTranslation = $defaultTranslation;
        $this->layout()->showPublishLanguage = $this->loginUser['level'] == 1;
        $this->layout()->hasTranslate = isset($translateList['hasTranslationTotal']) ? $translateList['hasTranslationTotal'] : '';
        $this->layout()->allTranslate = isset($translateList['allTranslationKeyTotal']) ? $translateList['allTranslationKeyTotal'] : '';
        $this->layout()->defaultTrans = isset($defaultTranslation['unique_title']) ? $defaultTranslation['unique_title'] : '';
        if ( $this->isAdmin() ) {
            $this->layout()->percent = isset($translateList['percent']) ? $translateList['percent'] : '';
        }
        
        $this->layout()->limit = self::TRANSLATION_LIMIT;
        $this->layout()->unCheckTranslate = isset($translateList['not_audit']) ? $translateList['not_audit'] : '';
        
        $this->javascript()->addSettings(array(
            'current_language' => $current_language,
            'default_language' => isset($defaultTranslation['unique_title']) ? $defaultTranslation['unique_title'] : ''
        ));
        
        return array(
            'translationList' => isset($translateList['translationList']) ? $translateList['translationList'] : '',
            'hasTranslate' => isset($translateList['hasTranslationTotal']) ? $translateList['hasTranslationTotal'] : '',
            'allTranslate' => isset($translateList['allTranslationKeyTotal']) ? $translateList['allTranslationKeyTotal'] : '',
            'unCheckTranslate' => isset($translateList['not_audit']) ? $translateList['not_audit'] : '',
            'limit' => self::TRANSLATION_LIMIT,
            'defaultTranslation' => $defaultTranslation
        );
    }

    public function getUntranslateKeyAction()
    {
        $langauge = self::$language;
        $queryLanguage = $this->params()->fromQuery('language');
        $user_id = $this->loginUser['user_id'];
        $unTranslateKeys = $this->getTranslationService()->getUnTranslationKey($langauge, $queryLanguage, $user_id, $this->isAdmin());
        
        zp_dump($unTranslateKeys);
        die();
    }

    public function clearcacheAction()
    {
        $cacheBasicWord = 'translation:translationKey:basicWords';
        $this->cache()->removeItem($cacheBasicWord);
        $this->cache()->removeItem('translation:translationPublish:from:' . self::$language . ':to:' . $this->defTransToLocale);
        return new JsonModel(array(
            'status' => 1
        ));
    }

    public function loadTransationAction()
    {
        $messageDomain = $this->params()->fromPost('language');
        $currentLanguage = self::$language;
        $user_id = $this->loginUser['user_id'];
        $translateList = $this->getTranslationService()->loadTranslation($currentLanguage, $messageDomain, $user_id, $this->isAdmin());
        $dataHtml = $this->getView('translation/translation/index.phtml', array(
            'translationList' => $translateList['translationList'],
            'limit' => self::TRANSLATION_LIMIT,
            'hasTranslate' => $translateList['hasTranslationTotal'],
            'allTranslate' => $translateList['allTranslationKeyTotal'],
            'unCheckTranslate' => $translateList['not_audit']
        ));
        $result = array(
            'status' => 1,
            'data' => array(
                'dataHtml' => $dataHtml,
                'hasTrans' => $translateList['hasTranslationTotal'],
                'all' => $translateList['allTranslationKeyTotal'],
                'uncheck' => $translateList['not_audit'],
                'percent' => $translateList['percent']
            )
        );
        return new JsonModel($result);
    }

    
    
   
    
   public function setEnUSCacheAction(){
       $translationService = $this->getTranslationService();
       $translationService->setI();//设置英文缓存
       return self::createJsonView(1);
   }
   
    
    
    public function publishAction()
    {
        $current_language = self::$language;
        $language = $this->params()->fromPost('language');
        
        $language = 'zh_CN';
        $translationService = $this->getTranslationService();
        
        $translationService->setI();//设置英文缓存
        
        
        $result = $translationService->publishNewLanguage($current_language, $language, $this->loginUser);
        if ( ! $result || isset($result['error']) ) {
            return new JsonModel(array(
                'status' => 0
            ));
        }
        
        return new JsonModel(array(
            'status' => 1
        ));
    }

    public function addWordsAction()
    {
        $str = $this->getRequest()
            ->getPost()
            ->toString();
        if ( ! empty($str) ) {
            $basicW = $this->getServiceLocator()->get('basicWordService');
            $msgid = $this->getParam('msgid');
            $inviable = $this->getParam('invisable');
            if ( empty($msgid) ) {
                echo "<script>alert('亲！msgid 不能为空！');</script>";
            } else {
                $r = $basicW->add($msgid, $inviable);
                if ( ! $r ) {
                    echo "<script>alert('亲！你提交的内容重复或失败');</script>";
                } else {
                    echo "<script>alert('亲！你提交的内容成功！ {$r}');</script>";
                }
            }
            echo "<script>window.location.href='/translation/add-words';</script>";
        }
        $view = new ViewModel();
        $view->setTerminal(true);
        return $view;
    }
    public function checkWordAction(){
        
        $user_id = $this->loginUser['user_id'];
        $this->layout('translation/layout');
        $this->headLink()->appendStylesheet('/css/common/base.css');
        $this->headLink()->appendStylesheet('/css/vendor/jquery.mCustomScrollbar.css');
        $this->headLink()->appendStylesheet('/css/vendor/facebox.css');
        $this->headLink()->appendStylesheet('/css/admin/admin.css');
        $this->requireJs()->loadRequiredFiles('JqueryFacebox');
        $this->requireJs()->loadRequiredFiles('TranslationReview');
        $this->requireJs()->loadRequiredFiles('Translation');
        $this->requireJs()->loadRequiredFiles('Header');
        $this->layout()->module = 'checkword';
        $words = $this->getTranslationService()->getBasicWords('settings');
//         zp_dump($words);
        return array('words'=>$words,
            'limit' => self::TRANSLATION_LIMIT,
        );
        
    }
    public function updateCheckStatusAction(){
        $art_key=$this->getParam('artkey');
        $check_status=$this->getParam('check_status');     
        if(empty($art_key)){
            return new JsonModel(
                array(
                    'status' => 0,
                    'data' => ''
                ));
            
        }
        $data=array('is_check'=>$check_status);
        $where=array('art_key'=>$art_key);
       $result= $this->getTranslationService()->updateText($data, $where);
       if($result){
            return new JsonModel(
                array(
                    'status' => 1,
                    'data' => ''
                ));
       }else {
           return new JsonModel(
               array(
                   'status' => 0,
                   'data' => ''
               ));
           
       }
    }
}