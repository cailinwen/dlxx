<?php
namespace Translation\Controller;

use Core\Controller\AbstractBaseCoreController;

class ModuleBaseController extends AbstractBaseCoreController
{

    protected $defTransToLocale = 'zh_CN';

    protected $allowAdminUser = array(
        1,
        2,
        5
    );

    public function preDispatch()
    {
        parent::preDisPatch();
        $this->checkLoginAndXmlRequest($this->loginUser);
        if ( ! in_array($this->loginUser['level'], $this->allowAdminUser) ) {
            exit('You do not have permission to access the translation module.');
        }
    }

    /**
     *
     * @var \Translation\Service\TranslationService
     */
    private $translationService;

    /**
     *
     * @var \Translation\Service\Audit
     */
    private $auditService;

    /**
     *
     * @return the $auditService
     */
    protected function getAuditService()
    {
        if ( ! $this->auditService ) {
            $this->auditService = $this->getServiceLocator()->get('auditService');
        }
        return $this->auditService;
    }

    /**
     *
     * @return the $translationService
     */
    protected function getTranslationService()
    {
        if ( ! $this->translationService ) {
            $this->translationService = $this->getServiceLocator()->get('transService');
        }
        return $this->translationService;
    }
}