<?php
namespace Translation\Event;

use Core\Event\AbstractEvent;
class languageEvent extends AbstractEvent
{

    /**
     * 
     * @var \Translation\Service\Country
     */
    protected $countryService;

    public function getCountryService()
    {
        if ( ! $this->countryService ) {
            $this->countryService = $this->getServiceLocator()->get('countryService');
        }
        return $this->countryService;
    }

    public function languageLoadPost($e)
    {
        $target = $e->getTarget();
        $language = $e->getParam('language');
        $eventArgs = $e->getParam('eventArgs');
        $countryLanguge = (array) $this->getCountryService()->countryLanguageLoad($language['unique_title']);
        if ( ! isset($eventArgs['isLoadCountry']) || $eventArgs['isLoadCountry'] ) {
            if ( $countryLanguge ) {
                $language['country'] = $countryLanguge['country'];
                $language['isAvailable'] = true;
            } else {
                $language['isAvailable'] = false;
            }
        }
    }
}