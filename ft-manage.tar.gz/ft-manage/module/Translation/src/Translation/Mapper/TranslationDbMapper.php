<?php
namespace Translation\Mapper;

use Zend\Db\Adapter\Adapter;
use Zend\Db\Sql\Select;

class TranslationDbMapper extends TranslationModuleBaseMapper
{

    const Zend_I18n_Translator_Messages_Prefix = 'Zend_I18n_Translator_Messages_';

    /**
     *
     * @param array $allTranslation
     *            所有翻译内容
     * @param string $language
     *            基础语言
     * @param string $trans_language
     *            发布语言
     * @param number $user_id
     *            发布者
     * @return boolean array
     */
    public function publishTranslation($allTranslation, $language, $trans_language, $user_id)
    {
        $cacheId = 'translation:translationPublish:from:' . $language . ':to:' . $trans_language;
        if ( $this->cache()->hasItem($cacheId) ) {
            $this->cache()->removeItem($cacheId);
        }
        $this->cache()->addItem($cacheId, $allTranslation);
        $result = $this->saveTranslation($language, $trans_language, $user_id);
        if ( isset($result['error']) ) {
            return false;
        } else {
            return $result;
        }
    }

    public function getPublishTranslationCache($language, $trans_language)
    {
        $cacheId = 'translation:translationPublish:from:' . $language . ':to:' . $trans_language;
        if ( $this->cache()->hasItem($cacheId) ) {
            return $this->cache()->getItem($cacheId);
        } else {
            return false;
        }
    }

    public function saveTranslation($language, $trans_language, $user_id)
    {
        $version = $this->getTranslationVersion($trans_language, $language);
        $set_version = '';
        if ( ! $version ) {
            $set_version = 1.0;
        } else {
            $set_version = number_format($version + 0.1, 1);
        }
        
        $result = $this->saveTranslationResult($language, $trans_language, $user_id, $set_version);
        try {
            if ( $result ) {
                $createVersion = array(
                    'from_locale_title' => $language,
                    'to_locale_title' => $trans_language,
                    'current_valid_version' => $set_version,
                    'created' => time()
                );
                
                if ( $version ) {
                    $createVersion['previous_version'] = $version;
                }
                $tv_id = $this->addTranslationVersion($createVersion);
                if ( $language == 'en_US' ) {
                    $updateInfo = array(
                        'resource_id' => $tv_id
                    );
                    if ( $set_version == '1.0' ) {
                        $updateInfo['is_publish'] = 1;
                    }
                    $this->updateInfo($updateInfo, $trans_language);
                }
            }
        } catch ( \Exception $e ) {
            throw new \Exception($e->getMessage());
        }
        
        return $result;
    }

    public function updateInfo($data, $language)
    {
        $this->clearAllLanguageCache();
        return $this->setTableGateway('ft_languages')->update($data, array(
            'unique_title' => $language
        ));
    }

    /**
     * 清除所有语言的缓存
     */
    public function clearAllLanguageCache()
    {
        $languageList = $this->getLanguageList();
        
        foreach ( $languageList as $key => $value ) {
            $this->clearLanguageCache($value['l_id']);
        }
    }

    /**
     * 清除指定ID的语言缓存
     *
     * @param 语言ID $lid            
     */
    public function clearLanguageCache($lid)
    {
        $langCid = 'languages:id:' . $lid;
        $this->cache()->removeItem($langCid);
    }

    private function addTranslationVersion($data)
    {
        $tableGateway = $this->setTableGateway('ft_translation_version_record');
        if ( $tableGateway->insert($data) ) {
            return $tableGateway->getLastInsertValue();
        } else {
            return false;
        }
    }

    private function saveTranslationResult($language, $trans_language, $user_id, $version)
    {
        $cacheId = 'translation:translationPublish:from:' . $language . ':to:' . $trans_language;
        $translations = $this->cache()->getItem($cacheId);
        if ( ! $translations ) {
            return false;
        }
        $conn = $this->getDbAdapter()
            ->getDriver()
            ->getConnection();
        $conn->beginTransaction();
        try {
            foreach ( $translations as &$translation ) {
                $translation['handler'] = $user_id;
                $translation['created'] = time();
                $translation['versions'] = $version;
                $result = $this->addTranslationResult($translation);
                if ( ! $result ) {
                    $conn->rollBack();
                    return false;
                }
            }
            
            $this->cacheTranslator($translations, $trans_language);
        } catch ( \Exception $e ) {
            $conn->rollBack();
            return $e->getMessage();
        }
        
        $conn->commit();
        return true;
    }

    public function cacheTranslator($trans, $trans_language, $textDomain = 'default')
    {
        $cacheTran = array();
        foreach ( $trans as $tran ) {
            $cacheTran[$tran['msgid']] = $tran['to_msgstr'];
        }
        
        $cacheId = self::Zend_I18n_Translator_Messages_Prefix . md5($textDomain . $trans_language);
        if ( $this->cache()->hasItem($cacheId) ) {
            $this->cache()->removeItem($cacheId);
        }
        $this->cache()->addItem($cacheId, $cacheTran);
    }

    private function addTranslationResult($data)
    {
        return $this->setTableGateway('ft_translation_results')->insert($data);
    }

    private function getTranslationVersion($trans_language, $language)
    {
        $version = $this->setTableGateway('ft_translation_version_record')
            ->select(function (Select $select) use($trans_language, $language)
        {
            $select->columns(array(
                'current_valid_version'
            ));
            
            $select->where->equalTo('from_locale_title', $language)
                ->equalTo('to_locale_title', $trans_language);
            
            $select->order('current_valid_version DESC')
                ->limit(1);
        })
            ->current();
        return $version ? $version['current_valid_version'] : false;
    }

    /**
     * 根据语言ID获取语言
     */
    public function languageLoad($lid, $eventArgs = array())
    {
        $langCid = 'languages:id:' . $lid;
        if ( ! $this->cache()->hasItem($langCid) ) {
            $sql = $this->getSql()->setTable('ft_languages');
            $sqlObject = $sql->select();
            $sqlObject->where->equalTo('l_id', $lid);
            $queryStr = $sql->getSqlStringForSqlObject($sqlObject);
            $language = $this->getDbAdapter()
                ->query($queryStr, Adapter::QUERY_MODE_EXECUTE)
                ->current();
            if ( empty($language) ) {
                return false;
            }
            $this->getEventManager()->trigger('languageLoad.post', $this, compact('language', 'eventArgs'));
            $this->cache()->setItem($langCid, $language);
        } else {
            $language = $this->cache()->getItem($langCid);
        }
        return $language;
    }

    /**
     * 获取所有语言的列表
     */
    public function getLanguageList($eventArgs = array())
    {
        $langListCid = 'languages:languageList:languageList';
        if ( ! $this->cache()->hasItem($langListCid) ) {
            $sql = $this->getSql()->setTable('ft_languages');
            $sqlObject = $sql->select();
            $sqlObject->columns(array(
                'l_id'
            ));
            $sqlObject->where->notEqualTo('pid', 0)->notEqualTo('status', 0);
            $sqlObject->order('language_name ASC');
            $queryStr = $sql->getSqlStringForSqlObject($sqlObject);
            $result = $this->getDbAdapter()
                ->query($queryStr, Adapter::QUERY_MODE_EXECUTE)
                ->toArray();
            if ( ! $result ) {
                return false;
            }
            foreach ( $result as $key => $value ) {
                $language = $this->languageLoad($value['l_id']);
                if ( $language['isAvailable'] ) {
                    $result[$key] = $language;
                } else {
                    unset($result[$key]);
                }
            }
            $this->cache()->setItem($langListCid, $result);
        } else {
            $result = $this->cache()->getItem($langListCid);
        }
        return $result;
    }

    /**
     * 获取翻译的文本列表
     *
     * @return mixed
     */
    public function getMessageList()
    {
        $sqlObj = $this->getSql()->setTable(array(
            't' => 'ft_translation_messages'
        ));
        $select = $sqlObj->select();
        $select->join(array(
            'l' => 'ft_translation_locales'
        ), 't.locale_id=l.locale_id', array(
            'locale_plural_forms',
            'name'
        ), $select::JOIN_LEFT);
        return $this->getDbAdapter()
            ->query($sqlObj->getSqlStringForSqlObject($select), Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
    }

    /**
     *
     * @param string $titles            
     * @param array $eventArgs            
     * @return bool array
     */
    public function languageLoadByTitle($title, $eventArgs = array())
    {
        $langCid = 'language:unique_title:' . $title;
        if ( $this->cache()->hasItem($langCid) ) {
            return $this->cache()->getItem($langCid);
        }
        $sql = $this->getSql()->setTable('ft_languages');
        $sqlObject = $sql->select();
        $sqlObject->where->equalTo('unique_title', $title);
        $sqlObject->limit(1);
        $queryStr = $sql->getSqlStringForSqlObject($sqlObject);
        $language = $this->fetchOneRow($sqlObject, $sql);
        if ( empty($language) ) {
            return false;
        }
        $this->getEventManager()->trigger('languageLoad.post', $this, compact('language', 'eventArgs'));
        $this->cache()->setItem($langCid, $language);
        return $language;
    }

    public function languageLoadByTitles($titles, $eventArgs = array())
    {
        // $langCid = 'language:multi_title:' . join('_', $titles);
        // if ( $this->cache()->hasItem($langCid) ) {
        // return $this->cache()->getItem($langCid);
        // }
        $sql = $this->getSql()->setTable('ft_languages');
        $sqlObject = $sql->select();
        $sqlObject->where->in('unique_title', $titles);
        $queryStr = $sql->getSqlStringForSqlObject($sqlObject);
        $language = $this->fetchAll($sqlObject, $sql);
        if ( empty($language) ) {
            return false;
        }
        // $this->getEventManager()->trigger('languageLoad.post', $this,
        // compact('language', 'eventArgs'));
        // $this->cache()->setItem($langCid, $language);
        return $language;
    }

    public function getTopLanguageGroup()
    {
        $languageGroup = 'languages:languagegroup:languagegroup';
        if ( ! $this->cache()->hasItem($languageGroup) ) {
            $sql = $this->getSql()->setTable('ft_languages');
            $sqlObject = $sql->select();
            $sqlObject->columns(array(
                '*'
            ));
            $sqlObject->where->equalTo('pid', 0);
            $queryStr = $sql->getSqlStringForSqlObject($sqlObject);
            $result = $this->getDbAdapter()
                ->query($queryStr, Adapter::QUERY_MODE_EXECUTE)
                ->toArray();
            $this->cache()->setItem($languageGroup, $result);
            return $result;
        } else {
            return $this->cache()->getItem($languageGroup);
        }
    }
}