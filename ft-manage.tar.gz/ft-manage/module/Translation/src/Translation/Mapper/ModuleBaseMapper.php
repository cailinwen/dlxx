<?php
namespace Translation\Mapper;

use Core\Mapper\AbstractMapper;
use Translation\Common\TranslationModuleCacheTrait;

class ModuleBaseMapper extends AbstractMapper
{
    use TranslationModuleCacheTrait;
}
