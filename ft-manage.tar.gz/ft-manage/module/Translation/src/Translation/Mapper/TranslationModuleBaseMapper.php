<?php
namespace Translation\Mapper;

use Core\DbMapper\AbstractDbMapper;

class TranslationModuleBaseMapper extends AbstractDbMapper
{
}