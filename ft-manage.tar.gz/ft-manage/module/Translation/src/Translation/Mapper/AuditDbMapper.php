<?php
namespace Translation\Mapper;

use Zend\Db\Sql\Select;
use Zend\Db\Adapter\Adapter;

class AuditDbMapper extends TranslationModuleBaseMapper
{

    public function saveAudit($data)
    {
        return $this->setTableGateway('ft_translation_audit_record')->insert($data);
    }

    public function clearAuditCache($cacheId)
    {
        $this->cache()->removeItem($cacheId);
    }

    public function deleteAudit($where)
    {
        return $this->setTableGateway('ft_translation_audit_record')->delete($where);
    }

    public function discardAudit($where)
    {
        return $this->setTableGateway('ft_translation_audit_record')->update(array(
            'status' => 0
        ), $where);
    }

    public function getAllAuditList($locale_id, $target_locale_id)
    {
        $cacheId = 'translation:audit:' . $locale_id . ':' . $target_locale_id;
        if ( ! $this->cache()->hasItem($cacheId) ) {
            $result = $this->setTableGateway('ft_translation_audit_record')
                ->select(function (Select $select) use($locale_id, $target_locale_id)
            {
                $select->where->equalTo('locale_id', $locale_id)
                    ->equalTo('status', 1)
                    ->equalTo('to_translation_locale', $target_locale_id);
            })
                ->toArray();
            $this->cache()->setItem($cacheId, $result);
        } else {
            $result = $this->cache()->getItem($cacheId);
        }
        return $result;
    }

    /**
     * 翻译审核管理员对翻译词的审核记录
     *
     * @param number $user_id            
     * @param string $locale_id            
     * @param string $target_locale_id            
     * @return array
     */
    public function getAuditList($user_id, $locale_id, $target_locale_id)
    {
        $cacheId = 'translation:audit:' . $user_id . ':' . $locale_id . ':' . $target_locale_id;
        if ( ! $this->cache()->hasItem($cacheId) ) {
            $sql = $this->getSql()->setTable('ft_translation_audit_record');
            $select = $sql->select();
            $select->where->equalTo('user_id', $user_id)
                ->equalTo('locale_id', $locale_id)
                ->equalTo('status', 1)
                ->equalTo('to_translation_locale', $target_locale_id);
            $result = $this->getDbAdapter()
                ->query($sql->getSqlStringForSqlObject($select), Adapter::QUERY_MODE_EXECUTE)
                ->toArray();
            $this->cache()->setItem($cacheId, $result);
        } else {
            $result = $this->cache()->getItem($cacheId);
        }
        return $result;
    }
}