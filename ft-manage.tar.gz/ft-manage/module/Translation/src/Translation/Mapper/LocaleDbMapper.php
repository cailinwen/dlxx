<?php
namespace Translation\Mapper;

use Zend\Db\Adapter\Adapter;

class LocaleDbMapper extends TranslationModuleBaseMapper
{

    /**
     * 根据语言标识获取翻译文本的语言标识的分组
     *
     * @param array $language            
     * @return unknown
     */
    public function groupMessageDomain($language)
    {
        $sqlObj = $this->getSql()->setTable('ft_translation_messages');
        $select = $sqlObj->select();
        $select->columns(array(
            'message_domain'
        ));
        $select->where(array(
            'locale_id' => $language
        ));
        $select->group('message_domain');
        $result = $this->getDbAdapter()
            ->query($sqlObj->getSqlStringForSqlObject($select), Adapter::QUERY_MODE_EXECUTE)
            ->toArray();
        return $result;
    }
}