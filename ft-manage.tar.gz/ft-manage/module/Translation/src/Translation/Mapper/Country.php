<?php
namespace Translation\Mapper;

use Zend\Db\Adapter\Adapter;
use Core\Mapper\AbstractDbMapper;
use Zend\Db\Sql\Select;

class Country extends TranslationModuleBaseMapper
{

    /**
     * 根据国家ID获取国家信息
     *
     * @param unknown $cid            
     * @param unknown $eventArgs            
     * @return array
     */
    public function countryLoad($cid, $eventArgs = array())
    {
        $countryCid = 'country:' . md5($cid);
        $cache = $this->cache();
        if ( ! $cache->hasItem($countryCid) ) {
            $sql = $this->getSql()->setTable('ft_country');
            $sqlObject = $sql->select();
            $sqlObject->where->equalTo('country_id', $cid);
            $queryStr = $sql->getSqlStringForSqlObject($sqlObject);
            $country = $this->getDbAdapter()
                ->query($queryStr, Adapter::QUERY_MODE_EXECUTE)
                ->current();
            $cache->setItem($countryCid, serialize($country));
        } else {
            $country = unserialize($cache->getItem($countryCid));
        }
        return $country;
    }

    public function findCountryByISO2($iso2)
    {
        $cacheKey = 'country:iso:' . $iso2;
        if ( ! $this->cache()->hasItem($cacheKey) ) {
            $country = $this->setTableGateway('ft_country')
                ->select(function (Select $select) use($iso2)
            {
                $select->where->equalTo('iso2', $iso2);
            })
                ->toArray();
            
            if ( ! $country ) {
                return false;
            }
            
            $country = current($country);
            $this->cache()->addItem($cacheKey, serialize($country));
            return $country;
        } else {
            return unserialize($this->cache()->getItem($cacheKey));
        }
    }

    /**
     * 根据语言标识关联国家信息
     */
    public function countryLanguageLoad($localeId, $eventArgs = array())
    {
        $countryLangCid = 'countryLanguage:' . md5($localeId);
        $cache = $this->cache();
        if ( ! $cache->hasItem($countryLangCid) ) {
            $sql = $this->getSql()->setTable('ft_country_language');
            $sqlObject = $sql->select();
            $sqlObject->where->equalTo('locale_id', $localeId);
            $queryStr = $sql->getSqlStringForSqlObject($sqlObject);
            $countryLanguage = $this->getDbAdapter()
                ->query($queryStr, Adapter::QUERY_MODE_EXECUTE)
                ->current();
            $countryLanguage['country'] = $this->countryLoad($countryLanguage['country_id']);
            $cache->setItem($countryLangCid, serialize($countryLanguage));
        } else {
            $countryLanguage = unserialize($cache->getItem($countryLangCid));
        }
        return $countryLanguage;
    }

    public function province()
    {
        $provinceCache = 'country:china:province';
        $cache = $this->cache();
        if ( ! $cache->hasItem($provinceCache) ) {
            $result = $this->setTableGateway('ft_position_province')
                ->select()
                ->toArray();
            $cache->setItem($provinceCache, serialize($result));
            return $result;
        } else {
            return unserialize($cache->getItem($provinceCache));
        }
    }

    public function city()
    {
        $cityCache = 'country:china:city';
        $cache = $this->cache();
        if ( ! $cache->hasItem($cityCache) ) {
            $result = $this->setTableGateway('ft_position_city')
                ->select()
                ->toArray();
            $cache->setItem($cityCache, serialize($result));
            return $result;
        } else {
            return unserialize($cache->getItem($cityCache));
        }
    }

    public function district()
    {
        $countyCache = 'country:china:county';
        $cache = $this->cache();
        if ( ! $cache->hasItem($countyCache) ) {
            $result = $this->setTableGateway('ft_position_county')
                ->select()
                ->toArray();
            $cache->setItem($countyCache, serialize($result));
            return $result;
        } else {
            return unserialize($cache->getItem($countyCache));
        }
    }
}