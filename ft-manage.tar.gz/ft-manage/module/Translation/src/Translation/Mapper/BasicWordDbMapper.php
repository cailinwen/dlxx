<?php
namespace Translation\Mapper;

use Zend\Db\Sql\Select;

class BasicWordDbMapper extends TranslationModuleBaseMapper
{
    protected static $basicWordsCacheKey = 'translation:translationKey:basicWords';

    public function add($msgid, $user_id, $invisable = 0)
    {
        if ( $this->existsKey($msgid) ) {
            return false;
        }
        $data = array(
            'msgid' => $msgid,
            'def_msgstr' => $msgid,
            'invisable' => $invisable,
            'created' => $_SERVER['REQUEST_TIME'],
            'user_id' => $user_id
        );
        $result = $this->dbInsert('ft_translation_all_basic_words', $data);
        if ( $result ) {
            $cacheKey = 'translation:translationKey:basicWords';
            $this->cache()->removeItem($cacheKey);
        }
        return $result;
    }

    public function existsKey($key)
    {
        return $this->setTableGateway('ft_translation_all_basic_words')
            ->select(function (Select $select) use($key)
        {
            $select->where->equalTo('msgid', $key);
        })
            ->current();
    }

    public function getAll()
    {
        $cacheKey = 'translation:translationKey:basicWords';
        if ( ! $this->cache()->hasItem($cacheKey) ) {
            $reuslt = $this->setTableGateway('ft_translation_all_basic_words')
                ->select(function (Select $select)
            {
                $select->columns(array(
                    'msgid',
                    'invisable'
                ));
                $select->where->equalTo('status', 1);
            })
                ->toArray();
            $this->cache()->setItem($cacheKey, $reuslt);
        } else {
            $reuslt = $this->cache()->getItem($cacheKey);
        }
        return $reuslt;
    }
    
    public function getBasicWords( $module='', $msgid = array() )
    {
        $sql = $this->getSql()->setTable(array(
            'a' => 'ft_translation_all_basic_words'
        ));
    
        $select = $sql->select();
        $select->join(array(
            't' => 'ft_static_text_template'
        ), 'a.template_id=t.template_id', array(
            'template'
        ), $select::JOIN_LEFT);
        if ($module){
            $select->where->equalTo('a.module', $module);
        }
        $select->where->equalTo('a.status', 1);
        if ( $msgid ) {
            $select->where->in('a.msgid', $msgid);
        }
        $select->order('a.sort desc');
        //         echo $sql->getSqlStringForSqlObject($select);
        $result = $this->fetchAll($select, $sql);
    
        return $result;
    }
    
    public function updateText( $data, $where )
    {
        if ( empty($data) ) {
            return false;
        }
    
        if ( empty($where) ) {
            return false;
        }
    
        $cacheKey = self::$basicWordsCacheKey;
        $this->cache()->removeItem($cacheKey);
        return $this->dbUpdate('ft_translation_all_basic_words', $data, $where, $this->getFeatDbAdapter());
    }
}