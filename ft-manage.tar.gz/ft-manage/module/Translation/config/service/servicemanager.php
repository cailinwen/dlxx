<?php
/**
 * Featee
 * This is not a free software, unauthorized use is prohibited.
 *
 * @copyright Copyright © 2010－2014. Feat Technologies. All Rights Reserved.
 */
return array(
    'invokables' => array(
        // Db Mapper
        'Translation_DbMapper_Locale' => 'Translation\Mapper\LocaleDbMapper',
        'Translation_DbMapper_Translation' => 'Translation\Mapper\TranslationDbMapper',
        'Translation_DbMapper_BasicWord' => 'Translation\Mapper\BasicWordDbMapper',
        'Translation_DbMapper_Audit' => 'Translation\Mapper\AuditDbMapper',
        'Translation_DbMapper_Country' => 'Translation\Mapper\Country',
        // Event
        'locale_event_languageEvent' => 'Translation\Event\languageEvent',
        // Service
        'Translation_Service_Translation' => 'Translation\Service\TranslationService',
        'Translation_Service_Country' => 'Translation\Service\Country',
        'Translation_Service_Audit' => 'Translation\Service\Audit',
        'Translation_Service_BasicWord' => 'Translation\Service\BasicWord',
        'Translation_Service_Locale' => 'Translation\Service\Locale'
    ),
    'factories' => array(),
    'aliases' => array(
        // Db Mapper
        'localeDbMapper' => 'Translation_DbMapper_Locale',
        'translationDbMapper' => 'Translation_DbMapper_Translation',
        'auditDbMapper' => 'Translation_DbMapper_Audit',
        'basicWordDbMapper' => 'Translation_DbMapper_BasicWord',
        'countryDbMapper' => 'Translation_DbMapper_Country',
        // Service
        'localeService' => 'Translation_Service_Locale',
        'transMapper' => 'Translation_Mapper_Translation',
        'transService' => 'Translation_Service_Translation',
        'basicWordService' => 'Translation_Service_BasicWord',
        'auditService' => 'Translation_Service_Audit',
        'countryService' => 'Translation_Service_Country'
    )
);