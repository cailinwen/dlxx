<?php
return array(
    'router' => array(
        'routes' => array(
            'translation' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/translation[/][:action]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*'
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Translation\Controller',
                        'controller' => 'Translation',
                        'action' => 'index'
                    )
                )
            )
        )
    )
);