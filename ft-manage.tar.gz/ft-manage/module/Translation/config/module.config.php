<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Translation\Controller\Translation' => 'Translation\Controller\TranslationController'
        )
    ),
    
    'minimum_audit' => 1, 
    'view_manager' => array(
        'template_map' => array(
            'translation/layout' => __DIR__ . '/../view/layout/trans-layout.phtml'
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view'
        )
    )
);
