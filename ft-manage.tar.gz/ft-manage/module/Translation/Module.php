<?php
namespace Translation;

use Zend\Mvc\MvcEvent;
class Module
{

    /**
     * Implement hook onBootstrap
     *
     * @param MvcEvent $e            
     */
    public function onBootstrap(MvcEvent $e)
    {
        $app = $e->getApplication();
        $eventManager = $app->getEventManager();
        $sem = $eventManager->getSharedManager();
        $sm = $app->getServiceManager();
        
        $languageEvent = $sm->get('locale_event_languageEvent');
        $sem->attach('*', 'languageLoad.post', array(
            $languageEvent,
            'languageLoadPost'
        ));
    }

    public function getConfig()
    {
        $config = array();
        $configFiles = array(
            __DIR__ . '/config/module.config.php',
            __DIR__ . '/config/module.config.route.php',
            __DIR__ . '/config/module.requirejs.config.php'
        );
        foreach ( $configFiles as $configFile ) {
            $config = array_merge($config, include $configFile);
        }
        return $config;
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__
                )
            )
        );
    }

    public function getServiceConfig()
    {
        return include (__DIR__ . '/config/service/servicemanager.php');
    }
}
