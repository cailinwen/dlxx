<?php
return array(
    'router' => array(
        'routes' => array(
            'advertising' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/advertising',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Advertising\Controller',
                        'controller' => 'Index',
                        'action' => 'index'
                    )
                )
            ),
            'ads-audit' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/ads/audit[/:action]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*'
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Advertising\Controller',
                        'controller' => 'AdsReview',
                        'action' => 'index'
                    )
                )
            )
        )
    )
);

