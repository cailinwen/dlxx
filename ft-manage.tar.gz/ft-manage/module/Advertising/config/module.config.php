<?php
namespace Advertising;

return array(
    'controllers' => array(
        'invokables' => array(
            'Advertising\Controller\Index' => 'Advertising\Controller\IndexController',
            'Advertising\Controller\AdsReview' => 'Advertising\Controller\AdsReviewController'
        ),
        'factories' => array()
    ),
    'view_manager' => array(
        'template_map' => array(
            'ads/audit-layout' => __DIR__ . '/../view/layout/audit-layout.phtml',
            //'ads/audit/index' => __DIR__ . '/../view/advertising/ads-review/index.phtml'
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view'
        )
    )
);
