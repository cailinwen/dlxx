<?php
namespace Advertising\Mapper;

use Core\DbMapper\AbstractDbMapper;

class AdvertisingModuleBaseMapper extends AbstractDbMapper
{}
