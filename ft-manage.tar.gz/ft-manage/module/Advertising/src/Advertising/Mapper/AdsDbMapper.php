<?php
namespace Advertising\Mapper;

class AdsDbMapper extends AdvertisingModuleBaseMapper
{

    public function getPendingReviewAds( $limit = 30, $offset = 0 )
    {
        $sql = $this->getSql()->setTable('ft_ads');
        $select = $sql->select();
        $select->where->equalTo('status', 3);
        if ( ! empty($limit) ) {
            $select->limit($limit)->offset($offset);
        }
        $select->order('addtime DESC');
        return $this->fetchAll($select, $sql);
    }

    public function updateAdsInfo( $data, $where )
    {
        $data['updated'] = $_SERVER['REQUEST_TIME'];
        return $this->dbUpdate(self::ADS_TABLE, $data, $where);
    }

    public function adsInfo( $where )
    {
        $sql = $this->getSql()->setTable(self::ADS_TABLE);
        $select = $sql->select();
        $select->where($where);
        $select->limit(1);
        return $sql->prepareStatementForSqlObject($select)
            ->execute()
            ->current();
    }

    public function getAdsInfosBy( $where )
    {
        $sql = $this->getSql()->setTable(self::ADS_TABLE);
        $select = $sql->select();
        $select->where($where);
        return $this->fetchAll($select, $sql);
    }

    public function adsSeries( $where )
    {
        $sql = $this->getSql()->setTable(self::ADS_SERIES_TAB);
        $select = $sql->select();
        $select->where($where);
        $select->limit(1);
        return $sql->prepareStatementForSqlObject($select)
            ->execute()
            ->current();
    }

    public function updateAdsSeries( $data, $where )
    {
        $data['updated'] = $_SERVER['REQUEST_TIME'];
        return $this->dbUpdate(self::ADS_SERIES_TAB, $data, $where);
    }

    public function updateAdsCampaign( $data, $where )
    {
        $data['update'] = $_SERVER['REQUEST_TIME'];
        return $this->dbUpdate(self::ADS_CAMPAIGN_TAB, $data, $where);
    }
}