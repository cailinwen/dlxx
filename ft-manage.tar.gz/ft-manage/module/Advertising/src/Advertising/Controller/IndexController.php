<?php
namespace Advertising\Controller;

class IndexController extends AdvertisingModuleBaseController
{

    public function indexAction()
    {
        $url = $this->url()->fromRoute('ads-audit');
        return $this->redirect()->toUrl($url);
    }
}