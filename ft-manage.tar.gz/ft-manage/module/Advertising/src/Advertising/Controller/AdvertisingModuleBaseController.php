<?php
namespace Advertising\Controller;

use Core\Controller\AbstractBaseCoreController;

class AdvertisingModuleBaseController extends AbstractBaseCoreController
{

    public function preDisPatch()
    {
        parent::preDisPatch();
        $this->checkLoginAndXmlRequest($this->loginUser);
    }
}