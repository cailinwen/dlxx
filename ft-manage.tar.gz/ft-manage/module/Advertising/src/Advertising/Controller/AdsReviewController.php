<?php
namespace Advertising\Controller;

class AdsReviewController extends AdvertisingModuleBaseController
{

    /**
     *
     * @var \Advertising\Service\AdsService
     */
    private $adsService;

    /**
     *
     * @return the $adsService
     */
    public function getAdsService()
    {
        if ( ! $this->adsService ) {
            $this->adsService = $this->getServiceLocator()->get('adsService');
        }
        return $this->adsService;
    }

    public function indexAction()
    {
        $this->layout('ads/audit-layout');
        $this->headLink()->appendStylesheet('/css/common/base.css');
        $this->headLink()->appendStylesheet('/css/admin/admin.css');
        $renderer = $this->getServiceLocator()->get('Zend\View\Renderer\PhpRenderer');
        $renderer->headTitle(GLOBAL_PROJECT . ' | Ads Audit');
        $this->layout()->module = 'advertising';
        return array(
            'adsData' => $this->getAdsService()->getPendingReviewAds()
        );
    }

    public function verifyOperateAction()
    {
        $params = $this->params()->fromPost();
        $ads_id = $params['ads_id'];
        $status = $params['status'];
        $adsInfo = $this->getAdsService()->adsInfo(array(
            'ads_id' => $ads_id
        ));
        if ( $status ) {
            if ( $adsInfo && $adsInfo['endtime'] ) {
                $status = 2; // 通过审核(已排程)
            } else {
                $status = 1; // 通过审核（投放中）
            }
        } else {
            $status = 4; // 未通过审核
        }
        
        if ( ! $this->getAdsService()->updateAdsInfo(compact('status'), array(
            'ads_id' => $ads_id,
            'status' => 3
        )) ) {
            return self::createJsonView(0, $params, 'Failed');
        }
        
        if ( $adsInfo && $status == 2 ) {
            $adsS = $this->getAdsService()->adsSeries(array(
                'ads_sid' => $adsInfo['ads_sid']
            ));
            $this->getAdsService()->updateAdsSeries(array(
                'status' => $adsS['endtime'] ? 2 : 1
            ), array(
                'ads_sid' => $adsInfo['ads_sid']
            ));
            
            $this->getAdsService()->updateAdsCampaign(array(
                'status' => 1
            ), array(
                'ads_cid' => $adsInfo['ads_cid']
            ));
        } elseif ( $adsInfo && $status == 4 ) {
            //@todo 如果广告未通过审核，则广告的状态为4
            //@todo 广告组的状态为4
            $this->getAdsService()->updateAdsSeries(array(
                'status' => 5
            ), array(
                'ads_sid' => $adsInfo['ads_sid']
            ));
            //@todo 广告系列的状态判断。
            //广告系列系的组只有一条数据是，则状态为未投放，
            //否则再判断系列下的广告，只要有一个是投放，则未投放，否则为未投放
            $adsS = $this->getAdsService()->getAdsInfosBy(array(
                'ads_cid' => $adsInfo['ads_cid']
            ));
            $isToufang = 3; //未投放
            if ( count($adsS) == 1 ) {
                $isToufang = 3;
            } else {
                foreach ( $adsS as $val ) {
                    if ( $val['status'] == 1 ) {
                        $isToufang = 1;
                        break;
                    }
                }
            }
            $this->getAdsService()->updateAdsCampaign(array(
                'status' => $isToufang
            ), array(
                'ads_cid' => $adsInfo['ads_cid']
            ));
        }
        
        return self::createJsonView(1, $params, 'Successed');
    }
}