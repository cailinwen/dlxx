<?php
namespace Advertising\Service;

use Core\Service\AbstractService;

class AdvertisingModuleBaseService extends AbstractService
{}