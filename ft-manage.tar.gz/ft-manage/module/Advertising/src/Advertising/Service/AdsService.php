<?php
namespace Advertising\Service;

class AdsService extends AdvertisingModuleBaseService
{

    /**
     *
     * @var \Advertising\Mapper\AdsDbMapper
     */
    private $adsDbMapper;

    /**
     *
     * @return the $adsDbMapper
     */
    protected function getAdsDbMapper()
    {
        if ( ! $this->adsDbMapper ) {
            $this->adsDbMapper = $this->getServiceLocator()->get('adsDbMapper');
        }
        return $this->adsDbMapper;
    }

    public function getPendingReviewAds( $limit = 30, $offset = 0 )
    {
        return $this->getAdsDbMapper()->getPendingReviewAds($limit, $offset);
    }

    public function updateAdsInfo( $data, $where )
    {
        return $this->getAdsDbMapper()->updateAdsInfo($data, $where);
    }

    public function getAdsInfosBy( $where )
    {
        return $this->getAdsDbMapper()->getAdsInfosBy($where);
    }

    public function adsInfo( $where )
    {
        return $this->getAdsDbMapper()->adsInfo($where);
    }

    public function adsSeries( $where )
    {
        return $this->getAdsDbMapper()->adsSeries($where);
    }

    public function updateAdsCampaign( $data, $where )
    {
        return $this->getAdsDbMapper()->updateAdsCampaign($data, $where);
    }

    public function updateAdsSeries( $data, $where )
    {
        return $this->getAdsDbMapper()->updateAdsSeries($data, $where);
    }
}