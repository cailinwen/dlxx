<?php
/**
 * This makes our life easier when dealing with paths. Everything is relative
 * to the application root now.
 */
chdir(dirname(__DIR__));

ini_set('date.timezone', 'PRC');

/**
 * check php version
 */
if ( version_compare(phpversion(), '5.3.3', '<') ) {
    printf('PHP 5.3.3 is required, you have %s', phpversion());
    exit(1);
}

/**
 * Display all errors when APPLICATION_ENV is development.
 */
if ( isset($_SERVER['APPLICATION_ENV']) && $_SERVER['APPLICATION_ENV'] == 'development' ) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}

/**
 * Public functions
 * 自定义调试输出
 *
 * @param var|string|array $data            
 * @param $usePr 是否使用print_r
 *            格式输入，
 */
function zp_dump($r, $usePr = false)
{
    if ( $usePr || false === method_exists('\Zend\Debug\Debug', 'dump') ) {
        echo '<pre>' . print_r($r, true) . '</pre>';
        return;
    }
    \Zend\Debug\Debug::dump($r);
}

// Setup autoloading
require 'init_autoloader.php';

// Run the application!
Zend\Mvc\Application::init(require 'config/application.config.php')->run();
