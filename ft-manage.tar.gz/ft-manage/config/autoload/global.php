<?php
return array(
    'db' => array(
        'driver' => 'Pdo',
        'dsn' => 'mysql:dbname=db_zf2_celestra;host=' . HOST_IP . ';port=' . DATABASE_PORT,
        'driver_options' => array(
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
        ),
        'username' => 'featee',
        'password' => 'abc123',
        
        // 多数据库配置
        'adapters' => array(
            'ft_feat' => array(
                'driver' => 'Pdo',
                'dsn' => 'mysql:dbname=db_zf2_celestra;host=' . HOST_IP . ';port=' . DATABASE_PORT,
                'username' => 'featee',
                'password' => 'abc123',
                'driver_options' => array(
                    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
                )
            ),
            'ft_manage' => array(
                'driver' => 'Pdo',
                'dsn' => 'mysql:dbname=db_ft_manage;host=' . HOST_IP . ';port=' . DATABASE_PORT,
                'username' => 'db_ft_manage',
                'password' => 'abc123',
                'driver_options' => array(
                    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
                )
            )
        )
    ),
    'session' => array(
        'config' => array(
            'class' => 'Zend\Session\Config\SessionConfig',
            'options' => array(
                'name' => 'ft-mange-session'
            )
        ),
        'storage' => 'Zend\Session\Storage\SessionArrayStorage',
        'validators' => array(
            array(
                'Zend\Session\Validator\RemoteAddr',
                'Zend\Session\Validator\HttpUserAgent'
            )
        )
    ),
    'service_manager' => array(
        'invokables' => array(
            'ErrorHandling' => 'Core\Service\ErrorHandle'
        ),
        'factories' => array(
            'Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory',
            'LogRecordFactory' => 'Core\Factory\LogRecordFactory'
        ),
        'abstract_factories' => array(
            'Zend\Db\Adapter\AdapterAbstractServiceFactory'
        ),
        'aliases' => array(
            'dbAdapter' => 'Zend\Db\Adapter\Adapter'
        )
    ),
    
    'IM_manager' => array(
        'fairfeat3' => array(
            'host' => HOST_IP,
            'protocol' => 'http://',
            'domain' => 'fairfeat3',
            'port' => '5222',
            'http_bind' => 'http://' . HOST_IP . ':7070/http-bind/',
            'Administrater' => 'celestra',
            'password' => 'push!SERVER3',
            'admin_port' => '9090'
        )
    ),
    
    'language' => array(
        'default' => 'en_US'
    ),
    
    'cdn_light' => array(
        'HeadLink' => true,
        'HeadScript' => true,
        'LinkCdn' => false,
        'global' => array(),
        'servers' => array(
            'static_1' => array(
                'scheme' => 'http',
                'host' => HOST_IP,
                'port' => 887
            )
        )
    )
);
