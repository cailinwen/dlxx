<?php
return array(
    'restful-manage' => array(
        'ft-rf-profile' => array(
            // 'remote_server' => 'http://10.0.10.105:86/ft-rf-profile/public/',
            'protocol' => 'http://',
            'host' => HOST_IP,
            'port' => 303
        // 'host' => '10.0.10.105',
        // 'port' => 86
                ),
        // 'ft-rf-translation' => array(
        // // 'remote_server' =>
        // // 'http://10.0.10.105:86/ft-rf-translation/public/',
        // 'protocol' => 'http://',
        // 'host' => HOST_IP,
        // 'port' => 301
        // ),
        'ft-rf-message' => array(
            // 'remote_server' => 'http://10.0.10.105:86/ft-rf-message/public/',
            'protocol' => 'http://',
            'host' => HOST_IP,
            'port' => 300
        // 'host' => '10.0.10.105',
        // 'port' => 86
                )
    )
);
