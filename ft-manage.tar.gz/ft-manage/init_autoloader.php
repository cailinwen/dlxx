<?php
ini_set('default_socket_timeout', 2000);

const IS_ONLINE = false;

const MUST_LOGIN = true;

const GLOBAL_PROJECT = 'Featee';

const CACHE_TYPE_DEFAULT = 'redis';

const MAIN_URI = 'http://10.0.10.118:898';

const ADMIN_URI = 'http://10.0.10.118:800';

const HOST_IP = '10.0.10.118';

const DATABASE_PORT = 3306;

defined('FAIRFEAT_ROOT_PATH') || define('FAIRFEAT_ROOT_PATH', __DIR__);
defined('FAIRFEAT_PUBLIC_PATH') || define('FAIRFEAT_PUBLIC_PATH', __DIR__ . '/public');
defined('FAIRFEAT_LIB_PATH') || define('FAIRFEAT_LIB_PATH', __DIR__ . '/vendor');
defined('FAIRFEAT_MODULE_PATH') || define('FAIRFEAT_MODULE_PATH', __DIR__ . '/module');
defined('FAIRFEAT_CONFIG_PATH') || define('FAIRFEAT_CONFIG_PATH', __DIR__ . '/config');

if ( ! defined('SLASH_SEPERATOR') ) {
    define('SLASH_SEPERATOR', '\\');
    define('EMPTYSPACE', ' ');
}

if ( file_exists('vendor/autoload.php') ) {
    $loader = include 'vendor/autoload.php';
}

$zf2Path = false;

if ( is_dir('vendor/ZF2/library') ) {
    $zf2Path = __DIR__ . '/vendor/ZF2/library';
} elseif ( getenv('ZF2_PATH') ) { // Support for ZF2_PATH environment variable
                                  // or git submodule
    $zf2Path = getenv('ZF2_PATH');
} elseif ( function_exists('zend_deployment_library_path') && zend_deployment_library_path('Zend Framework 2') ) {
    $zf2Path = zend_deployment_library_path('Zend Framework 2');
} elseif ( get_cfg_var('zf2_path') ) { // Support for zf2_path directive value
    $zf2Path = get_cfg_var('zf2_path');
}

if ( $zf2Path ) {
    if ( isset($loader) ) {
        $loader->add('Zend', $zf2Path);
    } else {
        include $zf2Path . '/Zend/Loader/AutoloaderFactory.php';
        Zend\Loader\AutoloaderFactory::factory(array(
            'Zend\Loader\StandardAutoloader' => array(
                'autoregister_zf' => true
            )
        ));
    }
}

if ( ! class_exists('Zend\Loader\AutoloaderFactory') ) {
    throw new RuntimeException('Unable to load ZF2. Run `php composer.phar install` or define a ZF2_PATH environment variable.');
}
