define('Util', [], function() {
	
	function Util() {
		
	}
    /** Function: jidToId
     * Translates a jid to a MD5-Id
     *
     * Parameters:
     *   (String) jid - Jid
     *
     * Returns:
     *   MD5-ified jid
     */
	Util.prototype.jidToId = function(jid) {
        return MD5.hexdigest(jid);
    };

    /** Function: escapeJid
     * Escapes a jid (node & resource get escaped)
     *
     * See:
     *   XEP-0106
     *
     * Parameters:
     *   (String) jid - Jid
     *
     * Returns:
     *   (String) - escaped jid
     */
    Util.prototype.escapeJid = function(jid) {
        var node = Strophe.escapeNode(Strophe.getNodeFromJid(jid)),
            domain = Strophe.getDomainFromJid(jid),
            resource = Strophe.getResourceFromJid(jid);

        jid = node + '@' + domain;
        if (resource) {
            jid += '/' + Strophe.escapeNode(resource);
        }

        return jid;
    };

    /** Function: unescapeJid
     * Unescapes a jid (node & resource get unescaped)
     *
     * See:
     *   XEP-0106
     *
     * Parameters:
     *   (String) jid - Jid
     *
     * Returns:
     *   (String) - unescaped Jid
     */
    Util.prototype.unescapeJid = function(jid) {
        var node = Strophe.unescapeNode(Strophe.getNodeFromJid(jid)),
            domain = Strophe.getDomainFromJid(jid),
            resource = Strophe.getResourceFromJid(jid);

        jid = node + '@' + domain;
        if (resource) {
            jid += '/' + Strophe.unescapeNode(resource);
        }

        return jid;
    };

    /** Function: crop
     * Crop a string with the specified length
     *
     * Parameters:
     *   (String) str - String to crop
     *   (Integer) len - Max length
     */
    Util.prototype.crop = function(str, len) {
        if (str.length > len) {
            str = str.substr(0, len - 3) + '...';
        }
        return str;
    };

    /** Function: setCookie
     * Sets a new cookie
     *
     * Parameters:
     *   (String) name - cookie name
     *   (String) value - Value
     *   (Integer) lifetime_days - Lifetime in days
     */
    Util.prototype.setCookie = function(name, value, lifetime_days) {
        var exp = new Date();
        exp.setDate(new Date().getDate() + lifetime_days);
        document.cookie = name + '=' + value + ';expires=' + exp.toUTCString() + ';path=/';
    };

    /** Function: cookieExists
     * Tests if a cookie with the given name exists
     *
     * Parameters:
     *   (String) name - Cookie name
     *
     * Returns:
     *   (Boolean) - true/false
     */
    Util.prototype.cookieExists = function(name) {
        return document.cookie.indexOf(name) > -1;
    };

    /** Function: getCookie
     * Returns the cookie value if there's one with this name, otherwise returns undefined
     *
     * Parameters:
     *   (String) name - Cookie name
     *
     * Returns:
     *   Cookie value or undefined
     */
    Util.prototype.getCookie = function(name) {
        if (document.cookie) {
            var regex = new RegExp(escape(name) + '=([^;]*)', 'gm'),
                matches = regex.exec(document.cookie);
            if (matches) {
                return matches[1];
            }
        }
    };

    /** Function: deleteCookie
     * Deletes a cookie with the given name
     *
     * Parameters:
     *   (String) name - cookie name
     */
    Util.prototype.deleteCookie = function(name) {
        document.cookie = name + '=;expires=Thu, 01-Jan-70 00:00:01 GMT;path=/';
    };

    /** Function: getPosLeftAccordingToWindowBounds
     * Fetches the window width and element width
     * and checks if specified position + element width is bigger
     * than the window width.
     *
     * If this evaluates to true, the position gets substracted by the element width.
     *
     * Parameters:
     *   (jQuery.Element) elem - Element to position
     *   (Integer) pos - Position left
     *
     * Returns:
     *   Object containing `px` (calculated position in pixel) and `alignment` (alignment of the element in relation to pos, either 'left' or 'right')
     */
    Util.prototype.getPosLeftAccordingToWindowBounds = function(elem, pos) {
        var windowWidth = $(document).width(),
            elemWidth = elem.outerWidth(),
            marginDiff = elemWidth - elem.outerWidth(true),
            backgroundPositionAlignment = 'left';

        if (pos + elemWidth >= windowWidth) {
            pos -= elemWidth - marginDiff;
            backgroundPositionAlignment = 'right';
        }

        return {
            px: pos,
            backgroundPositionAlignment: backgroundPositionAlignment
        };
    };

    /** Function: getPosTopAccordingToWindowBounds
     * Fetches the window height and element height
     * and checks if specified position + element height is bigger
     * than the window height.
     *
     * If this evaluates to true, the position gets substracted by the element height.
     *
     * Parameters:
     *   (jQuery.Element) elem - Element to position
     *   (Integer) pos - Position top
     *
     * Returns:
     *   Object containing `px` (calculated position in pixel) and `alignment` (alignment of the element in relation to pos, either 'top' or 'bottom')
     */
    Util.prototype.getPosTopAccordingToWindowBounds = function(elem, pos) {
        var windowHeight = $(document).height(),
            elemHeight = elem.outerHeight(),
            marginDiff = elemHeight - elem.outerHeight(true),
            backgroundPositionAlignment = 'top';

        if (pos + elemHeight >= windowHeight) {
            pos -= elemHeight - marginDiff;
            backgroundPositionAlignment = 'bottom';
        }

        return {
            px: pos,
            backgroundPositionAlignment: backgroundPositionAlignment
        };
    };

    /** Function: localizedTime
     * Localizes ISO-8610 Date with the time/dateformat specified in the translation.
     *
     * See: libs/dateformat/dateFormat.js
     * See: src/view/translation.js
     * See: jquery-i18n/jquery.i18n.js
     *
     * Parameters:
     *   (String) dateTime - ISO-8610 Datetime
     *
     * Returns:
     *   If current date is equal to the date supplied, format with timeFormat, otherwise with dateFormat
     */
    Util.prototype.localizedTime = function(dateTime) {
        if (dateTime === undefined) {
            return undefined;
        }

        var date = this.iso8601toDate(dateTime);
        if (date.toDateString() === new Date().toDateString()) {
            return date.format($.i18n._('timeFormat'));
        } else {
            return date.format($.i18n._('dateFormat'));
        }
    };

    /** Function: iso8610toDate
     * Parses a ISO-8610 Date to a Date-Object.
     *
     * Uses a fallback if the client's browser doesn't support it.
     *
     * Quote:
     *   ECMAScript revision 5 adds native support for ISO-8601 dates in the Date.parse method,
     *   but many browsers currently on the market (Safari 4, Chrome 4, IE 6-8) do not support it.
     *
     * Credits:
     *  <Colin Snover at http://zetafleet.com/blog/javascript-dateparse-for-iso-8601>
     *
     * Parameters:
     *   (String) date - ISO-8610 Date
     *
     * Returns:
     *   Date-Object
     */
    Util.prototype.iso8601toDate = function(date) {
        var timestamp = Date.parse(date),
            minutesOffset = 0;
        if (isNaN(timestamp)) {
            var struct = /^(\d{4}|[+\-]\d{6})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{3,}))?)?(?:(Z)|([+\-])(\d{2})(?::?(\d{2}))?))?/.exec(date);
            if (struct) {
                if (struct[8] !== 'Z') {
                    minutesOffset = +struct[10] * 60 + (+struct[11]);
                    if (struct[9] === '+') {
                        minutesOffset = -minutesOffset;
                    }
                }
                return new Date(+struct[1], +struct[2] - 1, +struct[3], +struct[4], +struct[5] + minutesOffset, +struct[6], struct[7] ? +struct[7].substr(0, 3) : 0);
            } else {
                // XEP-0091 date
                timestamp = Date.parse(date.replace(/^(\d{4})(\d{2})(\d{2})/, '$1-$2-$3') + 'Z');
            }
        }
        return new Date(timestamp);
    };

    /** Function: isEmptyObject
     * IE7 doesn't work with jQuery.isEmptyObject (<=1.5.1), workaround.
     *
     * Parameters:
     *   (Object) obj - the object to test for
     *
     * Returns:
     *   Boolean true or false.
     */
    Util.prototype.isEmptyObject = function(obj) {
        for (var prop in obj) {
            if (obj.hasOwnProperty(prop)) {
                return false;
            }
        }
        return true;
    };

    Util.prototype.objectLength = function(obj) {
        var count = 0;
        for (var n in obj) {
            if (obj.hasOwnProperty(n)) {
                count++;
            }
        }
        return count;
    };

    /** Function: forceRedraw
     * Fix IE7 not redrawing under some circumstances.
     *
     * Parameters:
     *   (jQuery.element) elem - jQuery element to redraw
     */
    Util.prototype.forceRedraw = function(elem) {
        elem.css({
            display: 'none'
        });
        setTimeout(function() {
            this.css({
                display: 'block'
            });
        }.bind(elem), 1);
    };

    Util.prototype.detectObject = function(obj, detectValue) {
        if (typeof detectValue == 'string') {
            if (typeof obj[detectValue] == 'undefined') {
                obj[detectValue] = {};
            }
        } else if (typeof detectValue == 'object') {
            for (var index in detectValue) {
                if (typeof obj[index] == 'undefined') {
                    obj[index] = {};
                    if (typeof detectValue[index] == 'object') {
                        obj[index] = this.detectObject(obj[index], detectValue[index]);
                    } else {
                        obj[index] = detectValue[index];
                    }
                }
            }
        }

        return obj;
    };

    Util.prototype.randomString = function(length) {
        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz_'.split('');

        if (!length) {
            length = Math.floor(Math.random() * chars.length);
        }

        var str = '';
        for (var i = 0; i < length; i++) {
            str += chars[Math.floor(Math.random() * chars.length)];
        }
        return str;
    };

    function formatContent(content) {
        var p = document.createElement("p");

        p.textContent = content;
        var text = p.innerHTML.replace(/\n/g, "<br/>");

        return text;
    }

    Util.prototype.formatContent = function(content) {
        return formatContent(content);
    };

    Util.prototype.history = function(url) {
        var rootdomain = '',
            protocol = window.location.protocol;

        if (window.location.host != window.location.hostname) {
            rootdomain = protocol + '//' + window.location.host;
        } else {
            rootdomain = protocol + '//' + window.location.hostname;
        }

        if (url.indexOf(rootdomain) < 0) {
            url = rootdomain + url;
        }

        if (history.pushState) {
            window.history.pushState({}, '', url);
        }
    };

    Util.prototype.newSms = function() {
        var audioElm = document.getElementById('smsPlay');
        audioElm.play();
    };

    Util.prototype.bowser = function() {
        /**
         * navigator.userAgent =>
         * Chrome: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.57 Safari/534.24"
         * Opera: "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.7; U; en) Presto/2.7.62 Version/11.01"
         * Safari: "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; en-us) AppleWebKit/533.21.1 (KHTML, like Gecko) Version/5.0.5 Safari/533.21.1"
         * IE: "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C)"
         * IE>=11: "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; .NET4.0E; .NET4.0C; Media Center PC 6.0; rv:11.0) like Gecko"
         * Firefox: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0) Gecko/20100101 Firefox/4.0"
         * iPhone: "Mozilla/5.0 (iPhone Simulator; U; CPU iPhone OS 4_3_2 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8H7 Safari/6533.18.5"
         * iPad: "Mozilla/5.0 (iPad; U; CPU OS 4_3_2 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8H7 Safari/6533.18.5",
         * Android: "Mozilla/5.0 (Linux; U; Android 2.3.4; en-us; T-Mobile G2 Build/GRJ22) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1"
         * Touchpad: "Mozilla/5.0 (hp-tabled;Linux;hpwOS/3.0.5; U; en-US)) AppleWebKit/534.6 (KHTML, like Gecko) wOSBrowser/234.83 Safari/534.6 TouchPad/1.0"
         * PhantomJS: "Mozilla/5.0 (Macintosh; Intel Mac OS X) AppleWebKit/534.34 (KHTML, like Gecko) PhantomJS/1.5.0 Safari/534.34"
         * Amazon Silk: "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-us; Silk/1.0.22.153_10033210) AppleWebKit/533.16 (KHTML, like Gecko) Version/5.0 Safari/533.16 Silk-Accelerated=true"
         */

        var ua = navigator.userAgent,
            t = true,
            ie = /(msie|trident)/i.test(ua),
            chrome = /chrome|crios/i.test(ua),
            phantom = /phantom/i.test(ua),
            iphone = /iphone/i.test(ua),
            ipad = /ipad/i.test(ua),
            touchpad = /touchpad/i.test(ua),
            silk = /silk/i.test(ua),
            safari = /safari/i.test(ua) && !chrome && !phantom && !silk,
            android = /android/i.test(ua),
            opera = /opera/i.test(ua) || /opr/i.test(ua),
            firefox = /firefox/i.test(ua),
            gecko = /gecko\//i.test(ua),
            seamonkey = /seamonkey\//i.test(ua),
            webkitVersion = /version\/(\d+(\.\d+)?)/i,
            firefoxVersion = /firefox\/(\d+(\.\d+)?)/i,
            o;

        function detect() {

            if (ie) return {
                name: 'Internet Explorer',
                msie: t,
                version: ua.match(/(msie |rv:)(\d+(\.\d+)?)/i)[2]
            };
            if (opera) return {
                name: 'Opera',
                opera: t,
                version: ua.match(webkitVersion) ? ua.match(webkitVersion)[1] : ua.match(/opr\/(\d+(\.\d+)?)/i)[1]
            };
            if (chrome) return {
                name: 'Chrome',
                webkit: t,
                chrome: t,
                version: ua.match(/(?:chrome|crios)\/(\d+(\.\d+)?)/i)[1]
            };
            if (phantom) return {
                name: 'PhantomJS',
                webkit: t,
                phantom: t,
                version: ua.match(/phantomjs\/(\d+(\.\d+)+)/i)[1]
            };
            if (touchpad) return {
                name: 'TouchPad',
                webkit: t,
                touchpad: t,
                version: ua.match(/touchpad\/(\d+(\.\d+)?)/i)[1]
            };

            if (silk) return {
                name: 'Amazon Silk',
                webkit: t,
                android: t,
                mobile: t,
                version: ua.match(/silk\/(\d+(\.\d+)?)/i)[1]
            };
            if (iphone || ipad) {
                o = {
                    name: iphone ? 'iPhone' : 'iPad',
                    webkit: t,
                    mobile: t,
                    ios: t,
                    iphone: iphone,
                    ipad: ipad
                };
                // WTF: version is not part of user agent in web apps
                if (webkitVersion.test(ua)) {
                    o.version = ua.match(webkitVersion)[1];
                }
                return o;
            }
            if (android) return {
                name: 'Android',
                webkit: t,
                android: t,
                mobile: t,
                version: (ua.match(webkitVersion) || ua.match(firefoxVersion))[1]
            };
            if (safari) return {
                name: 'Safari',
                webkit: t,
                safari: t,
                version: ua.match(webkitVersion)[1]
            };
            if (gecko) {
                o = {
                    name: 'Gecko',
                    gecko: t,
                    mozilla: t,
                    version: ua.match(firefoxVersion)[1]
                };
                if (firefox) {
                    o.name = 'Firefox';
                    o.firefox = t;
                }
                return o;
            }
            if (seamonkey) return {
                name: 'SeaMonkey',
                seamonkey: t,
                version: ua.match(/seamonkey\/(\d+(\.\d+)?)/i)[1]
            };
            return {};
        }

        var bowser = detect();

        // Graded Browser Support
        // http://developer.yahoo.com/yui/articles/gbs
        if ((bowser.msie && bowser.version >= 8) ||
            (bowser.chrome && bowser.version >= 10) ||
            (bowser.firefox && bowser.version >= 4.0) ||
            (bowser.safari && bowser.version >= 5) ||
            (bowser.opera && bowser.version >= 10.0)) {
            bowser.a = t;
        } else if ((bowser.msie && bowser.version < 8) ||
            (bowser.chrome && bowser.version < 10) ||
            (bowser.firefox && bowser.version < 4.0) ||
            (bowser.safari && bowser.version < 5) ||
            (bowser.opera && bowser.version < 10.0)) {
            bowser.c = t;
        } else bowser.x = t;

        return bowser;
    };

    /** Function: dataFormat
     *  格式化时间
     *
     * Parameters:
     *   (String) - format html object
     *   (Number) - timestamp 	int
     */
    Util.prototype.dateFormat = function(format, timestamp) {
        var that = this,
            jsdate = new Date(),
            f = {},
            // Keep this here (works, but for code commented-out
            // below for file size reasons)
            //, tal= [],
            txt_words = ['Sun', 'Mon', 'Tues', 'Wednes', 'Thurs', 'Fri', 'Satur', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
            // trailing backslash -> (dropped)
            // a backslash followed by any character (including backslash) -> the character
            // empty string -> empty string
            formatChr = /\\?(.?)/gi,
            formatChrCb = function(t, s) {
                return f[t] ? f[t]() : s;
            },
            _pad = function(n, c) {
                n = String(n);
                while (n.length < c) {
                    n = '0' + n;
                }
                return n;
            };
        f = {
            // Day
            d: function() { // Day of month w/leading 0; 01..31
                return _pad(f.j(), 2);
            },
            D: function() { // Shorthand day name; Mon...Sun
                return f.l().slice(0, 3);
            },
            j: function() { // Day of month; 1..31
                return jsdate.getDate();
            },
            l: function() { // Full day name; Monday...Sunday
                return txt_words[f.w()] + 'day';
            },
            N: function() { // ISO-8601 day of week; 1[Mon]..7[Sun]
                return f.w() || 7;
            },
            S: function() { // Ordinal suffix for day of month; st, nd, rd, th
                var j = f.j(),
                    i = j % 10;
                if (i <= 3 && parseInt((j % 100) / 10, 10) == 1) {
                    i = 0;
                }
                return ['st', 'nd', 'rd'][i - 1] || 'th';
            },
            w: function() { // Day of week; 0[Sun]..6[Sat]
                return jsdate.getDay();
            },
            z: function() { // Day of year; 0..365
                var a = new Date(f.Y(), f.n() - 1, f.j()),
                    b = new Date(f.Y(), 0, 1);
                return Math.round((a - b) / 864e5);
            },

            // Week
            W: function() { // ISO-8601 week number
                var a = new Date(f.Y(), f.n() - 1, f.j() - f.N() + 3),
                    b = new Date(a.getFullYear(), 0, 4);
                return _pad(1 + Math.round((a - b) / 864e5 / 7), 2);
            },

            // Month
            F: function() { // Full month name; January...December
                return txt_words[6 + f.n()];
            },
            m: function() { // Month w/leading 0; 01...12
                return _pad(f.n(), 2);
            },
            M: function() { // Shorthand month name; Jan...Dec
                return f.F().slice(0, 3);
            },
            n: function() { // Month; 1...12
                return jsdate.getMonth() + 1;
            },
            t: function() { // Days in month; 28...31
                return (new Date(f.Y(), f.n(), 0)).getDate();
            },

            // Year
            L: function() { // Is leap year?; 0 or 1
                var j = f.Y();
                return j % 4 === 0 & j % 100 !== 0 | j % 400 === 0;
            },
            o: function() { // ISO-8601 year
                var n = f.n(),
                    W = f.W(),
                    Y = f.Y();
                return Y + (n === 12 && W < 9 ? 1 : n === 1 && W > 9 ? -1 : 0);
            },
            Y: function() { // Full year; e.g. 1980...2010
                return jsdate.getFullYear();
            },
            y: function() { // Last two digits of year; 00...99
                return f.Y().toString().slice(-2);
            },

            // Time
            a: function() { // am or pm
                return jsdate.getHours() > 11 ? 'pm' : 'am';
            },
            A: function() { // AM or PM
                return f.a().toUpperCase();
            },
            B: function() { // Swatch Internet time; 000..999
                var H = jsdate.getUTCHours() * 36e2,
                    // Hours
                    i = jsdate.getUTCMinutes() * 60,
                    // Minutes
                    s = jsdate.getUTCSeconds(); // Seconds
                return _pad(Math.floor((H + i + s + 36e2) / 86.4) % 1e3, 3);
            },
            g: function() { // 12-Hours; 1..12
                return f.G() % 12 || 12;
            },
            G: function() { // 24-Hours; 0..23
                return jsdate.getHours();
            },
            h: function() { // 12-Hours w/leading 0; 01..12
                return _pad(f.g(), 2);
            },
            H: function() { // 24-Hours w/leading 0; 00..23
                return _pad(f.G(), 2);
            },
            i: function() { // Minutes w/leading 0; 00..59
                return _pad(jsdate.getMinutes(), 2);
            },
            s: function() { // Seconds w/leading 0; 00..59
                return _pad(jsdate.getSeconds(), 2);
            },
            u: function() { // Microseconds; 000000-999000
                return _pad(jsdate.getMilliseconds() * 1000, 6);
            },

            // Timezone
            e: function() { // Timezone identifier; e.g. Atlantic/Azores, ...
                // The following works, but requires inclusion of the very large
                // timezone_abbreviations_list() function.
                /*              return that.date_default_timezone_get();
                 */
                throw 'Not supported (see source code of date() for timezone on how to add support)';
            },
            I: function() { // DST observed?; 0 or 1
                // Compares Jan 1 minus Jan 1 UTC to Jul 1 minus Jul 1 UTC.
                // If they are not equal, then DST is observed.
                var a = new Date(f.Y(), 0),
                    // Jan 1
                    c = Date.UTC(f.Y(), 0),
                    // Jan 1 UTC
                    b = new Date(f.Y(), 6),
                    // Jul 1
                    d = Date.UTC(f.Y(), 6); // Jul 1 UTC
                return ((a - c) !== (b - d)) ? 1 : 0;
            },
            O: function() { // Difference to GMT in hour format; e.g. +0200
                var tzo = jsdate.getTimezoneOffset(),
                    a = Math.abs(tzo);
                return (tzo > 0 ? '-' : '+') + _pad(Math.floor(a / 60) * 100 + a % 60, 4);
            },
            P: function() { // Difference to GMT w/colon; e.g. +02:00
                var O = f.O();
                return (O.substr(0, 3) + ':' + O.substr(3, 2));
            },
            T: function() { // Timezone abbreviation; e.g. EST, MDT, ...
                // The following works, but requires inclusion of the very
                // large timezone_abbreviations_list() function.
                /*              var abbr = '', i = 0, os = 0, default = 0;
		      if (!tal.length) {
		        tal = that.timezone_abbreviations_list();
		      }
		      if (that.php_js && that.php_js.default_timezone) {
		        default = that.php_js.default_timezone;
		        for (abbr in tal) {
		          for (i=0; i < tal[abbr].length; i++) {
		            if (tal[abbr][i].timezone_id === default) {
		              return abbr.toUpperCase();
		            }
		          }
		        }
		      }
		      for (abbr in tal) {
		        for (i = 0; i < tal[abbr].length; i++) {
		          os = -jsdate.getTimezoneOffset() * 60;
		          if (tal[abbr][i].offset === os) {
		            return abbr.toUpperCase();
		          }
		        }
		      }
		*/
                return 'UTC';
            },
            Z: function() { // Timezone offset in seconds (-43200...50400)
                return -jsdate.getTimezoneOffset() * 60;
            },

            // Full Date/Time
            c: function() { // ISO-8601 date.
                return 'Y-m-d\\TH:i:sP'.replace(formatChr, formatChrCb);
            },
            r: function() { // RFC 2822
                return 'D, d M Y H:i:s O'.replace(formatChr, formatChrCb);
            },
            U: function() { // Seconds since UNIX epoch
                return jsdate / 1000 | 0;
            }
        };
        this.date = function(format, timestamp) {
            that = this;
            jsdate = (timestamp === undefined ? new Date() : // Not provided
                (timestamp instanceof Date) ? new Date(timestamp) : // JS Date()
                new Date(timestamp * 1000) // UNIX timestamp (auto-convert to int)
            );
            return format.replace(formatChr, formatChrCb);
        };
        return this.date(format, timestamp);
    };

    /**
     * Create partial url for a name/value pair
     */
    var makeUrlParam = function(name, value) {
        return [name, encodeURIComponent(value)].join('=');
    };

    Util.prototype.makeUrl = function(url, params) {
        var urlAppend = [];
        $.each(params, function(index, value) {
            urlAppend.push(makeUrlParam(index, value));
        });
        if (urlAppend.length) {
            url += url.indexOf('?') === -1 ? '?' : '&';
            url += urlAppend.join('&');
        }
        return url;
    };
    
    Util.prototype.escapeHtml = function(text) {
    		return text
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#039;');
    };
    
    Util.prototype.locationQuery = function(source){
        var map = {};
        source = source || this.search;

        if ("" != source) {
            var groups = source.substr(1).split("&"), i;

            for (i in groups) {
                i = groups[i].split("=");
                map[decodeURIComponent(i[0])] = decodeURIComponent(i[1]);
            }
        }

        return map;
    };
    
    /** Function: existPro
	 * 检测经历是否存在某属性
	 * 
	 * Parameters: 
	 * 		(Object) obj - experience object
	 * 		(String) propertyStr - experience property
	 */
    Util.prototype.existPro = function(obj, propertyStr) {
        var propertyList = propertyStr.split('.');

        if (!propertyList.length) return false;
        while (propertyList && propertyList.length) {
            var property = propertyList.shift();
            obj = obj[property];
            if (!obj) {
                return false;
            }
        };

        return obj ? true : false;
    };
    
    Util.prototype.removeClassRegEx = function (elem, regex) {
    	 	var classes = $(elem).attr('class');
         if (!classes || !regex) return false;

         var classArray = [];
         classes = classes.split(' ');
         for (var i = 0, len = classes.length; i < len; i++)
             if (!classes[i].match(regex)) classArray.push(classes[i]);

         $(elem).attr('class', classArray.join(' '));
         return $(elem);
    };
    
	Util.prototype.isLocalStorageNameSupport = function () {
		var testKey = 'testSupport'; storage = window.sessionStorage;
		try {
			storage.setItem(testKey, 1);
			storage.removeItem(testKey);
			return true;
		} catch (e) {
			return false;
		}
	};
	
	Util.prototype.clearObjectNullValue = function (list) {
		if (list) {
			var notNullList = {}, l = 0;
			for (var i in list) {
				var jid = list[i];
				if (list.hasOwnProperty(i) && jid != null) {
					notNullList [l] = jid;
				}
			}
			
			list = notNullList;
			return notNullList;
		}
	};
	
	Util.prototype.clearFileInputValue = function (elem) {
		if ($.browser.msie) {
			elem.replaceWith(elem.clone());
			elem.replaceWith(elem.clone());
	 	} else {
	 		elem.val('');
	 		elem.val('');
	 	}
	};

    return new Util;
});