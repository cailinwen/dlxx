define('User',[], function() {
	function User() {
		this._user = {};
        this._currentUserPublicInfo = {};
	}

	User.prototype.setUser = function(userInfo) {
        this._user = userInfo;

        this._currentUserPublicInfo.username = userInfo.username;
        this._currentUserPublicInfo.equipment = userInfo.equipment;
    };

    /** Function: getUser
     *  给房间列表元素绑定事件
     *
     * Parameters:
     *   (Object) item - 房间列表对象
     */
    User.prototype.getUser = function() {
        return this._user;
    };

    User.prototype.setUserJid = function(jid) {
	    	this._user.jid = jid;
	    	this._currentUserPublicInfo.jid = jid.split('/').shift();
    };

    User.prototype.getUserJid = function() {
        return this._user.jid;
    };

    User.prototype.setUserName = function(name) {
    		this._user.name = name;
    };

    User.prototype.getUserName = function() {
        return this._user.name;
    };

    /** Function: getUserPublicInfo
     *  获取当前用户的基本信息
     *
     */
    User.prototype.getUserPublicInfo = function() {
        return this._currentUserPublicInfo;
    };

    return new User;
});