
define('Core', ['Util', 'Template', 'Room'], function (Util, Template, Room) {
	function Core() {
		//贪婪型提交
		this._promiseReadState;
		this._promiseRoomState;
		this._promiseLeaveRoom;
	    
		this.transport_frame = 1;
		this._createIframeTimer = 0;
	    
	    //缓存查询数据
		this._localCacheMessage = {};
		this._localPhotoMessage = {};
		
		this._mutePromise;
		this._unmutePromise;
	}
    
    /** Function: ajaxLoadMessage
     * Get room publish message.
     *
     * Parameters:
     *   (Object) - data
     *   (String) - jid
     */
    Core.prototype.ajaxLoadMessage = function(data, jid, type) {
    		var dtd = $.Deferred(); //在函数内部，新建一个Deferred对象
    		var self = this;
        var cacheData = this.getCacheRoomData(jid),
        		cacheLength = parseInt(Util.objectLength(cacheData.messages)),
            loadAjax = false,
            returnValue = {},
            baseUrl = Project.settings.baseUrl;

        if (cacheData) {
            var room = Room.getRoom(jid),
                params = data.messages[room.thread_id];

            if (cacheLength > params.offset) {
                var queryFromCache = cacheLength >= params.offset + params.limit;
                sliceLength = parseInt(queryFromCache ? params.offset + params.limit : cacheLength);
                messages = cacheData.messages.slice(params.offset, sliceLength);

                returnValue.messages = messages;
                returnValue.more = cacheData.more || sliceLength < cacheLength;
                returnValue.total = cacheData.more ? parseInt(cacheData.total) + cacheLength - sliceLength : cacheLength - sliceLength;

                dtd.resolveWith(this, [returnValue]); // 改变Deferred对象的执行状态
            } else {
                loadAjax = true;
            }
        } else loadAjax = true;

        if (loadAjax) {
            try {
                try {
                    loadMore = typeof self._localCacheMessage[jid].more == 'undefined' ||
                    self._localCacheMessage[jid].more;
                } catch (err) {
                    loadMore = true;
                }
            } catch (err) {}

            if (loadMore) {
            		var target_user_id = {target_id:Project.settings.profile_id};
            		var paramsData = $.extend({}, data,target_user_id);
                $.ajax({
                    url: baseUrl + '/ajax/message/messageInfo',
                    data: paramsData,
                    dataType: 'json',
                    type: 'post',
                    beforeSend: function() {},
                    success: function(result, textStatus, jqXHR) {
                        if (result.status == 1) {
                            var data = $.parseJSON(result.data),
                                messages = data.actions,
                                ml = 0,
                                l = Util.objectLength(messages);

                            if (l !== 0) {
                                if (typeof self._localCacheMessage[jid] == 'undefined' ||
                                    (!cacheData && type == 'reload')) {
	                                	self._localCacheMessage[jid] = {};
	                                	self._localCacheMessage[jid].messages = [];
	                                	self._localCacheMessage[jid].more = false;
                                } else {
                                    ml = self._localCacheMessage[jid].messages.length;
                                }

                                if (data.hasMore != '0') {
                                		self._localCacheMessage[jid].more = data.hasMore;
                                } else {
                                		self._localCacheMessage[jid].more = false;
                                }

                                self._localCacheMessage[jid].total = data.total;

                                if (typeof self._localPhotoMessage[jid] == 'undefined') {
	                                	self._localPhotoMessage[jid] = {};
	                                	self._localPhotoMessage[jid].messages = {};
                                }

                                self._localCacheMessage[jid].last = messages[parseInt(l) - 1].message_id;

                                for (var i in messages) {
                                    if (messages.hasOwnProperty(i)) {
                                        var message = $.extend({}, messages[i]);

                                        if (typeof self._localCacheMessage[jid].messages[ml] == 'undefined') {
                                        		self._localCacheMessage[jid].messages[ml] = message;
                                            ml++;
                                        }

                                        if (message.share_type == 'log') {
                                            if (message.log_type == 'logo') {
                                            		self._localPhotoMessage[jid][message.message_id] = message;
                                            }
                                        } else {
                                            if (typeof message.attachments != 'undefined') {
                                                var attachments = message.attachments;
                                                if (typeof attachments.photo != 'undefined') {
                                                		self._localPhotoMessage[jid][message.message_id] = message;
                                                }
                                            }
                                        }
                                    }
                                }

                                returnValue.messages = messages;
                                returnValue.more = self._localCacheMessage[jid].more;
                                returnValue.total = data.total;

                                dtd.resolveWith(this, [returnValue]); // 改变Deferred对象的执行状态
                            } else dtd.resolveWith(this, []);
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        dtd.reject(this, [jqXHR, textStatus, errorThrown]);
                    }
                });
            }
        }

        return dtd.promise();
    };
    
    /** Function: addMessageToList
     *  添加消息到缓存列表
     *
     * Parameters:
     *   (Object) message - 消息
     *   (String) jid - 房间JID
     *
     */
    Core.prototype.addMessageToList = function(message, jid) {
        var cacheMessages = this._localCacheMessage[jid].messages;
        for (var i in cacheMessages) {
            if (cacheMessages[i].message_id == message.message_id) {
                return false;
            } else if (cacheMessages[i].message_id == message.cur_message_id) {
            		cacheMessages.splice(i,1);
            		cacheMessages.unshift(message);
            		return true;
            }
        }

        this._localCacheMessage[jid].messages.unshift(message);
    };
    
    /** Function: formatMessageCreated
     *  格式化消息时间
     *
     * Parameters:
     *   (String) timestamp - 时间戳
     *
     */
    Core.prototype.formatMessageCreated = function(timestamp) {
        var dateArray = [];
        var formats = Project.settings.formats;
        var phpTimeFormat = parseInt(timestamp),
        		currentDate = (new Date).getTime()/1000;

        dateArray.year = Util.dateFormat('Y', phpTimeFormat);
        dateArray.month = Util.dateFormat('m', phpTimeFormat);
        dateArray.day = Util.dateFormat('d', phpTimeFormat);
        dateArray.dateString = Util.dateFormat('Y-m-d', phpTimeFormat);
        
        if (dateArray.year == (new Date).getFullYear()) {
        		if (Util.dateFormat('m', currentDate) == dateArray.month) {
        			if (Util.dateFormat('d', currentDate) == dateArray.day) {
//        				dateArray.timestamp = JsTranslation.getTrans('Today');
        				dateArray.timestamp = 'Today';
        			} else if(Util.dateFormat('W', currentDate) == Util.dateFormat('W', phpTimeFormat)) {
        				dateArray.timestamp = this.weekMultiLanguage('l', phpTimeFormat);
        			} else {
        				dateArray.timestamp = Util.dateFormat(formats['F j'], phpTimeFormat);
        			}
    			} else {
    				dateArray.timestamp = Util.dateFormat(formats['F j'], phpTimeFormat);
    			}
        } else {
            dateArray.timestamp = Util.dateFormat(formats['F j, Y'], phpTimeFormat);
        }
        
        if (Util.dateFormat('d', currentDate) == dateArray.day) {
        		dateArray.timestamp_relative = Util.dateFormat(formats['g:ia'], phpTimeFormat);
        } else {
	        	dateArray.timestamp_relative = Util.dateFormat(formats['n/j, g:ia'], phpTimeFormat);
        }
        
    		dateArray.timestamp_relative = this.timeMultiLanguage(dateArray.timestamp_relative);
    		dateArray.header_time = Util.dateFormat(formats['F j, Y'], phpTimeFormat);
        
        return dateArray;
    };
    
    Core.prototype.weekMultiLanguage = function (format, time) {
	    	var language = Project.settings.locale,
	    		shortDayNames = Project.settings.shortDayNames,
			week;	
	    	switch (language) {
		    	case 'zh_CN':
		    		var day = new Date(time * 1000).getDay();
		    		if (day == 0) {
		    			week = shortDayNames [shortDayNames.length];
		    		} else {
		    			week = shortDayNames [day - 1];
		    		}
		    		break;
		    	case 'en_US':
		    		week = Util.dateFormat(format, time);
		    		break;
	    	}
	    	
	    	return week;
    };
    
    Core.prototype.timeMultiLanguage = function ($time) {
    		var language = Project.settings.locale,
    			date;
    		switch(language) {
    			case 'zh_CN':
    				date = $time.replace(/AM/, '上午').replace(/PM/, '下午');
				break;
    		}
    		
    		return date;
    };
    
    /** Function: getPhotoList
     *  获取图片列表
     *
     * Parameters:
     *   (Number) message_id - 消息ID
     *   (String) jid - 消息房间JID
     *
     */
    Core.prototype.getPhotoList = function(message_id, jid) {
    		try {
            var message = this._localPhotoMessage[jid][message_id];
            if (message.share_type == 'log') {
                return {
                    0: message.attachments.photo
                };
            } else {
                return message.attachments.photo;
            }
        } catch (err) {}

        return false;
    };
    
    /** Function: getCacheRoomData
     * 获取缓存信息
     *
     * Parameters:
     *   (String) - jid
     */
    Core.prototype.getCacheRoomData = function(jid) {
        try {
            return typeof this._localCacheMessage[jid] != 'undefined' && this._localCacheMessage[jid];
        } catch (err) {
            return false;
        }
    };
    
    Core.prototype.removeFromCacheList = function (message_id, jid) {
		var cacheMessages = this._localCacheMessage[jid].messages;
	    for (var i in cacheMessages) {
	        if (cacheMessages[i].message_id == message_id) {
	            	cacheMessages.splice(i,1);
	            	return false;
	        }
	    }
	};
	
	Core.prototype.setReadStateByJid = function(jid) {
        var room = Room.getRoom(jid),
            requestData = {},
            count;

        if (!room) {
        		return false;
        }
        
        count = room.unread != undefined ?parseInt(room.unread):0;
        if (count === 0) return false;

        requestData.target_id = room.thread_id;
        requestData.type = 'read';

        this.readState(requestData, jid);
    };
    
    /** Function: setPhotoList
     *  设置图片缓存
     *
     * Parameters:
     *   (Object) message - 消息
     *   (String) jid - 房间JID
     *
     */
    Core.prototype.setPhotoList = function(message, jid) {
        if (typeof this._localPhotoMessage[jid] == 'undefined') {
        		this._localPhotoMessage[jid] = {};
        }

        if (typeof this._localPhotoMessage[jid][message.message_id] == 'undefined') {
        		this._localPhotoMessage[jid][message.message_id] = message;
        }
    };
    
    /** Function: photoClickEvent
     *  图片点击事件
     *
     * Parameters:
     *   (Object) elem - 出发点击的DOM
     *   (String) jid - 房间JID
     *
     */
    Core.prototype.photoClickEvent = function(elem, jid) {
        try {
            var tmp = $(elem).attr('id').split('.'),
                message_id = tmp[1],
                photo_id = tmp[2],
                photoList = this.getPhotoList(message_id, jid);

            if (!photoList) {
            		return false;
            }
            
            return {list: photoList, id: photo_id};
        } catch (err) {}
        return false;
    };
    
    Core.prototype.updateCache = function(message, jid) {
        if (typeof this._localCacheMessage[jid] != 'undefined') {
            this.addMessageToList(message, jid);

            if ((message.share_type == 'message' && typeof message.attachments !== 'undefined' &&
                    typeof message.attachments.photo != 'undefined') ||
                (message.share_type == 'log' && message.log_type == 'logo')) {
                this.setPhotoList(message, jid);
            }
        }
        return true;
    };
    
    Core.prototype.attachmentBindDownloadEvent = function(attachmentDownloadLink) {
    		var self = this;
        clearTimeout(self._createIframeTimer);
        self._createIframeTimer = setTimeout(function() {
            var iframe = document.createElement('iframe');

            iframe.src = attachmentDownloadLink;
            iframe.id = 'transport_frame_' + self.transport_frame;
            iframe.className = 'hide';

            $('body').append(iframe);
            ++self.transport_frame;
        }, 1000);
    };
    
    Core.prototype.getTransportFrame = function() {
        return self.transport_frame;
    };

    Core.prototype.setTransportFrame = function(value) {
    		self.transport_frame = value;
    };
    
    /** Function: formatContent
     * 接受到新消息后，改变聊天室列表中对应项的最新聊天内容
     * Show message.
     *
     * Parameters:
     *   (object) - message	object
     */
    Core.prototype.formatContent = function(message) {
        var currentUser = User.getUser().user_id;
	    var snippet = {};
	    if (message.author == currentUser) {
		    	snippet.author_name = '你';
		    	snippet.currentUser = true;
	    } else {
	    		snippet.currentUser = false;
	    		snippet.author_name = message.author_name + ':';
	    }
	    
	    if (message.body === '') {
	    		snippet.hasContent = false;
	        if (message.attachments !== undefined) {
	        		snippet.showPhoto = function () {
	        			return typeof message.attachments.photo != 'undefined';
	        		};
	        		snippet.showFile = function () {
	        			return typeof message.attachments.file != 'undefined';
	        		};
	        		
	            if (typeof message.attachments.photo != 'undefined') {
	            		snippet.count = Util.objectLength(message.attachments.photo);
	
	            		if (message.share_type == 'message') {
	            			snippet.showMessagePhoto = true;
	            		} else {
	            			snippet.showLogPhoto = true;
	            		}
	            } else if (typeof message.attachments.file != 'undefined') {
		            	snippet.files = message.attachments.file;
		            	snippet.showFile = true;
	            }
	        }
	    } else {
		    	snippet.body = Util.escapeHtml(message.body);
		    	snippet.hasContent = true;
	    }
	
	    return Mustache.to_html(Template.Message.Snippet, snippet);
    };
    
    /** Function: mathPhotoSetParams
     *  计算图片的显示尺寸
     *
     * Parameters:
     *   (Object) photoList - 图片列表
     *
     */
    Core.prototype.mathPhotoSetParams = function(photoList) {
        var l = photoList.length,
	        paddingSize = 0,
	        lineElemSize = 2,
	        widthSize = 0,
	        XpositionSize = 0,
	        YpositionSize = 0,
	        maxWidth = 431,
//	        maxWidth = 549,
	        imageSpace = 15,
	        imageSpaceSize = imageSpace / maxWidth;
	    		divide = 0;
	
	    if (l <= 4) {
	        lineElemSize = l !== 3 ? 2 : 3;
	        divide = Math.ceil(l / lineElemSize);
	        widthSize = (maxWidth - (lineElemSize - 1) * imageSpace) / (lineElemSize * maxWidth);
	
	        paddingSize = (l <= 3) ? widthSize : 1;
	        XpositionSize = (widthSize + imageSpaceSize) * 100;
	        YpositionSize = (widthSize + imageSpaceSize) * 100;
	    } else {
	        lineElemSize = 3;
	        widthSize = (maxWidth - imageSpace * (lineElemSize - 1)) / (lineElemSize * maxWidth);
	        divide = Math.ceil(l / lineElemSize);
	
	        if (divide <= 3) {
	            paddingSize = (divide * widthSize * maxWidth +
	                (divide - 1) * imageSpace) / maxWidth;
	        } else {
	            paddingSize = (maxWidth + (divide - lineElemSize) *
	                (widthSize * maxWidth + imageSpace)) / maxWidth;
	        }
	
	        XpositionSize = (widthSize + imageSpaceSize) * 100;
	        imageSpaceSize = imageSpace / (paddingSize * maxWidth);
	        YpositionSize = (widthSize / paddingSize + imageSpaceSize) * 100;
	    }
	
	    setPadding = paddingSize * 100 + '%';
	
	    for (var i in photoList) {
	        if (photoList.hasOwnProperty(i)) {
	            var index = parseInt(i);
	            var top = YpositionSize * (Math.ceil((index + 1) / lineElemSize) - 1);
	
	            photoList[i].left = index % lineElemSize === 0 ? 0 : XpositionSize * (index % lineElemSize) + '%';
	            photoList[i].top = Math.ceil((index + 1) / lineElemSize) === 1 ? 0 : top + '%';
	            photoList[i].setWidth = widthSize * 100 + '%';
	        }
	    }
	
	    return {
	        'setPadding': setPadding,
	        'photo': photoList
	    };
    };
    
    /** Function: mathSinglePhoto
     *  计算单张图片的现实尺寸
     *
     * Parameters:
     *   (Object) photo - 图片列表
     *   (number) maxWidth - 图片最大宽度
     *   (number) maxHeight - 图片最大高度
     *
     */
    Core.prototype.mathSinglePhoto = function(photo, maxWidth, maxHeight) {
        var imgWidth = parseInt(photo.width),
            imgHeight = parseInt(photo.height);

        if (maxHeight > imgHeight && maxWidth > imgWidth) { //当图片的宽和高都小于窗口大小时执行一下代码
            return {
                width: imgWidth,
                height: imgHeight
            };
        } else {
            var width = 0,
                height = 0;
            if (imgWidth >= imgHeight) {
                height = maxWidth * imgHeight / imgWidth; //根据高来确定宽
                return {
                    width: maxWidth,
                    height: height
                };
            } else {
                width = imgWidth * maxHeight / imgHeight;
                height = maxHeight;

                if (width > maxWidth) {
                    width = maxWidth;
                    height = maxWidth * imgHeight / imgWidth;
                }
                return {
                    width: width,
                    height: height
                };
            }
        }
    };
    
    return new Core;
});