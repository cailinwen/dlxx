define('Template', [], function () {
	function Template() {
		this.Window = {
		        unreadmessages: '({{count}}) {{title}}'
		    };
	}
	
	Template.prototype.init = function () {
		var self = this;
		$.extend(self, Project.settings.message_templates);
    };
    
    return new Template;
});