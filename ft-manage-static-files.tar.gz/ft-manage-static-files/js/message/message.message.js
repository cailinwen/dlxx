define(['Mustache', 'User', 'Core', 'Room', 'MessageRoom', 'Preview', 'Template', 'Util', 'Cluetip', 'JqueryHighlight'], 
		function(Mustache, User, Core, Room, MessageRoom, Preview, Template, Util, Cluetip) {
    function Message() {
    		this.log_data = {log_message_data:{}, log_message_type: ''};
    		this._loadMore = true;
    		this._options = {
			roomListWrap: '#wmMasterViewThreadlist',
            message_header: '#webMessengerHeaderName',
            message_container: '.messageConversation .converSation',
            message_area: '.messageConversation',
            photo: {
	        		maxWidth: 431,
	        		maxHeight: 468
	        }
        };
    		
    		this._currentLoadType = 'reload';
        
        //贪婪型提交
        this._xhrLoadMessage;
        this._promiseDeleteMessage;

        //缓存查询数据
        this._localCacheMessage = {};
        this._currentData = {};

        this._messageScrollTop = 0;
        this._currentShow = 'message';
        this._currentLoadType = 'reload';
        this._messageStart = {}; //reload or loadmore
        
        this.timer;
    }

    /** Function: _factoryOfCreateMessageItem
     *  添加新聊天信息
     *
     * Parameters:
     *   (Object) container - DOM
     *   (Object) message - 消息内容
     *   (String) type - 加载类型
     *   (Object) dataCreateTime - 消息创建时间
     *
     */
    Message.prototype._factoryOfCreateMessageItem = function (container, message, type, dataCreateTime) {
        var self = this, 
        		newElem,
            detectImageload = false,
            hasPhoto = false,
            loadImage = 0,
            jid = Room.getCurrentRoom().jid, l;

        message.baseUrl = Project.settings.baseUrl;
        message.isCurrentUser = function() {
            return User.getUser().user_id == message.author;
        };

        message.body = Util.formatContent(message.body);
        if (message.share_type == 'log') {
            html = this.roomLogMessage(message, dataCreateTime);

            if (message.log_type == 'logo') {
                hasPhoto = true;
                detectImageload = true;

                if (type == 'add') {
                    var roomItem = MessageRoom.getRoomListItem(jid);
                    if (roomItem) {
                    		roomItem.find('.MercuryThreadImage img').attr('src', message.attachments.photo.originalUrl + '&preview=1');
                    }
                }
            }
            
            newElem = $(html);
        } else {
            if (typeof message.attachments != 'undefined') {
                var attachments = message.attachments;

                if (typeof attachments.photo != 'undefined') {
                    hasPhoto = true;
                    l = message.attachments.photo.length;

                    message.attachments.onlyOne = (l === 1);
                    if (l > 1) {
                        var mathPhotoSetParams = Core.mathPhotoSetParams(attachments.photo);
                        message.attachments.setPadding = mathPhotoSetParams.setPadding;
                        message.attachments.photo = mathPhotoSetParams.photo;
                    } else {
                        detectImageload = true;
                        var afterMath = Core.mathSinglePhoto(attachments.photo[0], this._options.photo.maxWidth, this._options.photo.maxHeight);
                        message.attachments.photo[0].mw = afterMath.width;
                        message.attachments.photo[0].mh = afterMath.height;
                    }
                }
            }

            html = Mustache.to_html(Template.Message.Item, message);
            newElem = $(html);
        }

        if (message.cur_message_id !== undefined && $('[data-id="mid.'+message.cur_message_id+'"]').length) {
        		$('[data-id="mid.'+message.cur_message_id+'"]').replaceWith(newElem);
        } else {
        		if (container.children('div').length === 0 || type === 'add') {
                container.append(newElem);
            } else {
                container.children('div:first').before(newElem);
            }
        }

        if (message.attachments !== undefined && message.attachments.file !== undefined) {
            newElem.find('a.downloadLink').bind('click', function(event) {
                var url = $(this).attr('href');
                Core.attachmentBindDownloadEvent(url);
                return false;
            });
        }

        try {
            if (hasPhoto && detectImageload) {
                if (type === 'add') {
                    Core._localPhotoMessage[jid][message.message_id] = message;
                }

                if (message.share_type == 'message') {
                    var photoList = newElem.find('div.attachmentWrap')
                        .children('div.attachment_photo').find('div.absolute');
                    
                    l = photoList.length;
                    if (l === 0) {
                        loadImage = newElem.find('div.attachmentWrap')
                            .children('div.attachment_photo').find('img').get(0);
                    }
                } else {
                    if (message.log_type === 'logo') {
                        loadImage = newElem.find('._ksh').children('img').get(0);
                    }
                }

                if (loadImage !== 0) {
                    this.FGetImg(loadImage);
                }
            }

            if (hasPhoto) {
                $(newElem).find('.jsPhotoPreview').click(function() {
                		var previewInfo = Core.photoClickEvent(this, Room.getCurrentRoom().jid);
                		Preview.openPreview(previewInfo.list, previewInfo.id);
                    return false;
                });
            }
        } catch (e) {
        		var trace = require('Stacktrace')({
	            e: e
	        });
	        console.log('Error!\n' + 'Message: ' + e.message + '\nStack trace:\n' + trace.join('\n'));
        }

        return;
    };

    Message.prototype.getBaseUrl = function() {
    		return Project.settings.baseUrl;
    };
    
    Message.prototype.messageHeight = function () {
	    "use strict";
	    var WHeight = $(window).height(),
	        HHeight = $('.header').height(),
	        wrapHeight = $('#createChatWrap').outerHeight(true),
	        mfHeight = WHeight - HHeight - $('div.wmMasterViewTabBar').height() - 1,
	        mbHeight = WHeight - HHeight - wrapHeight - $('#wmBoxHeader').outerHeight(true);
	    if (!$("#webMessengerRecentMessages").parent().hasClass('hide') ||
	    		!$('ul.msgSearchResultShow').parent().hasClass('hide')) {
	        mbHeight -= $('.sendEditWrap').height();
	    }
	    if ($("#wmMasterViewThreadlist").parent().hasClass('hide')) {
	        $('#messageFriends').css('height', 100);
	    } else {
	        $('#messageFriends').css('height', mfHeight);
	    }
	    $('#messagesAreaWrap').css('height', mbHeight);
	};
	
    Message.prototype.init = function () {
    		var self = this;
    		
    		MessageRoom.setMessageModule(self);
    		MessageRoom.init();
    		
    		this.messageHeight();
		
		$('.uiMenuItem>a').mouseenter(function() {
			$(this).focus().parent().addClass('selected').siblings().removeClass('selected');
		});
		
		$('.coverSearchInput').bind('paste cut change keyup', function (e) {
			if ($.trim($('.coverSearchInput').val()) == '') {
				self.getMessageContainer().unhighlight();
				$.each($('.highlightContainer'), function (i, o) {
					$(o).closest('.itemMessageContent').removeClass('highlightContainer');
				});
			} else {
				self.timer && clearTimeout(self.timer);
				self.timer = setTimeout(function () {
					var content = self.getMessageContainer();
					var highlightContainer = $('.highlightContainer'), l = highlightContainer.length;
					if (l != 0) {
						content.unhighlight();
						$.each(highlightContainer, function (i, o) {
							$(o).closest('.itemMessageContent').removeClass('highlightContainer');
							if (i == l - 1) {
								content.highlight($('.coverSearchInput').val());
								$('.highlight').each(function (j, obj) {
									$(obj).closest('.itemMessageContent').addClass('highlightContainer');
								});
							}
						});
					} else {
						content.highlight($('.coverSearchInput').val());
						$('.highlight').each(function (i, o) {
							$(o).closest('.itemMessageContent').addClass('highlightContainer');
						});
					}
				}, 1000);
			}
		});
    };
    
    Message.prototype.start = function(options) {
        $.extend(true, this._options, options);

        var self = this,
        		thread = [],
            order = [];
        
        order.offset = this._options.offset;
        order.limit = this._options.limit;
        this._loadMore = true;

        thread[options.thread_id] = order;
        this.queryparams.messages = Util.detectObject(this.queryparams.messages, thread);

        var messageContainer = this.getMessageContainer();
        this.messageScrollEventBind();
    };
    
    Message.prototype.messageScrollEventBind = function () {
    		var self = this; 
	    	var messageArea = this.getMessagesArea();
	
	    messageArea.mCustomScrollbar({
	        scrollInertia: 100,
	        mouseWheel: true,
	        autoHideScrollbar: true,
	        callbacks: {
	            onScroll: function() {
	                var top = messageArea.find('.mCSB_container').position().top;
                		self.setMessageScrollTop(top);
	            },
	            onTotalScrollBack:function(){
	            		if (self.getCurrentShow() == 'message' && !self._xhrLoadMessage) {
	                		self._xhrLoadMessage = true;
	                    self.messageLoad('scroll');
	                }
	            },
	            onTotalScrollOffset: 60,
	        }
	    });
    };

    /** Function: getOptions
     *  获取消息的设置
     *
     */
    Message.prototype.getOptions = function() {
        return this._options;
    };

    /** Function: queryparams
     *  消息查询请求参数
     *
     * Parameters:
     *   (Object) container - DOM
     *   (Object) message - 消息内容
     *   (String) type - 加载类型
     *   (Object) dataCreateTime - 消息创建时间
     *
     */
    Message.prototype.queryparams = {
        messages: {}
    };

    /** Function: resetparams
     *  初始化消息请求参数
     *
     */
    Message.prototype.resetparams = function() {
        this.queryparams = {
            messages: {}
        };
        this.getMessagesArea().mCustomScrollbar('destroy');
    };

    /** Function: setMessageScrollTop
     *  记录消息的滚动位置
     *
     * Parameters:
     *   (number) top - 滚动条的top值
     *
     */
    Message.prototype.setMessageScrollTop = function(top) {
    		this._messageScrollTop = top;
    };

    /** Function: getMessageScrollTop
     *  获取滚动条记录的位置
     *
     */
    Message.prototype.getMessageScrollTop = function() {
        return this._messageScrollTop;
    };

    /** Function: getCurrentShow
     *  获取当前执行操作类型
     *
     */
    Message.prototype.getCurrentShow = function() {
        return this._currentShow;
    };

    /** Function: setCurrentShow
     *  设置操作类型
     *
     * Parameters:
     *   (String) type - 状态  message、search
     *
     */
    Message.prototype.setCurrentShow = function(type) {
    		this._currentShow = type;
    };

    /** Function: roomLogMessage
     *  格式化房间的操作记录
     *
     * Parameters:
     *   (Object) message - 消息内容
     *   (Object) dataCreateTime - 消息创建时间
     */
    Message.prototype.roomLogMessage = function (message, dataCreateTime) {
    		var logHtml = '';
            message.staticServer = Project.settings.staticServer;
            
        switch (message.log_type) {
            case 'leave':
                logHtml = Mustache.to_html(Template.Message.Log.Leave, message);
                break;

            case 'join_room':
                if (message.log_data === null || User.getUser().user_id == message.log_data.user_id) {
                    logHtml = Mustache.to_html(Template.Message.Log.Start, {
                        'timestamp': dataCreateTime.header_time
                    });
                } else {
                    logHtml = Mustache.to_html(Template.Message.Log.JoinName,
                        message);
                }
                break;

            case 'name':
                logHtml = Mustache.to_html(Template.Message.Log.Name, message);
                break;

            case 'logo':
                var afterMath = Core.mathSinglePhoto(message.attachments.photo, 200, 200);
                message.attachments.photo.mw = afterMath.width;
                message.attachments.photo.mh = afterMath.height;

                logHtml = Mustache.to_html(Template.Message.Log.Logo, message);
                break;
        }
        return logHtml;
    };

    function removeImageAttr(img) {
        $(img).removeAttr('width');
        $(img).removeAttr('height');
    }

    /** Function: FGetImg
     *  图片加载
     *
     * Parameters:
     *   (number) imageObj - 加载图片对象
     *   (number) fCallback - 回调函数
     *
     */
    Message.prototype.FGetImg = function(imageObj, fCallback) {
        var img = imageObj;
        var bowser = Util.bowser();
        if (bowser.msie) {
            img.onreadystatechange = function() {
                if (this.readyState == "loaded" || this.readyState == "complete") {
                    removeImageAttr(img);
                }
            };
        } else if (bowser.firefox || bowser.safari || bowser.opera || bowser.chrome) {
            img.onload = function() {
                removeImageAttr(img);
            };
        }
    };

    /** Function: messageLoad
     *  消息加载
     *
     * Parameters:
     *   (String) type - 加载类型
     *
     */
    Message.prototype.messageLoad = function(type) {
        var self = this,
        		currentRoom = Room.getCurrentRoom(),
            thread = currentRoom.thread_id,
            jid = currentRoom.jid,
            messageArea = this.getMessagesArea(),
            messageContainer = this.getMessageContainer();

        if (type == 'reload') {
	        	this._currentData = {};
	        	this._messageStart = {};

            limit = Math.floor(messageArea.height() / 50);
            limit = limit < 20 ? this.getOptions().limit : limit + 1;
            this.queryparams.messages[thread].limit = limit;

            messageContainer.empty().removeClass('hide');
            messageArea.mCustomScrollbar('update');
            $('div.uiScrollableAreaContentTopLoadWrap').css('height', '100%');
        } else {
            if (!this._currentData.more) {
                return false;
            }

            this.queryparams.messages[thread].last = this._currentData.last;
        }

        $.when(Core.ajaxLoadMessage(this.queryparams, jid, type))
            .done(function() {
                self._xhrLoadMessage = false;
                var response = arguments[0];

                if (Room.getCurrentRoom().jid !== jid) {
                		return false;
                }
                
                if (!response) return false;
                messageArea.show();

                self._currentData.more = response.more;
                if (!Util.isEmptyObject(response.messages)) {
                    var currentRoom = Room.getCurrentRoom(),
                        thread = currentRoom.thread_id,
                        offset = self.queryparams.messages[thread].offset,
                        prevHeight = messageArea.find('.mCSB_container').height();

                    self.queryparams.messages[thread].offset = offset + limit;

                    self.viewMessage(messageContainer, response);
                    self._currentLoadType = 'loadmore';

                    messageContainer.prev().removeClass('hide');
                    if (!response.more) {
                        messageContainer.prev().addClass('hide');
                    } else {
                        messageContainer.prev().find('.more').text(response.total);
                    }

                    if (type == 'reload') {
                        var realMessageHeight = messageContainer.height(),
                            marginTop = $('#messagesAreaWrap').outerHeight(true) - realMessageHeight - 26 - 26;

                        marginTop = marginTop > 0 ? marginTop : '';
                        $('#messagesAreaWrap div.uiScrollableAreaContentTopLoadWrap').css('height', marginTop);

                        messageArea.mCustomScrollbar('update');
                        if (self.getMessageScrollTop() !== 0) {
                            messageArea.mCustomScrollbar('scrollTo',
                                Math.abs(self.getMessageScrollTop()), {
                                    scrollInertia: 0
                                });
                        } else {
                            messageArea.mCustomScrollbar('scrollTo', 'bottom', {
                                scrollInertia: 0
                            });
                        }
                    } else {
                        var updataTop = messageArea.find('.mCSB_container').height() - prevHeight;
                        messageArea.mCustomScrollbar('update');
                        messageArea.mCustomScrollbar('scrollTo', updataTop, {
                            scrollInertia: 0
                        });
                    }
                } else {
                    messageContainer.parents('div.uiScrollableAreaContent')
                        .children().eq(0).css('height', '');
                }
            }).fail(function() {
                self._xhrLoadMessage = false;
            });
    };

    /** Function: closeContentLoading
     * 关闭房间列表和聊天内容区域的加载效果
     *
     */
    Message.prototype.closeContentLoading = function() {
        $('#messagesAreaWrap img.wmMasterViewload').addClass('hide')
            .parent().css('heigth', '');
        $('#messagesAreaWrap').removeClass('loadInfo');
    };

    Message.prototype.getMessageContainer = function() {
        return $(this._options.message_container);
    };

    Message.prototype.getMessagesArea = function() {
        return $(this._options.message_area);
    };

    /** Function: openContentLoading
     * 开启聊天内容区域的加载效果
     *
     */
    Message.prototype.openContentLoading = function() {
        $('#messagesAreaWrap').addClass('loadInfo');
        $('#messagesAreaWrap').find('.wmMasterViewload').removeClass('hide');
    };

    Message.prototype.loadSelectRoom = function(jid) {
    		var self = this;
        var currentRoom = Room.getRoom(jid);
        var roomItem = MessageRoom.getRoomListItem(jid);

        roomItem.removeClass('hasUnread');
        
        $(document).trigger('readstate', [jid, 'read']);
        currentRoom.unread = 0;
        
        Room.setCurrentRoom(currentRoom);
        self.selected = jid;
        
        $('#sendTextarea').data('wallscript').updateDefaultPostData({
        		'target_id': currentRoom.thread_id,
        		'client_target_id': currentRoom.jid
        });

        this.headerCreate(currentRoom);
        $('#messagesAreaWrap').prev().empty();

        self.resizePage();
        var chatOption = {
            thread_id: currentRoom.thread_id,
            offset: 0,
            limit: 20,
        };

        self.resetparams();
        self.start(chatOption);

        self.messageLoad('reload');
    };
    
    /** Function: beforeLoadSet
     *  加载消息前的设置
     *
     * Parameters:
     *   (Object) item - DOM
     *
     */
    Message.prototype.beforeLoadSet = function(item, changeUrl) {
        var messageContainer = this.getMessageContainer(),
        		baseUrl = Project.settings.baseUrl;

        messageContainer.parent().removeClass('hide')
            .siblings('.msgOperate').addClass('hide');

        this.openContentLoading();

        $('#messagesAreaWrap').removeClass('createMessage');
        $('#wmBoxHeader').children('div.wmBoxButton').removeClass('hide');

        count = parseInt(item.find('div.unread span.count').text());
        if (!isNaN(count) && count > 0) {
            item.find('div.unread').addClass('hide').empty();
        }

        if (!$('a.closeMsgSearch').parent().hasClass('hideElem')) {
            $('a.closeMsgSearch').click();
        }

        if (!$('.wmpageTurnClose').parents('div.relative').hasClass('hide')) {
            $('.wmpageTurnClose').click();
        }

        var _currentRoomJid = item.attr('data-roomjid'),
            currentRoom = Room.getRoom(_currentRoomJid),
            roomItem = MessageRoom.getRoomListItem(_currentRoomJid),
            select = $('li.selectedFolder').attr('data-type');

        Room.setCurrentRoom(currentRoom);
        this.selected = _currentRoomJid;

//        var url = baseUrl + '/messages/' + (select == 'index' ? '' : select + '/') + currentRoom.query;
//        Util.history(url);

        $('.mainConverSationUp').empty().append(Mustache.to_html(Template.Message.Header, currentRoom));
//        $(document).trigger('update.title', currentRoom.title);
//        $('#messagesAreaWrap').prev().empty();

        this.resizePage();
        var chatOption = {
            thread_id: currentRoom.thread_id,
            offset: 0,
            limit: 20,
        };

        this.resetparams();
        this.start(chatOption);
        this.messageLoad('reload');
    };

    /** Function: setActiveItem
     *  加载房间聊天内容的点击操作
     *
     * Parameters:
     *   (object) - obj html object
     */
    Message.prototype.setActiveItem = function(obj) {
        var messageArea = this.getMessagesArea(),
            messageContainer = this.getMessageContainer();

        $(".searchLoadInfo").removeClass('searchLoadInfo');
        
        this.setCurrentShow('message');
        if (!obj.hasClass('selected') ||
            messageContainer.children().length === 0) {
        		this.openContentLoading();
        		obj.addClass('selected').siblings('.selected').removeClass('selected');

            _messageScrollTop = 0;
            this.beforeLoadSet(obj);
            messageArea.next().show();
        }
        	
        $("div.sendEditWrap").removeClass('hide');
        return false;
    };

    /** Function: viewMessage
     * Show message.
     *
     * Parameters:
     *   (object) - container html object
     *   (object) - data	json data
     */
    Message.prototype.viewMessage = function(container, result) {
	    	var self = this,
	    		len = Util.objectLength(result.messages),
	        messages = result.messages,
	        more = result.more;
	
	    for (var o in messages) {
	        if (messages.hasOwnProperty(o)) {
	            var messageInfo = $.extend({}, messages[o]);
	            if (len == parseInt(o) + 1) {
	            		this._currentData.last = messageInfo.message_id;
	            }
	
	            if (this._currentShow === 'message' &&
	                $('div[data-id="mid.' + messageInfo.message_id + '"]').length !== 0) {
	                continue;
	            }
	
	            var dataCreateTime = Core.formatMessageCreated(messageInfo.created);
	            if (Util.isEmptyObject(this._messageStart) && parseInt(o) === 0) {
	            		this._messageStart = dataCreateTime;
	            }
	            if (parseInt(o) === 0) {
	                	if (!Util.isEmptyObject(this._currentData) &&
	                			this._currentData.dateString == dataCreateTime.dateString) {
	                    container.find('div:first').remove();
	                } else if (!Util.isEmptyObject(this._currentData) &&
	                		this._currentData.dateString != dataCreateTime.dateString) {
	                		this._currentData = $.extend(this._currentData, dataCreateTime);
	                }
	            }
	            
	            if (Util.isEmptyObject(this._currentData)) {
	            		this._currentData = $.extend(this._currentData, dataCreateTime);
	            } else if (this._currentData.dateString != dataCreateTime.dateString && parseInt(o) !== 0) {
	                var timeHeaderHtml = Mustache.to_html(Template.Message.Log.TimeHeader, {
	                    'timestamp': this._currentData.timestamp
	                });
	
	                container.find('div:first').before(timeHeaderHtml);
	                this._currentData = $.extend(this._currentData, dataCreateTime);
	            }
	
	            messageInfo.float = messageInfo.author == Project.settings.profile_id?'me':'other';
	            messageInfo.timestamp_relative = dataCreateTime.timestamp_relative;
	            self._factoryOfCreateMessageItem(container, messageInfo, 'view', dataCreateTime);
	
	            if (len == parseInt(o) + 1) {
	                if (more) {
	                    var header = Mustache.to_html(Template.Message.Log.TimeHeader, {
	                        'timestamp': this._currentData.timestamp
	                    });
	                		container.find('div:first').before(header);
	                }
	
	                self.closeContentLoading();
	            }
	        }
	    }
    };

    Message.prototype.selected = '';

    Message.prototype.resizePage =  function () {
    		'use strict';
    		var self = this; 
        self.getMessagesArea().mCustomScrollbar('update');
        MessageRoom.getMessageFriend().mCustomScrollbar('update');
    };
    
    return new Message;
});