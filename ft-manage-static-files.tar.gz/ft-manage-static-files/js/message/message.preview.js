define('Preview', ['Mustache', 'Util', 'Template'], function(Mustache, Util, Template) {
    function Preview() {
	   	this.currentPreviewImages = [];
	   	this.listLength = 0;
	   	this.t = 0;
	   	this.canAddTime = false;
	   	this.imgHeight = 0;
	   	this.imgWidth = 0;
	   	this.current_image_index = 0;
	   	this.baseUrl = Project.settings.baseUrl;
    }
	

    /** Function: changeImg
     *  图片切换
     *
     */
    function changeImg() {
        var wH = window.innerHeight - 40,
            wW = window.innerWidth - 430,
            wrapWidth = 0, //保存宽度比较后用到的值
            wrapHeight = 0;

        $('img.spotlight').css('width', '');
        $('img.spotlight').css('height', '');

        if (wH > imgHeight && wW > imgWidth) { //当图片的宽和高都小于窗口大小时执行一下代码
            $('img.spotlight').css('width', imgWidth + 'px');
            $('img.spotlight').css('height', imgHeight + 'px');

            wrapWidth = imgWidth > 520 ? imgWidth : 520;
            wrapHeight = imgHeight > 520 ? imgHeight : 520;

            $('div.stageWrap').css('width', wrapWidth + 'px');
            $('div.stageWrap').css('height', wrapHeight + 'px');
            $('div.stageWrap').css('line-height', wrapHeight + 'px');
            $('div.photoUfiContainer').css('height', wrapHeight + 'px');
            $('div.photoContainer').css('min-width', wrapWidth + 'px');
        } else {
            var i = 0,
                width = 0;
            height = 0;

            if (imgWidth >= imgHeight) {
                wW = wW < 520 ? 520 : wW;
                i = wW * imgHeight / imgWidth; //根据高来确定宽
                width = wW;

                if (i > wH) {
                    if (imgHeight >= wH) {
                        width = imgWidth * 520 / imgHeight;
                        i = 520;
                    } else {
                        width = imgWidth;
                        i = imgHeight;
                    }
                }

                height = i <= 520 ? 520 : i;

                $('img.spotlight').css('width', width + 'px');
                if (i > 520) {
                    $('img.spotlight').css('height', height + 'px');
                }
            } else {
                wH = wH < 520 ? 520 : wH;
                i = imgWidth * wH / imgHeight;
                height = wH;

                if (i > wW) {
                    if (imgWidth >= wW) {
                        height = imgHeight * 520 / imgWidth;
                        i = 520;
                    } else {
                        height = imgHeight;
                        i = imgWidth;
                    }
                }
                width = i <= 520 ? 520 : i;

                $('img.spotlight').css('height', height + 'px');
                if (i > 520) {
                    $('img.spotlight').css('width', i + 'px');
                }
            }

            wrapWidth = width > 520 ? width : 520;
            wrapHeight = height > 520 ? height : 520;

            $('div.stageWrap').css('height', wrapHeight + 'px');
            $('div.stageWrap').css('width', wrapWidth + 'px');
            $('div.stageWrap').css('line-height', wrapHeight + 'px');
            $('div.photoUfiContainer').css('height', wrapHeight + 'px');
            $('div.photoContainer').css('min-width', wrapWidth + 'px');
        }
    }

    /** Function: closePreview
     *  关闭图片浏览
     *
     */
    function closePreview() {
        var div = document.createElement('div');
        $('div#preview').appendTo($(div));
        $(div).remove();

        $(window).unbind('resize.preview');
        $(window).unbind('keydown.preview');
        $(window).unbind('mouseup.preview');

        return false;
    }

    //创建一个img对象
    Preview.prototype.createImgObj = function (photoObj) {
        $('div.stage').css({
            'background': 'url(' + Project.settings.staticServer + 'imgs/notiload.gif) no-repeat',
            'background-position': 'center center'
        });
        $('img.spotlight').attr('src', '').css({
            'width': '',
            'height': ''
        });

        var currentImg = $('img.spotlight').get(0);
        currentImg.src = photoObj.originalUrl; //将当前加载的图片的url赋值给创建的img
        nowPhotoId = photoObj.photo_id;

        imgHeight = parseInt(photoObj.height);
        imgWidth = parseInt(photoObj.width);

        changeImg();
        $('#number').text(parseInt(this.current_image_index) + 1);

        //图片加载完成后获取图片的原始大小
        currentImg.onload = function() {
            $('div.stage').css('background', '');
            $('#photo_id').val(nowPhotoId);
        };

        //判断图判加载是否发生出错
        currentImg.onerror = function() {
            $('div.stage').css('background', '');
        };
    }

    /** Function: getCurrentImageInfo
     *  获取当前图片的信息
     *
     * Parameters:
     *   (Number) - photo_id  图片ID
     */
    Preview.prototype.getCurrentImageInfo = function (photo_id) {
        for (var i in this.currentPreviewImages) {
            if (this.currentPreviewImages[i].photo_id == photo_id) {
                this.currentPreviewImages[i].index = parseInt(i) + 1;
                this.current_image_index = i;
                return this.currentPreviewImages[i];
            }
        }
        return false;
    }

    /** Function: hideElement
     *  现实图标
     *
     */
    function hideElement () {
        $('a.prev').hide();
        $('a.next').hide();
        $('div.photoBottmInfo').hide();
    }

    /** Function: mouseMove
     *  鼠标移动
     *
     */
    Preview.prototype.mouseMove = function () {
    		var self = this;
        clearTimeout(this.t);
        showElement();
        if (this.canAddTime) {
            this.t = setTimeout(function() {
                hideElement();
            }, 3000);
        }
    }

    /** Function: mouseOver
     *  鼠标移入
     *
     */
    Preview.prototype.mouseOver = function () {
    		var self = this;
        clearTimeout(this.t);
        showElement();
        if (this.canAddTime) {
            this.t = setTimeout(function() {
                hideElement();
            }, 3000);
        }
    }

    /** Function: mouseOut
     *  鼠标移出
     *
     */
    Preview.prototype.mouseOut = function () {
    		hideElement();
    }

    /** Function: setPreviewImageList
     *  设置图片现实列表
     *
     * Parameters:
     *   (Object) - list  图片列表
     */
    Preview.prototype.setPreviewImageList = function (list) {
        this.currentPreviewImages = list;
        this.listLength = Util.objectLength(list);
    }

    /** Function: showElement
     *  现实图片列表
     *
     */
    function showElement() {
        $('a.prev').show();
        $('a.next').show();
        $('div.photoBottmInfo').show();
    }

    /** Function: close
     *  关闭图片浏览
     *
     */
    Preview.prototype.close = function() {
        closePreview();
        return false;
    };

    //下一张图片
    Preview.prototype.nextImage = function() {
        if (this.current_image_index < this.listLength - 1) {
            ++this.current_image_index;
        } else {
        		this.current_image_index = 0;
        }

        this.createImgObj(this.currentPreviewImages[this.current_image_index]);
    };

    /** Function: openPreview
     *  打开图片浏览
     *
     * Parameters:
     *   (Object) - imageList  图片列表
     *   (number) - currentSelect  图片ID
     */
    Preview.prototype.openPreview = function(imageList, currentSelect) {
        var self = this;
    		this.setPreviewImageList(imageList);

        imageInfo = this.getCurrentImageInfo(currentSelect);
        imageInfo.siblingsCount = this.listLength;
        imageInfo.noSiblings = function() {
            return self.listLength == 1;
        };

        imgHeight = imageInfo.height;
        imgWidth = imageInfo.width;

        var html = Mustache.to_html(Template.Preview, imageInfo);
        var previewObj = $(html);
        $('body').append(previewObj);

        this.createImgObj(imageInfo);

        $('div.photoShowLeft').on('mousemove', function(e) {
        		self.mouseMove();
            position = e.pageX;
            if (position - parseInt((window.innerWidth - $('div.stageWrap').width()) / 2) < 115) {
                $('a.prev').addClass('_selected');
                $('a.prev').next().removeClass('_selected');
            } else {
                $('a.next').addClass('_selected');
                $('a.next').prev().removeClass('_selected');
            }
        }).on('mouseleave', function() {
        		self.mouseOut();
        });

        if (this.listLength != 1) {
            $('div.stageWrap').click(function(e) {
                clearTimeout(t);
                if (e.target != $('div.photoChoseBtn')[0] &&
                    $(e.target).parents('ul.photoChoseEle').length === 0 &&
                    !$(e.target).hasClass('photoChoseEle')) {
                    if ($('a._selected').hasClass('next')) {
                        self.nextImage();
                    } else {
                    		self.prevImage();
                    }
                } else {
                    t = setTimeout(function() {
                        hideElement();
                    }, 3000);
                }
            });
        }

        $(window).bind('resize.preview', function() {
            changeImg();
        }).bind('mouseup.preview', function(e) {
            var p = $(e.target).parents('div.photoSnowLeftinner');
            var confirm = $(e.target).parents('#facebox_overlay')[0] !== undefined ||
                $(e.target).attr('id') == 'facebox_overlay';
            if (p.length === 0 && !confirm) {
                closePreview();
            }
        }).bind('keydown.preview', function(e) {
            if (e.keyCode == 27) {
                closePreview();
            }
        });

        $('a.prev').hover(function() {
        		this.canAddTime = false;
            $(this).addClass('_selected');
            $(this).next().removeClass('_selected');
        }, function() {
        		this.canAddTime = true;
            $(this).removeClass('_selected');
            $(this).next().addClass('_selected');
        });

        $('a.next').hover(function() {
        		this.canAddTime = false;
        }, function() {
        		this.canAddTime = true;
        });
    };

    //上一张图片
    Preview.prototype.prevImage = function() {
        if (this.current_image_index >= 1) {
            --this.current_image_index;
        } else {
        		this.current_image_index = this.listLength - 1;
        }

        this.createImgObj(this.currentPreviewImages[this.current_image_index]);
    };

    return new Preview;
});