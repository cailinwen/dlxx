define(['Mustache', 'Core', 'Room', 'Template', 'Util','CustomScrollbar'], function(Mustache, Core, Room, Template, Util) {
	
    function MessageRoom() {
    		this._options = {
			roomListWrap: '.allConversations ul',
            message_friend: '.allConversations',
        };
    		
    		this._roomScrollTop = 0;
    		this._loadRoomController = true;
    		this.loading = false;
    		this.loadingRoom;
    		
    		this.MessageModule;
    }
    
    MessageRoom.prototype.setMessageModule = function (module) {
    		this.MessageModule = module;
    };
    
    MessageRoom.prototype.clearRoomShow = function () {
		$(this._options.roomListWrap).empty();
    };
    
    MessageRoom.prototype.clearRoomShow = function () {
		$(this._options.roomListWrap).empty();
    };
    
    /** Function: formatSnippetCreated
     *  格式化房间创建时间
     *
     * Parameters:
     *   (Object) messageDayTime - 创建时间信息
     */
    MessageRoom.prototype.formatSnippetCreated = function(messageDayTime) {
        var phpTimeFormat = parseInt(messageDayTime);
        	var	currentDate = (new Date).getTime()/1000;
        	var formats = Project.settings.formats;
        var year = Util.dateFormat('Y', phpTimeFormat);
        var month = Util.dateFormat('m', phpTimeFormat);
        var day = Util.dateFormat('d', phpTimeFormat), timestamp;
        
        if (year == (new Date).getFullYear()) {
        		if (Util.dateFormat('m', currentDate) == month) {
        			if (Util.dateFormat('d', currentDate) == day) {
        				timestamp = Util.dateFormat(formats['g:ia'], phpTimeFormat);
        				timestamp = Core.timeMultiLanguage(timestamp);
        			} else if(Util.dateFormat('W', currentDate) == Util.dateFormat('W', phpTimeFormat)) {
        				timestamp = Core.weekMultiLanguage('D', phpTimeFormat);
        			} else {
        				timestamp = Util.dateFormat(formats['M j'], phpTimeFormat);
        			}
    			} else {
    				timestamp = Util.dateFormat(formats['M j'], phpTimeFormat);
    			}
        } else {
        		timestamp = Util.dateFormat(formats['m/d/y'], phpTimeFormat);
        }
        
        return timestamp;
    };
    
    MessageRoom.prototype.getMessageFriend = function () {
		var self = this;
		return $(self._options.message_friend);
	};
	
	MessageRoom.prototype.getFirstThread = function() {
	    var roomListContainer = $(this._options.roomListWrap);
	    if (!roomListContainer.children().length) {
	        return false;
	    }
	
	    return roomListContainer.children().eq(0);
	};
	
	MessageRoom.prototype.getRoomListContainer = function() {
	    return $(this._options.roomListWrap);
	};
	
	MessageRoom.prototype.getRoomListItem = function(jid) {
	    var roomListContainer = this.getRoomListContainer();
	    return roomListContainer.find('li[data-roomjid="' + jid + '"]');
	};
	
    /** Function: closeRoomLoading
     *  关闭房间列表加载loading
     *
     */
    MessageRoom.prototype.closeRoomLoading = function() {
    		this.loading = false;
    		var messageFriend = this.getMessageFriend();
    		messageFriend.siblings('img.wmMasterViewload').addClass('hide');
    		messageFriend.removeClass('loadInfo');
    };

    /** Function: openRoomLoading
     *  开启房间加载loading
     *
     */
    MessageRoom.prototype.openRoomLoading = function() {
    		this.loading = true;
    		var messageFriend = this.getMessageFriend();
    		messageFriend.siblings('img.wmMasterViewload').removeClass('hide');
    		messageFriend.addClass('loadInfo');
    };
    
    MessageRoom.prototype.event = function () {
    		var self = this;
    		$(window).unbind('resize.viewroom').bind({
    			'resize.viewroom': function () {
    				var MessageFriend = self.getMessageFriend(),
    		    	    		currentType = $('li.selectedFolder').attr('data-type'),
    		    	    		roomContainer = self.getRoomListContainer();
    		    	    	if (MessageFriend.height() > roomContainer.height() && 
    		    	    			self._loadRoomController ) {
    		    	    		self.ajaxLoadRoom();
    		    	    }
    			}
    		});
    };
    
    /** Function: formatRoomInfo
     *  格式化房间信息
     *
     * Parameters:
     *   (Object) room - 房间信息
     */
    MessageRoom.prototype.formatRoomInfo = function(room) {
    		var self = this;
        var participantList = room.participants;

        if (room.type === 'chat') {
            // 如果是用户对用户，不需要创建聊天室。
            var participant = participantList[0];

            room.user_id = participant.id;
            if (participant.handle) {
                room.query = participant.handle;
            } else {
                room.query = participant.id;
            }
        } else {
            //room.query = 'conversation-' + room.thread_id;
        }

       // room.snippetCreate = self.formatSnippetCreated(parseInt(room.snippet_created));

//        room.showUnreadMessage = function() {
//            return parseInt(room.unread) === 0 || parseInt(room.current_access) === 1;
//        };

//        room.sendContent = function() {
//            var sendContent = Room.roomSnippetContent(room);
//            return sendContent;
//        };

        return room;
    };
    
    /** Function: roomItemBindEvent
     *  给房间列表元素绑定事件
     *
     * Parameters:
     *   (Object) item - 房间列表对象
     */
    MessageRoom.prototype.roomItemBindEvent = function(item) {
    		var self = this;
        item.click(function() {
        		self.MessageModule.setActiveItem($(this));
	    });
    };
    
    MessageRoom.prototype.init = function () {
    		var self = this;
    		this.event();
		$('.uiMenuItem>a').mouseenter(function() {
			$(this).focus().parent().addClass('selected').siblings().removeClass('selected');
		});
		
		this._loadRoomController = true;
		
		$.when(self.ajaxLoadRoom()).always(function () {
			$('.conversationItem:first').trigger('click');
		});
		
		var messageFriend = self.getMessageFriend();
		messageFriend.mCustomScrollbar({
	        scrollInertia: 400,
	        mouseWheel: true,
	        autoHideScrollbar: true,
	        callbacks: {
	            onScroll: function() {
	                var top = messageFriend.find('.mCSB_container').position().top;
                		self.setRoomScrollTop(top);
	            },
	            onTotalScroll:function(){
            			self.ajaxLoadRoom();
	            },
	            onTotalScrollOffset: 60,
	        }
	    });
    };
    
    /** Function: setScrollTop
     * 设置消息页面滚动高度
     * Parameters:
     *   (number) top - 滚动高度
     */
    MessageRoom.prototype.setRoomScrollTop = function(top) {
        this._roomScrollTop = top;
    };

    /** Function: getScrollTop
     * 获取消息页面滚动高度
     */
    MessageRoom.prototype.getRoomScrollTop = function() {
        return this._roomScrollTop;
    };
    
    MessageRoom.prototype.ajaxLoadRoom = function () {
		var self = this,
			currentType = 'index', request = {};
		
	    	if (this.loadingRoom && this.loadingRoom.state() == 'pending') {
	    		return false;
	    }
	    	
	    	if ($('li.selectedFolder').length) {
	    		currentType = $('li.selectedFolder').attr('data-type');
	    	}
	    	
	    if (!this._loadRoomController || this.loading) {
	    		return false;
	    }
	    
	    self.openRoomLoading();
	    
	    var currentQuery = this._loadRoomController;
	    currentQuery = typeof currentQuery == 'boolean' ? {}:currentQuery;
	    request = $.extend(request, currentQuery);
	    
	    request.target_id = Project.settings.profile_id;
	    var dtd = $.Deferred(),
	        baseUrl = Project.settings.baseUrl;
	
	    this.loadingRoom = $.ajax({
	        url: baseUrl + '/ajax/room/room-list',
	        data: request,
	        dataType: 'json',
	        type: 'post',
	        success: function(result) {
		        //	self.closeRoomLoading();
	        		
	            	var messageFriend = self.getMessageFriend(),
	                firstLoad;
	            	
	            if (result.status == 1) {
	            		var response =  $.parseJSON(result.data),
	                    roomList = response.room,
	                    roomListContainer = self.getRoomListContainer(),
	                    currentRoom = {};
	                if (roomList !== undefined) {
	                		var l = Util.objectLength(roomList);
	                    for (var i in roomList) {
	                        if (roomList.hasOwnProperty(i)) {
	                            currentRoom = roomList[i];
	                            currentRoom = self.formatRoomInfo(currentRoom);
	                            Room.setRoomToList(currentRoom);
		                        	if (roomListContainer.length) {
		                        		var participants = $.extend([], currentRoom.participants);
		                        		currentRoom.itemParticipants = participants.splice(0,5);
		                        		
		                        		
//		                        		console.log(currentRoom);
//		                        		var clone = $.extend({}, currentRoom.itemParticipants[0]);
//		                        		currentRoom.itemParticipants.push(clone);
//		                        		var clone = $.extend({}, currentRoom.itemParticipants[1]);
//		                        		currentRoom.itemParticipants.push(clone);
//		                        		var clone = $.extend({}, currentRoom.itemParticipants[0]);
//		                        		currentRoom.itemParticipants.push(clone);
//		                        		var clone = $.extend({}, currentRoom.itemParticipants[0]);
//		                        		currentRoom.itemParticipants.push(clone);
//		                        		var clone = $.extend({}, currentRoom.itemParticipants[0]);
//		                        		currentRoom.itemParticipants.push(clone);
//		                        		var clone = $.extend({}, currentRoom.itemParticipants[0]);
//		                        		currentRoom.itemParticipants.push(clone);
//		                        		var clone = $.extend({}, currentRoom.itemParticipants[0]);
//		                        		currentRoom.itemParticipants.push(clone);
//		                        		var clone = $.extend({}, currentRoom.itemParticipants[0]);
//		                        		currentRoom.itemParticipants.push(clone);
//		                        		var clone = $.extend({}, currentRoom.itemParticipants[0]);
//		                        		currentRoom.itemParticipants.push(clone);
		                        		
		                        		currentRoom.participantLength = currentRoom.participants.length;
		                        		if(currentRoom.participantLength <= 2){
		                        			currentRoom.load_more_display = 'hidden';
		                        		}
		                        		
		                        		
		                        		for (var m in currentRoom.itemParticipants){
		                        			currentRoom.itemParticipants[m].col = m%2 !== 0;
		                        		}
		                        		
	                                var roomItem = Mustache.to_html(Template.Room.Item, currentRoom);
	                                var $roomItemObj = $(roomItem);
                                    roomListContainer.append($roomItemObj);
//	                                $roomItemObj.find('div.sendedContent').empty()
//	                                    .append(currentRoom.sendContent());
	                                self.roomItemBindEvent($roomItemObj);
	                            }
	                        }
	                        
	                        if (i == l - 1) {
	                        		//self.resizeRoomContainer();
	                        		self._loadRoomController = {start: currentRoom.room_sort};
	                        		setTimeout(function () {messageFriend.mCustomScrollbar('update');}, 0);
	                        		
	                        		var MessageFriend = self.getMessageFriend(),
				    		    	    		roomContainer = self.getRoomListContainer();
				    		    	    	if (MessageFriend.height() > roomContainer.height() && response.more) {
	                        			self.ajaxLoadRoom();
	                        		}
	                        }
	                    }
	                } else {
	                		self.MessageModule.closeContentLoading();
	                		self.MessageModule.setEmptyMessageHead();
	                		setTimeout(function () {messageFriend.mCustomScrollbar('update');}, 0);
	                }
	
	                if (!roomList || !response.more) {
	                		self._loadRoomController = false;
	                }
	                
	                if (roomListContainer.length) {
	                    roomListContainer.removeClass('hide').next().addClass('hide');
	                    self.MessageModule.closeContentLoading();
	                }
	            } else {
	            		self.MessageModule.closeContentLoading();
	            		self._loadRoomController = false;
	            }
	        		
	            return dtd.resolveWith(this, [result]);
	        },
	        error: function(jqXHR, textStatus, errorThrown) {
	            return dtd.rejectWith(this, [jqXHR, textStatus, errorThrown]);
	        }
	    });
	
	    return dtd.promise();
	};
    
    return new MessageRoom;
});