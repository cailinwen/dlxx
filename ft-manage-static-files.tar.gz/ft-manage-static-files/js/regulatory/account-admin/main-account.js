requirejs([ '../config' ], function(config) {
	if (Project.settings.isLogin) {
		require([ 'Account' ], function(Account){Account.init(); });
	} else {
		require([ 'Login' ], function(Login) {
			Login.init() 
		});
	};
});
