define('UserSearch', ['JqueryDatetimepicker','Mustache'], function () {
	'user strict';
	function UserSearch() {
		this.loadSearch;
		this.userInforLists = $('.userInforLists');
		this.form = $("#userSearchForm");
		this.searchContainer = $('.userInforListWrap');
	}
	
	function isValidDate(d) {
		if ( Object.prototype.toString.call(d) !== "[object Date]" )
		    return false;
		return !isNaN(d.getTime());
	}
	
	UserSearch.prototype.init = function () {
		this.tabulationForm($('.tabulationSearch'));
	};
	
	
	UserSearch.prototype.tabulationForm = function(searchButton){
		var self = this, tpl = null;
		searchButton.unbind('click').bind('click',function(e){
			e.preventDefault();
			var $this = $(this);
			self.loadSearch = $.ajax({
				url: self.form.get(0).action,
				data: self.form.serialize(),
				dataType: 'json',
				type: 'post',
				success: function (result) {
					if (result.status == '1') {
						var data = $.parseJSON(result.data);
						$(self.form.start).val(data.last);	
						tpl = $(data.html);
						$this.closest('.search-filter').next('.user-search-res').html(tpl);
						tpl.slideDown();
					}
				}
			});
		});
	};
	return new UserSearch;
});

