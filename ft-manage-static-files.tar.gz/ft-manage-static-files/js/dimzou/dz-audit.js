__F('DZAudit', ['jquery'], function(require, module, exports){
	'use strict';
	
	var defaults = {
			loadingImg : Project.settings.staticServer + 'imgs/left_strip.gif',
			loadingImg16 : '<img class="loading16" src="' + Project.settings.staticServer + 'imgs/loading_16.gif">',
			blockEls: ['p', 'ol', 'ul', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'div'],
			pageCount : 20,
		};
	
	function DZAudit(opts) {
		opts && $.extend(true, defaults, opts);
		this.showAuditUrl = Project.settings.baseUrl + '/dimzou/audit/ajaxGetArtById';
		this.auditListUrl = Project.settings.baseUrl + '/dimzou/audit/getArtsByCate';
		this.approvedUrl = Project.settings.baseUrl + '/dimzou/audit/approved';
		this.vetoingUrl = Project.settings.baseUrl + '/dimzou/audit/vetoing';
		this.wrap = $('.diWrap');
		this.jsAuditClose = null;
		this.curSort = 1;
		this.categoryName=$('#jsSortName').text();
		this.curStatus = 0;
		this.showAuditLock = false;
		this.loadArtLock = false;
		this.approvedLock = false;
		this.vetoLock = false;
		this.jsAuditListWrap = $('#jsAuditListWrap');
		this.jsShowAuditPage = this.wrap.find('.jsShowAuditPage');
		this.jsChangeTaxonomy = this.wrap.find('.jsChangeTaxonomy');
	}
	
	DZAudit.prototype.init = function() {
		this.handleCateMenu();
		this.handleSearchInput();
		this.scrollMoreArts();
		$(window).resize(tinyViewport);
		$(window).ready(tinyViewport);
		this.addListener( this.jsShowAuditPage, 'click.showAudit', this.showAudit );
		this.addListener( this.jsChangeTaxonomy, 'click.changeTaxonomy', this.changeTaxonomy );
		this.addListener( $('.diAuditNavLink'), 'click.switchStateTab', this.switchStateTab );
//		_parseUrl();
	};
	
	var tinyViewport = function(){
		if ($(window).width()<1752){
			$('html').addClass('tinyViewport');
		}else{
			$('html').removeClass('tinyViewport');
		}
	}
	
	var _addAttrLoadNext = function() {
		$('#jsAuditListWrap').find('.jsAuditTab').eq(-1).attr({'data-isloadnextart': 'false'});
	};
	
	DZAudit.prototype.handleCateMenu = function() {
		$('#diClassMenu,.hasNextlevel').mouseenter(function(){
			$(this).addClass('selectedClass');
		});
		$('#diClassMenu').mouseleave(function(){
			$(this).removeClass('selectedClass');
		});
		$('.hasNextlevel').parent().mouseleave(function(){
			$(this).children('.hasNextlevel').removeClass('selectedClass');
		});
	};
	
	DZAudit.prototype.handleSearchInput = function() {
		$('.dianSearchButton').click(function(){
			if ($(this).parent().hasClass('showSearch')){
				$(this).parent().removeClass('showSearch');
			}else{
				$(this).parent().addClass('showSearch');
			}
		});
		$(document).click(function(e){
			if (!$(e.target).closest('.dianSearchArea').length && !$('.dianSearchArea').is(e.target)){
				$('.dianSearchArea').removeClass('showSearch');
			}
		});
	};
	
	DZAudit.prototype.switchStateTab = function(e, obj) {
		e.preventDefault();
		var _this = this,
			curTab = $(obj).attr('id'),
			type = $(obj).attr('data-type'),
			auditStatus = $(obj).attr('data-status'),
			stateHtml = {'pendingTab': '待审核', 'approvedTab': '通过', 'vetoTab': '否决'};
		
		$(obj).addClass('selected').siblings('.diAuditNavLink').removeClass('selected');
		for ( var key in stateHtml ) {
			$('#' + key).html( stateHtml[key] );
		}
		
		var data = {'taxonomy': this.curSort, 'auditStatus': auditStatus,'taxonomyName':this.categoryName};
	
		var success = function(res) {
			if (res.status == 1) {
				_this.jsAuditListWrap.html(res.data.auditListHtml).attr({'data-offset': res.data.offset}).attr({'data-hasMore': res.data.hasMore});
				$('#newAuditHtml').attr({'data-offset': res.data.offset}).attr({'data-hasMore': res.data.hasMore});
				_this.curStatus = auditStatus;
				var h = eval('stateHtml.' + curTab),
					num = eval('res.data.' + type + 'Cnt');
				var tabHtml = h + '(<span id="' + curTab + 'CntSpan">' + num + '</span>)';
				$(obj).html(tabHtml);
				
//				_addAttrLoadNext();
				$('#passCntWrap').html(res.data.passCnt);
				_this.addListener( $('.jsShowAuditPage'), 'click.showAudit', _this.showAudit );
				_this.scrollMoreArts();
				
				var act = type !== 'pass' ? type : 'approved'; 
				console.log(act);
				history.pushState({}, '', Project.settings.baseUrl + '/dimzou/audit/' + act + '?cate='+_this.categoryName.toLowerCase());
			}
		};
		
		_this.ajaxCommit( _this.auditListUrl, data, success );
	};
	
	
	/**
	 * 切换分类
	 */
	DZAudit.prototype.changeTaxonomy = function(e, obj) {
		e.preventDefault();
		var _this = this,
			taxonomy = $(obj).attr('data-taxonomy');
			
		if (this.curSort == taxonomy) return true;
		this.curSort = taxonomy;
		this.categoryName = $(obj).find('span').text();
		$('#pendingTab').trigger('click.switchStateTab');
		$('#jsSortName').html($(obj).find('span').html());
		return;
		
		var data = {'taxonomy' : taxonomy,'taxonomyName':taxonomyName};
		var success = function(res) {
			if ( res['status'] == 1 ) {
				_this.jsAuditListWrap.html(res.data.auditListHtml).attr({'data-offset': res.data.offset}).attr({'data-hasMore': res.data.hasMore});
				$('#newAuditHtml').attr({'data-offset': res.data.offset}).attr({'data-hasMore': res.data.hasMore});
				_this.curSort = taxonomy;
				_this.addListener( $('.jsShowAuditPage'), 'click.showAudit', _this.showAudit );
				_this.scrollMoreArts();
				
				$('#pendingTab').addClass('selected').siblings('.diAuditNavLink').removeClass('selected');
				$('#jsSortName').html($(obj).find('span').html());
				$('#pendingTabCntSpan').html(res.data.pendingCnt);
				$('#passCntWrap').html(res.data.passCnt);
			}
		};
		
		if (this.curSort == taxonomy) return true;
		
		_this.ajaxCommit( _this.auditListUrl, data, success );
	};
	
	DZAudit.prototype.scrollMoreArts = function() {
		var _this = this;
		$(document).unbind('scroll.scrollMoreArts').bind('scroll.scrollMoreArts', function(e){
			if ($('.auditArticleFrame').css('display') === 'block') return true; 
			if ($(window).scrollTop() >= $('.diFooter').offset().top - $(window).height()) {
				_this.loadMoreArts();
			}
		});  
	};
	
	DZAudit.prototype.auditApproved = function(e, obj) {
		e.preventDefault();
		var _this = this,
			artId = $(obj).attr('data-artid'),
			nextId = $(obj).attr('data-nextid'),
			prevId = $('.auditPrevButton').attr('data-art-id'),
			content = $('#auditContent').html(),
			title = $('.auditArticleTile').html(),
			taxonomy = this.curSort,
			offset = this.jsAuditListWrap.attr('data-offset');
		
		var data = {'artId': artId, 'title': title, 'content': content, 'taxonomy' : taxonomy, 'offset': offset, 'nextId': nextId, 'lastArtId': _getPageLastId()},
		bef = function() {
			_this.approvedLock = true;
			$('.auditArticelButtonArea').children().append(defaults.loadingImg16);
		};
	
		var success = function(res) {
			_this.approvedLock = false;
			_removeLoading();
			if (res.status == 1) {
				var listHtml = _getNewList(res.data, artId);
				_this.jsAuditListWrap.html(listHtml);
				_updateChain(prevId, nextId);
				_addAttrLoadNext();
				_this.addListener( $('.jsShowAuditPage'), 'click.showAudit', _this.showAudit );
				_resetScroll();

				_handleNoTab(nextId, artId);
				_increPassCnt();
				_decrePendingCnt();
			} else if (res.status === 0) {
				$('.jsAuditClose').trigger('click.closeAudit');
			}
		};
		
		if (_this.approvedLock) return false;

		_this.ajaxCommit( _this.approvedUrl, data, success, bef );
	};
	
	var _updateChain = function(prevId, nextId) {
		if ( prevId !== '0' ) {
			var prevTab = $('#jsArt_' + prevId).closest('.jsAuditTab'),
				prevOldName = $('#jsArt_' + prevId).attr('name'),
				prevIdAry = prevOldName.split('_'),
				prevNewName = prevIdAry[0] + '_' + prevIdAry[1] + '_' + prevIdAry[2] + '_' + nextId;
			prevTab.find('.jsShowAuditPage').attr('name', prevNewName);
		}
		
		if ( nextId !== '0' ) {
			var	nextTab = $('#jsArt_' + nextId).closest('.jsAuditTab'),
				nextOldName = $('#jsArt_' + nextId).attr('name'),
				nextIdAry = nextOldName.split('_'),
				nextNewName = nextIdAry[0] + '_' + prevId + '_' + nextIdAry[2] + '_' + nextIdAry[3];
			nextTab.find('.jsShowAuditPage').attr('name', nextNewName);
		}
		
	};
	
	var _getPageLastId = function() {
		var endTab = $('#jsAuditListWrap').find('.jsAuditTab:last');
		return endTab.attr('data-artid');
	};
	
	var _handleNoTab = function(nextId, artId) {
		var len = $('#jsAuditListWrap .jsAuditTab').length;
		
		if ( nextId === '0' || !len || $('#jsArt_' + nextId).length === 0 ) {
			if ( !len ) {
				$('#jsAuditListWrap').html('<div class="diTr clearfix"><div style="padding: 200px 20px 400px;font-size: 30px;color: #848484;text-align: center;">NO CONTENT</div></div>');
			}
			$('.jsAuditClose').trigger('click.closeAudit');
		} else {
			$('#jsArt_' + nextId).trigger('click');
		}
		
	};
	
	var _getNewList = function(data, artId) {
		var isEndTab = _isEndTab(artId);
		_delCurTab(data, artId);
		
		if ( !$.isEmptyObject(data.newAudit) && !isEndTab ) {
			$('#jsAuditListWrap').append(data.newAuditHtml);
		} else {
			var newTab = $('#newAuditHtml').find('.jsAuditTab:first');
			$('#jsAuditListWrap').append(newTab);
//			newTab.remove();
		}
		
		var listHtml = '',
			jsAuditTab = $('#jsAuditListWrap').find('.jsAuditTab'),
			len = jsAuditTab.length;
		listHtml += '<div class="diTr clearfix">';
		jsAuditTab.each(function(k, v){
			listHtml += v.outerHTML;
			if ( (k + 1) % 4 == 0 ) listHtml += '</div><div class="diTr clearfix">';
		});
		if ( len % 4 !== 0 ) {
			var n = 4 - len % 4;
			for ( var i = 0; i < n; i++ ) {
				listHtml += '<div class="diTd fl"><div class="diTdm"><div class="diCategory clearfix"></div></div></div>';
			}
		}
		listHtml += '</div>';
		
		return listHtml;
	};
	
	var _delCurTab = function(data, artId){
		$('#newAuditHtml').find('div[data-artid="' + artId + '"]').remove();
		$('#jsAuditListWrap').find('div[data-artid="' + artId + '"]').remove();
		if (!data.newAudit) {
			var nofs = parseInt($('#newAuditHtml').attr('data-offset'));
			var aofs = parseInt($('#jsAuditListWrap').attr('data-offset'));
			$('#newAuditHtml').attr('data-offset', --nofs);
			$('#jsAuditListWrap').attr('data-offset', --aofs);
		}
	};
	
	var _isEndTab = function(artId) {
		var endTab = $('#jsAuditListWrap').find('.jsAuditTab:last'),
		endTabId = endTab.attr('data-artid');
		return artId === endTabId;
	};
	
	DZAudit.prototype.auditVeto = function(e, obj) {
		var nextId = $(obj).attr('data-nextid'),
			artId = $(obj).attr('data-artid');
		
		$('#auditApproved').hide();
		$('#auditVeto').hide();
		$('#vetoConfirm').show();
		$('#vetoCancel').show();
//		$(obj).parent().prepend('<a class="dib auditArticelButton" id="vetoConfirm" style="background-color: #44ACE8;" href="javascript:void(0);" data-artid="'+artId+'" data-nextid="'+nextId+'">确定</a>\
//				<a class="dib auditArticelButton" id="vetoCancel" style="background-color: gray;" href="javascript:void(0);" data-artid="'+artId+'" data-nextid="'+nextId+'">取消</a>');

		$('#auditContent').children().unbind('mouseenter.addBox').bind('mouseenter.addBox', function(){
			if ($(this).closest('.auditVetoComments').length) return false;
			$(this).wrap('<div class="auditVetoComments"></div>');
			$(this).after('<div class="auditVetoCommentBox"><textarea class="auditVetoCommentTextarea" placeholder="否决原因？"></textarea></div>');
			$(this).next().find('textarea').focus().autosize();
			$(this).parent().mouseleave(_removeCommentBox);
		});
		
		this.addListener( $('#vetoConfirm'), 'click.vetoConfirm', this.vetoConfirm );
		this.addListener( $('#vetoCancel'), 'click.vetoCancel', this.vetoCancel );
	};
	
	var _removeCommentBox = function () {
		if ($(this).find('textarea').val() !== '') return false;
		var blockStr = defaults.blockEls.join(',');
		$(this).children(blockStr).not('.auditVetoCommentBox').replaceAll(this);
	};
	
	DZAudit.prototype.vetoCancel = function(e, obj) {
		e.preventDefault();
		
		$('#vetoConfirm').hide();
		$('#vetoCancel').hide();
		$('#auditApproved').show();
		$('#auditVeto').show();
		
		var blockStr = defaults.blockEls.join(',');
		$('.auditVetoComments').each(function(k){
			$(this).children(blockStr).not('.auditVetoCommentBox').replaceAll(this);
		});
		$('#auditContent').children().unbind('mouseenter.addBox');
	};
	
	DZAudit.prototype.vetoConfirm = function(e, obj) {
		e.preventDefault();
		var _this = this,
			reasoninfo = [],
			content = $('#auditContent').html(),
			title = $('.auditArticleTile').html(),
			offset = this.jsAuditListWrap.attr('data-offset'),
			taxonomy = this.curSort,
			prevId = $('.auditPrevButton').attr('data-art-id'),
			nextId = $(obj).attr('data-nextid'),
			artId = $('.auditArticleFrame').attr('data-artid');
		
		$('.auditVetoComments').each(function(k){
			var pid = $(this).children(':first').attr('data-origin'),
				pid = pid ? pid : '',
				reason = $(this).find('.auditVetoCommentTextarea').val();
			reasoninfo.push({'pid': pid, 'reason': reason});
		});
		
		var data = {'artId': artId, 'title': title, 'content': content, 'reasoninfo': JSON.stringify(reasoninfo), 'taxonomy' : taxonomy, 'offset': offset, 'lastArtId': _getPageLastId()},
			bef = function() {
				_this.vetoLock = true;
				$('.auditArticelButtonArea').children().append(defaults.loadingImg16);
			};

		var success = function(res) {
			_this.vetoLock = false;
			_removeLoading();
			if (res.status == 1) {
				var listHtml = _getNewList(res.data, artId);
				_this.jsAuditListWrap.html(listHtml);
				_updateChain(prevId, nextId);
				_addAttrLoadNext();
				_this.addListener( $('.jsShowAuditPage'), 'click.showAudit', _this.showAudit );
				_resetScroll();

				_handleNoTab(nextId, artId);
				_decrePendingCnt();
			} else if (res.status === 0) {
				$('.jsAuditClose').trigger('click.closeAudit');
			}
		};
//		console.log(_this.vetoLock, reasoninfo);
		if (_this.vetoLock) return false;
		if ($.isEmptyObject(reasoninfo)) {
			alert('请填写否决原因！');
			return false;
		}
		_this.ajaxCommit( _this.vetoingUrl, data, success, bef );
	};
	
	var _removeLoading = function() {
		$('.loading16').remove();
	};
	
	var _increPassCnt = function() {
		var passCntWrap = $('#passCntWrap'),
			curCnt = passCntWrap.html();
		passCntWrap.html( ++curCnt );
	};
	
	var _decrePendingCnt = function() {
		var pendingTabCntSpan = $('#pendingTabCntSpan'),
			curCnt = pendingTabCntSpan.html();
		pendingTabCntSpan.html( --curCnt );
	};
	
	DZAudit.prototype.loadMoreArts = function() {
		var _this = this,
			taxonomy = this.curSort,
			auditStatus = this.curStatus,
			offset = this.jsAuditListWrap.attr('data-offset'),
			hasMore = this.jsAuditListWrap.attr('data-hasMore'),
			lastArtId = this.jsAuditListWrap.find('.jsAuditTab:last').attr('data-artid');
		
		var data = {'taxonomy' : taxonomy, 'offset': offset, 'auditStatus': auditStatus, 'lastArtId': lastArtId},
			bef = function() {
				_this.loadArtLock = true;
			};
		
		var success = function(res) {
			_this.loadArtLock = false;
			if (res.status == 1) {
				_this.jsAuditListWrap.append(res.data.auditListHtml).attr({'data-offset': res.data.offset}).attr({'data-hasMore': res.data.hasMore});
				$('#newAuditHtml').attr({'data-offset': res.data.offset}).attr({'data-hasMore': res.data.hasMore});
				_this.addListener( $('.jsShowAuditPage'), 'click.showAudit', _this.showAudit );
			}
		};
		
		if (_this.loadArtLock || hasMore === 'false') return false;
		_this.ajaxCommit( _this.auditListUrl, data, success, bef );
	};
	
	DZAudit.prototype.showAudit = function(e, obj) {
		e.preventDefault();
		var _this = this,
			full = $(obj).attr('name'),
			idAry = full.split('_'),
			current_id = idAry[2],
			wrapStyle = $('.diWrap').attr('style') || '';
		
		this.wrap.data({style: wrapStyle}).css({position: 'fixed', top: -1 * $('body').scrollTop(), left : 0, right: 0});
		
		var data = { 'art_id': current_id, 'pre': idAry[1], 'next': idAry[3] };
		var bef = function() {
			_this.showAuditLock = true;
		};
		var	success = function(res) {
			_this.showAuditLock = false;
			if(res.status == 1){
				$('.auditArticleFrame').remove();
				$('body').append(res.data.view);
				
				if ( res.data.artInfo.is_audit === '2' ) {
					$.each(res.data.reasons, function(k){
//						console.log(this);
						var pid = this.paragraphs_id;
						_wrapVetoBox($('#auditContent').children('[data-origin="' + pid + '"]'), this.reason);
					});
				}
				
				var isLoadNextArt = $(obj).closest('.jsAuditTab').attr('data-isloadnextart');
				if ( $('#newAuditHtml').attr('data-hasMore') === 'true' && isLoadNextArt === 'false' ){
					_handleList.call(_this, obj, current_id);
				}

				_this.jsAuditClose = $('body').find('.jsAuditClose');
				_this.jsAuditSwitch = $('body').find('.jsAuditSwitch');
				_this.addListener( _this.jsAuditClose, 'click.closeAudit', _this.closeAudit );
				_escClose();
				_this.addListener( _this.jsAuditSwitch, 'click.switchArt', _this.switchArt );
//				_keySwithArt();
				_this.addListener( $('#auditApproved'), 'click.auditApproved', _this.auditApproved );
				_this.addListener( $('#auditVeto'), 'click.auditVeto', _this.auditVeto );
				
				$(window).scroll(auditSwitch);
				$(window).resize(auditSwitch);
				auditSwitch();
			}
		};
		
		if (this.showAuditLock) return false;
		
		this.ajaxCommit( this.showAuditUrl, data, success );
		
	};
	
	var _escClose = function() {
		var KEYCODE_ESC = 27;
		$(document).keyup(function(e){
			if (e.which === KEYCODE_ESC) $('.jsAuditClose').click();
		});
	};
	
	var _keySwithArt = function() {
		var KEYCODE_LEFT = 37,
			KEYCODE_RIGHT = 39;
		$(document).keyup(function(e){
			if ( e.which === KEYCODE_LEFT ) $('.auditPrevButton').click();
			if ( e.which === KEYCODE_RIGHT ) $('.auditNextButton').click();
		});
	};
	
	var _handleList = function(obj, current_id) {
		var _this = this,
			offset = this.jsAuditListWrap.attr('data-offset'),
			data = {'taxonomy': this.curSort, 'auditStatus': this.curStatus, 'offset': offset, 'lastArtId': current_id},
			def = _this.ajaxCommit( _this.auditListUrl, data );
		
		var succ = function(res) {
			if (res.status == 1) {
				if ( $.isEmptyObject(res.data.auditList) ) {
					return;
				}
				
				$(obj).closest('.jsAuditTab').attr({'data-isloadnextart': 'true'});
				$('#newAuditHtml').attr({'data-offset': res.data.offset}).attr({'data-hasMore': res.data.hasMore});
				
				$('#newAuditHtml').append(res.data.auditListHtml);
				$('.auditNextButton').attr({'data-art-id': res.data.auditList[0].art_id});
				_this.addListener( $('.jsShowAuditPage'), 'click.showAudit', _this.showAudit );
//				_this.scrollMoreArts();
			}
		};
		
		def.done(succ);
	};
	
	var _modifyTabName = function(obj, nextId) {
		var jsAuditTab = $(obj).closest('.jsAuditTab'),
			newName = $(obj).attr('name') + nextId;
		
		jsAuditTab.find('.jsShowAuditPage').attr({'name': newName});
	};
	
	var _wrapVetoBox = function(block, reason){
		block.wrap('<div class="auditVetoComments"></div>');
		block.after('<div class="auditVetoCommentBox"><textarea class="auditVetoCommentTextarea" placeholder="否决原因？" disabled>' + reason + '</textarea></div>');
	};
	
	var auditSwitch = function () {
		if (!$('a.auditPrevButton').length || !$('a.auditNextButton').length) return false;
		$('.jsAuditSwitch').css({position: 'relative', top: $(window).height()/2 + $('body').scrollTop()});
	}
	
	DZAudit.prototype.switchArt = function(e, obj) {
		var artid = $(obj).attr('data-art-id'),
			arttabid = 'jsArt_' + artid;
		
		if ( !artid ) return true;
		_resetScroll();
		$('#' + arttabid).trigger('click');
	};
	
	var _resetScroll = function() {
		var top = parseInt($('.diWrap').css('top')) * -1;
		$('.diWrap').attr({style: $('.diWrap').data('style')});
		$('body').scrollTop(top);
	};
	
	var _parseUrl = function() {
		var action,
			curUrl = window.location.href;
		console.log(curUrl.indexOf('?'));
		if (curUrl.indexOf('?')) {
			console.log(curUrl.split('?'));
			var basu = curUrl.split('?').shift();
			console.log(basu);
			action = basu.split('/').pop();
		} else {
			action = curUrl.split('/').pop();
		}
		$('#' + action + 'Tab').trigger('click.switchStateTab');
		console.log(action);
	};
	
	DZAudit.prototype.closeAudit = function(e, obj) {
		_resetScroll();
		$('.auditArticleFrame').hide();
	};
	
	DZAudit.prototype.addListener = function( obj, evt, method ) {
		var _this = this,
			fn = function(e) {
			method.call(_this, e, this);
		};
		
		obj.unbind(evt).bind(evt, fn);
	};
	
	/**
	 * ajax提交
	 */
	DZAudit.prototype.ajaxCommit = function( url, data, success, bef ) {
		return $.ajax({
			url : url,
			type : 'POST',
			dataType : 'json',
			beforeSend : bef,
			success : success,
			data : data
		});
	};
	
	var arg = function(h, w, n) {
		var r = Math.sqrt(w * h / n);
		return Math.floor(r);
	};
	
	var gcd = function(a, b) {
	    if ( ! b) {
	        return a;
	    }

	    return gcd(b, a % b);
	};
	
	var argtm = function(h, w) {
		var gcm = gcd(h, w);
		if ( gcm === 1 ) {
			w++;
			return argtm(h, w);
		} else {
			return gcm;
		}
	};
	
	var argthm = function(h, w) {
		var r, n;
		var sq = h * w; 
		
		var recurs = function(r, sq) {
			r = r / 2;
			if (isInt(r)) {
				n = sq / r * r;
				if (isInt(n)) {
					return r;
				} else {
					recurs(r, sq);
				}
			} else {
				r++;
				recurs(r, sq);
			}
		};
		
		return recurs(h, sq);
		
	}
	
	var isInt = function(n) {
	    return typeof n == "number" && isFinite(n) && n%1===0;
	};
	
	exports.exports = new DZAudit;
});

__F(['DZAudit'], function(require, module, exports){
	require('DZAudit').init();
});

