define('Category', ['jquery.bootstrap' ,'bootstrap.switch'], function(){
	'use strict';
	
	function Category(){
		
	}
	
	Category.prototype.init = function(){
		this.changeTopCategory();
		this.addNewNode();
		this.auditInsOrDelNode();
		this.deleteCategory();
		this.triggerDeleteCategory();
		this.editCategory();
		this.switchCategoryEvent();

		
	}
	
	
	Category.prototype.switchCategoryEvent = function(){
		var switchOption = {size:'mini',onText:'ON',offText:'OFF',onColor: 'success'}; 
		$("input[name='isPublic']").bootstrapSwitch(switchOption).on('switchChange.bootstrapSwitch', function(event, state) {
			var liObj = $(this).closest('li'), params = {};
			params.state = state ? 1 : 0;
			params.code = liObj.attr('data-code');
			params.level = liObj.attr('data-level');
			$.post('/category/switch-category', params,function(returnData){window.location.assign("/category");},'json');
		});
	}
	
	
	Category.prototype.editCategory = function(){
		var _this = this;
		var dbckFun = function(elem){
			var $self = $(elem);
			var nameObj = $self.find('.category_name');
			var old_name = nameObj.text();
			nameObj.attr('contentEditable',true);
			nameObj.addClass('editCname');
			nameObj.unbind().blur(function(e){
				e.preventDefault();
				$(this).removeClass('editCname').removeAttr('contentEditable');
				var new_name = $(this).text();
				if(new_name==old_name || $.trim(old_name)==''){
					return false;
				}
				$.post('/category/editCategoryName', 
					{code: $self.attr('data-code'), new_name: new_name, old_name: old_name},function(){},'josin');
			});
		}
		$('.tcate li, .scate li').on('dblclick', function(){ dbckFun(this); });
	}
	
	Category.prototype.deleteCategory = function(){
		var clckFun = function(elem){
			var $this = $(elem), modalObj = $('#delCategoryModal');
			var liObj = $this.closest('li');
			modalObj.modal('show');
			$('button[name=delCategoryBtn]').unbind().click(function(){
				$.post( 
					'/category/delete-category',
					{code: liObj.attr('data-code'), level: liObj.attr('data-level')}, 
					function(returnData){},
					'json'
				);
				modalObj.modal('hide');
				liObj.remove();
			});
		}
		$('.tcate li, .scate li, .specific_things li').find('button[aria-label="Close"]').on('click', function(){ clckFun(this); return false; })
	};
	
	
	Category.prototype.triggerDeleteCategory = function(){
		$('.tcate li, .scate li, .specific_things li').on('mouseenter',function(){
			$(this).find('button[aria-label="Close"]').removeClass('invisible');
		}).on('mouseleave',function(){
			$(this).find('button[aria-label="Close"]').addClass('invisible');
		});
	}
	
	
	
	Category.prototype.changeTopCategory = function(){
		var _this = this, clickCount = 0;
		$('.tcate li').click(function(){
			var $this = $(this);
			if($this.find('input[name=newNodeName]').length){
				return false;
			}
			if( clickCount && $this.hasClass('active') ){
				return false;
			}else{
				$this.closest('.tcate').find('.active').removeClass('active');
				$this.addClass('active');
			}
			var params = {  pcode: $this.attr('data-code') };
			var subNode = $('input[name=subNode]').val();
			if( !clickCount && subNode ){
				params.sub = subNode;
			}
			$this.find('img').removeClass('hide');
			clickCount++;
			
			if( $this.attr('data-level')=='1'){
				$.get('/category/package-record',{code:params.pcode},function(returnData){
					$this.after($(returnData.data.logHtml));
					_this.auditDropCategory();
				},'json');
				
				
				return false;
			}
			$.get('/category/change-category', params, function(returnData){
//				$this.find('img').addClass('hide');
				var $subNodeHtml = $(returnData.data.html);
				$('.scate').html($subNodeHtml);
				if($this.next().length && $this.next().get(0).tagName=='DIV'){
					$this.next().remove();
				}
				$this.after($(returnData.data.logHtml));
				$('input[name=subNode]').val('');
				_this.auditInsOrDelNode();
				_this.auditDropCategory();
				_this.addNewNode();
				_this.deleteCategory();
				_this.changeSubCategory();
				_this.switchCategoryEvent();
				_this.triggerDeleteCategory();
			},'json');
		});
	};
	
	
	Category.prototype.changeSubCategory = function(){
		var _this = this, clickCount = 0;
		$('.scate li').click(function(){
			var $this = $(this);
			if($this.find('input[name=newNodeName]').length){
				return false;
			}
			if( clickCount && $this.hasClass('active') ){
				return false;
			}else{
				$this.closest('.scate').find('.active').removeClass('active');
				$this.addClass('active');
			}
			var params = {  pcode: $this.attr('data-code') };
			var subNode = $('input[name=subNode]').val();
			if( !clickCount && subNode ){
				params.sub = subNode;
			}
			clickCount++;
			$.get('/category/change-sub-category', params, function(returnData){
				var $subNodeHtml = $(returnData.data.html);
				$('.specific_things').html($subNodeHtml);
				if($this.next().length && $this.next().get(0).tagName=='DIV'){
					$this.next().remove();
				}
				$this.after($(returnData.data.logHtml));
//				$('input[name=subNode]').val('');
				_this.auditInsOrDelNode();
				_this.auditDropCategory();
				_this.addNewNode();
				_this.triggerDeleteCategory();
				_this.deleteCategory();
				_this.switchCategoryEvent();
			},'json');
		});
	};
	
	
	
	/**
	 * 添加分类
	 */
	Category.prototype.addNewNode = function(){
		$('button[name=addNode]').click(function(){
			var $this = $(this);
			var liObj = $this.closest('li');
			var nameObj = liObj.find('input[name="newNodeName"]');
			var level1 = liObj.attr('data-level1');
			var level2 = liObj.attr('data-level2');
			var level3 = liObj.attr('data-level3');
			if( nameObj.val() != '' ){
				$.post( '/category/add-category', 
					{category_name: nameObj.val(), codeLevel: liObj.attr('data-level'), level1: level1, level2: level2, level3: level3}, 
					function(returnData){
						if(returnData.status){
							liObj.after(returnData.data.html);
							window.location.assign("/category");
						}else{
							alert(returnData.info);
						}
					},
					'json'
				);
			}else{
				return false;
			}
			nameObj.val('');
			return false;
		});
	};
	
	/**
	 * 审核添加和删除
	 */
	Category.prototype.auditInsOrDelNode = function(){
		var _this = this;
		$('button[name=auditBtn]').unbind().click(function(){
			var $this = $(this);
			var audit_status = $this.attr('data-audit');
			var liObj = $this.closest('li');
			var category_name = liObj.find('.category_name').text();
			var codes = liObj.attr('data-code');
			var audit_op = liObj.attr('data-op');
			var level = liObj.attr('data-level');
			$.post(
				'/category/audit-category',
				{category_name: category_name, level: level, code: codes, audit_op: audit_op, audit_status: audit_status},
				function(returnData){
					if(returnData.status){
						if(audit_status=='0'){
							liObj.remove();
							alert(returnData.info);
						}else{
							var tpl = '<button type="button" class="close hide" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
							liObj.removeAttr('data-op').removeClass('diffInserted').find('.pull-right').html($(tpl));
							_this.triggerDeleteCategory();
						}
						window.location.assign("/category");
					}
			},'json');
			return false;
		});
	};
	
	
	
	
	
	
	
	
	Category.prototype.auditDropCategory = function(){
		var _this = this;
		$('button[name=auditDropBtn]').click(function(){
			var $this = $(this), params = {};
			var op_ids = $(this).closest('li').attr('data-opid');
			params.audit_status = $(this).attr('data-audit');
			params.code = $(this).closest('li').attr('data-code');
			params.audit_op = $(this).closest('li').attr('data-op');
			if(op_ids){
				params.opids = op_ids;
				params.category_name = $(this).closest('li').find('.category_name').text();
			}else{
				if( params.audit_status==1 ){
					var pkgObj = $(this).closest('li').next().find('input[type="radio"]');
					var checkedPkgObj = $(this).closest('li').next().find('input[type="radio"]:checked');
					if( pkgObj.length && !checkedPkgObj.length ){
						alert('请选择包名称');
						return false;
					}
					params.package_name = checkedPkgObj.val();
				}
			}
			$.post('/category/auditDropCategory', params, function(returnData){
				if(returnData.status){
					if(params.audit_status==1){
						$this.closest('li').remove();
					}else{
						window.location.assign("/category");
					}
					window.location.assign("/category");
				}else{
					alert(returnData.info);
				}
			},'json');
			return false;
		});
	};
	
	
	
	
	
	
	
	return new Category;
});
require(['Category'], function(Category){
	Category.init();
});