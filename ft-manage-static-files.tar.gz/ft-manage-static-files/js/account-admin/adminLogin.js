
define('AdminAccount', ['jquery'], function(){
	function AdminLogin() {
		
	}
	
	
	AdminLogin.prototype.init = function(){
		if($('.loginBgArea').length){
			this.logIn();
		}else{
			this.transTab();
		}
		this.navNeedRequestArray = ['rUsers','rUserLoginRecord','addRuser'];
	}
	
	

	AdminLogin.prototype.logIn = function() {
		var name, pwd, error = $('.loginError');
		$('.loginButton').unbind('click.login').bind('click.login',function(){
			name = $('input[name="username"]').val();
			pwd = $('input[name="password"]').val();
			if (name == '' || pwd == '') {
				error.html('请把信息填写完整.');
				return false;
			}
			$.ajax({
				type : "POST",
				url : '/auth',
				data : {
					username : name,
					password : pwd
				},
				beforeSend : function() {
					error.html('');
				},
				success : function(data) {
					window.location.replace(data.data);
				},
				error : function() {
					error.html('信息填写不正确.');
				}
			});
		});
	};
	
	AdminLogin.prototype.addUserFun = function(){
		var addUserForm =  $('.addUserForm'), 
			newUserName = addUserForm.find('input[name="newUserName"]'),
			newPwd = addUserForm.find('input[name="newPwd"]'),
			newPhone = addUserForm.find('input[name="newPhone"]'),
			newEmail = addUserForm.find('input[name="newEmail"]'),
			varialLoad = $('.varialLoad'),
			varial = $('.confirmVarial'),
			confirmVarial = true;
		
		//检测用户名是否存在
		newUserName.blur(function(){
			if($(this).val()=='')	return false;
			$.ajax({
		        type: "POST",
		        url: '/register/existUsername',
		        data: {username:$(this).val()},
		        beforeSend: function(){
		        		varialLoad.removeClass('hide');
		        		varial.html('');
		        },
		        success: function(data){
		        		if(data.status==1){
		        			varialLoad.addClass('hide');
		        			confirmVarial = true;
		        		}else{
	        				confirmVarial = false;
		        		}
		        		varial.html(data.info);
		        },
		        error: function(){
		        		varial.html('检测用户名是否存在失败.');
		        }
		    });
		});
		
		$('.addButton').unbind('click.addUser').bind('click.addUser',function(){
			if(newUserName.val() == '' || newPwd.val() == ''){
				$(this).next().html('必填项必须填写完整');
				return false;
			}
			if(!confirmVarial){
				$(this).next().html('该用户名不可用');
				return false;
			}
			if(newPhone.val()!=='' && !checkPhone(newPhone.val())){
				$(this).next().html('手机号码不正确');
				return false;
			}
			if(newEmail.val()!=='' && !checkMail(newEmail.val())){
				$(this).next().html('邮箱格式不正确');
				return false;
			}
			var $this = $(this);
			$.ajax({
		        type: "POST",
		        url: '/register/executeReg',
		        data: addUserForm.serialize(),
		        beforeSend: function(){
		        		$this.next().html('');
		        },
		        success: function(data){
		        		if(data.status==1){
		        			addUserForm.find('input').val('');
		        			$this.next().html('');
			        		varial.html('');
			        		window.location.reload('/account-manage');
		        		}
		        },
		        error: function(){
		        		$this.next().html('创建用户失败.');
		        }
		    });
		});
		function checkPhone(phone){
			var reg = /^[0-9]{11}$/;
			return reg.test(phone);
		}
		function checkMail(mail){
			var reg = /^([a-zA-Z0-9]+[_|-|.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|-|.]?)*[a-zA-Z0-9]+.[a-zA-Z]{2,3}$/;
			return reg.test(mail);
		}
	};
	
	AdminLogin.prototype.userToggleFun = function(){
		$(document).on('click.on','.toggle',function(){
			var _this = $(this), uid = $(this).attr('data-uid'), status = $(this).attr('data-status');
			$.post('/account-manage/saveUserStatus',{uid:uid,status:status},function(data){
				_this.closest('tr').toggleClass('toggle-on');
				_this.closest('tr').siblings().removeClass('toggle-on');
			},'json');
		});
	};
	
	AdminLogin.prototype.resetFormFun = function(){
		$(document).on('click.reset','.buttonReset',function(){
			var formStyle = $(this).parent().prev();
			formStyle.find('input').val('');
			if(formStyle.is('form')){
				formStyle.find('select').each(function(){ $(this).get(0).selectedIndex = 0; });
			}else{
				$('.confirmVarial').html('');
				$('.addError').html('');
			}
		});
	};
	
	/**
	 * Ajax提交
	 */
	AdminLogin.prototype.ajaxCommit = function(url,type, data, submitSuccess, beforeSubmit) {
		$.ajax({
			url : url,
			type : type,
			dataType : 'json',
			beforeSend : beforeSubmit,
			success : submitSuccess,
			data : data
		});
	};
	
	AdminLogin.prototype.recordsFun = function(){
		var _this = this,
			recordForm = $('.userRecordsFrom'),
			recordsList = $('.recordsTableList');
		$('.recordsSubmit').unbind('click.record').bind('click.record',function(){
			var $this = $(this),
				dateRight = _this.checkDate(recordForm);
			if(dateRight){
				$.ajax({
			        type: "POST",
			        url: '',
			        data: recordForm.serialize(),
			        beforeSend: function(){
			        		$this.prev().html('');
			        		$('.listsLoading').removeClass('hide');
			        },
			        success: function(data){
			        		$('.listsLoading').addClass('hide');
			        		recordsList.find('table').html(recordTemple());
			    			recordsList.mCustomScrollbar('update');
			        },
			        error: function(){
			        		$this.prev().html('查询用户失败.');
			        }
			    });
			}else{
				$this.prev().html('查询条件不正确');
			}
		});
	};
	
	AdminLogin.prototype.transTab = function(){
		var _this = this;
		var manageItem = $('.manageItem'),
			manageRight = $('.manageRight');
		
		$('.usersTableList').mCustomScrollbar({});
		$('.recordsTableList').mCustomScrollbar({});
		//Tab切换
		manageItem.unbind('click.tab').bind('click.tab',function(){
			if($(this).hasClass('selectedItem')) return false;
			var $this = $(this),
				index = $this.index(),
				tab = $this.attr('data-tab');
			$this.addClass('selectedItem').siblings().removeClass('selectedItem');
			if($.inArray(tab, _this.navNeedRequestArray) >-1){
				var url = '/account-manage', type = 'GET', data = {tab:tab}, 
					submitSuccess = function(data){
						data = $.parseJSON(data.data);
						$('.mCustomScrollbar').mCustomScrollbar('destroy');
						manageRight.html(data.viewHtml);
						(index == 0) && $('.usersTableList').mCustomScrollbar({});
						(index == 1) && _this.addUserFun();
						(index == 2) && $('.recordsTableList').mCustomScrollbar({});
						window.history.replaceState({},0,Project.settings.baseUrl+'/account-manage?tab='+tab);
					};
				_this.ajaxCommit(url, type, data, submitSuccess, function(){});
			}
		});
		
		//下属用户状态开启
		_this.userToggleFun();
		//重置表单
		_this.resetFormFun();
		//用户查询记录
		_this.recordsFun();
		
	};
	
	var recordTemple = function(){
		var table;
		for(var $i=0;$i<20;$i++){
			table += '<tr><td>Chritai</td><td>10.0.10.110:880</td><td>2015.02.01</td><td>钟村</td><td>web登录</td></tr>';
		}
	    return table;
	};
	
	AdminLogin.prototype.checkDate = function(form){
		var dataRight = true;
		var name = form.find('input[name="loginUserName"]').val(),
			beginY = form.find('select[name="loginBeginYear"]').val(),
			beginM = form.find('select[name="loginBeginMonth"]').val(),
			beginD = form.find('select[name="loginBeginDay"]').val(),
			endY = form.find('select[name="loginEndYear"]').val(),
			endM = form.find('select[name="loginEndMonth"]').val(),
			endD = form.find('select[name="loginEndDay"]').val();
//		console.log(name,beginY,beginM,beginD,endY,endM,endD);
//		console.log(name=='' && beginY==0 && endY==0);
		if(name=='' && beginY==0 && endY==0){
			dataRight = false;
			return dataRight;
		}
//		console.log((beginY==0 && (beginM!=0 || beginD!=0)),(endY==0 && (endM!=0 || endD!=0)));
		if((beginY==0 && (beginM!=0 || beginD!=0)) || (endY==0 && (endM!=0 || endD!=0))){
			dataRight = false;
			return dataRight;
		}
//		console.log((beginM==0 && beginD!=0),(endM==0 && endD!=0));
		if((beginM==0 && beginD!=0) || (endM==0 && endD!=0)){
			dataRight = false;
			return dataRight;
		}
		if(beginY>endY && endY!=0){
			dataRight = false;
		}else if(beginY==endY){
			if(beginM>endM && endM!=0){
				dataRight = false;
			}else if(beginM==endM){
				if(beginD>endD && endD!=0){
					dataRight = false;
				}else if(beginD<endD && beginD==0){
					dataRight = false;
				}
			}else if(beginM<endM && beginM==0){
				dataRight = false;
			}
		}else if(beginY<endY && beginY==0){
			dataRight = false;
		}
		return dataRight;
	};
	
	return new AdminLogin;
});
require(['AdminAccount'], function(AdminLogin){
	AdminLogin.init();
});
