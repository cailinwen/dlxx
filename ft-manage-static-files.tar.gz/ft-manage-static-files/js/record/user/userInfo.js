$(function(){
	
	function UserRelatedInfo(){
		this.navigationObj = $('.navigation_li');
		this.user_id = $('input[name=cur_user]').val();
		this.loadTabUrl = Project.settings.baseUrl+'/uinfo';
		this.container = $('.navigation_showArea').children();
		this.initTab = false;
	};
	
	/**
	 * 监听事件
	 * @param obj
	 * @param evt
	 * @param method
	 */
	UserRelatedInfo.prototype.addListener = function( obj, evt, method ) {
		var _this = this,
		fn = function(e) {
			method.call(_this, e, this);
		};
		obj.unbind(evt).bind(evt, fn);
	};
	
	/**
	 * ajax提交
	 */
	UserRelatedInfo.prototype.ajaxCommit = function( url, data, submitSuccess, beforeSubmit ) {
		$.ajax({
			url : url,
			type : 'POST',
			dataType : 'json',
			beforeSend : beforeSubmit,
			success : submitSuccess,
			data : data
		});
	};
	
	UserRelatedInfo.prototype.init = function(){
		this.addListener( this.navigationObj, 'click.loadTab', this.loadTab );
		$('.navigation_ul').find('.tabin').trigger('click.loadTab');
	};
	
	/**
	 * Tab型切换页面
	 */
	UserRelatedInfo.prototype.loadTab = function(e, obj){
		e.preventDefault();
		if ($(obj).hasClass('tabin') && this.initTab) return false;
		this.initTab = true;
		var _this = this,
			tab = $(obj).attr('data-tab'),
			data = {tab : tab,'id':_this.user_id},
			beforeSubmit = function () {
				$('.navigation_ul li.tabin').removeClass('tabin');
				$(obj).addClass('tabin');
			},
			submitSuccess = function ( result ) {
				if (result.status === 1) {
					_this.container.html(result.data.view);
					window.history.pushState({},0,_this.loadTabUrl+'?id='+_this.user_id+'&tab='+tab);
					if (tab == 'messages') {
						require(['MessageBundle'], function (Messaging) {
							Messaging.init();
						});
					}else{
						_this.scrollMsc();
					}
				}
			};
		_this.ajaxCommit(_this.loadTabUrl, data, submitSuccess, beforeSubmit);	
	};
	
	UserRelatedInfo.prototype.scrollMsc = function(){
		var area = $('.showAreaScroll');
		if(area.children().height()>area.height()){
			area.mCustomScrollbar({
				scrollInertia: 200,
				autoHideScrollbar: true
			});
		}
	};
	
	var userRelated = new UserRelatedInfo();
	userRelated.init();
});