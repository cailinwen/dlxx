
define('Translation', ['TranslationReview','jquery'], function(){
	var box = $('.outer').not('.hide');
	var isok = $('.isok');    
	var wrap = $('.main_hight');
	var show = box.find('.show');
	var min_width = 1240;
	var winWidth = $(window).width();
	
	function showTranslation(box) {
		for(var m=1;m<=box.length;m++){
			var before = min_width*(m-1),
				after = min_width*(m);
			
			if(winWidth>before&&winWidth<=after){
				more_less(box, m);
				break;
			}else{
				continue;
			}
		}
	}
	
	showTranslation(box);
	
	/**
	 * 窗口改变
	 */
	$(window).resize(function(){
		winWidth =  $(this).width();
		var box = $('.outer').not('.hide');
		showTranslation(box);
	});
	
	$(document).bind('renderPage', function () {
		var box = $('.outer').not('.hide,.hideShow');
		showTranslation(box);
	});
	
	/**
	 * 展开更多翻译
	 */
	show.each(function(index){
		$(this).click(function(){
			winWidth = $(window).width();
			$(this).parents('.model').find('.another').css('display','block');
			$(this).parents('.model').find('.trans_more').css('display','none');
			showTranslation(box);
		});
	});
	
	/**
	 * 瀑布流（交错排序）
	 */
	function more_less(box, m){
		var boxWidth = (100/m);
			box.css('width',boxWidth+'%');
		var boxHeight = new Array();

		for(var i=0;i<m;i++){
			var trBox = new Array();
			boxHeight.push(trBox);
		}
		for(var j=0;j<box.length;j++){
			var hight = new Array();
			if(j<m){
				box.eq(j).css({position: 'absolute',left:(j*boxWidth)+'%',top:0});
				boxHeight[j].push(box.eq(j).height());
			}
			else{
				for(var y=0;y<boxHeight.length;y++){
					var trhight = 0;
					for(var x=0;x<boxHeight[y].length;x++){
						trhight += boxHeight[y][x];
					}
					hight.push(trhight);
				}
				var min = hight[0],w = 0;
				for(var z=0;z<hight.length;z++){
					if(hight[z]<min){
						w=z;
					}
				}
				boxHeight[w].push(box.eq(j).height());
				box.eq(j).css({position: 'absolute',left:(w*boxWidth)+'%',top: hight[w]+'px'});
			}
			
		}
		
		var hei = new Array();
		for(var y=0;y<boxHeight.length;y++){
			var hh = 0;
			for(var x=0;x<boxHeight[y].length;x++){
				hh += boxHeight[y][x];
				hei.push(hh);
			}
		}
		var maxhight = hei[0];
		for(var z=0;z<hei.length;z++){
			if(hei[z]>=maxhight){
				maxhight = hei[z];
			}
		}
		wrap.css('height',maxhight+20);
	}
	
	var translationReview = require('TranslationReview');
	$(window).load(function () {
		translationReview.init({'view': {
				container: $('.main_hight'),
				scroll_load_elem: $('.loadMores'),
			}
		});
	});
	
	$(".jsClearTranslationCache").click(function () {
		$.ajax({
			url: Project.settings.baseUrl + '/translation/clearcache',
			dataType: 'json',
			type: 'get',
			success: function (result) {
				window.location.reload();
			}
		});
	});
	
	$(".jsUnTranslateKey").click(function () {
		$(".jsUnTranslateKey").attr('href', Project.settings.baseUrl + '/translation/getUntranslateKey?language='+ Project.settings.default_language);
	});
	
	$(".jsTriggerLoadTranslation").click(function () {
		var $this = $(this),
			language_title;
		
		language_title = $this.find('a').attr('data-language-title')
		translationReview.loadTranslation($this, language_title);
	});
	
	var publishState;
	$(".jsPublishNewLanguage").click(function () {
		if (!(publishState && publishState.state() == 'pending')) {
			var $this = $(this),
				publish_language = translationReview.getLanguageTitle(),
				baseUrl = Project.settings.baseUrl;
		
			publishState = $.ajax({
				url: baseUrl + '/translation/publish',
				data: {language: publish_language},
				dataType: 'json',
				type: 'POST',
				success: function (result) {
					if (result.status == 0) {
						alert('发布不成功');
					}
				}
			});
		}
	});
	$(".jsTranlsateCheckButton").click(function () {
		var artkey=$(this).closest('.jsTranslateKeyAudit').attr('data-id');
		var baseUrl = Project.settings.baseUrl;
		var $this = $(this);
		publishState = $.ajax({
			url: baseUrl + '/translation/updateCheckStatus',
			data: {artkey:artkey,check_status: $this.hasClass('ok_confirm')?0:1,},
			dataType: 'json',
			type: 'POST',
			success: function (result) {
				if (result.status == 0) {
					alert('不成功');
				}else{
 					$this.toggleClass('ok_confirm');
				}
				
			}
		});
		
	});
	/**
	 * 瀑布流（顺序排列，不交错）
	 */
/*	function moreTD(m){
		var boxWidth = (100/m)-1;
			box.css('width',boxWidth+'%');
		var boxHeight = new Array();
		var hight = new Array();
		for(var i=0;i<m;i++){
			var trBox = new Array();
			boxHeight.push(trBox);
		}
		for(var j=0;j<box.length;j++){
			var td = j%m;
			for(var x=td;x<m;x++){
				box.eq(j).css('left',(x*boxWidth+x+1)+'%');
				boxHeight[x].push(box.eq(j).height());
				var tr = Math.floor(j/m);
				if(tr==0){
					box.eq(j).css('top',0);
				}else{
					var heightSum = 0;
					for(var k=0;k<tr;k++){
						heightSum += boxHeight[x][k];
					}
					box.eq(j).css('top',heightSum+'px');
				}
				break;
			}
			for(var y=0;y<boxHeight.length;y++){
				var trhight = 0;
				for(var x=0;x<boxHeight[y].length;x++){
					trhight += boxHeight[y][x];
					hight.push(trhight);
				}
			}
			var max = hight[0];
			for(var z=0;z<hight.length;z++){
				if(hight[z]>max){
					max = hight[z];
				}
			}
			wrap.css('height',max+'px');
		}
	}*/
});