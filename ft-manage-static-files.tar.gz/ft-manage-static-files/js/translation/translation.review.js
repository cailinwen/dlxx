define('TranslationReview', [], function(){
	
	function TranslationReview() {
		this.options;
		
		this.baseUrl = Project.settings.baseUrl;
		
		this.loadTranslationRequest;
		this.languageTitle;
		this.changeLanguageElem;
		
		this.limit = 5;
		
		this.initTranslateAudit = {};
		this.loading = false;
	}
	
	TranslationReview.prototype.getLanguageTitle = function () {
		return this.languageTitle;
	};
	
	TranslationReview.prototype.loadMoreTranslation = function () {
		var self = this,
			container = self.options.view.container,
			loadmore = self.options.view.scroll_load_elem;
		
		var items = container.children('.hide').not('.hideShow');
		if (!items.length) {
			loadmore.addClass('hideElem');
			return false;
		}
		
		items.each(function(i, obj) {
			if (i < self.limit) {
				$(obj).removeClass('hide');
			} else {
				return false;
			}
		});
		
		items.length <= self.limit? loadmore.addClass('hideElem'):'';
		$(document).trigger('renderPage');
		self.loading = false;
	}
	
	TranslationReview.prototype.init = function (options) {
		this.options = $.extend({}, options);
		
		var self = this,
			container = self.options.view.container,
			loadmore = self.options.view.scroll_load_elem;
			
		this.translationEvent(container);
		this.languageTitle = Project.settings.default_language; 
		
		while (window.innerHeight + $(window).scrollTop() > loadmore.offset().top && 
			container.children('.hide').length) {
			self.loadMoreTranslation();
		}
		
		if (!container.children('.hide').length) {
			loadmore.addClass('hideElem');
		}
		
		$(".jsShowAllTranslate").unbind('click').click(function () {
			var $this = $(this);
			if ($this.hasClass('selected')) {
				return false;
			}
			
			$this.addClass('selected').siblings().removeClass('selected');
			$('.outer').removeClass('hideShow').addClass('hide');
			
			if (loadmore.hasClass('hideElem')) {
				loadmore.removeClass('hideElem');
			}
			
			if ($('.outer').not('.hide').length == 0) {
				self.loadMoreTranslation();
			}
			
			$(document).trigger('renderPage');
			while (window.innerHeight + $(window).scrollTop() > loadmore.offset().top && 
				container.children('.hide').length) {
				self.loadMoreTranslation();
			}
		});
		
		$(".jsShowUnAuditTranslate").unbind('click').click(function () {
			var $this = $(this);
			if ($this.hasClass('selected')) {
				return false;
			}
			
			$this.addClass('selected').siblings().removeClass('selected');
			$('a.ok_confirm').closest('.outer').addClass('hideShow');
			
			if ($('.outer').not('.hide,.hideShow').length == 0) {
				self.loadMoreTranslation();
			}
			
			$(document).trigger('renderPage');
			while (window.innerHeight + $(window).scrollTop() > loadmore.offset().top && container.children('.hide').not('.hideShow').length) {
				self.loadMoreTranslation();
			}
		});
		
		$(document).unbind('scroll').scroll(function () {
			if (self.loading) {
				return false;
			}
			
			var hideItem = $('.main_hight').children('.hide');
			if ($(".jsShowUnAuditTranslate").hasClass('selected')) {
				hideItem = $('.main_hight').children().not('.hide,.hideShow');
			}
			
			if (window.innerHeight + $(window).scrollTop() > loadmore.offset().top && hideItem.length) {
				self.loading = true;
				self.loadMoreTranslation();
			}
		});
		
		$(window).unbind('resize').bind('resize', function () {
			var hideItem = $('.main_hight').children('.hide');
			if ($(".jsShowUnAuditTranslate").hasClass('selected')) {
				hideItem = $('.main_hight').children().not('.hide,.hideShow');
			}
			
			if (window.innerHeight + $(window).scrollTop() >= loadmore.offset().top && hideItem.length) {
				if (self.loading) {
					return false;
				}
				
				self.loading = true;
				self.loadMoreTranslation();
			}
		});
	}
	
	TranslationReview.prototype.ajaxRequest = function (url, method, data, callback) {
		var self = this;
		
		var ajaxCallback = function (data) {
			callback.call(self, data);
		}
		
		$.ajax({
			url: url,
			type: method,
			data: data,
			datatype: 'json',
			success: ajaxCallback,
			error: function () {
				var result = {status: 0, data: data};
				ajaxCallback(result);
			}
		});
	};
	
	TranslationReview.prototype.loadTranslation = function (transElem, language_title) {
		if (this.languageTitle == language_title) {
			return false;
		}
		
		this.languageTitle = language_title;
		Project.settings.default_language = language_title;
		
		this.changeLanguageElem = transElem;
		var loadUrl = this.baseUrl + '/translation/loadTransation';
		if (this.loadTranslationRequest && this.loadTranslationRequest.state() == 'panding') {
			this.loadTranslationRequest.abort();
		}
		
		$(".jsShowAllTranslate").addClass('selected').siblings().removeClass('selected');
		this.loadTranslationRequest = this.ajaxRequest(loadUrl, 'POST', {language: language_title}, this.viewTranslation);
	};
	
	TranslationReview.prototype.loadMore = function (trigger) {
		var self = this;
		var contair = $(trigger).siblings('ul');
		
		contair.find('li.hide').each(function(i, obj) {
			if (i < self.limit) {
				$(obj).removeClass('hide');
			} else {
				return false;
			}
		});
		
		contair.find('li.hide').length == 0? $(trigger).addClass('hideElem'):'';
		$(document).trigger('renderPage');
	}
	
	TranslationReview.prototype.auditReuqest = function (data, dom) {
		var auditUrl = this.baseUrl + '/translation/audit'
		
		dom.siblings().find('.jsTranlsateKeyAuditButton').addClass('disable');
		this.ajaxRequest(auditUrl, 'POST', data, this.auditHandler);
	}
	
	TranslationReview.prototype.auditHandler = function (result) {
		var self = this,
			data = result.data,
			key = data.key,
			auditObj = $('ul[data-id="' + key + '"]');
		
		auditObj.find('.jsTranlsateKeyAuditButton').removeClass('disable');
		if (!result || result.status != 1) {
			auditObj.find('.ok_confirm').removeClass('ok_confirm');
			if ($.trim(key) !== '') {
				var index = typeof self.initTranslateAudit [key] != 'undefined'?self.initTranslateAudit [key]:false;
				if (index !== false) {
					auditObj.find('.jsTranslateMessage').eq(index).find('.jsTranlsateKeyAuditButton').addClass('ok_confirm');
				}
			}
		} else {
			var type;
			if (data.accept == 0) {
				self.initTranslateAudit [key] = false;
				type = 'increment';
			} else {
				type = 'decrement';
				self.initTranslateAudit [key] = auditObj.find('.ok_confirm').closest('.jsTranslateMessage').index();
			}
			
			$('.jsUnCheckTranslate').trigger('audit', [type]);
		}
	}
	
	TranslationReview.prototype.translationEvent = function (dom) {
		var self = this;
		
		dom.find('.jsTranslateKeyAudit').each(function () {
			var $this = $(this),
				key = $this.attr('data-id');
			
			if ($this.find('.ok_confirm').length) {
				var index = $this.find('.ok_confirm').closest('.jsTranslateMessage').index();
				self.initTranslateAudit [key] = index;
			}
		});
		
		/**
		 * 每个模块只能有一个按钮作用
		 */
		dom.find('.outer').each(function(){
			var isok = $(this).find('.isok');
			isok.each(function(index){
				$(this).click(function(){
					if(!$(this).hasClass('ok_confirm')){
						$(this).addClass('ok_confirm');
						isok.not($(this)).removeClass('ok_confirm');
					}else{
						$(this).removeClass('ok_confirm');
					}
				});
			});
		});
		
		dom.find('.trans_more').not('.hideElem').bind('click', function () {
			self.loadMore(this);
		});
		
		dom.find('.jsTranlsateKeyAuditButton').bind('click', function () {
			var $this = $(this),
				translate = $this.closest('.jsTranslateKeyAudit'),
				trans_key = translate.attr('data-translate-key'),
				key = translate.attr('data-id'),
				choseTranslate = $this.closest('.jsTranslateMessage').attr('data-translate-message');
			
			var data = {'trans_key': trans_key, 'trans_message': choseTranslate, 'accept': $this.hasClass('ok_confirm')?1:0,
					 target_locale: self.languageTitle,
					 key: key};
			self.auditReuqest(data, $this);
		});
		
		$('.jsUnCheckTranslate').bind('audit', function (e, type) {
			var originalValue = parseInt($(this).text());
			
			if (isNaN(originalValue)) {
				return ;
			}
			
			if (type == 'increment') {
				++originalValue;
			} else if (type == 'decrement') {
				--originalValue;
			}
			
			if (originalValue >= 0) {
				$(this).text(originalValue);
			}
		});
	}
	
	TranslationReview.prototype.viewTranslation = function (result) {
		var self = this,
			data = result.data,
			container = self.options.view.container,
			loadmore = self.options.view.scroll_load_elem;
		
		if (result.status == 1) {
			self.changeLanguageElem.addClass('selected').siblings().removeClass('selected');
			$translationHtml = $(data.dataHtml);
			container.empty().append($translationHtml);
			
			if (data.percent) {
				$(".diTransProgress").width(data.percent);
				$(".diTransProgressArea").siblings().text(data.percent);
			}
			
			$('.jsTotalAllTranslate').text(data.all);
			$('.jsTotalHasTranslate').text(data.hasTrans);
			$('.jsUnCheckTranslate').text(data.uncheck);
			
			loadmore.removeClass('hideElem');
			$(document).trigger('renderPage');
			self.init(self.options);
		}
	}
	
	return new TranslationReview();
});