# encoding: utf-8

import logging
import rsa
import os
import base64
from pyasn1.codec.der import decoder

from OpenSSL import crypto
from SDKConfig import SDKConfig


class Cert(object):
    certId = None
    key = None
    cert = None


class CertUtil(object):

    __signCerts = {}
    __encryptCert = {}
    __verifyCerts = {} #5.0.0验签证书，key是certId
    __verifyCerts5_1_0 = {} #5.1.0验签证书，key是base64的证书内容
    __x509Store = None

    @staticmethod
    def initSignCert(certPath, certPwd):
        if certPath is None or certPwd is None:
            logging.info("signCertPath or signCertPwd is none, exit initSignCert")
            return
        logging.info("读取签名证书……")
        cert = Cert()
        fs = open(certPath, 'rb')
        pkcs12 = crypto.load_pkcs12(fs.read(), certPwd)
        fs.close()
        pkey = pkcs12.get_privatekey()
        pkey = crypto.dump_privatekey(crypto.FILETYPE_PEM, pkey)
        # pkcs8->pkcs1。妈蛋为什么这种没有写好的库，把我找了一个下午的时间还给我
        pkey = pkey.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "")\
            .replace("\n", "")
        pkey = base64.b64decode(pkey)
        pkey = base64.b64encode(decoder.decode(pkey)[0].getComponentByPosition(2)._value)
        pkey = "-----BEGIN RSA PRIVATE KEY-----\n" + pkey + "\n-----END RSA PRIVATE KEY-----"
        pkey = rsa.PrivateKey.load_pkcs1(pkey, 'PEM')
        cert.key = pkey
        cert.certId = str(pkcs12.get_certificate().get_serial_number())
        cert.cert= pkcs12.get_privatekey()
        CertUtil.__signCerts[certPath] = cert
        logging.info("签名证书读取成功，序列号：" + cert.certId)


    @staticmethod
    def getSignPriKey(certPath=SDKConfig().signCertPath, certPwd=SDKConfig().signCertPwd):
        if not CertUtil.__signCerts.has_key(certPath):
            CertUtil.initSignCert(certPath, certPwd)
        return CertUtil.__signCerts[certPath].cert


    @staticmethod
    def getSignCertId(certPath=SDKConfig().signCertPath, certPwd=SDKConfig().signCertPwd):
        if not CertUtil.__signCerts.has_key(certPath):
            CertUtil.initSignCert(certPath, certPwd)
        return CertUtil.__signCerts[certPath].certId


    @staticmethod
    def initEncryptCert(certPath=SDKConfig().encryptCertPath):
        if certPath is None:
            logging.info("encryptCertPath is none, exit initEncryptCert")
            return
        logging.info("读取加密证书……")
        cert = Cert()
        fs = open(certPath, 'rb')
        c = crypto.load_certificate(crypto.FILETYPE_PEM, fs.read())
        pkey = crypto.dump_publickey(crypto.FILETYPE_PEM, c.get_pubkey())
        cert.cert = rsa.PublicKey.load_pkcs1_openssl_pem(pkey)
        cert.certId = str(c.get_serial_number())
        fs.close()
        CertUtil.__encryptCert[certPath] = cert
        logging.info("加密证书读取成功，序列号：" + cert.certId)


    @staticmethod
    def initRootCert():
        if CertUtil.__x509Store is not None:
            return
        if SDKConfig().rootCertPath is None or SDKConfig().middleCertPath is None:
            logging.info("rootCertPath or middleCertPath is none, exit initRootCert")
            return
        logging.info("start initRootCert")
        fs = open(SDKConfig().middleCertPath, 'rb')
        middleCert = crypto.load_certificate(crypto.FILETYPE_PEM, fs.read())
        fs.close()
        fs = open(SDKConfig().rootCertPath, 'rb')
        rootCert = crypto.load_certificate(crypto.FILETYPE_PEM, fs.read())
        fs.close()
        CertUtil.__x509Store = crypto.X509Store()
        CertUtil.__x509Store.add_cert(rootCert)
        CertUtil.__x509Store.add_cert(middleCert)
        logging.info("initRootCert succeed")

    @staticmethod
    def verifyAndGetVerifyCert(certBase64String):

        if certBase64String in CertUtil.__verifyCerts5_1_0:
            return CertUtil.__verifyCerts5_1_0[certBase64String];

        if SDKConfig().middleCertPath is None or SDKConfig().rootCertPath is None:
            logging.info("rootCertPath or middleCertPath is none, exit initRootCert")
            return None

        if CertUtil.__x509Store is None:
            CertUtil.initRootCert()

        x509Cert = crypto.load_certificate(crypto.FILETYPE_PEM, certBase64String)

        if x509Cert.has_expired():
            logging.info("signPubKeyCert has expired")
            return None

        UNIONPAY_CNNAME  = "中国银联股份有限公司"
        cn = CertUtil.getIdentitiesFromCertficate(x509Cert);
        if SDKConfig().ifValidateCNName.lower() != "false":
            if UNIONPAY_CNNAME != cn :
                logging.error("cer owner is not CUP:" + cn)
                return None
        elif UNIONPAY_CNNAME != cn and cn != "00040000:SIGN": #测试环境目前是00040000:SIGN
            logging.error("cer owner is not CUP:" + cn)
            return None

        try:
            x509StoreContext = crypto.X509StoreContext(CertUtil.__x509Store, x509Cert)
            x509StoreContext.verify_certificate()
            CertUtil.__verifyCerts5_1_0[certBase64String] = x509Cert
            return x509Cert
        except Exception:
            logging.info("validate signPubKeyCert by rootCert failed")
            return None


    @staticmethod
    def getIdentitiesFromCertficate(x509Cert):
        cpnts = x509Cert.get_subject().get_components()
        for cpnt in cpnts:
            key = cpnt[0]
            value = cpnt[1]
            if key == "CN":
                ss = value.split("@")
                if ss is not None and len(ss) > 2:
                    return ss[2]
        return None


    @staticmethod
    def getEncryptKey(certPath=SDKConfig().encryptCertPath):
        if not CertUtil.__encryptCert.has_key(certPath):
            CertUtil.initEncryptCert(certPath)
        return CertUtil.__encryptCert[certPath].cert


    @staticmethod
    def getEncryptCertId(certPath=SDKConfig().encryptCertPath):
        if not CertUtil.__encryptCert.has_key(certPath):
            CertUtil.initEncryptCert(certPath)
        return CertUtil.__encryptCert[certPath].certId


    @staticmethod
    def initVerifyCerts(certDir=SDKConfig().validateCertDir):
        logging.info("读取验签证书文件夹下所有cer文件……")
        files = os.listdir(certDir)
        if len(files) == 0:
            logging.info("请确定[" + certDir + "]路径下是否存在cer文件")
            return
        for f in files:
            if os.path.splitext(f)[1] == ".cer":
                fs = open(certDir + "/" + f, 'rb')
                fCert = crypto.load_certificate(crypto.FILETYPE_PEM, fs.read())
                fs.close()
                cert = Cert()
                cert.certId = str(fCert.get_serial_number())
                cert.cert = fCert
                CertUtil.__verifyCerts[cert.certId] = cert
                logging.info(f + "读取成功，序列号：" + cert.certId)


    @staticmethod
    def getVerifyCertFromPath(certId):
        if len(CertUtil.__verifyCerts) == 0:
            CertUtil.initVerifyCerts()
        if len(CertUtil.__verifyCerts) == 0:
            logging.info("未读取到任何证书……")
            return None
        if CertUtil.__verifyCerts.has_key(certId):
            return CertUtil.__verifyCerts[certId].cert
        else:
            logging.info("未匹配到序列号为[" + certId + "]的证书")
            return None


    @staticmethod
    def getDecryptPriKey(certPath=SDKConfig().signCertPath, certPwd=SDKConfig().signCertPwd):
        if not CertUtil.__signCerts.has_key(certPath):
            CertUtil.initSignCert(certPath, certPwd)
        return CertUtil.__signCerts[certPath].key

    @staticmethod
    def resetEncryptCertPublicKey():
        CertUtil.__encryptCert = {}
        CertUtil.initEncryptCert()


# for i in range(0,100,1):
#     print CertUtil.getSignCertId()
#     print CertUtil.getSignPriKey()


