﻿python2.7.11环境调试
如是其他版本的python，出现问题请自行对应着解决

要装一大堆依赖模块，请尽量用pip安装：
安装easy_install：http://pypi.python.org/pypi/setuptools（windows环境下载那个ez_setup.py安装，注意看提示的路径）
安装pip：easy_install pip
安装其他依赖包：pip install pyOpenSSL cryptography cffi pycparser pyasn1 rsa cherrypy
其中cherrypy是demo用的，sdk本身用不到

Windows下pip安装包报错：Microsoft Visual C++ 9.0 is required Unable to find vcvarsall.bat:
https://www.microsoft.com/en-us/download/details.aspx?id=44266


目录结构

upacp_sdk_python
  │
  ├com.unionpay.acp.sdk ┈┈┈┈┈┈┈┈┈ sdk，其中AcpService为对外接口，其他为内部使用
  │  │
  │  └acp_sdk.ini ┈┈┈┈┈┈┈┈┈ 配置文件，默认使用了测试环境证书方式签名的配置文件
  │
  ├demo
  │  │
  │  ├backRcvResponse.py ┈┈┈┈┈┈┈┈┈ 后台通知演示
  │  │
  │  ├frontRcvResponse.py ┈┈┈┈┈┈┈┈┈ 前台通知演示
  │  │
  │  ├batTrans.py ┈┈┈┈┈┈┈┈┈ 批量交易演示
  │  │
  │  ├batTransQuery.py ┈┈┈┈┈┈┈┈┈ 批量查询演示
  │  │
  │  ├fileDownload.py ┈┈┈┈┈┈┈┈┈ 对账文件下载演示
  │  │
  │  ├multiCertDemo.py ┈┈┈┈┈┈┈┈┈ 多证书签名演示
  │  │
  │  ├multiKeyDemo.py ┈┈┈┈┈┈┈┈┈ 多密钥签名演示
  │  │
  │  ├backTradeDemo.py ┈┈┈┈┈┈┈┈┈ 后台交易演示*
  │  │
  │  ├frontTradeDemo.py ┈┈┈┈┈┈┈┈┈ 前台交易演示*
  │  │
  │  └frontTradeDemo2.py ┈┈┈┈┈┈┈┈┈ 前台交易演示*
  │
  ├lib
  │  │
  │  └bottle.py ┈┈┈┈┈┈┈┈┈ start.py用的轻量级web框架
  │
  └start.py ┈┈┈┈┈┈┈┈┈ demo的web服务启动


demo说明：
*   具体接口字段请参考其他语言开发包demo文件夹下的demo代码。
    eg.
    如果demo里使用了AcpService.createAutoFormHtml，则参考frontTradeDemo代码修改。
    如果demo里使用了AcpService.post，则参考backTradeDemo代码修改。

生产、测试环境证书、配置文件、样例对账文件、样例批量文件等参考其他语言开发包assets文件夹。
注意涉及加密的业务上规定只能用证书方式签名，请勿使用密钥方式签名的配置文件。
其他说明请参考其他语言开发包的readme。



