# encoding: utf-8
from demo import frontTradeDemo, frontRcvResponse, backRcvResponse, backTradeDemo, fileDownload, batTrans, \
    batTransQuery, multiCertDemo, multiKeyDemo, frontTradeDemo2, encryptCerUpdateQuery
from lib.bottle import post, run, get


@get("/")
def index():
    return "<a href='frontTradeDemo'>前台交易示例</a><br>\n" \
           "<a href='frontTradeDemo2'>前台交易示例</a><br>\n"\
           "<a href='backTradeDemo'>后台交易示例</a><br>\n"\
           "<br>\n"\
           "<a href='fileDownload'>对账文件下载示例</a><br>\n"\
           "<a href='batTrans'>批量交易示例</a><br>\n"\
           "<a href='batTransQuery'>批量查询示例</a><br>\n"\
           "<a href='multiCertDemo'>多证书示例</a><br>\n"\
           "<a href='multiKeyDemo'>多密钥示例</a><br>\n"\
           "<a href='encryptCerUpdateQuery'>加密证书更新示例</a><br>\n"


@get('/frontTradeDemo')
def front_trade():
    return frontTradeDemo.getDemoHtml()

@get('/frontTradeDemo2')
def front_trade2():
    return frontTradeDemo2.getDemoHtml()

@get('/backTradeDemo')
def back_trade():
    return backTradeDemo.demoTrade()


@get('/fileDownload')
def file_download():
    return fileDownload.trade()


@get('/batTrans')
def bat_trans():
    return batTrans.trade()


@get('/batTransQuery')
def bat_query():
    return batTransQuery.trade()


@get('/multiCertDemo')
def multi_cert():
    return multiCertDemo.trade()

@get('/multiKeyDemo')
def multi_key():
    return multiKeyDemo.trade()

@post('/frontRcvResponse')
def front_notify():
    return frontRcvResponse.notify()


@post('/backRcvResponse')
def back_notify():
    return backRcvResponse.notify()


@get('/encryptCerUpdateQuery')
def encCertUpdate():
    return encryptCerUpdateQuery.demoTrade()


@post('/test')
def test(): # 测内存泄漏用的挡板
    # return "orderId=20160526231654&certId=68759585097&issInsCode=CMB&respCode=00&encoding=utf-8&bizType=000301&txnType=78&accessType=0&txnTime=20160526231654&signature=IlENMkF3dxnqvEFVcpYT8eGeTBjMVAkEsmbn29kIlS7RBpF2FU1TjBTw3Zav6V/i7AFeTMzCxH7DdRhWjk00gxq4rDbyvB/kFHnInglvW39AE/du0CQLw+aEU6LMC8pSl1RCwYdypRv7VhzasPesZ518ozGejzYmMD3RnXKs1t/KiSwo2I+LOn8kTNBpVeZQwZQcuVLbVk/7QA0RaOwWA55CCcNZD51gmuhF1ye5D/mNQps0S4Zr0ewa25DoIvU2VHreah0hBFrxmK1MDBwgdjsob6rGNUVEqxRdC3a5AkPksqcEvl+evPwJowNgRNTwwsY96pGYjGhL4VY49CdTnQ==&customerInfo=e2VuY3J5cHRlZEluZm89WHZsSVVSWkdTUTJQdVBOK3pxMXRHVmppL2ZXU1p6Qlc0N1FYUFR1QVdodEh6M0dyakJFeklLOGpGS2g1ZUc3MzN6d1RkZWNmaWNuS3QwYlo2VlByM01Da0JzWi93Njh6Q2JHbDRmdWtKZk8wb3d6OXEwMlFHMjYyZjErVHJtKzlSbzM1Z3BVZndYdUw5ei9IdHAwZ1hJb0cwWW81NzZZanpzUWttWU9Ca1NLS0pONXRjNFBzL1RPUFQ5SWsybHdJdlQ1VUg3M3dXdjdpSmM0RDZ0TVBOUTRoWGdIWlZMMTZ1bUhuMys3K3hUVEIvVjZNNk9lb3o0bExtRUZPNExFRVIxZGZEMmxBTDQ1NXFFaG5XVytDdE4yc05ZQjdkc09uVEtBOXFGWHZOckFGYk50MFZDU1I5bjFBbFZ2enJXV3FlWStKM1U4QlFtSUtCSGdPVGVUMFVRPT19&respMsg=成功[0000000]&version=5.0.0&txnSubType=00&signMethod=01&payCardType=01&merId=777290058110097&activateStatus=1"
    return "accessType=0&activateStatus=1&bizType=000301&customerInfo=e2VuY3J5cHRlZEluZm89VkRsSEU0MGRpSFlaYU1kcnR4ZFdHZHhrYldOY0V5MUgxTGhmQVVlbUtZWW5QYWk4UlZZT0p2QmYzUkNJYUxjUktqWm9xY1BMdk1mQWJmZy9pVUpTOFRLRFNLaHB1bTFEOHc3WFdaZ2VPYXVDSGNPbFUzVnVEbk1ZNG9JbUVySFFGUk44c3RxVGxmNHh1ZUthWVFoSzE5NU44RlJ0SXZpM1EyMWVrUTRlTC9qRmxFeTJoUlVKWGxPakRqTWlNbXc5dkRycklWWmp1aE1lU2pDVUI0bEREYjE5aytISDhSdy95M2IrSUtCdmo4L0MvU1o3Ry9hVHlQOEpEbDZ3VVN3UlpXajhmUnB1ZUhQSzk0bVU0VWRDZk1iQitNYXZmd0ZsY2FBUVZ0ZVhmNCtJVTJkOTlibWpMUTBTWkF1UnRZL3IrZHY2UWFoSExTYWdHbzdKVXQrQ2pBPT19&encoding=utf-8&issInsCode=CMB&merId=777290058110097&orderId=20160803090759&payCardType=01&respCode=00&respMsg=成功[0000000]&signMethod=01&txnSubType=00&txnTime=20160803090759&txnType=78&version=5.1.0&signPubKeyCert=-----BEGIN CERTIFICATE-----\r\nMIIEOjCCAyKgAwIBAgIFEAJkAUkwDQYJKoZIhvcNAQEFBQAwWDELMAkGA1UEBhMC\r\nQ04xMDAuBgNVBAoTJ0NoaW5hIEZpbmFuY2lhbCBDZXJ0aWZpY2F0aW9uIEF1dGhv\r\ncml0eTEXMBUGA1UEAxMOQ0ZDQSBURVNUIE9DQTEwHhcNMTUxMjA0MDMyNTIxWhcN\r\nMTcxMjA0MDMyNTIxWjB5MQswCQYDVQQGEwJjbjEXMBUGA1UEChMOQ0ZDQSBURVNU\r\nIE9DQTExEjAQBgNVBAsTCUNGQ0EgVEVTVDEUMBIGA1UECxMLRW50ZXJwcmlzZXMx\r\nJzAlBgNVBAMUHjA0MUBaMTJAMDAwNDAwMDA6U0lHTkAwMDAwMDA2MjCCASIwDQYJ\r\nKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMUDYYCLYvv3c911zhRDrSWCedAYDJQe\r\nfJUjZKI2avFtB2/bbSmKQd0NVvh+zXtehCYLxKOltO6DDTRHwH9xfhRY3CBMmcOv\r\nd2xQQvMJcV9XwoqtCKqhzguoDxJfYeGuit7DpuRsDGI0+yKgc1RY28v1VtuXG845\r\nfTP7PRtJrareQYlQXghMgHFAZ/vRdqlLpVoNma5C56cJk5bfr2ngDlXbUqPXLi1j\r\niXAFb/y4b8eGEIl1LmKp3aPMDPK7eshc7fLONEp1oQ5Jd1nE/GZj+lC345aNWmLs\r\nl/09uAvo4Lu+pQsmGyfLbUGR51KbmHajF4Mrr6uSqiU21Ctr1uQGkccCAwEAAaOB\r\n6TCB5jAfBgNVHSMEGDAWgBTPcJ1h6518Lrj3ywJA9wmd/jN0gDBIBgNVHSAEQTA/\r\nMD0GCGCBHIbvKgEBMDEwLwYIKwYBBQUHAgEWI2h0dHA6Ly93d3cuY2ZjYS5jb20u\r\nY24vdXMvdXMtMTQuaHRtMDgGA1UdHwQxMC8wLaAroCmGJ2h0dHA6Ly91Y3JsLmNm\r\nY2EuY29tLmNuL1JTQS9jcmw0NDkxLmNybDALBgNVHQ8EBAMCA+gwHQYDVR0OBBYE\r\nFAFmIOdt15XLqqz13uPbGQwtj4PAMBMGA1UdJQQMMAoGCCsGAQUFBwMCMA0GCSqG\r\nSIb3DQEBBQUAA4IBAQB8YuMQWDH/Ze+e+2pr/914cBt94FQpYqZOmrBIQ8kq7vVm\r\nTTy94q9UL0pMMHDuFJV6Wxng4Me/cfVvWmjgLg/t7bdz0n6UNj4StJP17pkg68WG\r\nzMlcjuI7/baxtDrD+O8dKpHoHezqhx7dfh1QWq8jnqd3DFzfkhEpuIt6QEaUqoWn\r\nt5FxSUiykTfjnaNEEGcn3/n2LpwrQ+upes12/B778MQETOsVv4WX8oE1Qsv1XLRW\r\ni0DQetTU2RXTrynv+l4kMy0h9b/Hdlbuh2s0QZqlUMXx2biy0GvpF2pR8f+OaLuT\r\nAtaKdU4T2+jO44+vWNNN2VoAaw0xY6IZ3/A1GL0x\r\n-----END CERTIFICATE-----&signature=Os2m8A1yaA6cWdrbo/a8F37Bs1Smde9Tjs2oijqfQiGH8mi+cwkj2HRzD38oOGEU+HfCRk0G+0XSidkubqeJh8RkSF/sKExvuV0BwidhPsqK7dA+mbpaTCr48bEspfEiIPlISmu7rTWmDrD6YnzcHMlmsKjzASMRGsbp8dJGXUtJkafVYjtFiuUHXt+WmheuLBqcn4rKcr68pOGMShdiIhvY27zS9ECsh2hLNK2mOs9xmXFId0YEH2VadOvA9s5pTragJ0HxRVr6kYO8uy1p1ZBtqejPWNfp+hVR+i3xQqCxFqDRODra2SO2szA2BWuaGA3tGtPvL+uk8nMid0L8wg=="

# run(host='localhost', port=8080)
run(host='localhost', port=8080, server='cherrypy')
