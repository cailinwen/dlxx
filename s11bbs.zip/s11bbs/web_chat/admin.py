#
# from django.contrib import admin
# from  web_chat import models
# # Register your models here.
# admin.site.register(models.QQGroup)
