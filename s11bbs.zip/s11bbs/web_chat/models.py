from __future__ import unicode_literals
from web.models import UserProfile
from django.db import models

# Create your models here.
class QQGroup(models.Model):
    name = models.CharField(max_length=64,unique=True)
    description = models.CharField(max_length=255,default="nothing")
    members = models.ManyToManyField(UserProfile,blank=True)
    admins = models.ManyToManyField(UserProfile,related_name='group_admin')
    max_member_nums = models.IntegerField(default=200)
    def __unicode__(self):
        return self.name