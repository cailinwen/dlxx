codetheme
=========

**已经是最新源码**

线上地址:[http://ipic.beginman.cn/](http://ipic.beginman.cn/)

Github[https://github.com/BeginMan/codetheme](https://github.com/BeginMan/codetheme)

由于利用两周下班时间熬夜做的，难免有些粗糙，感兴趣的可以浏览浏览。(仅限于学习,有些地方不够完善,等有时间了再完善,不过基本实现社区功能.)

搭建在SAE上,到Github Clone一份直接能运行,里面包括所有需要的第三方库, 最好用virtualenv 隔离 然后把项目里面的site-packages 拷贝到 隔离环境里面去,创建配置数据库.就能直接运行了.

注：微博登录这块，由于网站还未审核，只有内测账号，就是我的weibo账号可以登录，不过也可以试试。

更多功能正在完善中……

##开发环境
Python 2.7

Django 1.5.5

Mysql 5.5

Boostrap

##功能
注册登陆

微博登陆

发帖

回帖

关注

私信

管理员发通告

发链接

修改资料

检索

等等....

##注意：
setting配置中，由于对七牛云存储进行封装，更改你的七牛云存储Key，name即可, 对微博也有封装,改成自己的key就能用了.

##预览
![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme1.png)

![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme2.png)

![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme3.png)

![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme5.png)


![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme6.png)


![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme7.png)


![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme8.png)


![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme9.png)


![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme10.png)


![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme11.png)


![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme12.png)


![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme13.png)


![](http://images.cnblogs.com/cnblogs_com/BeginMan/486940/o_theme14.png)
