#_*_coding:utf-8_*_
from __future__ import unicode_literals
from deli.deliauth import UserProfile
from django.contrib.auth.models import User
from django.db import models


# Create your models here.
