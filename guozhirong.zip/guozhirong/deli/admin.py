from django.contrib import admin
from django.contrib.auth.models import Group
from deli import models
from deli_admin import UserAdmin
# Register your models here.
admin.site.unregister(Group)
admin.site.register(models.UserProfile,UserAdmin)
