from django.db import models

# Create your models here.
from deli import models as deli



class QQGroup(models.Model):
    name = models.CharField(max_length=64)
    founder = models.ForeignKey(deli.UserProfile)
    brief = models.CharField(max_length=254,default="nothing here....")
    members = models.ManyToManyField(deli.UserProfile,blank=True,related_name='group_members')
    admins = models.ManyToManyField(deli.UserProfile,blank=True,related_name='group_admins')
    member_limit = models.IntegerField(default=200)
    def __unicode__(self):
        return  self.name
