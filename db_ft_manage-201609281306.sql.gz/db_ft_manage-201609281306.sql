-- MySQL dump 10.13  Distrib 5.5.27, for osx10.6 (i386)
--
-- Host: 10.0.10.118    Database: db_ft_manage
-- ------------------------------------------------------
-- Server version	5.5.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ft_admin_sessions`
--

DROP TABLE IF EXISTS `ft_admin_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ft_admin_sessions` (
  `id` char(32) NOT NULL DEFAULT '',
  `name` varchar(32) NOT NULL DEFAULT '',
  `modified` int(11) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `data` text,
  PRIMARY KEY (`id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ft_admin_sessions`
--

LOCK TABLES `ft_admin_sessions` WRITE;
/*!40000 ALTER TABLE `ft_admin_sessions` DISABLE KEYS */;
INSERT INTO `ft_admin_sessions` VALUES ('14ap9q0p3emle28n14qa97dnqgfi7s9a','ft_backmanage',1474962921,2419200,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1474962921.3138731;}'),('61me7ets6ephist917dtte5ievf82p47','ft_backmanage',1474329910,2419200,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1474329910.9072521;}'),('6784potgtrf5nftjj5iljhu09l4rc4qr','ft_backmanage',1473038790,1440,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1473038789.467591;}'),('8302r6t35ik9vu8l1fd93v8g73ab18o8','ft_backmanage',1474886423,2419200,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1474886421.447437;}'),('a2vhp62og3kn2gd10ukflbi03sec8gou','ft_backmanage',1472545356,1440,'__ZF|a:2:{s:20:\"_REQUEST_ACCESS_TIME\";d:1472545356.476897;s:4:\"user\";a:1:{s:6:\"EXPIRE\";i:1472552556;}}user|C:23:\"Zend\\Stdlib\\ArrayObject\":881:{a:4:{s:7:\"storage\";a:1:{s:9:\"userInfos\";s:651:\"a:11:{s:7:\"user_id\";s:1:\"1\";s:8:\"username\";s:6:\"pardus\";s:9:\"upassword\";s:60:\"$2y$10$PsYg0ILN0Urug6mrNp8PE.oTvkwQFJyZm6WuDSceNwrocSaep4oRm\";s:5:\"level\";s:1:\"1\";s:12:\"country_code\";s:2:\"CN\";s:12:\"country_name\";s:5:\"China\";s:7:\"created\";s:10:\"1432879657\";s:7:\"updated\";s:10:\"1432879657\";s:6:\"status\";s:1:\"1\";s:9:\"developer\";a:0:{}s:9:\"feat_user\";a:9:{s:7:\"user_id\";s:1:\"1\";s:8:\"username\";s:6:\"pardus\";s:9:\"upassword\";s:60:\"$2y$10$PsYg0ILN0Urug6mrNp8PE.oTvkwQFJyZm6WuDSceNwrocSaep4oRm\";s:5:\"level\";s:1:\"1\";s:12:\"country_code\";s:2:\"CN\";s:12:\"country_name\";s:5:\"China\";s:7:\"created\";s:10:\"1432879657\";s:7:\"updated\";s:10:\"1432879657\";s:6:\"status\";s:1:\"1\";}}\";}s:4:\"flag\";i:2;s:13:\"iteratorClass\";s:13:\"ArrayIterator\";s:19:\"protectedProperties\";a:4:{i:0;s:7:\"storage\";i:1;s:4:\"flag\";i:2;s:13:\"iteratorClass\";i:3;s:19:\"protectedProperties\";}}}'),('bo97c3np0tfknnqouidm0u35i6nvjnst','ft_backmanage',1472545108,1440,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1472545107.5318301;}'),('i957b3ek6buts5hcveb5jrj2u02ic11k','ft_backmanage',1473226594,2419200,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1473226590.177532;}'),('ldcfehdstk6faku4ugijqqppn3tph4gi','ft_backmanage',1472693245,1440,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1472693211.2598;}'),('li5ttip9l5fffqgouonr8ir61hf12d1t','ft_backmanage',1472635510,1440,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1472635505.393342;}'),('nnijh2lb83gdutcu47vpfb3n9b678949','ft_backmanage',1472642508,1440,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1472642505.7378969;}'),('q9vu3resrsp4m5f0e3l5rldjmhnbdkun','ft_backmanage',1474263505,2419200,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1474263500.66028;}'),('qqj5cgst27vcfug415ihlc3v2f4qd3r2','ft_backmanage',1475023362,2419200,'__ZF|a:2:{s:20:\"_REQUEST_ACCESS_TIME\";d:1475023362.1442599;s:4:\"user\";a:1:{s:6:\"EXPIRE\";i:1475030562;}}user|C:23:\"Zend\\Stdlib\\ArrayObject\":881:{a:4:{s:7:\"storage\";a:1:{s:9:\"userInfos\";s:651:\"a:11:{s:7:\"user_id\";s:1:\"1\";s:8:\"username\";s:6:\"pardus\";s:9:\"upassword\";s:60:\"$2y$10$PsYg0ILN0Urug6mrNp8PE.oTvkwQFJyZm6WuDSceNwrocSaep4oRm\";s:5:\"level\";s:1:\"1\";s:12:\"country_code\";s:2:\"CN\";s:12:\"country_name\";s:5:\"China\";s:7:\"created\";s:10:\"1432879657\";s:7:\"updated\";s:10:\"1432879657\";s:6:\"status\";s:1:\"1\";s:9:\"developer\";a:0:{}s:9:\"feat_user\";a:9:{s:7:\"user_id\";s:1:\"1\";s:8:\"username\";s:6:\"pardus\";s:9:\"upassword\";s:60:\"$2y$10$PsYg0ILN0Urug6mrNp8PE.oTvkwQFJyZm6WuDSceNwrocSaep4oRm\";s:5:\"level\";s:1:\"1\";s:12:\"country_code\";s:2:\"CN\";s:12:\"country_name\";s:5:\"China\";s:7:\"created\";s:10:\"1432879657\";s:7:\"updated\";s:10:\"1432879657\";s:6:\"status\";s:1:\"1\";}}\";}s:4:\"flag\";i:2;s:13:\"iteratorClass\";s:13:\"ArrayIterator\";s:19:\"protectedProperties\";a:4:{i:0;s:7:\"storage\";i:1;s:4:\"flag\";i:2;s:13:\"iteratorClass\";i:3;s:19:\"protectedProperties\";}}}'),('t4h1j7giith85ag8ta74itrcs21t385j','ft_backmanage',1473065404,2419200,'__ZF|a:1:{s:20:\"_REQUEST_ACCESS_TIME\";d:1473065402.9774649;}'),('troe03jbvlc949v8fslp0ek879bqun0u','ft_backmanage',1473045799,2419200,'__ZF|a:2:{s:20:\"_REQUEST_ACCESS_TIME\";d:1473045799.3085279;s:4:\"user\";a:1:{s:6:\"EXPIRE\";i:1473052999;}}user|C:23:\"Zend\\Stdlib\\ArrayObject\":881:{a:4:{s:7:\"storage\";a:1:{s:9:\"userInfos\";s:651:\"a:11:{s:7:\"user_id\";s:1:\"1\";s:8:\"username\";s:6:\"pardus\";s:9:\"upassword\";s:60:\"$2y$10$PsYg0ILN0Urug6mrNp8PE.oTvkwQFJyZm6WuDSceNwrocSaep4oRm\";s:5:\"level\";s:1:\"1\";s:12:\"country_code\";s:2:\"CN\";s:12:\"country_name\";s:5:\"China\";s:7:\"created\";s:10:\"1432879657\";s:7:\"updated\";s:10:\"1432879657\";s:6:\"status\";s:1:\"1\";s:9:\"developer\";a:0:{}s:9:\"feat_user\";a:9:{s:7:\"user_id\";s:1:\"1\";s:8:\"username\";s:6:\"pardus\";s:9:\"upassword\";s:60:\"$2y$10$PsYg0ILN0Urug6mrNp8PE.oTvkwQFJyZm6WuDSceNwrocSaep4oRm\";s:5:\"level\";s:1:\"1\";s:12:\"country_code\";s:2:\"CN\";s:12:\"country_name\";s:5:\"China\";s:7:\"created\";s:10:\"1432879657\";s:7:\"updated\";s:10:\"1432879657\";s:6:\"status\";s:1:\"1\";}}\";}s:4:\"flag\";i:2;s:13:\"iteratorClass\";s:13:\"ArrayIterator\";s:19:\"protectedProperties\";a:4:{i:0;s:7:\"storage\";i:1;s:4:\"flag\";i:2;s:13:\"iteratorClass\";i:3;s:19:\"protectedProperties\";}}}');
/*!40000 ALTER TABLE `ft_admin_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ft_admin_users`
--

DROP TABLE IF EXISTS `ft_admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ft_admin_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `upassword` varchar(255) NOT NULL,
  `level` tinyint(1) NOT NULL COMMENT '级别。1超级管理员，2、账号管理员,3category模块管理员',
  `country_code` char(2) NOT NULL DEFAULT 'CN',
  `country_name` varchar(50) NOT NULL DEFAULT 'China',
  `created` int(11) NOT NULL DEFAULT '0',
  `updated` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ft_admin_users`
--

LOCK TABLES `ft_admin_users` WRITE;
/*!40000 ALTER TABLE `ft_admin_users` DISABLE KEYS */;
INSERT INTO `ft_admin_users` VALUES (1,'pardus','$2y$10$PsYg0ILN0Urug6mrNp8PE.oTvkwQFJyZm6WuDSceNwrocSaep4oRm',1,'CN','China',1432879657,1432879657,1),(2,'lily','$2y$10$Pvn4zcuA2/SeO46qQZtUvOT0eyrCw.k2rXmhlQYRso8jo8P0pekSm',3,'CN','China',1450323736,1450323736,1);
/*!40000 ALTER TABLE `ft_admin_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-28 13:07:17
