# encoding: utf-8
'''
Created on 2016年4月17日

@author: sunchenlan
'''
import urllib2
import urllib
import ssl
import hashlib
import base64
import os
import json
import shutil
import logging
import rsa
from pyasn1.codec.der import decoder

from OpenSSL import crypto
from SDKConfig import SDKConfig
from CertUtil import CertUtil
from sm3 import sm3


def post(url, content):
    logging.info("post url:["+url+"]")
    logging.info("post content:["+content+"]")
    content = content.encode(SDKConfig().encoding)
    req = urllib2.Request(url = url,data = content)
    if SDKConfig().ifValidateRemoteCert.lower() == "false":
        ssl._create_default_https_context = ssl._create_unverified_context
    res_data = urllib2.urlopen(req)
    result = res_data.read()
    logging.info("resp:["+result+"]")
    return result


def createLinkString(para, sort, encode):
    linkString = ""
    keys = para.keys()
    if (sort):
        keys = sorted(keys)
    for key in keys:
        value = para[key]
#         print(key + ":" + value)
        if encode:
            value = urllib.quote(value)
        # print(str(type(key))+":"+str(type(value))+":"+str(key)+":"+str(value))
        linkString = linkString + key + "=" + value + "&"
    linkString = linkString[:-1]
#    print (linkString)
    return linkString


def filterNoneValue(para):
    keys = para.keys()
    for key in keys:
        value = para[key]
        if value is None or value == "":
            para.pop(key)

def buildSignature(req, signCertPath=SDKConfig().signCertPath, signCertPwd=SDKConfig().signCertPwd, secureKey=SDKConfig().secureKey):

    filterNoneValue(req)

    if "signMethod" not in req:
        logging.error("signMethod must not null")
        return None

    if "version" not in req:
        logging.error("version must not null")
        return None


    if "01" == req["signMethod"]:
        req["certId"] = CertUtil.getSignCertId(signCertPath, signCertPwd)
        logging.info("=== start to sign ===")
        prestr = createLinkString(req, True, False)
        logging.info("sorted: [" + prestr + "]")
        if "5.0.0" == req["version"]:
            prestr = sha1(prestr)
            logging.info("sha1: [" + prestr + "]")
            logging.info("sign cert: [" + signCertPath + "], pwd: [" + signCertPwd + "]")
            key = CertUtil.getSignPriKey(signCertPath, signCertPwd)
            signature = base64.b64encode(crypto.sign(key, prestr.encode(SDKConfig().encoding), 'sha1'))
            logging.info("signature: [" + signature + "]")
        else:
            prestr = sha256(prestr)
            logging.info("sha256: [" + prestr + "]")
            logging.info("sign cert: [" + signCertPath + "], pwd: [" + signCertPwd + "]")
            key = CertUtil.getSignPriKey(signCertPath, signCertPwd)
            signature = base64.b64encode(crypto.sign(key, prestr.encode(SDKConfig().encoding), 'sha256'))
            logging.info("signature: [" + signature + "]")
    elif "11" == req["signMethod"]:
        logging.info("=== start to sign ===")
        prestr = createLinkString(req, True, False)
        logging.info("sorted: [" + prestr + "]")
        if secureKey is None:
            logging.error("secureKey must not null")
            return None
        prestr = prestr + "&" + sha256(secureKey)
        logging.debug("before final sha256: [" + prestr + "]")
        signature = sha256(prestr)
        logging.info("signature: [" + signature + "]")
    elif "12" == req["signMethod"]:
        # logging.info("=== start to sign ===")
        # prestr = createLinkString(req, True, False)
        # logging.info("sorted: [" + prestr + "]")
        # if secureKey is None:
        #     logging.error("secureKey must not null")
        #     return None
        # prestr = prestr + "&" + sm3(secureKey)
        # logging.debug("before final sm3: [" + prestr + "]")
        # signature = sm3(prestr)
        # logging.info("signature: [" + signature + "]")
        logging.error("sm3算法暂未实现，请勿使用。")
        return None
    else:
        logging.info("invalid signMethod: [" + req["signMethod"] + "]")
    logging.info("=== end of sign ===")
    req["signature"] = signature
    return signature


def paraFilter(para):
    result = {}
    for key in para.keys():
        if (key == "signature" or para[key] == ""):
            continue
        else:
            result[key] = para[key]
    return result
 

def sha1(data):
    return hashlib.sha1(data).hexdigest()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def putKeyValueToMap(temp, isKey, key, m):
    if isKey:
        m[str(key)] = ""
    else:
        m[str(key)] =  temp


def parseQString(respString):
    resp = {}
    temp = ""
    key = ""
    isKey = True
    isOpen = False;
    openName = "\0";

    for curChar in respString : #遍历整个带解析的字符串
        if(isOpen):
            if(curChar == openName):
                isOpen = False
            temp = temp + curChar
        elif(curChar == "{"):
            isOpen = True
            openName = "}"
            temp = temp + curChar
        elif(curChar == "["):
            isOpen = True
            openName = "]"
            temp = temp + curChar
        elif(isKey and curChar == "="):
            key = temp
            temp = ""
            isKey = False
        elif(curChar == "&" and not isOpen) : # 如果读取到&分割符
            putKeyValueToMap(temp, isKey, key, resp)
            temp = ""
            isKey = True
        else :
            temp = temp + curChar
            
    putKeyValueToMap(temp, isKey, key, resp)
    return resp


def verify(resp):

    if "signMethod" not in resp:
        logging.error("signMethod must not null")
        return None

    if "version" not in resp:
        logging.error("version must not null")
        return None

    if "signature" not in resp:
        logging.error("signature must not null")
        return None

    signMethod = resp["signMethod"]
    version = resp["version"]
    result = False

    if "01" == signMethod:
        logging.info("=== start to verify signature ===")
        if "5.0.0" == version:
            signature = resp.pop("signature")
            logging.info("signature: [" + signature+ "]")
            prestr = createLinkString(resp, True, False)
            logging.info("sorted: [" + prestr + "]")
            prestr = sha1(prestr)
            logging.info("sha1: [" + prestr + "]")
            cert = CertUtil.getVerifyCertFromPath(resp["certId"])
            if cert is None:
                logging.info("no cert was found by certId: " + resp["certId"])
                result = False
            else:
                signature = base64.b64decode(signature)
                try:
                    crypto.verify(cert, signature, prestr, 'sha1')
                    result = True
                except Exception:
                    result = False
        else:
            signature = resp.pop("signature")
            logging.info("signature: [" + signature + "]")
            prestr = createLinkString(resp, True, False)
            logging.info("sorted: [" + prestr + "]")
            prestr = sha256(prestr)
            logging.info("sha256: [" + prestr + "]")
            cert = CertUtil.verifyAndGetVerifyCert(resp["signPubKeyCert"])
            if cert is None:
                logging.info("no cert was found by signPubKeyCert: " + resp["signPubKeyCert"])
                result = False
            else:
                signature = base64.b64decode(signature)
                try:
                    crypto.verify(cert, signature, prestr, 'sha256')
                    result = True
                except Exception:
                    result = False
        logging.info("verify signature " + "succeed" if result else "fail")
        logging.info("=== end of verify signature ===")
        return result
    elif "11" == signMethod or "12" == signMethod:
        return verifyBySecureKey(resp, SDKConfig().secureKey)
    else:
        logging.info("Error signMethod [" + signMethod + "] in validate. ")
        return False


def verifyBySecureKey(resp, secureKey):

    if "signMethod" not in resp:
        logging.error("signMethod must not null")
        return None

    if "signature" not in resp:
        logging.error("signature must not null")
        return None

    signMethod = resp["signMethod"]
    result = False

    logging.info("=== start to verify signature ===")
    if "11" == signMethod:
        signature = resp.pop("signature")
        logging.info("signature: [" + signature+ "]")
        prestr = createLinkString(resp, True, False)
        logging.info("sorted: [" + prestr + "]")
        beforeSha256 = prestr + "&" + sha256(secureKey)
        logging.debug("before final sha256: [" + beforeSha256 + "]")
        afterSha256 = sha256(beforeSha256)
        result = afterSha256 == signature
        if not result:
            logging.debug("after final sha256: [" + afterSha256 + "]")
    elif "12" == signMethod:
        signature = resp.pop("signature")
        logging.info("signature: [" + signature+ "]")
        prestr = createLinkString(resp, True, False)
        logging.info("sorted: [" + prestr + "]")
        beforeSm3 = prestr + "&" + sm3(secureKey)
        logging.debug("before final sm3: [" + beforeSm3 + "]")
        afterSm3 = sm3(beforeSm3)
        result = afterSm3 == signature
        if not result:
            logging.debug("after final sha256: [" + afterSm3 + "]")
    logging.info("verify signature " + "succeed" if result else "fail")
    logging.info("=== end of verify signature ===")
    return result


def verifyAppResponse(jsonData):
    data = json.loads(jsonData)
    sign = data["sign"]
    data = data["data"]
    dataMap = parseQString(data)
    vCert = CertUtil.getVerifyCertFromPath(dataMap["cert_id"])
    signature = base64.b64decode(sign)
    return crypto.verify(vCert, signature, sha1(data), 'sha1')


def createAutoFormHtml(params, reqUrl):
    result = "<html>\
<head>\
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=" + SDKConfig().encoding + "\" />\
</head>\
<body onload=\"javascript:document.pay_form.submit();\">\
    <form id=\"pay_form\" name=\"pay_form\" action=\"" + reqUrl + "\" method=\"post\">"
    for key, value in params.iteritems():
        result = result + "    <input type=\"hidden\" name=\"" + key + "\" id=\"" + key +"\" value=\""+ value +"\" />\n";
    result = result + "<!-- <input type=\"submit\" type=\"hidden\">-->\
    </form>\
</body>\
</html>"
    logging.info("auto post html:" + result)
    return result


def encryptPub(data, certPath=SDKConfig().encryptCertPath):
    rsaKey = CertUtil.getEncryptKey(certPath)
    result = rsa.encrypt( data, rsaKey)
    result = base64.b64encode(result)
    return result


def decryptPri(data, certPath=SDKConfig().signCertPath, certPwd=SDKConfig().signCertPwd):
    pkey = CertUtil.getDecryptPriKey(certPath, certPwd)
    data = base64.b64decode(data)
    result = rsa.decrypt(data, pkey)
    return result


def deCodeFileContent(params, fileDirectory):
    if not params.has_key("fileContent"):
        return False
    logging.info("---------处理后台报文返回的文件---------")
    fileContent = params["fileContent"]
    if not fileContent:
        logging.info("文件内容为空")
        return False
    fileContent = base64.b64decode(fileContent).decode('zlib') #python3: zlib.decompress(data)
    filePath = "";
    if not params.has_key("fileName"):
        logging.info("文件名为空")
        filePath = fileDirectory + params["merId"] + "_" + params["batchNo"] + "_" + params["txnTime"] + ".txt"
    else:
        filePath = fileDirectory + params ['fileName']
    output = open(filePath, 'wb')
    output.write(fileContent)
    logging.info("文件位置 >:" + filePath)
    output.close()
    return True


def enCodeFileContent(path):
    file = open(path, "rb")
    fileContent = file.read()
    file.close()
    fileContent = fileContent.encode('zlib')
    fileContent = base64.b64encode(fileContent)
    return fileContent

def getEncryptCert(params):
    if "encryptPubKeyCert" not in params or "certType" not in params:
        logging.error("encryptPubKeyCert or certType is null")
        return -1
    strCert = params["encryptPubKeyCert"];
    certType = params["certType"];

    x509Cert = crypto.load_certificate(crypto.FILETYPE_PEM, strCert)
    if "01" == certType:
        # 更新敏感信息加密公钥
        if str(x509Cert.get_serial_number()) == CertUtil.getEncryptCertId():
            return 0;
        else:
            localCertPath = SDKConfig().encryptCertPath
            newLocalCertPath = genBackupName(localCertPath)
            # 将本地证书进行备份存储
            try:
                shutil.move(localCertPath, newLocalCertPath)
            except Exception as e:
                logging.error("备份旧加密证书失败。" + e)
                return -1
            # 备份成功,进行新证书的存储
            try:
                f = file(localCertPath, "w+")
                f.write(strCert)
                f.close()
            except Exception as e:
                logging.error("写入新加密证书失败。" + e)
                return -1

            logging.info("save new encryptPubKeyCert success");
            CertUtil.resetEncryptCertPublicKey();
            return 1;
    elif "02" == certType:
        return 0;
    else:
        logging.error("unknown cerType:"+certType)
        return -1

def genBackupName(fileName):
    i = fileName.rfind(".")
    leftFileName = fileName[0 : i]
    rightFileName = fileName[i + 1 : ]
    newFileName = leftFileName + "_backup" + "." + rightFileName
    return newFileName

# def testDecryptPri():
#     data="BxqNdggaUsjTf8BEDCLvUy/SdjhC5w49rrZ0lMvQbB4qXjcTnskImSxY8y1SbhI6lKZKbFKPhT8B2rFNuRduDSglhLA/yvUUy7eTndBhELOtgxUL0Oddbw/cWD3HM8UIgvMc4300H2SJDJnWacjSqLbt5aedV9Ar2GefxUhJN/UNnz6thbWsQGwjNL1+zMYf0ePC+M7qYVToPkKXxeoNaEj1Y3ibQYHsnIx3mXUhDPN1rink/AjAbeNkTXCOtPGjksKAtD52s9D0DVeSCFH8iA2cye/0MRodSDERpObldnRoksZBeQ5p3qx0i++T57706TRAdk0vwcsaYiNeYc+Qew=="
#     print(decryptPri(data))
#
# def testPost():
#     url = " https://101.231.204.80:5000/gateway/api/queryTrans.do"
#     data = "version=5.0.0&encoding=utf-8&signMethod=01&txnType=00&txnSubType=00&bizType=000000&accessType=0&channelType=07&orderId=20160417090108&merId=777290058110097&txnTime=20160417090108&certId=68759663125&signature=Hyz31eHxPhXnXWSsquV1p%2FI%2BtD4pM9A5OQkPw4xO7Ntrb58eP8xdIMLvtaj%2BeqywBuw7g6w49RoukrQIStYzZ43pQanw5%2F%2F3xzmnn50PiJPYTbxCXd6by1Ct5QVpVbYRdF12ioJvxgoEPhT9kfdQ8lrOikFlInyDR3DTsVInng73lZqVpiFq21Eky0b0M46BiV94vnAtiCpZjpuD%2BycSsmljRgBUvAbrpuS6G7qZCDlRBCeXB%2B4y7%2BoWo%2F07ZFcB0pCqzxUaG822Om49m54%2B86ywUzig8mDGBZ0LbTrwvZV22zE9wlKglQkAH4iL2aZeLqL%2BY4yoaE9rFiKModfuoA%3D%3D"
#     print(post(url,data))
#  
# def testBuildSignature():
#     a = {"transType":"01", "sysReserved":"{aaa=a&bbb=b}", "merId":"888888888888888"}
#     print(buildSignature(a, "d:/certs/acp_test_sign.pfx", "000000"))
# 
# def testCreateLinkString():
#     a = {"transType":"01", "sysReserved":"{aaa=a&bbb=b}", "merId":"888888888888888"}
#     print(createLinkString(a, True, True))
#     print(createLinkString(a, False, True))
#     print(createLinkString(a, True, False))
# 
# def testParaFilter():
#     a = {"signature":"111", "transType":"01", "sysReserved":"{aaa=a&bbb=b}", "merId":"888888888888888"}
#     print(paraFilter(a))
#  
# def testParseQString():
#     respString = "accessType=0&bizType=000000&certId=68759585097&encoding=utf-8&merId=777290058110097&orderId=20160417104527&respCode=34&respMsg=查无此交易[2600000]&signMethod=01&txnSubType=00&txnTime=20160417104527&txnType=00&version=5.0.0&signature=PZ+yd0zaI8EChNs+SjRZVyoVDK3ZaRhEV4NK7fHk1gmAlCezvM1RZBNwFOsux/JWFSgxSEclh6vvfqlCKjr+WC/J7Xg6GW0poDwjJE5SjAREP4zAw8/DjVWn+OqBxPX+d3WSURnmOWdq7tr8k2aigsM+o+nsmuBaWWDvvMRI7ayAhFuG/kyrEL40nlfMnCD5W9tEeK6E27IrZk+wTqN8aP/jxLZq2JYBRYIJr8kWAV3xtnB2XmulyCOqDPPtGRwGUKUk9hM609L66ceITQkbfe5nlWaTmvqWBTrhICGnYA8xfhuXOM/jcPWi+VY+Jar40+q7as4D3qZqcKkyF+6ZzA=="
#     resp = parseQString(respString)
#     print(resp)
#
# def testVerify():
#     a = {"certId":"68759585097","signature":"vgEL+lPX394JTxHHlcLgC/bcwMKumwb9jjsR0EE+apQm4Jcq16x65eAei2MMUZfxvTkviYupOyAEkC/97btz1/Vi9PeTAyX4AModdDXvFVmnvSu91Aen2IJzv8Q0D6wpULkAPTKU5uqxzQne7P2G/LkXFA76Jqvmln8ZwwpR9D5JvWDHj7IApq5VJkGjVwJoyOpM3qTvcP9oUr8FVgGp4mL04jxi04spJnjAVdZK5gX4Hki3eEnM4J08TDFPUcOLl7iwOgGy59C7TQhIjch0Bgz2NYykGroRsbNXXNqkYkDKlncQ9ZfADAfDtdSaE+fpBjm8NO/WUcg5L0iRP8jqlg==", "transType":"01", "sysReserved":"{aaa=a&bbb=b}", "merId":"888888888888888"}
#     print(verify(a))
# testVerify()
