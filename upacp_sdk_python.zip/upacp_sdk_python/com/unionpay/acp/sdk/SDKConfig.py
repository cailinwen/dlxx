# encoding: utf-8
import ConfigParser
import logging
import os
'''
Created on 2016年8月2日

@author: sunchenlan
'''


class Singleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


class SDKConfig(object):

    __metaclass__ = Singleton

    def __init__(self):
        '''
        Constructor
        '''

        cf = ConfigParser.ConfigParser()
        path = os.path.split(os.path.realpath(__file__))[0]
        print("load conf: " + path + "/acp_sdk.ini")
        cf.read(path + "/acp_sdk.ini")
        self.frontTransUrl = cf.get("acpsdk", "acpsdk.frontTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.frontTransUrl") else None
        self.singleQueryUrl = cf.get("acpsdk", "acpsdk.singleQueryUrl").strip() if cf.has_option("acpsdk", "acpsdk.singleQueryUrl") else None
        self.backTransUrl = cf.get("acpsdk", "acpsdk.backTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.backTransUrl") else None
        self.batchTransUrl = cf.get("acpsdk", "acpsdk.batchTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.batchTransUrl") else None
        self.fileTransUrl = cf.get("acpsdk", "acpsdk.fileTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.fileTransUrl") else None
        self.appTransUrl = cf.get("acpsdk", "acpsdk.appTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.appTransUrl") else None
        self.cardTransUrl = cf.get("acpsdk", "acpsdk.cardTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.cardTransUrl") else None

        self.jfFrontTransUrl = cf.get("acpsdk", "acpsdk.jfFrontTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.jfFrontTransUrl") else None
        self.jfBackTransUrl = cf.get("acpsdk", "acpsdk.jfBackTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.jfFrontTransUrl") else None
        self.jfSingleQueryUrl = cf.get("acpsdk", "acpsdk.jfSingleQueryUrl").strip() if cf.has_option("acpsdk", "acpsdk.jfFrontTransUrl") else None
        self.jfCardTransUrl = cf.get("acpsdk", "acpsdk.jfCardTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.jfFrontTransUrl") else None
        self.jfAppTransUrl = cf.get("acpsdk", "acpsdk.jfAppTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.jfFrontTransUrl") else None

        self.qrcBackTransUrl = cf.get("acpsdk", "acpsdk.qrcBackTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.qrcBackTransUrl") else None
        self.qrcB2cIssBackTransUrl = cf.get("acpsdk", "acpsdk.qrcB2cIssBackTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.qrcB2cIssBackTransUrl") else None
        self.qrcB2cMerBackTransUrl = cf.get("acpsdk", "acpsdk.qrcB2cMerBackTransUrl").strip() if cf.has_option("acpsdk", "acpsdk.qrcB2cMerBackTransUrl") else None

        self.signMethod = cf.get("acpsdk", "acpsdk.signMethod").strip() if cf.has_option("acpsdk", "acpsdk.signMethod") else None
        self.version = cf.get("acpsdk", "acpsdk.version").strip() if cf.has_option("acpsdk", "acpsdk.version") else "5.0.0"

        self.ifValidateCNName = cf.get("acpsdk", "acpsdk.ifValidateCNName").strip() if cf.has_option("acpsdk", "acpsdk.ifValidateCNName") else "true"
        self.ifValidateRemoteCert = cf.get("acpsdk", "acpsdk.ifValidateRemoteCert").strip() if cf.has_option("acpsdk", "acpsdk.ifValidateRemoteCert") else "false"

        self.signCertPath = cf.get("acpsdk", "acpsdk.signCert.path").strip() if cf.has_option("acpsdk", "acpsdk.signCert.path") else None
        self.signCertPwd = cf.get("acpsdk", "acpsdk.signCert.pwd").strip() if cf.has_option("acpsdk", "acpsdk.signCert.pwd")else None

        self.validateCertDir = cf.get("acpsdk", "acpsdk.validateCert.dir").strip() if cf.has_option("acpsdk", "acpsdk.validateCert.dir") else None
        self.encryptCertPath = cf.get("acpsdk", "acpsdk.encryptCert.path").strip() if cf.has_option("acpsdk", "acpsdk.encryptCert.path") else None
        self.rootCertPath = cf.get("acpsdk", "acpsdk.rootCert.path").strip() if cf.has_option("acpsdk", "acpsdk.rootCert.path") else None
        self.middleCertPath = cf.get("acpsdk", "acpsdk.middleCert.path").strip() if cf.has_option("acpsdk", "acpsdk.middleCert.path") else None

        self.frontUrl = cf.get("acpsdk", "acpsdk.frontUrl").strip() if cf.has_option("acpsdk", "acpsdk.frontUrl") else None
        self.backUrl = cf.get("acpsdk", "acpsdk.backUrl").strip() if cf.has_option("acpsdk", "acpsdk.backUrl") else None

        self.encoding = cf.get("acpsdk", "acpsdk.encoding").strip() if cf.has_option("acpsdk", "acpsdk.encoding") else "utf-8"
        self.secureKey = cf.get("acpsdk", "acpsdk.secureKey").strip() if cf.has_option("acpsdk", "acpsdk.secureKey") else None

        logFilePath = cf.get("acpsdk", "acpsdk.log.file.path").strip() if cf.has_option("acpsdk", "acpsdk.log.file.path") else None
        logLevel = cf.get("acpsdk", "acpsdk.log.level").strip() if cf.has_option("acpsdk", "acpsdk.log.level") else "INFO"

        self.setLogging(logLevel, logFilePath);

    def __setattr__(self, attr, value):
        if hasattr(self, attr):
            raise Exception("Attempting to alter read-only value")

        self.__dict__[attr] = value

    def setLogging(self, logLevel, logFilePath):

        if logLevel is None:
            print "LogLevel is not set. Exit setLogging.";

        if logging.getLogger().handlers:
            print "Logging is already set. Exit setLogging.";

        print "print log to " + logFilePath;
        if "INFO" == logLevel.upper():
            level = logging.INFO
        elif "DEBUG" == logLevel.upper():
            level = logging.DEBUG
        elif "WARN" == logLevel.upper():
            level = logging.WARN
        elif "ERROR" == logLevel.upper():
            level = logging.ERROR
        elif "FATAL" == logLevel.upper():
            level = logging.FATAL
        else:
            level = logging.NOTSET

        logfmt = "%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s"
        if logFilePath is not None:
            logging.basicConfig(level=level, filename=logFilePath, format=logfmt)
        else:
            logging.basicConfig(level=level, format=logfmt)



